"""Restore a focused Surface source snapshot from its verified primary source."""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat


PACKET = Path(__file__).resolve().parent
SKIP = {".git", "target", "artifacts"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def source_entries(root):
    entries = {}
    for directory, dirs, files in os.walk(root):
        dirs[:] = [name for name in dirs if name not in SKIP]
        parent = Path(directory)
        for name in files + [name for name in dirs if (parent / name).is_symlink()]:
            if name in SKIP:
                continue
            path = parent / name
            if path.is_symlink():
                mode, data = "symlink", os.readlink(path).encode()
            else:
                mode = path.stat().st_mode
                if not stat.S_ISREG(mode):
                    raise ValueError(f"Invalid source file type in {path.relative_to(root)}")
                mode, data = f"{mode & 0o111:o}", path.read_bytes()
            entries[path.relative_to(root).as_posix()] = [mode, digest(data)]
    return entries


def receipt(entries):
    content = "".join(
        f"{mode}  {sha}  {name}\n" for name, (mode, sha) in sorted(entries.items())
    )
    return len(entries), digest(content.encode())


def checked_overlay(variant, source):
    updates = []
    for change in variant["changes"]:
        relative = PurePosixPath(change["path"])
        if relative.is_absolute() or any(part in SKIP | {".", ".."} for part in relative.parts):
            raise ValueError(f"Invalid source path {relative}")
        if source.get(relative.as_posix()) != change["before"]:
            raise ValueError(f"Unexpected primary file {relative}")
        mode, sha = change["after"]
        if (
            not re.fullmatch(r"[0-7]{1,3}", mode)
            or int(mode, 8) & ~0o111
            or not re.fullmatch(r"[0-9a-f]{64}", sha)
        ):
            raise ValueError(f"Invalid blob record for {relative}")
        data = (PACKET / "blobs" / sha).read_bytes()
        if digest(data) != sha:
            raise ValueError(f"Blob checksum differs for {relative}")
        updates.append((relative, int(mode, 8), data))
    return updates


def main():
    variants = json.loads((PACKET / "manifest.json").read_text())["overlays"]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("overlay", choices=sorted(variants))
    parser.add_argument("primary", type=Path, help="restored primary source from the evidence link")
    parser.add_argument("output", type=Path, help="new output folder")
    args = parser.parse_args()

    variant = variants[args.overlay]
    primary = args.primary.resolve(strict=True)
    output = args.output.resolve()
    if not primary.is_dir() or output.exists() or output.is_relative_to(primary):
        parser.error("Use a verified primary directory and a new output folder outside it.")

    original = source_entries(primary)
    expected_primary = (variant["primary_files"], variant["primary_manifest_sha256"])
    if receipt(original) != expected_primary:
        raise ValueError(f"Primary source differs. Restore it via {variant['primary_replay']}")
    updates = checked_overlay(variant, original)
    shutil.copytree(primary, output, symlinks=True, ignore=shutil.ignore_patterns(*SKIP))
    for relative, mode, data in updates:
        destination = output / relative
        if destination.is_symlink() or not destination.resolve().is_relative_to(output):
            raise ValueError(f"Symlink escapes the output: {relative}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        destination.chmod(0o644 | mode)

    actual = receipt(source_entries(output))
    expected = (variant["focused_files"], variant["focused_manifest_sha256"])
    if actual != expected:
        raise ValueError(f"Focused source differs for {args.overlay}: {actual}")
    print(f"{args.overlay}: verified {actual[0]} files, source SHA-256 {actual[1]}")


if __name__ == "__main__":
    main()
