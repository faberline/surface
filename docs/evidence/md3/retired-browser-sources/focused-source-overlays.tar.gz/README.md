# Retired Surface browser test source

This packet preserves the exact source of ten focused browser test
snapshots. It contains 76 path changes in 59 distinct UTF-8 source
blobs. Each snapshot starts from one of eight published primary
source trees at the revision below.

[Published Material 3 evidence](https://github.com/faberline/surface/tree/5204847292f6cf6c50eb39d834324ca5dcfb2a8b/docs/evidence/md3)

The recorded Git head in the old snapshots was
`e9ada81387dc686b9a5257348e7e50c2410942e4`. Their worktree files include
the changes from the corresponding published primary source. The local
audit found zero staged differences and zero unique local refs in all
18 repositories.

## Restore a snapshot

1. Run `shasum -a 256 -c SHA256SUMS` from this folder.
2. Select a record in `manifest.json` and follow its `primary_replay`
   link to restore the matching primary source.
3. Run the following command with Python 3.9 or later.

```sh
python3 restore.py chrome-search-view-focused-src \
    /tmp/restored-primary-source /tmp/restored-search-view-focused
```

The output path must be new. The script verifies the complete primary
manifest, copies the primary source, and applies the selected changes.
It checks every source path, file byte, symlink target, and executable
mask in the result. The [local replay receipt](verification.txt) records
the expected file count and SHA-256 for each snapshot.

The source manifest uses the published recovery method. It sorts
relative paths and hashes the sequence of executable masks and
individual file hashes. Source files under `.git`, `target`, and
`artifacts` are outside the manifest. Only Rust source, Markdown and
JSON from the focused variants are in the blob directory.
