#!/usr/bin/env bash
set -euo pipefail

if [[ $# != 2 || ! -d "$1" ]]; then
    echo 'Usage: build-and-run.sh VERIFIED_SURFACE_CHECKOUT NEW_ARTIFACT_DIRECTORY' >&2
    exit 2
fi

snapshot=$(cd "$1" && pwd -P)
evidence=$(cd "$(dirname "$0")" && pwd -P)
output=$2
scratch=$(mktemp -d /tmp/surface-md3-modal-rail-replay.XXXXXXXX)
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
export CARGO_BUILD_JOBS=2
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/tmp/cargo-target/surface-$(basename "$scratch")}"
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
case "$CARGO_TARGET_DIR" in
    /tmp/cargo-target/*) ;;
    *) echo 'CARGO_TARGET_DIR must be under /tmp/cargo-target' >&2; exit 2 ;;
esac

mkdir "$scratch/source"
rsync -a --exclude .git --exclude target --exclude artifacts "$snapshot/" "$scratch/source/"
(
    cd "$scratch/source"
    shasum -a 256 -c "$evidence/material-adaptive-final-source.sha256"
    shasum -a 256 -c "$evidence/gallery-source.sha256"
    mkdir -p examples/material-gallery/examples
    cp "$evidence/public_screenshot_gallery.rs" examples/material-gallery/examples/
    cap cargo build --locked -p surface-material-gallery \
        --features surface-material-gallery/devtools,surface-platform/macos-accessibility \
        --example public_screenshot_gallery -p surface-devtools --bin surface-devtools
    shasum -a 256 -c "$evidence/material-adaptive-final-source.sha256"
    shasum -a 256 -c "$evidence/gallery-source.sha256"
)
swiftc -module-cache-path "$scratch/swift-cache" \
    "$evidence/read-modal-gallery-ax.swift" -o "$scratch/read-modal-gallery-ax"
mkdir "$scratch/binaries"
cp "$CARGO_TARGET_DIR/debug/examples/public_screenshot_gallery" \
    "$CARGO_TARGET_DIR/debug/surface-devtools" "$scratch/binaries/"
python3 -B "$evidence/verify-modal-wide-rail.py" \
    --gallery "$scratch/binaries/public_screenshot_gallery" \
    --cli "$scratch/binaries/surface-devtools" \
    --ax-reader "$scratch/read-modal-gallery-ax" --artifacts "$output"
