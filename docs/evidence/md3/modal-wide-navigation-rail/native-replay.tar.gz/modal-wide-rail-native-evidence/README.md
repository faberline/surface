# Native Modal Wide Navigation Rail verification

This packet records a production Surface Gallery run on macOS 27.2.1 (26B131), Apple M1 Max, Rust 1.96.1. The separate example launcher sets window dimensions through public `surface_platform::Options`. It starts the stock Gallery. The native Metal renderer, DevTools transport, CLI and MCP come from the product source. All input uses public `Action.activate` and `Action.key` requests. The Swift collector only reads the spawned Gallery's AppKit data.

## Replay

Use the canonical restored Modal Wide Navigation Rail source on an active macOS desktop with Metal. Cap and Xcode command line tools are required. The replay checks the final manifest for four Material files and two Gallery files.

- Canonical Material manifest SHA-256 `ed0626e4d8fb0000f3057d0b164beaaebcab3e9904962d891c62067527a60bfa`
- Material manifest used to build the captured native run SHA-256 `0f34d29d637655caa327070cc8ac923d5c8cf7ee74015f80d83189e184848e43`
- Gallery source manifest SHA-256 `82e0f739f78d933014d4d08e1d32ee49c20df593822d8fcc8e0bea6c46b5b673`
- Example launcher SHA-256 `261a40b5635a8df17fa9456187831bac96bb43e412ed6130ad661c5359c69295`

```sh
shasum -a 256 -c evidence.sha256
bash build-and-run.sh /path/to/verified-surface-checkout /tmp/new-modal-rail-captures
```

The replay copies source to a new `/tmp` directory and keeps Cargo output under `/tmp/cargo-target`. Each Gallery run uses a separate private localhost DevTools session. The reduced-motion flag keeps the selected frame stable for byte comparison. The packet includes the test source, images and measurements.

`source-comparison.json` records the comparison of all files in the native build checkout and the canonical checkout. It found 673 identical paths. The differing paths were the Material regression test, browser E2E test and coverage documentation. The build checkout also contained the separately pinned launcher. The compiled application sources and build inputs match byte for byte. The PNGs and report come from the original native execution.

## Results

| Profile | Content viewport and PNG | Modal panel | Destination scroll |
| --- | --- | --- | --- |
| Wide, light, LTR | 960 × 800 | 288 × 800 on the left | All entries fit |
| Narrow, dark, RTL, 200% text | 320 × 240 | 320 × 240 with mirrored header and item positions | 136 dp with the header and page stationary |

Both profiles verified the modal name and navigation landmark in AppKit. Initial focus went to Close. The Home item remained current when an arrow skipped the disabled Archive and focused Inbox. Escape restored the opener. Enter selected Inbox and restored the opener. Reopening with the 96 dp inline rail retained made Inbox current in the modal. The Close button restored the opener again. Actions on background controls and the inline copy of Inbox were rejected while the modal was open.

The wide light scrim darkened 70 sampled pixels outside the panel. At 320 × 240 dp, the focused Inbox label fit its clip and measured 216 × 80 dp. Both text rows rendered across 26 pixel rows. The matching foreground pixel counts were 1466 and 1315. The raw DevTools PNG, CLI PNG and MCP `image/png` content block matched byte for byte.

AppKit measured outer windows of 960 × 832 pt and 320 × 272 pt. The 32 pt difference is native title-bar space. The compact closed Gallery keeps its stock floating add button. The button overlaps the right edge of the inline rail sample. The modal covers it when open.

The earlier compact capture in `before-adaptive-inbox.png` shows that the fixed header spacing clipped the second line of the 200% label. The final captures use the adaptive spacing and are checked for full geometric containment and foreground ink on both lines. This native run exercises keyboard dismissal. The public protocol does not supply a physical pointer gesture for clicking or swiping the scrim.
