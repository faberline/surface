"""Audit the two captured e07e7234 inline frames retained as visual evidence."""

from itertools import groupby
import json
from pathlib import Path
import runpy
import sys


HERE = Path(__file__).resolve().parent
PNG = runpy.run_path(str(HERE / "verify-public-screenshot.py"))


def measure(path, right):
    width, height, pixels = PNG["read_png"](path.read_bytes())
    assert (width, height) == (352, 256), path.name
    counts = {
        y: sum(pixels[y][x * 4] < 170 and pixels[y][x * 4 + 2] < 192
               for x in range(59, right))
        for y in range(202, height)
    }
    groups = [
        [y for _, y in band]
        for _, band in groupby(enumerate(y for y, n in counts.items() if n >= 2),
                              key=lambda pair: pair[1] - pair[0])
    ]
    rows = [{"first_y": g[0], "last_y": g[-1], "ink_pixels": sum(counts[y] for y in g)}
            for g in groups]
    rail_starts = [y for y in range(90, height)
                   if pixels[y][28 * 4:29 * 4] == pixels[75][28 * 4:29 * 4]]
    return {"png": path.name, "paint_scale": 0.5, "label_rows": rows,
            "last_rail_background_y": rail_starts[-1],
            "pixels_between_bottom_ink_and_rail": rail_starts[-1] - rows[-1]["last_y"]}


captures = Path(sys.argv[1])
collapsed = measure(captures / "light-wide-inline-collapse-02.png", 100)
expanded = measure(captures / "light-wide-inline-expand-01.png", 151)
assert len(collapsed["label_rows"]) == 4 and len(expanded["label_rows"]) == 2
assert collapsed["pixels_between_bottom_ink_and_rail"] == 9
assert collapsed["label_rows"][-1]["ink_pixels"] == expanded["label_rows"][-1]["ink_pixels"] == 39
print(json.dumps({"174_dp_closing": collapsed, "276_dp_opening": expanded}, indent=2))
