# Reproduce Drawer Swipe on macOS

Start from the verified Surface source for the Drawer Swipe evidence.
Use the `source.patch.gz` and source receipt from the same evidence entry
to reproduce that source first. Get `native-qa.patch.gz` from the same
entry. The replay checks the product input manifest, the published QA
patch digest, and the exact private QA input bytes.

```sh
sh build-and-run.sh /absolute/path/to/verified/surface/source /absolute/path/to/native-qa.patch.gz
```

Run from an Accessibility-authorized local terminal with an active
graphical login on a Mac with an Apple M1 Max Metal adapter. Install
Xcode Command Line Tools and Rust. Use Python 3 and the Surface `cap`
command to build the private Gallery and the Surface DevTools CLI.
The script creates its private checkout, harness copy, and capture
files under `/tmp` and prints the output path.

Use `--prepare-only` before the two paths to verify the source and QA
inputs and load both original Python entry points without building or
launching the Gallery. The archive retains the original runner, audit,
and launcher bytes. The helper tree keeps their relative imports intact.

The native runner captures real Metal frames with Surface
`Page.screenshot` and reads the public AppKit accessibility tree.
It injects Winit mouse events at wide sizes and Winit Touch events
at 320 × 240 dp. These reproduce the AppKit journeys without requiring
a physical touch device. The audit checks the screenshots, swipe
geometry, focus, modal scope, and compact CLI and MCP equality.
