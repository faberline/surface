#!/usr/bin/env python3
"""Audit saved Metal frames, gesture endpoints, raster and public modal scope."""

import argparse
from collections import Counter
import json
from pathlib import Path
import runpy


HERE = Path(__file__).resolve().parent
RUN = runpy.run_path(str(HERE / "verify-native-drawer-swipe.py"))
require = RUN["require"]
STAGES = (
    "initial", "short-held", "short-reverted", "cross-rejected", "before-cancel",
    "capture-cancelled", "resize-cancelled", "opening-held", "opening-settle",
    "gesture-opened", "row-click", "button-opened", "dismiss-held", "closing-settle",
    "gesture-dismissed",
)
PREVIEWS = {"short-held", "before-cancel", "opening-held", "opening-settle", "dismiss-held", "closing-settle"}
OPENED = {"gesture-opened", "button-opened", "dismiss-held", "closing-settle"}
HELD_FRACTIONS = {"short-held": .22, "before-cancel": .37, "opening-held": .67, "dismiss-held": .38}


def audit_frame(folder, frame, profile):
    (width, height), dark, rtl, scale, input_kind = profile
    stage = frame["stage"]
    expected = (width + 20, height + 20) if stage == "resize-cancelled" else (width, height)
    require((frame["width"], frame["height"]) == expected and
            (frame["dark"], frame["rtl"], frame["text_scale"], frame["input"]) == (dark, rtl, scale, input_kind),
            "Viewport, direction, input route or scale differs")
    RUN["read_png"](folder, frame)
    opened = stage in OPENED
    preview = stage in PREVIEWS
    after_row = STAGES.index(stage) >= STAGES.index("row-click")
    require(frame["focus"] == (RUN["CLOSE"] if opened else RUN["OPEN"])
            and frame["page"] == (RUN["INBOX"] if after_row else RUN["HOME"])
            and frame["trace"] == ([RUN["INBOX"]] if after_row else []),
            "Focus, controlled page or exact row press differs")
    controls = frame["macos"]["controls"]
    modals = [item for item in controls if item["modal"] is True]
    openers = [item for item in controls if item["name"] == RUN["MAC"]["OPENER"] and item["role"] == "AXButton"]
    require(len(modals) == int(opened) and len(openers) == int(not opened),
            "AppKit modal scope differs while the gesture is held or settling")
    counts = Counter(cli_pngs=1, os_ax_checks=1, os_ax_modals=len(modals))
    if preview or opened:
        panel, visible = frame["panel"], frame["visible_panel"]
        expected_alpha = round(82. * visible["width"] / panel["width"]) if preview else 82
        alpha_tolerance = 1 if preview else 0
        require(panel["width"] == min(width, 360.) and panel["height"] == height
                and visible["height"] == height
                and abs(frame["scrim"][3] - expected_alpha) <= alpha_tolerance,
                "Panel or scrim geometry differs")
        if stage in HELD_FRACTIONS:
            require(abs(visible["width"] - panel["width"] * HELD_FRACTIONS[stage]) <= 1.,
                    f"The held preview in {stage} did not follow the pointer: {visible}")
            counts.update(travel_probes=1)
        point = tuple(frame["face_probe"])
        pixels = RUN["pixels_for"](folder / frame["file"], frame, [point])
        require(RUN["color_matches"](pixels[point], frame["face_color"], 4), "Metal panel face is absent")
        counts.update(previews=int(preview), modal_frames=int(opened))
        if "scrim_samples" in frame:
            probes = [tuple(item["point"]) for item in frame["scrim_samples"]]
            raster = RUN["pixels_for"](folder / frame["file"], frame, probes)
            require(all(raster[tuple(item["point"])] == item["observed"]
                        and item["prior"] != item["observed"] for item in frame["scrim_samples"]),
                    "Scrim raster did not darken the backdrop")
            counts.update(scrim_pixels=len(probes))
        if "fab_stacking_probe" in frame:
            probe = frame["fab_stacking_probe"]
            point = tuple(probe["point"])
            observed = RUN["pixels_for"](folder / frame["file"], frame, [point])[point]
            require(observed == probe["observed"] and RUN["color_matches"](observed, probe["expected"], 4)
                    and observed != probe["prior"],
                    f"Drawer preview did not cover the Gallery FAB at {point}: {probe}")
            counts.update(fab_stacking_probes=1)
    else:
        require(frame["edge"]["width"] == 24., "Closed gesture edge width differs")
    return counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    report = json.loads((args.folder / "report.json").read_text())
    require(not report["errors"] and set(report["runs"]) == set(RUN["PROFILES"]), "Incomplete native swipe matrix")
    totals = Counter()
    for name, profile in RUN["PROFILES"].items():
        frames = [frame for frame in report["frames"] if frame["file"].startswith(name + "-")]
        require(tuple(frame["stage"] for frame in frames) == STAGES, f"Wrong ordered journey for {name}")
        for frame in frames:
            totals.update(audit_frame(args.folder, frame, profile))
        totals.update({"synthetic_touch_profiles" if profile[-1] == "touch" else "mouse_profiles": 1})
    parity = report["runs"]["compact-dark-rtl-2x"]["mcp"]
    require((args.folder / parity["cli"]).read_bytes() == RUN["read_png"](args.folder, parity),
            "MCP and CLI disagree during the held swipe")
    print(json.dumps({"renderer": "Apple M1 Max Metal", **totals, "matching_mcp": parity,
                      "touch_input": report["touch_input"]}, indent=2))


if __name__ == "__main__":
    main()
