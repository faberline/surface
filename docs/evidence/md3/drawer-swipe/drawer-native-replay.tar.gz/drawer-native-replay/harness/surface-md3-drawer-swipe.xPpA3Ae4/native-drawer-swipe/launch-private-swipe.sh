#!/bin/sh
set -eu
capture_dir=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
: "${SURFACE_QA_SWIPE_TRACE:?Set the private trace path}"
export SURFACE_TRACE="$SURFACE_QA_SWIPE_TRACE"
exec "$capture_dir/binaries/examples/fab_menu_native" "$@"
