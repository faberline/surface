#!/bin/sh
set -eu

prepare_only=false
if [ "${1:-}" = --prepare-only ]; then
    prepare_only=true
    shift
fi
if [ "$#" -ne 2 ]; then
    printf '%s\n' 'Usage: sh build-and-run.sh [--prepare-only] /path/to/verified/source /path/to/native-qa.patch.gz' >&2
    exit 2
fi

bundle=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
source_path=$(CDPATH='' cd -- "$1" && pwd)
patch_path=$2
output=$(mktemp -d /tmp/surface-md3-drawer-swipe-replay.XXXXXXXX)
workspace="$output/source"
runner_d="surface-md3-drawer-swipe.xPpA3Ae4/native-drawer-swipe"
patch_hash=$(shasum -a 256 "$patch_path" | awk '{print $1}')
expected_patch_hash=325a2f95d9b03d75ca501b8db21497be4f75c5fa532f44d665500a808bf7450e
if [ "$patch_hash" != "$expected_patch_hash" ]; then
    printf '%s\n' 'The native QA patch hash differs from the published evidence.' >&2
    exit 1
fi

export PYTHONDONTWRITEBYTECODE=1
printf 'Native replay output %s\n' "$output"
(cd "$source_path" && shasum -a 256 -c "$bundle/product.sha256")
python3 "$bundle/check-qa-inputs.py" "$source_path" "$bundle/native-qa-inputs.json" production
(cd "$bundle" && shasum -a 256 -c harness.sha256 && shasum -a 256 -c original-runner.sha256)
mkdir -p "$workspace"
rsync -a --exclude='/.git' --exclude='/target' --exclude='/artifacts' "$source_path/" "$workspace/"
gzip -dc "$patch_path" > "$output/private-qa.patch"
(
    cd "$workspace"
    git apply --check "$output/private-qa.patch"
    git apply "$output/private-qa.patch"
)
python3 "$bundle/check-qa-inputs.py" "$workspace" "$bundle/native-qa-inputs.json" qa
cp -R "$bundle/harness" "$output/harness"
runner="$output/harness/$runner_d"
python3 "$runner/verify-native-drawer-swipe.py" --help > "$output/runner-help.txt"
python3 "$runner/audit-native-drawer-swipe.py" --help > "$output/audit-help.txt"
if [ "$prepare_only" = true ]; then
    printf '%s\n' 'Verified replay inputs and loaded both original entry points.'
    exit 0
fi

export CARGO_BUILD_JOBS=2 CARGO_PROFILE_DEV_DEBUG=0 CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/tmp/cargo-target/surface-${output##*/}}"
(
    cd "$workspace"
    cap cargo build --locked -p surface-material-gallery \
        --features surface-material-gallery/devtools,surface-platform/macos-accessibility \
        --example fab_menu_native -p surface-devtools --bin surface-devtools
) > "$output/native-build.log" 2>&1
mkdir -p "$runner/binaries/examples"
cp "$CARGO_TARGET_DIR/debug/surface-devtools" "$runner/binaries/surface-devtools"
cp "$CARGO_TARGET_DIR/debug/examples/fab_menu_native" "$runner/binaries/examples/fab_menu_native"
"$runner/binaries/examples/fab_menu_native" --palette > "$output/palette.json"
(cd "$runner" && shasum -a 256 binaries/surface-devtools binaries/examples/fab_menu_native \
    > "$output/replay-binaries.sha256")
sw_vers > "$output/macos-version.txt"
python3 "$runner/verify-native-drawer-swipe.py" --checkout "$workspace" \
    --artifacts "$output/captures" > "$output/native-run.log" 2>&1
python3 "$runner/audit-native-drawer-swipe.py" "$output/captures" > "$output/native-audit.json"
tail -4 "$output/native-run.log"
