"""Check the original and private-overlay inputs against the evidence manifest."""

import hashlib
import json
from pathlib import Path
import sys


root, manifest = map(Path, sys.argv[1:3])
phase = sys.argv[3]
if phase not in ("production", "qa"):
    raise SystemExit(f"Unknown input phase {phase}")

inputs = json.loads(manifest.read_text())
for name, entry in sorted(inputs.items()):
    path = root / name
    actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
    if actual != entry.get(phase):
        raise SystemExit(f"{phase} input differs at {name}")
print(f"Verified {len(inputs)} {phase} inputs")
