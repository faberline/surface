#!/usr/bin/env python3
"""Verify live AX current destinations and capture the native Material Gallery."""

import argparse
from collections import Counter
from contextlib import contextmanager
from copy import copy
import json
import os
from pathlib import Path
import runpy
import subprocess
import tempfile
import time


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
RAIL = runpy.run_path(str(WORKSPACE / "surface-md3-navigation-rail.2Vp8O5Jj/native-navigation-rail/verify-native-navigation-rail.py"))
DRAWER = runpy.run_path(str(WORKSPACE / "surface-md3-navigation-drawer.UG1gs3Lj/native-navigation-drawer/verify-native-navigation-drawer.py"))
MAC = runpy.run_path(str(HERE / "read-current-ax.py"))
COMMON, MOTION, QA = (RAIL[name] for name in ("COMMON", "MOTION", "QA"))
capture, focus, key, node, read_png, require, write_json = (
    RAIL[name] for name in ("capture", "focus", "key", "node", "read_png", "require", "write_json")
)
R_ITEMS = RAIL["ITEMS"]
D_ITEMS = DRAWER["ROWS"][:3]
LEASE = {"current-lease-home": "常駐首頁", "current-lease-inbox": "常駐收件匣"}
SECTION = "section-1"


def public(case, names, current, *, focused=None, disabled=None, pressable=None):
    deadline = time.monotonic() + 4.
    names = tuple(names)
    while True:
        tree = MAC["inspect"](case.child.pid, names)
        buttons = {item["name"]: item for item in tree["buttons"]}
        if tree["trusted"] and len(buttons) == len(tree["buttons"]) and set(buttons) == set(names):
            valid = all(item["role"] == "AXButton" and item["title"] == name
                        and item["current"] == ("page" if name == current else None)
                        and item["lists_current"] is (name == current)
                        and item["enabled"] is (name != disabled)
                        and (pressable is None or item["actions"].count("AXPress") == int(name in pressable))
                        for name, item in buttons.items())
            if valid and (not focused or buttons[focused]["focused"] or buttons[focused]["focus_attr"]):
                return buttons
        require(time.monotonic() < deadline, f"Public current, title, role, or actions differ: {tree}")
        time.sleep(.05)


def app_trace(receipt, row_ids):
    trace = map(json.loads, receipt["trace"].splitlines())
    return [record["data"]["source"]["id"] for record in trace if record["kind"] == "Message"
            and (record["data"]["source"] or {}).get("id") in row_ids]


def verify_state(case, snapshot, row_ids, names, current, focus_id, expected_count,
                 *, disabled=None, preserve_legacy=False):
    receipt = json.loads(case.receipt.read_text())
    ax = receipt["accesskit"]["nodes"]
    for id in row_ids:
        require(node(snapshot, id).get("current_page") is (None if preserve_legacy else (id == current))
                and ax[id]["current_page"] == ("Page" if id == current else None),
                f"Surface or AccessKit projection of current page differs for {id}: {ax[id]}")
        require(ax[id]["role"] == "Button" and ax[id]["name"] == names[id]
                and ax[id]["disabled"] is (id == disabled), f"Button semantics differ for {id}")
    expected = [current] * expected_count if isinstance(expected_count, int) else expected_count
    actions = app_trace(receipt, row_ids)
    require(actions == expected, f"Expected exactly one app press per requested destination, got {actions}")
    offers = [names[id] for id in row_ids if ax[id]["press"]]
    inspect_ids = list(row_ids)
    if focus_id in names and focus_id not in row_ids:
        inspect_ids.append(focus_id)
        if ax[focus_id]["press"]:
            offers.append(names[focus_id])
    live = public(case, [names[id] for id in inspect_ids], names.get(current),
                  focused=names.get(focus_id), disabled=names.get(disabled), pressable=offers)
    return {"focus": focus_id, "current": current, "presses": actions,
            "projected": {id: ax[id] for id in row_ids}, "macos": live}


def take(case, stage, focus_id, current, row_ids, names, count, disabled=None, *, legacy=False):
    case.clock.advance(500)
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{stage}",
                              case.size, case.dark, SECTION)
    require(not frame["errors"] and snapshot["interaction"]["focused"] == focus_id,
            f"Wrong focus or capture in {stage}: {snapshot['interaction']}")
    frame.update(state=verify_state(case, snapshot, row_ids, names, current, focus_id, count,
                                   disabled=disabled, preserve_legacy=legacy))
    return frame


def press_current(case, names, name):
    result = MAC["inspect"](case.child.pid, names, activate=name)
    require(result.get("press_status") == 0, f"AppKit AXPress rejected {name}: {result}")


def expect_page(case, id, text):
    deadline = time.monotonic() + 3.
    while node(case.snapshot(), id)["text"] != text:
        require(time.monotonic() < deadline, f"Application page did not change to {text!r}")
        time.sleep(.04)


def mcp(case, frame):
    other = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
    require(read_png(case.plan.artifacts, frame) == read_png(case.plan.artifacts, other),
            "CLI and MCP returned different PNG contents")
    return {**other, "cli": frame["file"]}


def rail_run(case):
    home, archive, inbox = R_ITEMS
    names = RAIL["NAMES"]
    case.call("action", "activate", SECTION)
    case.call("action", "activate", RAIL["RTL"])
    case.call("action", "activate", RAIL["SCALE"])
    case.point("leave")
    QA["reveal"](case, RAIL["LAYOUT"])
    focus(case, RAIL["SCALE"])
    key(case, "tab", home)
    frames = [take(case, "before", home, home, R_ITEMS, names, 0, archive)]
    key(case, "down", inbox)
    frames.append(take(case, "arrow", inbox, home, R_ITEMS, names, 0, archive))
    press_current(case, names.values(), names[inbox])
    expect_page(case, RAIL["PAGE"], RAIL["PAGES"][inbox])
    current = take(case, "pressed", inbox, inbox, R_ITEMS, names, 1, archive)
    frames.append(current)
    mirror = mcp(case, current)
    key(case, "up", home)
    frames.append(take(case, "arrow-back", home, inbox, R_ITEMS, names, 1, archive))
    QA["reveal"](case, "navigation-drawer-card")
    legacy = take(case, "legacy", home, None, ("drawer-inbox",), {"drawer-inbox": "Inbox"}, 0, legacy=True)
    return {"frames": [*frames, legacy], "mcp": mirror}


def drawer_run(case):
    home, archive, inbox = D_ITEMS
    names = dict(DRAWER["NAMES"])
    case.call("action", "activate", SECTION)
    case.call("action", "activate", DRAWER["RTL"])
    case.call("action", "activate", DRAWER["SCALE"])
    case.point("leave")
    opener, close = DRAWER["OPEN"], DRAWER["CLOSE"]
    QA["reveal"](case, opener)
    focus(case, opener)
    key(case, "enter", close)
    frames = [take(case, "before", close, home, D_ITEMS, names, 0, archive)]
    key(case, "tab", home)
    key(case, "down", inbox)
    frames.append(take(case, "arrow", inbox, home, D_ITEMS, names, 0, archive))
    press_current(case, [names[id] for id in D_ITEMS], names[inbox])
    expect_page(case, DRAWER["PAGE"], names[inbox])
    require(case.snapshot()["interaction"]["focused"] == opener, "Drawer did not restore the opener")
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-selected",
                              case.size, case.dark, SECTION)
    require(not frame["errors"] and DRAWER["PANEL"] not in DRAWER["ids"](snapshot)
            and node(snapshot, DRAWER["PAGE"])["text"] == names[inbox], "Drawer stayed open")
    events = app_trace(json.loads(case.receipt.read_text()), D_ITEMS)
    require(events == [inbox], f"Drawer activation dispatched more than once: {events}")
    frame.update(state={"current_page_after_close": inbox, "presses": events, "focus": opener})
    frames.append(frame)
    key(case, "enter", close)
    key(case, "tab", inbox)
    selected = take(case, "reopened", inbox, inbox, D_ITEMS, names, 1, archive)
    frames.append(selected)
    return {"frames": frames, "mcp": mcp(case, selected)}


@contextmanager
def retained_app(plan):
    with (tempfile.TemporaryDirectory(prefix="surface-current-lease-", dir="/private/tmp") as private,
          (plan.artifacts / "leased.log").open("wb") as log):
        folder = Path(private)
        log_path = plan.artifacts / "appkit-current.tsv"
        log_path.touch(mode=0o600)
        session = folder / "session.json"
        receipt = folder / "receipt.json"
        clock = COMMON["COMMON"]["Clock"](folder / "frame-time")
        env = dict(os.environ, SURFACE_DEVTOOLS_SESSION=str(session), SURFACE_QA_ANIMATION_TIME=str(clock.path),
                   SURFACE_QA_CAPTURE_RECEIPT=str(receipt), SURFACE_QA_POINTER_AUTOMATION="1",
                   SURFACE_TRACE=str(plan.artifacts / "leased-trace.jsonl"),
                   SURFACE_QA_CURRENT_EVENT_LOG=str(log_path),
                   DYLD_INSERT_LIBRARIES=str(HERE / "record-appkit-current.dylib"))
        env.pop("SURFACE_BRIDGE_SESSION", None)
        child = subprocess.Popen([plan.native, "--leased-fixture", "540", "300"], cwd=plan.checkout,
                                 env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
        try:
            COMMON["wait_for_session"](session, child, plan.startup_timeout)
            case = COMMON["Case"](plan, "leased", (540, 300), False, child, session, clock, receipt)
            clock.advance(1000)
            yield case, log_path
        finally:
            MOTION["stop"](child)


def events_after(case, path, names):
    deadline = time.monotonic() + 3.
    pid = str(case.child.pid)
    while True:
        rows = [line.split("\t") for line in path.read_text().splitlines()]
        require(rows and rows[0] == [pid, "loaded"], f"Native event collector did not attach: {rows}")
        actual = [{"title": title, "instance": instance} for row_pid, title, instance in rows[1:] if row_pid == pid]
        require(len(actual) <= len(names), f"An unchanged native node posted a duplicate current event: {actual}")
        if len(actual) == len(names):
            require(Counter(event["title"] for event in actual) == Counter(names), "Wrong native current events")
            return actual
        require(time.monotonic() < deadline, f"Native current state notifications never arrived: {actual}")
        time.sleep(.04)


def leased_run(case, receipt):
    home, inbox = LEASE
    names = list(LEASE.values())
    frames = []
    details = capture.__globals__["png_details"]

    def check(tag, active, focus_id, presses, notifications):
        case.clock.advance(400)
        path = case.plan.artifacts / f"{tag}.png"
        meta = case.call("page", "screenshot", "--scale", "1", "--out", path)
        frame = details(path, meta)
        snapshot = case.snapshot()
        require(node(snapshot, "current-lease-presses")["text"] == str(len(presses)), "A retained press duplicated")
        require(snapshot["interaction"]["focused"] == focus_id, "Retained test lost keyboard focus")
        verify = verify_state(case, snapshot, tuple(LEASE), LEASE, active, focus_id, presses)
        frame.update(state=verify, native_events=events_after(case, receipt, notifications))
        frames.append(frame)
        return frame

    focus(case, home)
    check("leased-initial", home, home, [], [])
    key(case, "tab", inbox)
    check("leased-focus-only", home, inbox, [], [])
    press_current(case, names, LEASE[inbox])
    expect_page(case, "current-lease-presses", "1")
    change = check("leased-changed", inbox, inbox, [inbox], names)
    press_current(case, names, LEASE[inbox])
    expect_page(case, "current-lease-presses", "2")
    check("leased-repeated", inbox, inbox, [inbox, inbox], names)
    press_current(case, names, LEASE[home])
    expect_page(case, "current-lease-presses", "3")
    restored = check("leased-restored", home, home, [inbox, inbox, home], names * 2)
    previous = {entry["title"]: entry["instance"] for entry in change["native_events"]}
    latest = {entry["title"]: entry["instance"] for entry in restored["native_events"][-2:]}
    require(previous == latest, "The native buttons were recreated instead of retaining their objects")
    return {"frames": frames, "retained": previous}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--mode", action="append", choices=("rail", "drawer", "leased"))
    plan = parser.parse_args()
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    plan.checkout = HERE / "qa-exact"
    plan.client = HERE / "binaries/surface-devtools"
    plan.launcher = HERE / "launch-current-gallery.sh"
    plan.native = HERE / "binaries/examples/fab_menu_native"
    plan.case, plan.startup_timeout = "normal", 30
    plan.palette = json.loads(subprocess.check_output([plan.native, "--palette"]))
    require(MAC["AX"]["trusted"](), "Use the Accessibility-authorized local process")
    root = plan.artifacts
    result = {}
    for name, size, run in (("rail", (320, 640), rail_run), ("drawer", (320, 240), drawer_run)):
        if not plan.mode or name in plan.mode:
            stage = copy(plan)
            stage.artifacts = root / name
            stage.artifacts.mkdir(mode=0o700)
            os.environ["SURFACE_QA_CURRENT_TRACE"] = str(stage.artifacts / "trace.jsonl")
            with COMMON["gallery"](stage, name, size, True) as case:
                result[name] = run(case)
            log = (stage.artifacts / f"{name}.log").read_text()
            require("Apple M1 Max" in log and "backend: Metal" in log, "Expected Apple Metal")
            write_json(root / "report.json", result)
    if not plan.mode or "leased" in plan.mode:
        stage = copy(plan)
        stage.artifacts = root / "leased"
        stage.artifacts.mkdir(mode=0o700)
        with retained_app(stage) as (case, receipt):
            result["leased"] = leased_run(case, receipt)
        log = (stage.artifacts / "leased.log").read_text()
        require("Apple M1 Max" in log and "backend: Metal" in log, "Expected Apple Metal")
        write_json(root / "report.json", result)
    print(f"Passed {sum(len(run['frames']) for run in result.values())} native PNGs and {len(result)} current-state journeys")


if __name__ == "__main__":
    main()
