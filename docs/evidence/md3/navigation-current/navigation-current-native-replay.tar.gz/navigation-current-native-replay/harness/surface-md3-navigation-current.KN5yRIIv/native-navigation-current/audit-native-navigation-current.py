#!/usr/bin/env python3
"""Audit current-page PNGs, public attributes, and retained AppKit events."""

import argparse
from collections import Counter
import json
from pathlib import Path
import runpy


HERE = Path(__file__).resolve().parent
RUN = runpy.run_path(str(HERE / "verify-native-navigation-current.py"))
require, read_png = RUN["require"], RUN["read_png"]
BEFORE_RAIL = HERE.parents[1] / "surface-md3-navigation-rail.2Vp8O5Jj/native-navigation-rail/verified/compact-dark-rtl-2x-ax-pressed.png"
BEFORE_DRAWER = HERE.parents[1] / "surface-md3-navigation-drawer.UG1gs3Lj/native-navigation-drawer/verified/compact-dark-rtl-2x-skip-disabled.png"


def current_state(frame):
    state = frame["state"]
    macos = state.get("macos")
    if macos is None:
        require(state["presses"] == ["drawer-demo-inbox"], "The Drawer press duplicated")
        return Counter()
    active = [button for button in macos.values() if button["current"] == "page"]
    require(len(active) == int(bool(state["current"])), "Current destination count changed")
    for name, button in macos.items():
        require(button["title"] == name and button["role"] == "AXButton"
                and button["lists_current"] is (button["current"] == "page")
                and button["actions"].count("AXPress") <= 1, "Button identity or action changed")
        if button["enabled"] is False:
            require(not button["lists_current"] and "AXPress" not in button["actions"],
                    "Disabled control acquired a current state or press")
    return Counter(public_ax=1, active_attributes=len(active),
                   absent_attributes=len(macos) - len(active))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    report = json.loads((args.folder / "report.json").read_text())
    require(set(report) == {"rail", "drawer", "leased"}, "Three native journeys are required")
    total = Counter()
    comparisons = {}
    for kind, run in report.items():
        root = args.folder / kind
        frames = run["frames"]
        for frame in frames:
            read_png(root, frame)
            total.update(current_state(frame))
            total.update(cli_pngs=1)
        if kind == "leased":
            counts = [len(frame["native_events"]) for frame in frames]
            require(counts == [0, 0, 2, 2, 4], "Initial, focus, select, repeat or return event count differs")
            rows = (root / "appkit-current.tsv").read_text().splitlines()
            require(len(rows) == 5, "Extra AppKit current event after the final frame")
            events = Counter(line.split("\t")[1] for line in rows[1:])
            require(events == {name: 2 for name in RUN["LEASE"].values()},
                    "A retained native button raised an incorrect current-state count")
            require(all(run["retained"][entry["title"]] == entry["instance"]
                        for entry in frames[-1]["native_events"]), "An AppKit button identity was replaced")
            total.update(retained_events=len(rows) - 1)
        else:
            mirror = run["mcp"]
            require((root / mirror["cli"]).read_bytes() == read_png(root, mirror), f"{kind} MCP PNG differs")
            before, current = ((BEFORE_RAIL, "rail-pressed.png") if kind == "rail"
                               else (BEFORE_DRAWER, "drawer-arrow.png"))
            require(before.read_bytes() == (root / current).read_bytes(), f"{kind} gained visible pixels")
            comparisons[kind] = {"mcp": mirror, "prior_image": str(before), "identical_current_image": current}
    require(total["cli_pngs"] == 14 and total["public_ax"] == 13 and total["retained_events"] == 4,
            "Native evidence count differs")
    print(json.dumps({"renderer": "Apple M1 Max Metal", **total, "comparisons": comparisons}, indent=2))


if __name__ == "__main__":
    main()
