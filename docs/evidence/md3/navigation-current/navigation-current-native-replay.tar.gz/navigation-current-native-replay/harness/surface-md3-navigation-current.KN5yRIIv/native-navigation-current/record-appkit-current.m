#import <AppKit/AppKit.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static FILE *receipt(void) {
    const char *path = getenv("SURFACE_QA_CURRENT_EVENT_LOG");
    return path ? fopen(path, "a") : NULL;
}

__attribute__((constructor))
static void record_start(void) {
    FILE *output = receipt();
    if (output) {
        fprintf(output, "%d\tloaded\n", getpid());
        fclose(output);
    }
}

static void record_request(id element, NSAccessibilityNotificationName notification) {
    if ([notification isEqualToString:@"AXCurrentStateChanged"]) {
        NSString *title = [element accessibilityTitle];
        FILE *output = receipt();
        if (output) {
            fprintf(output, "%d\t%s\t%p\n", getpid(), title.UTF8String, (void *)element);
            fclose(output);
        }
    }
    NSAccessibilityPostNotification(element, notification);
}

__attribute__((used, section("__DATA,__interpose")))
static const struct {
    const void *replacement;
    const void *original;
} current_hook = {
    (const void *)record_request,
    (const void *)NSAccessibilityPostNotification,
};
