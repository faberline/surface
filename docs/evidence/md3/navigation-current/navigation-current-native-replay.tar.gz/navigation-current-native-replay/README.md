# Reproduce Current Page in Native Material Navigation

Use the restored Navigation Current source from the corresponding evidence
entry. Run from an Accessibility-authorized local terminal with an active
graphical login on a Mac with an Apple M1 Max Metal adapter. Install Xcode
Command Line Tools, Python 3, Rust, and the Surface `cap` command.

```sh
sh build-and-run.sh /absolute/path/to/restored/navigation-current/source
```

Use `--prepare-only` before the source path to verify the archive, its
original scripts, and the 18 private QA input hashes and to load the runner
and auditor. The full script builds an isolated Gallery and DevTools CLI.
It compiles the AppKit notification collector from the archived Objective-C
source. The collector runs inside the private retained-control fixture
for that journey only. The bundle keeps the original helper and comparison
paths. The script creates its build and capture inputs under `/tmp`.

The native runner captures 14 Metal PNGs and checks 13 live public AppKit
trees. It checks unchanged current page during Arrow navigation, one press
per activation, and the compact CLI and MCP PNGs. The retained-control
fixture checks actual AppKit current-state notifications. VoiceOver speech
remains outside this receipt.
