# Reproduce the Wide Navigation Rail on macOS

Start with the source tree for this evidence batch. The
`product.sha256` file verifies the five changed product
source inputs. Use the checkout identified by the source
record in the corresponding GitHub evidence.

Run the replay on a Mac with an Apple M1 Max Metal adapter,
an active graphical login, and Accessibility access for the
terminal. Use Xcode Command Line Tools, Python 3, Rust, and
the Surface repository's `cap` build wrapper.

```sh
sh build-and-run.sh /absolute/path/to/verified/surface/source
```

The script copies the source to `/tmp`, applies a private QA
overlay, builds the Gallery and Surface DevTools CLI, and
prints the output directory. The overlay fixes animation time
and injects named keys and pointer events into the normal input
routes. It isolates unrelated physical input and can make its
own window key for the AppKit queries. The overlay changes test
instrumentation without changing the rail or Gallery sample.

The Gallery paints real Metal frames. The runner checks
`Page.screenshot` through the CLI and verifies native current
page, focus, disclosure, and Press through the public AppKit
accessibility interface. The dark compact shot uses the MCP
tool as well. The audit checks the frame dimensions, PNG
digests, AppKit tree snapshots, geometry, and exact CLI/MCP
byte equality. It writes a JSON report.
