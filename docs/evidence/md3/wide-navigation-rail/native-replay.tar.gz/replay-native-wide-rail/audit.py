"""Verify the captured rail report and retain evidence digests."""

import hashlib
import json
import math
import struct
import sys
from pathlib import Path


PROFILE_STAGES = {
    "wide-light-ltr": ["collapsed", "expanded", "arrow", "pressed"],
    "wide-dark-rtl-2x": [
        "collapsed", "expanded", "arrow", "pressed", "round-trip-600",
        "round-trip-599", "round-trip-returned", "disclosure-focus-restored",
    ],
    "compact-light-ltr-2x": ["bottom-home", "bottom-arrow", "bottom-pressed"],
    "compact-dark-rtl-2x": ["bottom-home", "bottom-arrow", "bottom-pressed"],
}
BUTTONS = {
    "wide-rail-home": "瀏覽首頁",
    "wide-rail-archive": "封存資料",
    "wide-rail-inbox": "收件匣",
}


def require(condition, detail):
    if not condition:
        raise RuntimeError(detail)


def sha(contents):
    return hashlib.sha256(contents).hexdigest()


def dimensions(contents):
    require(contents[:16] == b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR", "Invalid PNG header")
    return struct.unpack(">II", contents[16:24])


def contains(parent, child):
    slop = 1e-6
    for coord, size in (("x", "width"), ("y", "height")):
        if (child[coord] < parent[coord] - slop
                or child[coord] + child[size] > parent[coord] + parent[size] + slop):
            return False
    return True


def check_frame(captures, profile, stage, frame):
    filename = f"{profile}-{stage}.png"
    contents = (captures / filename).read_bytes()
    require(frame["file"] == filename and frame["sha256"] == sha(contents),
            f"PNG digest differs in {stage}")
    require(dimensions(contents) == (frame["width"], frame["height"]),
            f"PNG dimensions differ in {stage}")
    dpi = frame["viewport"]
    require(frame["width"] == round(dpi["width"] * frame["scale"])
            and frame["height"] == round(dpi["height"] * frame["scale"]),
            f"PNG scale differs in {stage}")
    paint = frame["paint"]
    nav = frame["nav"]
    require(set(paint) == set(BUTTONS)
            and all(contains(nav, p["target"]) and p["icon_pixels"] > 0
                    and p["label_pixels"] > 0 and p["label_lines"] for p in paint.values()),
            f"Rail did not contain all visible destinations in {stage}")
    if profile.startswith("compact-"):
        require((dpi["width"], dpi["height"]) == (320, 240)
                and frame["mode"] == "bottom" and frame["text_scale"] == 2.,
                f"Compact fallback was not a 320 by 240 dp viewport in {stage}")
    public = frame["macos"]
    require(public["trusted"] and len(public["navigation"]) == 1 and not public["modals"],
            f"Public AppKit navigation differs in {stage}")
    current = [item["name"] for item in public["buttons"] if item["current"] == "page"]
    require(current == [BUTTONS[frame["selected"]]], f"AppKit current page differs in {stage}")
    if frame["mode"] != "bottom":
        expanded = frame["mode"] == "expanded"
        disclosure = "收合導覽列" if expanded else "展開導覽列"
        require(len([item for item in public["buttons"] if item["name"] == disclosure
                     and item["expanded"] is expanded]) == 1, f"Public AXExpanded differs in {stage}")
        require(nav["width"] == 96. if not expanded else 220. <= nav["width"] <= 360.,
                f"Rail width differs in {stage}")
        require(math.isclose(nav["height"], frame["content"]["height"]),
                f"Adjacent pane height fails to match rail height in {stage}")
        stack_bottom = max(row["target"]["y"] + row["target"]["height"] for row in paint.values())
        require(math.isclose(nav["y"] + nav["height"], stack_bottom, abs_tol=0.001),
                f"Unneeded gap below the rail destinations in {stage}")
    return {
        "png": filename,
        "sha256": sha(contents),
        "viewport_dp": [int(dpi["width"]), int(dpi["height"])],
        "navigation_width_dp": int(nav["width"]),
        "appkit_current": current[0],
        "destination_focus": frame["focused"],
        "long_label_lines": len(paint["wide-rail-inbox"]["label_lines"]),
    }


def main(captures):
    report = json.loads((captures / "report.json").read_text())
    require(not report["errors"] and set(report["runs"]) == set(PROFILE_STAGES),
            "Incomplete profile report")
    frames = {frame["file"]: frame for frame in report["frames"]}
    require(len(frames) == len(report["frames"]) == 18, "Expected 18 distinct real screenshots")
    report_summary = {}
    for profile, stages in PROFILE_STAGES.items():
        require("Apple M1 Max" in report["runs"][profile]["adapter"]
                and "backend: Metal" in report["runs"][profile]["adapter"],
                f"Metal adapter missing in {profile}")
        report_summary[profile] = [
            check_frame(captures, profile, stage, frames[f"{profile}-{stage}.png"])
            for stage in stages
        ]
    rtl = report_summary["wide-dark-rtl-2x"]
    require(rtl[1]["long_label_lines"] >= 2, "Wide RTL 200% expanded label did not wrap")
    require([item["viewport_dp"][0] for item in rtl[4:7]] == [600, 599, 600],
            "Adaptive boundary replay differs")
    mcp = report["runs"]["compact-dark-rtl-2x"]["mcp"]
    cli = (captures / mcp["cli"]).read_bytes()
    mirror = (captures / mcp["file"]).read_bytes()
    require(cli == mirror and sha(mirror) == mcp["sha256"], "CLI and MCP PNGs differ")
    print(json.dumps(
        {
            "rendered_cli_pngs": len(frames),
            "verified_public_appkit_snapshots": len(frames),
            "identical_mcp_pair": mcp,
            "profiles": report_summary,
        },
        ensure_ascii=False,
        indent=2,
    ))


if __name__ == "__main__":
    main(Path(sys.argv[1]))
