#!/bin/sh
set -eu

bundle=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
source_path=$(CDPATH='' cd -- "${1:?Pass the verified Surface source directory}" && pwd)
output=$(mktemp -d /tmp/surface-md3-wide-rail-replay.XXXXXXXX)
workspace="$output/source"
runner="$bundle/qa-harness/surface-md3-wide-rail.bWzU1RgV/native-wide-rail"

printf 'Native replay output %s\n' "$output"
(cd "$source_path" && shasum -a 256 -c "$bundle/product.sha256")
mkdir -p "$workspace" "$output/binaries/examples"
rsync -a --exclude='/.git/' --exclude='/target/' --exclude='/artifacts/' "$source_path/" "$workspace/"
(
    cd "$workspace"
    git apply --check "$bundle/private-qa-overlay.patch"
    git apply "$bundle/private-qa-overlay.patch"
)

export CARGO_BUILD_JOBS=2 CARGO_PROFILE_DEV_DEBUG=0 CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/tmp/cargo-target/surface-${output##*/}}"
export PYTHONDONTWRITEBYTECODE=1
(
    cd "$workspace"
    cap cargo build --locked -p surface-material-gallery \
        --features surface-material-gallery/devtools,surface-platform/macos-accessibility \
        --example fab_menu_native -p surface-devtools --bin surface-devtools
) > "$output/native-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/surface-devtools" "$output/binaries/surface-devtools"
cp "$CARGO_TARGET_DIR/debug/examples/fab_menu_native" "$output/binaries/examples/fab_menu_native"
swiftc -module-cache-path "$output/swift-cache" "$runner/activate-private-gallery.swift" \
    -o "$output/binaries/activate-private-gallery"
sw_vers > "$output/macos-version.txt"
rustc --version > "$output/rust-version.txt"
(cd "$output" && shasum -a 256 binaries/surface-devtools binaries/examples/fab_menu_native \
    binaries/activate-private-gallery > retained-binaries.sha256)
python3 "$runner/verify-native-wide-rail.py" --checkout "$workspace" --binaries "$output/binaries" \
    --artifacts "$output/captures" > "$output/native-run.log" 2>&1
python3 "$bundle/audit.py" "$output/captures" > "$output/native-audit.json"
tail -6 "$output/native-run.log"
