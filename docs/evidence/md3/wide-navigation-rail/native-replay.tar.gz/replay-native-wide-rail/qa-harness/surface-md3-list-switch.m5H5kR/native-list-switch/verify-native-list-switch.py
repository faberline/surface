#!/usr/bin/env python3
"""Verify trailing switches in the actual Metal Material Gallery."""

import argparse
import json
import math
from pathlib import Path
import runpy
import subprocess

HERE = Path(__file__).resolve().parent
TRAILING = runpy.run_path(str(HERE.parents[1] / "surface-md3-list-trailing.1baAgw"
                              / "native-list-trailing" / "verify-native-list-trailing.py"))
BASE, COMMON, MOTION, VIEWPORTS, PROFILES = (
    TRAILING[key] for key in ("BASE", "COMMON", "MOTION", "VIEWPORTS", "PROFILES")
)
capture, close, color_matches, contains, focus, key, node, rect, center, pixels_for, require, same_rect, sample_points, write_json = (
    TRAILING[key] for key in ("capture", "close", "color_matches", "contains", "focus", "key",
                             "node", "rect", "center", "pixels_for", "require", "same_rect",
                             "sample_points", "write_json")
)
blend, visible_ink, paint_entries, reject, frame_row, complete_bands, all_bands, press_ax = (
    TRAILING[key] for key in ("blend", "visible_ink", "paint_entries", "reject", "frame_row",
                             "complete_bands", "all_bands", "press_ax")
)

SECTION = "section-5"
PREFIX = "list-switch-"
LIST, DIRECTION, SCALE, STATUS, FILE, GROUP, PRIMARY_DISABLED, DISABLED = (
    PREFIX + suffix for suffix in ("rows", "direction", "scale", "status", "file", "group",
                                    "primary-disabled", "disabled")
)
ROWS = {
    FILE: ("開啟文件", "追蹤文件", {"headline": "文件"}, "False"),
    GROUP: ("開啟專案", "追蹤專案",
            {"headline": "專案總覽", "supporting": "開啟專案可查看最新回覆與待辦事項。"}, "True"),
    PRIMARY_DISABLED: ("開啟封存", "追蹤封存", {"headline": "已封存"}, "True"),
    DISABLED: ("開啟唯讀文件", "追蹤唯讀文件", {"headline": "唯讀文件"}, "False"),
}
PRIMARY = "-row"
SWITCH = "-trailing-action"
TRACK = "-trailing-track"
THUMB = "-trailing-thumb"


def count(case, expected):
    row = node(case.snapshot(), STATUS)
    text = f"開啟 {expected[0]} 次，切換 {expected[1]} 次"
    observed = row["text"] or row["name"]
    require(observed == text, f"Expected {text!r}; observed {observed!r}")


def pointer(case, point, before, after, id=None):
    case.point("move", point)
    case.point("down", point)
    require(case.snapshot()["interaction"]["pressed"] == id, f"Wrong pointer owner for {id}")
    count(case, before)
    case.point("up", point)
    case.point("leave")
    count(case, after)


def inactive_release(case, point, opposite, id, counts):
    case.point("move", point)
    case.point("down", point)
    require(case.snapshot()["interaction"]["pressed"] == id, f"Wrong cross-target owner for {id}")
    case.point("move", opposite)
    case.point("up", opposite)
    case.point("leave")
    require(case.snapshot()["interaction"]["pressed"] is None, "Cross-target release left a held press")
    count(case, counts)


def touch_cancel(case, point, id, counts):
    case.point("touch-start", point)
    require(case.snapshot()["interaction"]["pressed"] == id, f"Wrong Winit touch owner for {id}")
    case.point("touch-cancel", point)
    case.point("touch-end", point)
    require(case.snapshot()["interaction"]["pressed"] is None, "Cancellation left a held press")
    count(case, counts)


def by_center(box, size):
    x, y = center(box)
    return {"x": x - size / 2, "y": y - size / 2, "width": size, "height": size}


def geometry(case, snapshot, item, rtl, scale, value):
    primary = rect(snapshot, item + PRIMARY)
    target = rect(snapshot, item + SWITCH)
    track = rect(snapshot, item + TRACK)
    thumb = rect(snapshot, item + THUMB)
    selected = value == "True"
    diameter = 24. if selected else 16.
    close(track["width"], 52., "Switch track width")
    close(track["height"], 32., "Switch track height")
    close(thumb["width"], diameter, "Switch thumb width")
    close(thumb["height"], diameter, "Switch thumb height")
    require(contains(track, thumb), "Switch thumb escapes track")
    for actual, expected in zip(center(track), center(target)):
        close(actual, expected, "Centered switch track")
    offset = 36. if selected else 16.
    if rtl:
        offset = 52. - offset
    close(center(thumb)[0] - track["x"], offset, "Direction-relative thumb center")
    close(center(thumb)[1], center(track)[1], "Vertically centered thumb")
    body = {suffix: rect(snapshot, item + "-" + suffix) for suffix in ROWS[item][2]}
    item_box = rect(snapshot, item)
    close(item_box["width"], rect(snapshot, LIST)["width"], "List item spans container")
    if case.size[0] == 320:
        require(item_box["width"] >= 216., "Compact list lost usable width")
    require(primary["width"] >= 48. and primary["height"] >= 48. and contains(item_box, primary),
            f"{item}: primary control misses 48 dp or its row")
    require(all(contains(primary, box) for box in body.values()), "Visible body escapes primary hit area")
    close(target["width"], 52., "Separate switch hit width")
    close(target["height"], 48., "Separate switch hit height")
    require(contains(item_box, target), "Switch protrudes outside the list item")
    edge = (target["x"] - item_box["x"] if rtl else
            item_box["x"] + item_box["width"] - target["x"] - target["width"])
    close(edge, 16., "Mirrored end inset")
    h = body["headline"]
    gap = h["x"] - target["x"] - target["width"] if rtl else target["x"] - h["x"] - h["width"]
    close(gap, 16., "Space from body to switch")
    separate = primary["x"] - target["x"] - target["width"] if rtl else target["x"] - primary["x"] - primary["width"]
    require(separate > 0., "Body and switch targets overlap")
    y = item_box["y"] if primary["height"] >= 88. else center(primary)[1] - 24.
    close(target["y"], y, "Switch alignment")
    if scale == 1 and case.size[0] == 960:
        close(primary["height"], 72. if item == GROUP else 56., "Baseline row height")
    divider = None
    if item != DISABLED:
        divider = rect(snapshot, item + "-divider")
        close(divider["y"], primary["y"] + primary["height"], "Divider outside both hit targets")
        close(divider["height"], 1., "Divider thickness")
        close(divider["x"] - item_box["x"], 0. if rtl else 16., "Divider left inset")
        close(item_box["x"] + item_box["width"] - divider["x"] - divider["width"], 16. if rtl else 0.,
              "Divider right inset")
    return primary, target, track, thumb, body, divider, item_box


def a11y(snapshot, receipt, item, primary, target, value):
    tree = receipt["accesskit"]
    native = tree["nodes"]
    require(native[LIST]["role"] == "List" and native[LIST]["name"] == "追蹤設定清單",
            "Native list role or localized label changed")
    require(not any(id.endswith((TRACK, THUMB, "-divider", "-leading-artwork")) for id in native),
            "Decorative switch visual, leading vector, or divider entered AccessKit")
    owner = native[item]
    require(owner["role"] == "ListItem" and owner["name"] is None
            and not any(owner[k] for k in ("press", "focusable", "disabled")),
            "List item became a third control or disabled its independent targets")
    focus_id = snapshot["interaction"]["focused"]
    _, ids = COMMON["dom_index"](snapshot)
    visible = {}
    for suffix, box, role, name, disabled, toggled in (
        (PRIMARY, primary, "Button", ROWS[item][0], item == PRIMARY_DISABLED, None),
        (SWITCH, target, "Switch", ROWS[item][1], item == DISABLED, value),
    ):
        id = item + suffix
        clip = snapshot["layout"]["nodes"][ids[id]]["clip"]
        bounds = [max(box["x"], clip["x"]), max(box["y"], clip["y"]),
                  min(box["x"] + box["width"], clip["x"] + clip["width"]),
                  min(box["y"] + box["height"], clip["y"] + clip["height"])]
        if bounds[3] <= bounds[1]:
            require(id not in native or not native[id]["press"], f"{id}: clipped control still takes Click")
            continue
        control = native[id]
        require(control["role"] == role and control["name"] == name and control["toggled"] == toggled
                and control["disabled"] is disabled and control["press"] is not disabled
                and control["focusable"] is not disabled and control["focused"] is (focus_id == id),
                f"{id}: wrong name, native role, toggled state, or action: {control}")
        for actual, logical in zip(control["bounds"], bounds):
            close(actual, logical * tree["scale"], f"{id}: AccessKit bounds")
        visible[suffix] = control
    names = [child["name"] for child in tree["viewport_subtree"]]
    name, check_name = ROWS[item][:2]
    if len(visible) == 2:
        require(names.count(name) == names.count(check_name) == 1 and names.index(name) < names.index(check_name),
                "AX reading order or unique labels changed")
    return visible


def palette_roles(palette, checked, disabled):
    bg, ink = palette["surface"], palette["on_surface"]
    if checked:
        return (blend(bg, ink, .12), bg, None) if disabled else (
            palette["primary"], palette["on_primary"], None)
    if disabled:
        return (blend(bg, palette["surface_container_highest"], .12),
                blend(bg, ink, .38), blend(bg, ink, .12))
    return palette["surface_container_highest"], palette["outline"], palette["outline"]


def ring_bands(frame, box, switch):
    x, y = map(math.floor, center(box))
    left = math.floor(box["x"])
    if switch:
        right = math.ceil(box["x"] + box["width"])
        top = math.floor(box["y"])
        bottom = math.ceil(box["y"] + box["height"])
        return {
            "left": {(col, row) for col in range(left, left + 4) for row in range(y - 3, y + 4)},
            "right": {(col, row) for col in range(right - 4, right) for row in range(y - 3, y + 4)},
            "top": {(col, row) for col in range(x - 3, x + 4) for row in range(top, top + 4)},
            "bottom": {(col, row) for col in range(x - 3, x + 4) for row in range(bottom - 4, bottom)},
        }
    if y < 6 or y >= frame["height"] - 6:
        y = math.floor(max(box["y"] + 8., frame["viewport"]["y"] + 8.))
    return {"left": {(col, row) for col in range(left, left + 4) for row in range(y - 3, y + 4)}}


def paint(case, frame, receipt, item, geometry, rtl, scale, value, focus_id, phase):
    primary, target, track, thumb, body, divider, _ = geometry
    palette = case.plan.palette["dark" if case.dark else "light"]
    bg, ink = palette["surface"], palette["on_surface"]
    muted, secondary = palette["on_surface_variant"], palette["secondary"]
    compare = lambda a, b: color_matches(a, b, 10)
    clip = frame["viewport"]
    text_slots = {}
    text_ops = paint_entries(receipt, ("Text", "StyledText"))
    for slot, box in body.items():
        font, line_height = BASE["TEXT_METRICS"][slot]
        n, bands = complete_bands(box, line_height * scale, clip)
        text_ink = ink if slot == "headline" else muted
        if item == PRIMARY_DISABLED:
            text_ink = blend(bg, ink, .30 if slot == "headline" else .38)
        if bands:
            text = ROWS[item][2][slot]
            own = [op for op in text_ops if op["text"] == text and same_rect(op["rect"], box)]
            require(len(own) == 1 and own[0]["color"] == text_ink, f"{item}: missing {slot} paint")
            close(own[0]["style"]["font_size"], font * scale, f"{slot}: scaled font")
            close(own[0]["style"]["line_height"], line_height * scale, f"{slot}: scaled line height")
        text_slots[slot] = n, bands, text_ink

    wanted = [band for _, bands, _ in text_slots.values() for band in bands.values()]
    strokes = paint_entries(receipt, ("Stroke", "ShapeStroke"))
    fills = paint_entries(receipt, ("Quad", "Shape"))
    focused_ring = None
    for suffix, box, ring_ink in ((PRIMARY, primary, ink), (SWITCH, target, secondary)):
        if suffix == PRIMARY:
            test_rect = {**box, "width": 2.}
            matches = [op for op in fills if same_rect(op["rect"], test_rect) and op["color"] == ring_ink]
        else:
            matches = [op for op in strokes if same_rect(op["rect"], box) and op["color"] == ring_ink
                       and abs(op["width"] - 2.) < .03]
        require(len(matches) == int(focus_id == item + suffix),
                f"{item}{suffix}: wrong number of focus outlines ({len(matches)})")
        if matches:
            focus_edges = ring_bands(frame, box, suffix == SWITCH)
            wanted.extend(focus_edges.values())
            focused_ring = {"id": item + suffix, "ink": ring_ink}

    ruler = None
    if divider and contains(clip, divider):
        require(any(op["color"] == palette["outline_variant"] and same_rect(op["rect"], divider)
                    for op in fills), "Missing inset divider paint")
        x, _ = center(divider)
        ruler = {(math.floor(x), y) for y in range(math.floor(divider["y"]), math.ceil(divider["y"] + 1))}
        wanted.append(ruler)

    show_track = contains(clip, track)
    switch = None
    if show_track:
        checked = value == "True"
        fill, handle, border = palette_roles(palette, checked, item == DISABLED)
        for bounds, color, subject in ((track, fill, "track"), (thumb, handle, "thumb")):
            require(any(op["color"] == color and same_rect(op["rect"], bounds) for op in fills),
                    f"{item}: missing {value} {subject} paint")
        track_strokes = [op for op in strokes if same_rect(op["rect"], track)]
        if border is not None:
            require(any(op["color"] == border and abs(op["width"] - 2.) < .03 for op in track_strokes),
                    f"{item}: off switch has no 2dp outline")
        else:
            require(not track_strokes, f"{item}: on switch painted the off-state outline")
        tx, ty = center(thumb)
        mid = center(track)[0]
        opposite = mid * 2 - tx + (4. if tx < mid else -4.)
        # A 4 dp square on the empty end of the track, clear of the thumb.
        track_sample = sample_points({"x": opposite - 2., "y": ty - 2., "width": 4., "height": 4.})
        thumb_sample = sample_points({"x": tx - 2., "y": ty - 2., "width": 4., "height": 4.})
        # Sample the straight edge away from both the thumb halo and the
        # switch focus outline that passes over the extreme track ends.
        edge_x = math.floor(mid + (6. if tx < mid else -6.))
        bottom = math.ceil(track["y"] + track["height"])
        outline_sample = {(x, y) for x in range(edge_x - 1, edge_x + 2)
                          for y in range(bottom - 4, bottom)}
        wanted += [track_sample, thumb_sample, outline_sample]

        halo = by_center(thumb, 40.)
        ripples = [op["Ripple"] for op in receipt["presented"]["ops"] if "Ripple" in op
                   and same_rect(op["Ripple"]["bounds"], halo)]
        if phase == "press":
            require(len(ripples) == 1, "Held pointer did not paint the bounded switch ripple")
            ripple = ripples[0]["ripple"]
            close(ripple["x"], tx, "Ripple center follows thumb horizontally")
            close(ripple["y"], ty, "Ripple center follows thumb vertically")
            require(15. <= ripple["radius"] <= 20. and ripple["color"][:3] == ink[:3] and ripple["color"][3] > 0,
                    f"Unexpected press ripple: {ripple}")
        else:
            require(not ripples, "Idle or hovered switch painted a press ripple")
        if phase == "hover":
            state_fills = [op["color"] for op in fills if same_rect(op["rect"], halo)]
            require(any(color[:3] == ink[:3] and 0 < color[3] < 31 for color in state_fills),
                    "Off hover did not paint the 40 dp state layer")
    require(wanted, "No list content was visible")
    values = pixels_for(case.plan.artifacts / frame["file"], frame, set.union(*wanted))
    text = {}
    for slot, (total, bands, text_ink) in text_slots.items():
        ink_counts = {str(i): sum(visible_ink(values[p], text_ink, bg) for p in band) for i, band in bands.items()}
        require(all(n >= 4 for n in ink_counts.values()), f"{item}-{slot}: missing CJK pixels")
        text[slot] = {"total": total, "sampled_ink": ink_counts}
    if ruler:
        require(any(visible_ink(values[p], palette["outline_variant"], bg) for p in ruler),
                "The inset divider did not reach PNG")
    if focused_ring:
        measured = {edge: sum(compare(values[p], focused_ring["ink"]) for p in band)
                    for edge, band in focus_edges.items()}
        require(min(measured.values()) >= 3, f"{focused_ring['id']}: focus ring obscured on an edge: {measured}")
        focused_ring["edge_ink_pixels"] = measured
    if show_track:
        thumb_pixels = sum(compare(values[p], handle) for p in thumb_sample)
        require(thumb_pixels >= .9 * len(thumb_sample) >= 8, f"{item}: native thumb lacks its expected color ({thumb_pixels} pixels)")
        track_pixels = sum(compare(values[p], fill) for p in track_sample)
        require(track_pixels >= .9 * len(track_sample) >= 8, f"{item}: native track lacks its expected color ({track_pixels} pixels)")
        outline_pixels = 0
        if border is not None:
            outline_pixels = sum(compare(values[p], border) for p in outline_sample)
            require(outline_pixels >= 1, f"{item}: native off outline did not reach pixels")
        switch = {"state": value, "phase": phase, "track_fill": fill, "thumb_fill": handle,
                  "track_pixels": track_pixels, "thumb_pixels": thumb_pixels,
                  "outline": border, "outline_pixels": outline_pixels}
    return {"text": text, "switch": switch, "divider_pixels": bool(ruler), "focus_ring": focused_ring}


def take(case, stage, item, rtl, scale, value, counts=(0, 0), offset=None, focused=None, phase="rest"):
    case.clock.advance({"hover": 120, "press": 160}.get(phase, 700))
    if offset is not None:
        y = rect(case.snapshot(), item)["y"]
        case.point("scroll", (12., case.size[1] / 2.), y - (5. - offset))
        close(rect(case.snapshot(), item)["y"], 5. - offset, f"{item}: scrolled view")
        oversize = True
    elif phase == "rest":
        oversize = frame_row(case, item)
    else:
        oversize = False
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{stage}",
                              case.size, case.dark, SECTION)
    require(not frame["errors"], str(frame["errors"]))
    count(case, counts)
    focus_id = snapshot["interaction"]["focused"]
    if focused:
        require(focus_id == focused, f"Expected focus {focused}; observed {focus_id}")
    receipt = json.loads(case.receipt.read_text())
    boxes = geometry(case, snapshot, item, rtl, scale, value)
    primary, target, track, thumb, body, divider, item_box = boxes
    axis = a11y(snapshot, receipt, item, primary, target, value)
    painted = paint(case, frame, receipt, item, boxes, rtl, scale, value, focus_id, phase)
    frame.update(stage=stage, item=item, rtl=rtl, text_scale=scale, counts=counts, focused=focus_id,
                 oversize=oversize, primary=primary, target=target, track=track, thumb=thumb,
                 body=body, divider=divider, item_box=item_box, paint=painted, accesskit=axis)
    case.frames.append(frame)
    return frame


def points(case, item):
    frame_row(case, item)
    view = case.snapshot()
    return center(rect(view, item + "-headline")), center(rect(view, item + SWITCH))


def stable(before, after):
    for label in ("primary", "target", "track"):
        origin = lambda shot: {**shot[label],
                               "x": shot[label]["x"] - shot["item_box"]["x"],
                               "y": shot[label]["y"] - shot["item_box"]["y"]}
        require(same_rect(origin(before), origin(after)), f"Changing value moved the {label}")


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2:
        case.call("action", "activate", SCALE)
    case.point("leave")
    result = {"mcp": None}
    rest, cjk = {}, {}
    for item, data in ROWS.items():
        stage = item.removeprefix(PREFIX)
        first = take(case, stage, item, rtl, scale, data[3])
        require(first["paint"]["switch"], f"{item}: initial frame missed the track")
        rest[item] = first
        if item == GROUP and case.size[0] == 320 and case.dark and rtl and scale == 2:
            mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
            require((case.plan.artifacts / mcp["file"]).read_bytes() ==
                    (case.plan.artifacts / first["file"]).read_bytes(), "CLI/MCP PNG bytes differ")
            result["mcp"] = {**mcp, "cli": first["file"]}
        frames = [first]
        if first["oversize"]:
            travel = first["item_box"]["height"] - case.size[1] + 10.
            step = round(case.size[1] - 10. - 24. * scale)
            for i, offset in enumerate(range(step, math.ceil(travel), step), 1):
                frames.append(take(case, f"{stage}-middle-{i}", item, rtl, scale, data[3], offset=offset))
            frames.append(take(case, stage + "-tail", item, rtl, scale, data[3], offset=travel))
        cjk[stage] = all_bands(*frames)
        if item != DISABLED:
            pointer(case, center(frames[-1]["divider"]), (0, 0), (0, 0))

    p, t = points(case, GROUP)
    inactive_release(case, p, t, GROUP + PRIMARY, (0, 0))
    inactive_release(case, t, p, GROUP + SWITCH, (0, 0))
    touch_cancel(case, p, GROUP + PRIMARY, (0, 0))
    touch_cancel(case, t, GROUP + SWITCH, (0, 0))
    press_ax(case, GROUP + SWITCH)
    stable(rest[GROUP], take(case, "group-off-accesskit", GROUP, rtl, scale, "False", (0, 1)))
    reject(case, "focus", GROUP + TRACK, "no live AccessKit focus")
    reject(case, "press", GROUP + THUMB, "no live AccessKit press")

    _, t = points(case, FILE)
    case.point("move", t)
    take(case, "file-hover", FILE, rtl, scale, "False", (0, 1), phase="hover")
    case.point("down", t)
    require(case.snapshot()["interaction"]["pressed"] == FILE + SWITCH, "Wrong Winit switch owner")
    take(case, "file-press", FILE, rtl, scale, "False", (0, 1), phase="press")
    case.point("up", t)
    case.point("leave")
    stable(rest[FILE], take(case, "file-on-pointer", FILE, rtl, scale, "True", (0, 2)))

    p, t = points(case, PRIMARY_DISABLED)
    pointer(case, p, (0, 2), (0, 2))
    reject(case, "press", PRIMARY_DISABLED + PRIMARY, "no live AccessKit press")
    pointer(case, t, (0, 2), (0, 3), PRIMARY_DISABLED + SWITCH)
    stable(rest[PRIMARY_DISABLED], take(case, "archive-off-pointer", PRIMARY_DISABLED, rtl, scale,
                                        "False", (0, 3)))
    p, t = points(case, DISABLED)
    pointer(case, t, (0, 3), (0, 3))
    reject(case, "press", DISABLED + SWITCH, "no live AccessKit press")
    pointer(case, p, (0, 3), (1, 3), DISABLED + PRIMARY)
    stable(rest[DISABLED], take(case, "disabled-unchanged", DISABLED, rtl, scale, "False", (1, 3)))

    idle = take(case, "group-off-rest", GROUP, rtl, scale, "False", (1, 3))
    require(idle["paint"]["focus_ring"] is None, "The Off baseline has focus paint")
    focus(case, SCALE)
    key(case, "tab", FILE + PRIMARY)
    key(case, "tab", FILE + SWITCH)
    key(case, "tab", GROUP + PRIMARY)
    count(case, (1, 3))
    key(case, "enter", GROUP + PRIMARY)
    take(case, "group-primary-focus", GROUP, rtl, scale, "False", (2, 3), focused=GROUP + PRIMARY)
    key(case, "tab", GROUP + SWITCH)
    count(case, (2, 3))
    key(case, "space", GROUP + SWITCH)
    stable(rest[GROUP], take(case, "group-on-focus", GROUP, rtl, scale, "True", (2, 4),
                             focused=GROUP + SWITCH))
    key(case, "tab", PRIMARY_DISABLED + SWITCH)
    key(case, "enter", PRIMARY_DISABLED + SWITCH)
    take(case, "archive-on-enter", PRIMARY_DISABLED, rtl, scale, "True", (2, 5),
         focused=PRIMARY_DISABLED + SWITCH)
    key(case, "tab", DISABLED + PRIMARY)
    key(case, "enter", DISABLED + PRIMARY)
    count(case, (3, 5))
    case.call("action", "qa-key", "tab")
    last_focus = case.snapshot()["interaction"]["focused"]
    require(last_focus not in (DISABLED + SWITCH, DISABLED + PRIMARY),
            f"Tab failed to leave the final row: {last_focus}")
    count(case, (3, 5))
    frame_row(case, GROUP)
    press_ax(case, GROUP + PRIMARY)
    count(case, (4, 5))
    press_ax(case, GROUP + SWITCH)
    take(case, "group-off-again", GROUP, rtl, scale, "False", (4, 6))

    return {**result, "cjk_visible_lines": cjk, "final": [4, 6], "cross_target_releases": 2,
            "winit_touch_cancellations": 2, "passive_pointer_attempts": 5, "denied_accesskit_requests": 4}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile")
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--startup-timeout", type=int, default=45)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "runs": {}, "frames": [], "errors": []}
    for viewport, theme, direction, scale in PROFILES:
        name = f"{viewport}-{theme}-{direction}-{scale}x"
        if plan.profile not in (None, name) or plan.theme not in (None, theme):
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, VIEWPORTS[viewport], theme == "dark") as case:
                result = journey(case, direction == "rtl", scale)
            output = (plan.artifacts / f"{name}.log").read_text()
            metal = next((line for line in output.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in metal and "backend: Metal" in metal, f"{name}: did not use Metal")
            report["runs"][name] = {**result, "adapter": metal}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(report["errors"][-1], flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"] and report["runs"], "\n".join(report["errors"]) or "No matching journey")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
