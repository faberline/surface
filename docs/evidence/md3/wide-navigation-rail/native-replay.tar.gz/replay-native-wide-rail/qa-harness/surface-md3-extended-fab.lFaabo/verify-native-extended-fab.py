#!/usr/bin/env python3
"""Verify the controlled Extended FAB against an isolated native Gallery."""

import argparse
from collections import Counter
from contextlib import contextmanager
import json
import math
import os
from pathlib import Path
import runpy
import subprocess
import tempfile
import time


HERE = Path(__file__).resolve().parent
COMMON = runpy.run_path(str(HERE.parent / "surface-md3-button.xczNtB/verify-native-buttons.py"))
call = COMMON["call"]
capture = COMMON["capture"]
check_mcp = COMMON["check_mcp"]
coords = COMMON["coords"]
descendants = COMMON["descendants"]
dom_index = COMMON["dom_index"]
focus = COMMON["focus"]
is_inside = COMMON["is_inside"]
make_active = COMMON["make_active"]
match_tinted = COMMON["match_tinted"]
png_pixels = COMMON["png_pixels"]
require = COMMON["require"]
rgba_near = COMMON["rgba_near"]
stop = COMMON["stop"]
visibles = COMMON["visibles"]
wait_for_session = COMMON["wait_for_session"]
window_state = COMMON["window_state"]
write_json = COMMON["write_json"]

SECTION = "section-1"
BUTTON = "extended-fab-controlled"
RTL = "extended-fab-controlled-rtl"
DISABLED = "extended-fab-controlled-disabled"
NAME = "建立圖片"
DISABLED_NAME = "無法建立圖片"


@contextmanager
def gallery(plan, client, binary, label):
    with (
        tempfile.TemporaryDirectory(prefix="surface-extended-fab-", dir="/private/tmp") as folder,
        (plan.artifacts / f"{label}.log").open("wb") as log,
    ):
        session = Path(folder) / "session.json"
        env = dict(os.environ, SURFACE_DEVTOOLS_SESSION=str(session), SURFACE_REDUCED_MOTION="1")
        env.pop("SURFACE_TRACE", None)
        env.pop("SURFACE_BRIDGE_SESSION", None)
        child = subprocess.Popen(
            (binary,), cwd=HERE / "qa", env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
        )
        try:
            wait_for_session(session, child)
            require("Page.screenshot" in call(client, session, "capabilities")["methods"],
                    "screenshot capability missing")
            nodes, index = dom_index(call(client, session, "dom", "snapshot"))
            if nodes[index["theme"]]["checked"]:
                call(client, session, "action", "activate", "theme")
            call(client, session, "action", "activate", SECTION)
            yield session, child
        finally:
            stop(child)


def subject(snapshot):
    nodes, index = dom_index(snapshot)
    button = index[BUTTON]
    disabled = nodes[index[DISABLED]]
    require(disabled["role"] == "Button" and disabled["disabled"] and disabled["name"] == DISABLED_NAME,
            f"disabled specimen lacks the expected semantics: {disabled.get('name')}")
    node = nodes[button]
    require(
        node["role"] == "Button" and node["name"] == NAME and not node["disabled"]
        and node.get("expanded") is None and node.get("checked") is None,
        "controlled FAB is not a plain enabled action with its full name",
    )
    children = list(descendants(nodes, button))
    glyphs = [i for i in children if nodes[i].get("text") == "+"]
    labels = [i for i in children if nodes[i].get("text") == NAME]
    require(len(glyphs) == 1 and len(labels) <= 1, f"unexpected glyphs/labels: {glyphs}, {labels}")
    return nodes, button, glyphs[0], labels[0] if labels else None


def is_expanded(snapshot):
    return subject(snapshot)[-1] is not None


def reveal(client, session, expanded):
    current = call(client, session, "dom", "snapshot")
    observations = []
    for _ in range(4):
        observed = is_expanded(current)
        if visibles(current, (BUTTON,)) and observed == expanded:
            return
        _, index = dom_index(current)
        geometry = current["layout"]["nodes"][index[BUTTON]]
        observations.append({"expanded": observed, "bounds": geometry["bounds"],
                             "clip": geometry["clip"], "focus": current["interaction"]["focused"]})
        call(client, session, "action", "activate", BUTTON)
        current = call(client, session, "dom", "snapshot")
    raise RuntimeError(f"could not fully reveal the FAB with expanded={expanded}: {observations}")


def close(actual, expected, label):
    require(math.isclose(actual, expected, abs_tol=0.6),
            f"{label} is {actual} dp, expected {expected} dp")


def center(bounds):
    return bounds["x"] + bounds["width"] / 2


def overlap(first, second):
    return {
        length: max(0., min(first[axis] + first[length], second[axis] + second[length])
                    - max(first[axis], second[axis]))
        for axis, length in (("x", "width"), ("y", "height"))
    }


def outline(snapshot, expanded, rtl):
    nodes, button, glyph, label = subject(snapshot)
    layout = snapshot["layout"]["nodes"]
    hit = layout[button]["bounds"]
    glyph_box = nodes[glyph]["parent"]
    glyph_bounds = layout[glyph_box]["bounds"]
    close(hit["height"], 56., "action height")
    close(glyph_bounds["width"], 24., "glyph width")
    close(glyph_bounds["height"], 24., "glyph height")
    close(glyph_bounds["y"] + glyph_bounds["height"] / 2,
          hit["y"] + hit["height"] / 2, "glyph vertical center")
    require(is_inside(glyph_bounds, hit) and is_inside(glyph_bounds, layout[glyph_box]["clip"]),
            "glyph is clipped")
    detail = {
        "hit": hit, "glyph": glyph_bounds, "name": nodes[button]["name"],
        "expanded": expanded, "rtl": rtl, "focus": snapshot["interaction"]["focused"],
        "hover": snapshot["interaction"]["hovered"],
        "fill": nodes[button]["style"]["background"],
        "glyph_ink": nodes[glyph]["style"]["foreground"],
    }
    fixed_action = next((i for i, node in enumerate(nodes)
                         if node.get("stable_id") == "gallery-fab-toggle"), None)
    if fixed_action is not None:
        covered = overlap(hit, layout[fixed_action]["bounds"])
        require(not (covered["width"] > 0.01 and covered["height"] > 0.01),
                f"fixed Gallery action obscures the controlled FAB: {covered}")
        detail["fixed_overlay_overlap"] = covered
    if expanded:
        require(hit["width"] >= 80. and label is not None, "expanded FAB lacks its label or 80 dp width")
        label_bounds = layout[label]["bounds"]
        require(is_inside(label_bounds, hit) and is_inside(label_bounds, layout[label]["clip"]),
                f"expanded label is clipped: {label_bounds}")
        if rtl:
            padding = [
                hit["x"] + hit["width"] - glyph_bounds["x"] - glyph_bounds["width"],
                glyph_bounds["x"] - label_bounds["x"] - label_bounds["width"],
                label_bounds["x"] - hit["x"],
            ]
        else:
            padding = [
                glyph_bounds["x"] - hit["x"],
                label_bounds["x"] - glyph_bounds["x"] - glyph_bounds["width"],
                hit["x"] + hit["width"] - label_bounds["x"] - label_bounds["width"],
            ]
        for actual, expected, attribute in zip(padding, (16., 12., 20.), ("start", "gap", "end")):
            close(actual, expected, attribute)
        detail.update({"label": label_bounds, "label_ink": nodes[label]["style"]["foreground"],
                       "logical_spacing": padding})
    else:
        close(hit["width"], 56., "collapsed action width")
        close(center(glyph_bounds), center(hit), "collapsed glyph horizontal center")
        require(label is None, "collapsed FAB still has a painted label")
    return detail


def pixels_for(plan, details, geometry):
    hit = geometry["hit"]
    cx = math.floor(center(hit))
    top = math.ceil(hit["y"] + 8)
    body = [(x, y) for x in range(cx - 4, cx + 5) for y in range(top, top + 4)]
    canvas = (details["width"], details["height"])
    glyph = list(coords(geometry["glyph"], canvas))
    label = list(coords(geometry["label"], canvas)) if geometry["expanded"] else []
    pixels = png_pixels(plan.artifacts / details["file"], details, {*body, *glyph, *label})
    fill = tuple(geometry["fill"])
    backdrop = Counter(tuple(pixels[pos]) for pos in body).most_common(1)[0][0]
    require(rgba_near(fill, backdrop, 35 if geometry["hover"] == BUTTON else 3),
            f"painted face differs from its fill: {backdrop}, {fill}")
    for points, channel in ((glyph, "glyph_ink"), (label, "label_ink")):
        if points:
            matching = sum(match_tinted(pixels[pos], backdrop, [tuple(geometry[channel])]) for pos in points)
            require(matching >= 5, f"{channel} lacks visible shape pixels: {matching}")
            geometry[f"{channel}_pixel_count"] = matching
    geometry["painted_fill"] = backdrop


def verify_size(plan, client, binary, key, size, report):
    with gallery(plan, client, binary, key) as (session, _):
        for theme in ("light", "dark"):
            dark = theme == "dark"
            if dark:
                call(client, session, "action", "activate", "theme")
            for rtl in (False, True):
                if rtl:
                    call(client, session, "action", "activate", RTL)
                direction = "rtl" if rtl else "ltr"
                for expanded in (True, False):
                    reveal(client, session, expanded)
                    state = "expanded" if expanded else "collapsed"
                    prefix = f"{key}-{theme}-{direction}-{state}"
                    details, snapshot = capture(plan, client, session, prefix, size, dark, SECTION, (BUTTON,))
                    require(not details["errors"], "; ".join(details["errors"]))
                    details["fab"] = outline(snapshot, expanded, rtl)
                    pixels_for(plan, details, details["fab"])
                    report["frames"].append(details)
                    if key == "compact" and dark and rtl and not expanded:
                        mcp = check_mcp(plan, client, session, size)
                        require(mcp["sha256"] == details["sha256"], "CLI and MCP PNG bytes differ")
                        report["mcp"] = mcp
            call(client, session, "action", "activate", RTL)


def query_ax(probe, child, *names):
    result = json.loads(subprocess.check_output(
        (probe, str(child.pid), *names), text=True, timeout=12,
    ))
    require(result["trusted"] and result["queried"], "native AX probe lacks trust")
    return result


def read_ax(plan, child, expected, disabled=False):
    name = DISABLED_NAME if disabled else NAME
    result = None
    reacquired = False
    for _ in range(8):
        result = query_ax(plan.probe, child, name)
        if not result["active"] and not reacquired:
            make_active(plan.probe, child)
            reacquired = True
            continue
        if result["active"] and len(result["matches"]) == 1:
            detail = result["matches"][0]
            if disabled or detail.get("focused") is True:
                break
        time.sleep(0.10)
    else:
        raise RuntimeError(f"native AX did not expose one {name} action: {result}")
    actions = detail.get("actions", [])
    require(detail["role"] == "AXButton" and detail["label"] == name and "expanded" not in detail,
            f"unexpected role, name or disclosure state: {detail}")
    require(detail["enabled"] is not disabled and ("AXPress" in actions) is not disabled,
            f"unexpected native action availability: {detail}")
    close(detail["size"]["height"], expected["height"], "AX target height")
    close(detail["size"]["width"], expected["width"], "AX target width")
    return detail


def keyboard_step(plan, client, session, child, key, before, after):
    def active():
        state = window_state(plan.probe, child)
        if state["active"]:
            return state
        attempt = make_active(plan.probe, child)
        return {**attempt["after"], "reacquired": True}

    host_before = active()
    focus(client, session, before)
    event = call(client, session, "action", "key", key)
    host_after = active()
    require(event["focused"] == after, f"key {key} focus result: {event}")
    focus(client, session, after)
    return {
        "key": key, "from": before, "to": after, "response": event,
        "host_before": host_before, "host_after": host_after,
    }


def verify_ax(plan, client, binary, width, report):
    with gallery(plan, client, binary, f"{width}-accessibility") as (session, child):
        report["activation"][width] = make_active(plan.probe, child)
        call(client, session, "action", "activate", RTL)
        snapshot = call(client, session, "dom", "snapshot")
        _, index = dom_index(snapshot)
        bounds = snapshot["layout"]["nodes"][index[DISABLED]]["bounds"]
        report["disabled"][width] = read_ax(plan, child, bounds, disabled=True)
        trace = []
        report["keyboard"][width] = trace
        trace.append(keyboard_step(plan, client, session, child, "tab", RTL, BUTTON))
        for step, expanded in ((None, True), ("enter", False), ("space", True)):
            if step:
                trace.append(keyboard_step(plan, client, session, child, step, BUTTON, BUTTON))
            geometry = outline(focus(client, session, BUTTON), expanded, True)
            report["ax"].append({
                "viewport": width, "key": step or "tab", "expanded": expanded, "body": geometry,
                "native": read_ax(plan, child, geometry["hit"]),
            })
        request = query_ax(plan.probe, child, NAME, "--press")
        require(request.get("pressStatus") == 0, f"native AXPress failed: {request}")
        for _ in range(10):
            snapshot = focus(client, session, BUTTON)
            if not is_expanded(snapshot):
                break
            time.sleep(0.08)
        require(not is_expanded(snapshot), "native AXPress did not change the FAB state")
        geometry = outline(snapshot, False, True)
        report["ax"].append({"viewport": width, "key": "AXPress", "expanded": False, "body": geometry,
                             "native": read_ax(plan, child, geometry["hit"])})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--probe", type=Path, required=True)
    parser.add_argument("--mode", choices=("visual", "ax", "all"), default="all")
    parser.add_argument("--viewport", choices=("wide", "compact", "narrow"))
    plan = parser.parse_args()
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    report = {
        "capture": "Surface Page.screenshot", "frames": [], "keyboard": {}, "ax": [],
        "activation": {}, "disabled": {}, "errors": [],
    }
    client = plan.debug_dir / "surface-devtools"
    viewports = (
        ("wide", plan.debug_dir / "surface-material-gallery", (960, 800)),
        ("compact", plan.debug_dir / "examples/compact", (420, 360)),
        ("narrow", plan.debug_dir / "examples/extended_fab_narrow", (320, 360)),
    )
    errors = (RuntimeError, KeyError, ValueError, TypeError, OSError, subprocess.SubprocessError)
    if plan.mode in ("visual", "all"):
        for key, binary, size in viewports:
            if plan.viewport and key != plan.viewport:
                continue
            try:
                verify_size(plan, client, binary, key, size, report)
            except errors as error:
                report["errors"].append(f"{key}: {error}")
    if plan.mode in ("ax", "all"):
        for key, binary, _ in viewports:
            if plan.viewport and key != plan.viewport:
                continue
            try:
                verify_ax(plan, client, binary, key, report)
            except errors as error:
                report["errors"].append(f"{key} AX: {error}")
    write_json(plan.artifacts / "report.json", report)
    if report["errors"]:
        raise SystemExit("\n".join(report["errors"]))
    print(f"Passed {len(report['frames'])} PNG frames and {len(report['ax'])} native AX states")


if __name__ == "__main__":
    main()
