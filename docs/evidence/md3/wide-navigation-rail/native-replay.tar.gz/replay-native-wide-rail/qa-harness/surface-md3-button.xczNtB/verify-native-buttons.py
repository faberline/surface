#!/usr/bin/env python3
"""Exercise Surface common buttons in a private native Gallery."""

import argparse
from collections import Counter
from contextlib import contextmanager
import json
import math
import os
from pathlib import Path
import runpy
import subprocess
import tempfile
import time


HERE = Path(__file__).resolve().parent
COMMON = runpy.run_path(str(HERE.parent / "surface-md3-icon.Lll0y0/verify-native-icons.py"))
call = COMMON["call"]
capture = COMMON["capture"]
check_mcp = COMMON["check_mcp"]
coords = COMMON["coords"]
dom_index = COMMON["dom_index"]
focus = COMMON["focus"]
key_step = COMMON["key_step"]
make_active = COMMON["make_active"]
png_pixels = COMMON["png_pixels"]
require = COMMON["require"]
rgb_over = COMMON["rgb_over"]
rgba_near = COMMON["rgba_near"]
stop = COMMON["stop"]
wait_for_session = COMMON["wait_for_session"]
window_state = COMMON["window_state"]
write_json = COMMON["write_json"]

SECTION = "section-3"
CARD = "expressive-button-specimen"
XS, SMALL, MEDIUM, TEXT, DISABLED, LARGE, XL = (
    f"expressive-button-{size}" for size in ("xs", "small", "medium", "text", "disabled", "large", "xl")
)
RTL, ENLARGE = "expressive-button-rtl", "expressive-button-enlarge"
SAMPLES = {
    XS: ("開始", 32, False, "▶", 0),
    SMALL: ("收藏", 40, True, None, 0),
    MEDIUM: ("釘選", 56, True, "◆", 0),
    TEXT: ("取消", 40, False, None, 0),
    DISABLED: ("無法送出", 32, False, None, 1),
    LARGE: ("匯出", 96, False, None, 2),
    XL: ("開", 136, False, None, 0),
}
COMPACT = (XS, SMALL, MEDIUM, TEXT, DISABLED)
BIG = (LARGE, XL)
VIEWPORTS = {"wide": (960, 800), "compact": (420, 360), "narrow": (320, 360)}
PROBE = Path("/private/tmp/surface-button-xczNtB-ax")


@contextmanager
def gallery(plan, client, binary, label):
    with (
        tempfile.TemporaryDirectory(prefix="surface-button-", dir="/private/tmp") as folder,
        (plan.artifacts / f"{label}.log").open("wb") as log,
    ):
        session = Path(folder) / "session.json"
        env = dict(os.environ, SURFACE_DEVTOOLS_SESSION=str(session), SURFACE_REDUCED_MOTION="1")
        env.pop("SURFACE_TRACE", None)
        env.pop("SURFACE_BRIDGE_SESSION", None)
        child = subprocess.Popen(
            (binary,), cwd=HERE / "qa", env=env, stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT,
        )
        try:
            wait_for_session(session, child)
            methods = call(client, session, "capabilities")["methods"]
            require("Page.screenshot" in methods, "screenshot capability missing")
            nodes, index = dom_index(call(client, session, "dom", "snapshot"))
            if nodes[index["theme"]]["checked"]:
                call(client, session, "action", "activate", "theme")
            call(client, session, "action", "activate", SECTION)
            yield session, child
        finally:
            stop(child)


def is_inside(rect, clip):
    x, y = rect["x"], rect["y"]
    return (rect["width"] > 0 and rect["height"] > 0
            and x >= clip["x"] - 0.01 and y >= clip["y"] - 0.01
            and x + rect["width"] <= clip["x"] + clip["width"] + 0.01
            and y + rect["height"] <= clip["y"] + clip["height"] + 0.01)


def visibles(snapshot, keys):
    _, index = dom_index(snapshot)
    layout = snapshot["layout"]
    return [key for key in keys
            if is_inside(layout["nodes"][index[key]]["bounds"], layout["nodes"][index[key]]["clip"])
            and is_inside(layout["nodes"][index[key]]["bounds"], layout["viewport"])]


def descendants(nodes, owner):
    index = nodes[owner]["first_child"]
    while index is not None:
        yield index
        yield from descendants(nodes, index)
        index = nodes[index]["next_sibling"]


def match_tinted(pixel, backdrop, possible):
    reference = max(possible, key=lambda c: sum(abs(a - b) for a, b in zip(c, backdrop)))
    return (any(abs(a - b) >= 8 for a, b in zip(pixel, backdrop))
            and all(min(a, b) - 3 <= s <= max(a, b) + 3
                    for s, a, b in zip(pixel, backdrop, reference)))


def read_samples(plan, details, snapshot, ids, selected=(), rtl=False, enlarged=False, pressed=False):
    require(not details["errors"], "; ".join(details["errors"]))
    nodes, index = dom_index(snapshot)
    layout = snapshot["layout"]["nodes"]
    card_fill = tuple(nodes[index[CARD]]["style"]["background"])
    size = details["width"], details["height"]
    samples = {}
    areas = {}
    for key in ids:
        label, nominal, toggle, glyph, outline = SAMPLES[key]
        node = nodes[index[key]]
        role = "Checkbox" if toggle else "Button"
        require((node["role"], node["name"], node["disabled"])
                == (role, label, key == DISABLED), f"{key} has wrong semantics: {node['role']}")
        require(node.get("checked") is ((key in selected) if toggle else None),
                f"{key} wrong checked state")
        hit = layout[index[key]]["bounds"]
        f = node["first_child"]
        face = layout[f]["bounds"]
        require(is_inside(face, hit) and hit["width"] >= 48 and hit["height"] >= max(48, nominal),
                f"{key} hit target {hit} and face {face}")
        require(face["height"] >= nominal if enlarged else math.isclose(face["height"], nominal, abs_tol=0.1),
                f"{key} face {face['height']} expected {nominal} at normal scale")
        require(math.isclose(face["y"], hit["y"] + (hit["height"] - face["height"]) / 2, abs_tol=0.05),
                f"{key} face is not vertically centered")

        style = nodes[f]["style"]
        require(math.isclose(style["border_width"], outline, abs_tol=0.01),
                f"{key} outline is {style['border_width']}, expected {outline}")
        if key in (XS, SMALL, MEDIUM, XL):
            require(style["background"][3] == 255 and tuple(style["background"]) != card_fill,
                    f"{key} does not have a distinct opaque fill")
        name_index = next(i for i in descendants(nodes, f) if nodes[i]["text"] == label)
        name_bounds = layout[name_index]["bounds"]
        require(is_inside(name_bounds, face) and is_inside(name_bounds, layout[name_index]["clip"]),
                f"{key} label clipped: {name_bounds} in {face}")
        name_ink = nodes[name_index]["style"]["foreground"]
        m = {"hit": hit, "face": face, "label": name_bounds, "ink": name_ink,
             "fill": style["background"], "border": style["border_color"], "outline": outline,
             "corners": style["corners"], "checked": node["checked"]}
        areas[key] = {"face": coords(face, size), "label": coords(name_bounds, size)}
        if glyph:
            glyph_index = next(i for i in descendants(nodes, f) if nodes[i]["text"] == glyph)
            symbol = layout[glyph_index]["bounds"]
            require(is_inside(symbol, face), f"{key} glyph outside face: {symbol}")
            icon_on_left = symbol["x"] + symbol["width"] / 2 < name_bounds["x"] + name_bounds["width"] / 2
            require(icon_on_left == ((key == XS) != rtl), f"{key} glyph side is wrong in RTL={rtl}")
            m["icon"] = symbol
            m["icon_on_left"] = icon_on_left
            areas[key]["icon"] = coords(symbol, size)
        if key == SMALL:
            # Under the visual face and away from the label and adjacent controls.
            areas[key]["shadow"] = [
                (x, y)
                for y in range(math.ceil(face["y"] + face["height"]), min(
                    size[1], math.ceil(face["y"] + face["height"]) + 3))
                for x in range(math.ceil(face["x"] + face["width"] * 0.25),
                               math.floor(face["x"] + face["width"] * 0.75))
            ]
        samples[key] = m

    points = {p for button in areas.values() for region in button.values() for p in region}
    image = png_pixels(plan.artifacts / details["file"], details, points)
    for key, m in samples.items():
        regions = {region: [tuple(image[p]) for p in region_points]
                   for region, region_points in areas[key].items()}
        backdrops = rgb_over(m["fill"], card_fill)
        if pressed and key == XS:
            # Held ripple and state rendering can add the ink tint.
            backdrops = [c for base in backdrops for c in rgb_over([*m["ink"][:3], 26], base)]
        pixels = regions["face"]
        colors = Counter(pixels)
        m["common_face_pixels"] = colors.most_common(3)
        solid = sum(any(rgba_near(p, c) for c in backdrops) for p in pixels)
        if not pressed:
            require(solid >= 0.3 * len(pixels), f"{key} rendered only {solid} fill pixels")
        m["fill_pixels"] = solid
        if m["outline"]:
            edge_colors = rgb_over(m["border"], card_fill)
            edge_count = sum(any(rgba_near(p, c, delta=3) for c in edge_colors)
                             and not rgba_near(p, card_fill, delta=0) for p in pixels)
            require(edge_count >= 8, f"{key} outline did not paint: {edge_count} pixels")
            m["outline_pixels"] = edge_count
        ink_choices = [c for base in backdrops for c in rgb_over(m["ink"], base)]
        for region in ("label", "icon"):
            if region not in regions:
                continue
            if m["ink"][3] < 255:
                painted = sum(match_tinted(p, card_fill, ink_choices) for p in regions[region])
            else:
                painted = sum(any(rgba_near(p, c, delta=6) for c in ink_choices)
                              for p in regions[region])
            require(painted >= 8, f"{key} has no visible {region} ink ({painted} pixels)")
            m[f"{region}_pixels"] = painted
        if "shadow" in regions:
            m["shadow_pixels"] = sum(not rgba_near(p, card_fill, delta=0) for p in regions["shadow"])
            if key not in selected and not enlarged:
                require(m["shadow_pixels"] >= 6, f"{key} cast no visible elevation shadow")
        if key == XS:
            face = m["face"]
            x, y = math.ceil(face["x"] - 0.5), math.ceil(face["y"] - 0.5)
            m["corner_face_pixels"] = [
                list(pixel) for point, pixel in zip(areas[key]["face"], pixels)
                if point[0] < x + 9 and point[1] < y + 9
            ]
            m["corner_ink_pixels"] = sum(not rgba_near(pixel, card_fill, delta=2)
                                        for pixel in m["corner_face_pixels"])
    details["buttons"] = samples
    return details


def frame(plan, client, session, label, size, dark, keys, **state):
    details, snapshot = capture(plan, client, session, label, size, dark, SECTION, keys)
    return read_samples(plan, details, snapshot, keys, **state)


def collect_views(plan, client, session, prefix, size, dark, report, **state):
    sampled = {}
    for key, pane in ((XS, "compact"), (TEXT, "compact-lower"), (LARGE, "large"), (XL, "large-lower")):
        call(client, session, "action", "activate", key)
        dom = call(client, session, "dom", "snapshot")
        frontier = COMPACT if key in COMPACT else (*COMPACT, *BIG)
        visible = visibles(dom, [k for k in frontier if k not in sampled])
        if not visible:
            continue
        details = frame(plan, client, session, f"{prefix}-{pane}", size, dark, visible, **state)
        report.append(details)
        sampled.update(details["buttons"])
    require(set(sampled) == set(SAMPLES), f"{prefix} omitted controls: {set(SAMPLES) - set(sampled)}")
    return sampled


def check_keyboard(plan, client, session, child, report):
    report["window_activation"] = make_active(PROBE, child)
    call(client, session, "action", "activate", XS)
    trace = []
    report["keyboard_trace"] = trace
    for key, before, after in (
        ("tab", XS, SMALL), ("enter", SMALL, SMALL),
        ("tab", SMALL, MEDIUM), ("enter", MEDIUM, MEDIUM),
        ("tab", MEDIUM, TEXT),
    ):
        key_step(client, session, PROBE, child, key, before, after, trace)
    state = focus(client, session, TEXT)
    keys = visibles(state, (SMALL, MEDIUM))
    require(keys == [SMALL, MEDIUM], "two selected controls are not visible")
    report["checked_frame"] = frame(
        plan, client, session, "compact-dark-checked", VIEWPORTS["compact"], True, keys,
        selected=(SMALL, MEDIUM),
    )
    rejected = subprocess.run(
        (client, "--session", session, "action", "activate", DISABLED),
        capture_output=True, text=True, timeout=12,
    )
    require(rejected.returncode and "disabled" in rejected.stderr,
            f"disabled button accepted activation: {rejected.stdout} {rejected.stderr}")
    focus(client, session, TEXT)
    key_step(client, session, PROBE, child, "tab", TEXT, LARGE, trace)
    key_step(client, session, PROBE, child, "tab", LARGE, XL, trace)
    report["disabled_rejected"] = rejected.stderr.strip()


def verify_size(plan, client, binary, label, size, report):
    with gallery(plan, client, binary, label) as (session, child):
        for dark, theme in ((False, "light"), (True, "dark")):
            if dark:
                call(client, session, "action", "activate", "theme")
            sampled = collect_views(plan, client, session, f"{label}-{theme}", size, dark, report["frames"])
            if label == "compact" and dark:
                call(client, session, "action", "activate", XS)
                plain = frame(plan, client, session, "compact-dark-cli", size, dark, (XS,))
                report["mcp_reference"] = plain
                report["mcp"] = check_mcp(plan, client, session, size)
                require(report["mcp"]["sha256"] == plain["sha256"], "MCP and CLI PNG bytes differ")
                check_keyboard(plan, client, session, child, report)
            if label == "narrow" and dark:
                call(client, session, "action", "activate", RTL)
                call(client, session, "action", "activate", ENLARGE)
                large_text = collect_views(plan, client, session, "narrow-dark-rtl-200", size, dark,
                                           report["rtl_200"], rtl=True, enlarged=True)
                for key in (XS, MEDIUM):
                    require(large_text[key]["label"]["height"] >= sampled[key]["label"]["height"] * 1.65,
                            f"{key} label did not grow at 200%")
                    require(large_text[key]["icon"]["width"] == sampled[key]["icon"]["width"],
                            f"{key} fixed icon unexpectedly grew at 200%")


def probe_target(child, *arguments):
    result = subprocess.run((PROBE, str(child.pid), *arguments), text=True,
                            capture_output=True, timeout=12)
    require(result.returncode == 0, f"Gallery AX operation failed: {result.stdout} {result.stderr}")
    return json.loads(result.stdout)


def ax_observe(client, session, child, checked, focused):
    labels = {SAMPLES[key][0]: key for key in COMPACT}
    for _ in range(6):
        value = probe_target(child, *labels)
        require(value["trusted"], "native AX probe lacks trust")
        if len(value["matches"]) == len(labels):
            break
        time.sleep(0.1)
    require(value["active"], "Gallery was not active during AX observation")
    require(len(value["matches"]) == len(labels), f"missing AX buttons: {value}")
    snapshot = call(client, session, "dom", "snapshot")
    _, index = dom_index(snapshot)
    layout = snapshot["layout"]["nodes"]
    for observed in value["matches"]:
        key = labels[observed["label"]]
        role = "AXCheckBox" if SAMPLES[key][2] else "AXButton"
        box = layout[index[key]]["bounds"]
        require(observed["role"] == role
                and math.isclose(observed["size"]["width"], box["width"], abs_tol=0.1)
                and math.isclose(observed["size"]["height"], box["height"], abs_tol=0.1),
                f"{key} native role or size mismatch {observed}")
        require(observed["enabled"] == (key != DISABLED)
                and ("AXPress" in observed["actions"]) == (key != DISABLED)
                and observed["focused"] == (key == focused),
                f"{key} native action, disabled or focus mismatch: {observed}")
        if SAMPLES[key][2]:
            require(observed.get("value") == (key in checked), f"{key} native checked mismatch")
    return value


def verify_ax(plan, client, binary, report):
    with gallery(plan, client, binary, "ax") as (session, child):
        report["window_activation"] = make_active(PROBE, child)
        for key, checked in ((XS, ()), (SMALL, (SMALL,)), (MEDIUM, (SMALL, MEDIUM))):
            call(client, session, "action", "activate", key)
            focus(client, session, key)
            report["ax"].append(ax_observe(client, session, child, checked, key))


def await_pressed(client, session, expected):
    last = None
    for _ in range(12):
        dom = call(client, session, "dom", "snapshot")
        last = dom["interaction"]["pressed"]
        if last == expected:
            return
        time.sleep(0.045)
    raise RuntimeError(f"Surface pressed state was {last!r}, expected {expected!r}")


def verify_press(plan, client, binary, report):
    with gallery(plan, client, binary, "press") as (session, child):
        size = VIEWPORTS["wide"]
        report["window_activation"] = make_active(PROBE, child)
        call(client, session, "action", "activate", XS)
        focus(client, session, XS)
        idle = frame(plan, client, session, "button-idle", size, False, (XS,))
        report["idle"] = idle
        for _ in range(6):
            native = probe_target(child, "開始")
            if native["matches"]:
                break
            time.sleep(0.12)
        require(len(native["matches"]) == 1, f"press target AX is missing: {native}")
        report["native_press_target"] = native
        try:
            report["pointer_down"] = probe_target(child, "--pointer-down", "開始")
            await_pressed(client, session, XS)
            down = frame(plan, client, session, "button-held", size, False, (XS,), pressed=True)
            report["held"] = down
            await_pressed(client, session, XS)
            changed = sum(a != b for a, b in zip(idle["buttons"][XS]["corner_face_pixels"],
                                                 down["buttons"][XS]["corner_face_pixels"]))
            require(changed >= 12, f"pressed corner changed only {changed} pixels")
            report["pressed_corner_pixels_changed"] = changed
            before_ink = idle["buttons"][XS]["corner_ink_pixels"]
            after_ink = down["buttons"][XS]["corner_ink_pixels"]
            require(after_ink >= before_ink + 6,
                    f"press did not paint farther into the corner: {before_ink} → {after_ink}")
        finally:
            if "pointer_down" in report:
                report["pointer_up"] = probe_target(child, "--pointer-up", "開始")
        await_pressed(client, session, None)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--mode", choices=("visual", "ax", "press"), default="visual")
    args = parser.parse_args()
    args.artifacts = args.artifacts.resolve()
    args.artifacts.mkdir(parents=True, exist_ok=False, mode=0o700)
    debug = args.debug_dir
    client = debug / "surface-devtools"
    wide = debug / "surface-material-gallery"
    compact = debug / "examples/compact"
    report = {"capture": "Surface Page.screenshot", "frames": [], "rtl_200": [], "ax": [], "errors": []}
    guarded = (RuntimeError, StopIteration, KeyError, ValueError, TypeError, OSError, subprocess.SubprocessError)
    if args.mode == "visual":
        for label, binary in (("wide", wide), ("compact", compact),
                              ("narrow", debug / "examples/button_narrow")):
            try:
                verify_size(args, client, binary, label, VIEWPORTS[label], report)
            except guarded as error:
                report["errors"].append(f"{label}: {error}")
    else:
        try:
            if args.mode == "ax":
                verify_ax(args, client, wide, report)
            else:
                verify_press(args, client, wide, report)
        except guarded as error:
            report["errors"].append(f"{args.mode}: {error}")
    write_json(args.artifacts / "report.json", report)
    require(not report["errors"], "\n".join(report["errors"]))


if __name__ == "__main__":
    main()
