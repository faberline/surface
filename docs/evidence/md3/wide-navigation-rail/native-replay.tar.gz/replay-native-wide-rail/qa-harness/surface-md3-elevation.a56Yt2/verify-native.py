#!/usr/bin/env python3
"""Verify Material elevation on the native Surface Gallery through Page.screenshot."""

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import tempfile
import time
import zlib


HERE = Path(__file__).resolve().parent
ELEVATIONS = tuple(f"elevation-{level}" for level in range(6))
CLIP = "elevation-clip"
CLIPPED_CASTER = "elevation-clipped-caster"
LADDER_SECTION = "section-5"
COMPONENTS_SECTION = "section-2"
CARD = "elevated-action-card"
MENU = "options-menu"
DIALOG = "rename-dialog"
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
PNG_END = b"\0\0\0\0IEND\xaeB`\x82"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def call(client, session, *arguments):
    result = subprocess.run(
        (client, "--session", session, *arguments),
        check=False,
        capture_output=True,
        text=True,
        timeout=12,
    )
    require(
        result.returncode == 0,
        f"Surface CLI {' '.join(map(str, arguments))}: {result.stderr.strip()}",
    )
    return json.loads(result.stdout)


def wait_for_session(session, child):
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        if child.poll() is not None:
            raise RuntimeError(f"Gallery exited before initializing DevTools: {child.returncode}")
        try:
            with session.open() as ready:
                endpoint = json.load(ready)
        except (FileNotFoundError, json.JSONDecodeError):
            time.sleep(0.05)
            continue
        require(endpoint["pid"] == child.pid, "DevTools session belongs to another process")
        require(endpoint["endpoint"].startswith("127.0.0.1:"), "DevTools is not loopback")
        require(session.stat().st_mode & 0o077 == 0, "DevTools session is not private")
        return
    raise RuntimeError("Timed out waiting for the Gallery DevTools session")


def stop(child):
    if child.poll() is not None:
        return
    child.terminate()
    try:
        child.wait(timeout=10)
    except subprocess.TimeoutExpired:
        child.kill()
        child.wait(timeout=5)


def png_details(path, metadata):
    png = path.read_bytes()
    require(png.startswith(PNG_SIGNATURE), f"{path.name} is missing the PNG signature")
    require(png.endswith(PNG_END), f"{path.name} is missing the final PNG chunk")
    header_size, header, width, height, depth, color, compression, filtering, interlace = (
        struct.unpack_from(">I4sIIBBBBB", png, len(PNG_SIGNATURE))
    )
    require((header_size, header) == (13, b"IHDR"), f"{path.name} has an invalid PNG header")
    require(
        (depth, color, compression, filtering, interlace) == (8, 6, 0, 0, 0),
        f"{path.name} is not an 8-bit RGBA PNG",
    )
    require(
        (metadata["format"], metadata["width"], metadata["height"], metadata["scale"])
        == ("png", width, height, 1),
        f"{path.name} dimensions or scale disagree with the CLI",
    )
    return {
        "file": path.name,
        "sha256": hashlib.sha256(png).hexdigest(),
        "width": width,
        "height": height,
        "scale": metadata["scale"],
        "bytes": len(png),
    }


def paeth(left, above, corner):
    predicted = left + above - corner
    left_error = abs(predicted - left)
    above_error = abs(predicted - above)
    corner_error = abs(predicted - corner)
    if left_error <= above_error and left_error <= corner_error:
        return left
    return above if above_error <= corner_error else corner


def png_pixels(path, details, points):
    """Read selected pixels while decoding each PNG scanline at most once."""
    width, height = details["width"], details["height"]
    columns = {}
    for x, y in points:
        require(0 <= x < width and 0 <= y < height, f"Pixel {x},{y} is outside {path.name}")
        columns.setdefault(y, set()).add(x)
    png = path.read_bytes()
    compressed = []
    offset = len(PNG_SIGNATURE)
    while offset < len(png):
        size, kind = struct.unpack_from(">I4s", png, offset)
        if kind == b"IDAT":
            compressed.append(png[offset + 8 : offset + 8 + size])
        offset += size + 12
    raw = zlib.decompress(b"".join(compressed))
    stride = 1 + width * 4
    require(len(raw) == stride * height, f"Unexpected PNG scanline size in {path.name}")
    length = (max(x for x, _ in points) + 1) * 4
    previous = bytearray(length)
    result = {}
    for row in range(max(columns) + 1):
        start = row * stride
        filter_type = raw[start]
        line = bytearray(raw[start + 1 : start + 1 + length])
        require(filter_type < 5, f"Unsupported PNG filter {filter_type} in {path.name}")
        if filter_type:
            for i in range(length):
                left = line[i - 4] if i >= 4 else 0
                above = previous[i]
                corner = previous[i - 4] if i >= 4 else 0
                if filter_type == 1:
                    predictor = left
                elif filter_type == 2:
                    predictor = above
                elif filter_type == 3:
                    predictor = (left + above) // 2
                else:
                    predictor = paeth(left, above, corner)
                line[i] = (line[i] + predictor) & 0xFF
        for x in columns.get(row, ()):
            result[x, row] = list(line[x * 4 : (x + 1) * 4])
        previous = line
    return result


def dom_index(snapshot):
    nodes = snapshot["dom"]["nodes"]
    return nodes, {
        node["stable_id"]: i for i, node in enumerate(nodes) if node.get("stable_id")
    }


def right(rect):
    return rect["x"] + rect["width"]


def bottom(rect):
    return rect["y"] + rect["height"]


def center_x(rect):
    return math.floor(rect["x"] + rect["width"] / 2)


def contains(rect, inner):
    tolerance = 0.01
    return (
        rect["x"] - tolerance <= inner["x"]
        and rect["y"] - tolerance <= inner["y"]
        and right(rect) + tolerance >= right(inner)
        and bottom(rect) + tolerance >= bottom(inner)
    )


def same_color(left, right_color, tolerance=1):
    return all(abs(a - b) <= tolerance for a, b in zip(left, right_color))


def darkness(pixel, baseline):
    return sum(base - actual for base, actual in zip(baseline[:3], pixel[:3])) / 3


def report_check(details, condition, failure):
    if not condition:
        details["errors"].append(f"{details['file']}: {failure}")


def geometry(snapshot, stable_id):
    nodes, index = dom_index(snapshot)
    i = index[stable_id]
    style = nodes[i]["style"]
    layout = snapshot["layout"]["nodes"][i]
    bounds = layout["bounds"]
    clip = layout["clip"]
    return {
        "bounds": bounds,
        "clip": clip,
        "role": nodes[i]["role"],
        "fill": style["background"],
        "radius": style["radius"],
        "fully_visible": (
            all(map(math.isfinite, bounds.values()))
            and bounds["width"] > 0
            and bounds["height"] > 0
            and contains(clip, bounds)
            and contains(snapshot["layout"]["viewport"], bounds)
        ),
    }


def capture(plan, client, session, label, size, dark, section, stable_ids=()):
    png = plan.artifacts / f"{label}.png"
    dom = plan.artifacts / f"{label}.dom.json"
    metadata = call(client, session, "page", "screenshot", "--scale", "1", "--out", png)
    snapshot = call(client, session, "dom", "snapshot")
    write_json(dom, snapshot)
    details = png_details(png, metadata)
    viewport = snapshot["layout"]["viewport"]
    details.update({"viewport": viewport, "dark": dark, "dom": dom.name, "nodes": {}, "errors": []})
    report_check(
        details,
        (details["width"], details["height"]) == size
        and (round(viewport["width"]), round(viewport["height"])) == size,
        f"expected viewport {size}, renderer reported {viewport}",
    )
    nodes, index = dom_index(snapshot)
    report_check(details, nodes[index[section]]["selected"] is True, f"expected {section} selected")
    report_check(details, nodes[index["theme"]]["checked"] is dark, "unexpected Gallery theme")
    for stable_id in stable_ids:
        if stable_id not in index:
            report_check(details, False, f"missing node {stable_id}")
            continue
        node = geometry(snapshot, stable_id)
        details["nodes"][stable_id] = node
        report_check(details, node["fully_visible"], f"{stable_id} has zero size or is clipped")
    print(f"{label}: {details['width']} × {details['height']} PNG", flush=True)
    return details, snapshot


def ladder_pixels(plan, details, snapshot):
    nodes = details["nodes"]
    if not all(stable_id in nodes for stable_id in (*ELEVATIONS, CLIP, CLIPPED_CASTER)):
        return
    rects = [nodes[stable_id]["bounds"] for stable_id in ELEVATIONS]
    zero = rects[0]
    clip = nodes[CLIP]["bounds"]
    caster = nodes[CLIPPED_CASTER]["bounds"]
    fill = nodes[ELEVATIONS[0]]["fill"]
    series = []
    for rect in rects:
        x = center_x(rect)
        start = math.ceil(bottom(rect))
        stop = min(start + 19, details["height"])
        if clip["x"] <= x < right(clip) and clip["y"] > start:
            stop = min(stop, math.floor(clip["y"]))
        series.append([(x, y) for y in range(start, stop)])
    # The empty edge of the page stays clear of all casters and their shadows.
    control_x = details["width"] - 5
    far = [(control_x, math.ceil(bottom(rect)) + 4) for rect in rects]
    corner = (math.ceil(zero["x"]), math.ceil(zero["y"]))
    flat_top = (center_x(zero), math.ceil(zero["y"]) + 2)
    raised_corner = [(math.ceil(rects[-1]["x"]), y) for _, y in series[-1][:4]]
    inside_y = math.ceil(bottom(caster)) + 2
    outside_y = math.ceil(bottom(clip)) + 1
    near_x = center_x(caster)
    far_x = math.floor(right(clip)) - 2
    clip_points = {
        "inside": (near_x, inside_y), "inside_control": (far_x, inside_y),
        "outside": (near_x, outside_y), "outside_control": (far_x, outside_y),
    }
    sample_points = {point for line in series for point in line}
    sample_points.update((*far, corner, flat_top, *raised_corner, *clip_points.values()))
    if any(
        not 0 <= x < details["width"] or not 0 <= y < details["height"]
        for x, y in sample_points
    ) or any(len(points) < 4 for points in series):
        report_check(details, False, "fixture leaves no room for one or more pixel controls")
        return
    pixels = png_pixels(plan.artifacts / details["file"], details, sample_points)

    def pixel_data(point):
        return {"xy": point, "rgba": pixels[point]}

    expected_background = geometry(snapshot, "surface-page")["fill"]
    report_check(
        details,
        all((rect["width"], rect["height"]) == (36, 36) for rect in rects)
        and all(nodes[stable_id]["fill"] == fill for stable_id in ELEVATIONS),
        "elevation boxes must have matching 36 × 36 bounds and fill",
    )
    report_check(
        details,
        all(same_color(pixels[point], expected_background) for point in series[0][:4]),
        "level 0 shows a shadow",
    )
    report_check(
        details,
        all(same_color(pixels[point], expected_background) for point in far),
        "far control differs from the unshadowed background",
    )
    report_check(
        details,
        same_color(pixels[corner], expected_background) and same_color(pixels[flat_top], fill),
        "level 0 does not have the expected rounded silhouette or fill",
    )
    report_check(
        details,
        any(
            darkness(pixels[center], pixels[edge]) > 1
            for center, edge in zip(series[-1], raised_corner)
        ),
        "level 5 shadow does not soften near the rounded corner",
    )
    report_check(
        details,
        (clip["width"], clip["height"], caster["width"], caster["height"]) == (76, 40, 36, 36)
        and contains(clip, caster) and inside_y < bottom(clip) < outside_y,
        "clipped caster and ancestor do not have the expected geometry",
    )
    report_check(
        details,
        darkness(pixels[clip_points["inside"]], pixels[clip_points["inside_control"]]) > 1,
        "level 5 shadow is missing inside its clip",
    )
    report_check(
        details,
        same_color(pixels[clip_points["outside"]], pixels[clip_points["outside_control"]]),
        "level 5 shadow escapes its ancestor clip",
    )
    reaches = []
    for level, points in enumerate(series):
        darkened = [
            offset
            for offset, point in enumerate(points)
            if darkness(pixels[point], expected_background) > 1
        ]
        reaches.append(max(darkened, default=-1))
        if level:
            report_check(
                details, any(offset < 4 for offset in darkened),
                f"no raster shadow within 4 pixels of level {level}",
            )
    report_check(
        details,
        reaches == sorted(reaches) and reaches[-1] > reaches[1],
        f"shadow reach does not increase across levels: {reaches}",
    )
    details["pixels"] = {
        "below_center": [[pixel_data(point) for point in points] for points in series],
        "shadow_reach_px": reaches,
        "far_controls": [pixel_data(point) for point in far],
        "rounded_corner": pixel_data(corner),
        "raised_corner": [pixel_data(point) for point in raised_corner],
        "flat_top": pixel_data(flat_top),
        "clip": {name: pixel_data(point) for name, point in clip_points.items()},
    }


def component_shadow(plan, frame, stable_id, baseline=None):
    if stable_id not in frame["nodes"] or not frame["nodes"][stable_id]["fully_visible"]:
        return
    bounds = frame["nodes"][stable_id]["bounds"]
    viewport = frame["viewport"]
    center = center_x(bounds)
    # Sample below each component, away from the rounded corners.
    near = [(center, math.ceil(bottom(bounds)) + dy) for dy in range(4)]
    far = [(center, math.ceil(bottom(bounds)) + dy) for dy in (18, 21, 24)]
    # Wide cards fill the width of the close control. Use the blank leading margin.
    leading = [(math.floor(bounds["x"]) - 9, y) for _, y in (*near, *far)]
    points = near + far + leading
    if any(not 0 <= x < viewport["width"] or not 0 <= y < viewport["height"] for x, y in points):
        report_check(frame, False, f"no room for pixel controls near {stable_id}")
        return
    current = png_pixels(plan.artifacts / frame["file"], frame, points)
    previous = (
        png_pixels(plan.artifacts / baseline["file"], baseline, points) if baseline else None
    )
    if stable_id == MENU:
        deltas = [darkness(current[point], previous[point]) for point in near]
        far_deltas = [darkness(current[point], previous[point]) for point in far]
        report_check(frame, all(abs(delta) <= 1 for delta in far_deltas), f"{stable_id}: far controls changed")
    else:
        # For a dialog, the leading control is inside the same scrim.
        # Keep comparisons only when both positions started as the same color.
        candidates = list(zip(near, leading))
        if previous:
            candidates = [
                (point, control) for point, control in candidates
                if same_color(previous[point], previous[control])
            ]
        deltas = [darkness(current[point], current[control]) for point, control in candidates]
        far_deltas = [darkness(current[point], current[control]) for point, control in zip(far, leading[len(near):])]
    report_check(frame, any(delta > 1 for delta in deltas), f"missing raster shadow below {stable_id}")
    frame["shadow_pixels"] = {
        "component": stable_id,
        "near_darkening": deltas,
        "far_darkening": far_deltas,
        "near": [{"xy": point, "rgba": current[point]} for point in near],
        "far": [{"xy": point, "rgba": current[point]} for point in far],
        "leading_controls": [{"xy": point, "rgba": current[point]} for point in leading],
        "pre_open": (
            [{"xy": point, "rgba": previous[point]} for point in points] if previous else None
        ),
    }


def verify_components(plan, client, session, size):
    call(client, session, "action", "activate", "section-1")
    call(client, session, "action", "activate", CARD)
    card, _ = capture(plan, client, session, "wide-dark-card", size, True, "section-1", (CARD,))
    component_shadow(plan, card, CARD)
    call(client, session, "action", "activate", COMPONENTS_SECTION)
    baseline, _ = capture(plan, client, session, "wide-dark-components", size, True, COMPONENTS_SECTION)
    call(client, session, "action", "activate", "open-menu")
    menu, _ = capture(plan, client, session, "wide-dark-menu", size, True, COMPONENTS_SECTION, (MENU,))
    component_shadow(plan, menu, MENU, baseline)
    call(client, session, "action", "key", "escape")
    call(client, session, "action", "activate", "open-dialog")
    dialog, snapshot = capture(
        plan, client, session, "wide-dark-dialog", size, True, COMPONENTS_SECTION, (DIALOG,)
    )
    report_check(dialog, MENU not in dom_index(snapshot)[1], "Escape did not close the menu")
    component_shadow(plan, dialog, DIALOG, baseline)
    return [card, baseline, menu, dialog]


def verify_size(plan, client, binary, name, size, frames):
    with (
        tempfile.TemporaryDirectory(prefix="surface-md3-", dir="/private/tmp") as folder,
        (plan.artifacts / f"{name}.log").open("wb") as log,
    ):
        session = Path(folder) / "session.json"
        env = os.environ.copy()
        env.pop("SURFACE_TRACE", None)
        env.pop("SURFACE_BRIDGE_SESSION", None)
        env["SURFACE_REDUCED_MOTION"] = "1"
        env["SURFACE_DEVTOOLS_SESSION"] = str(session)
        child = subprocess.Popen(
            (binary,), cwd=plan.checkout, env=env, stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT,
        )
        try:
            wait_for_session(session, child)
            capabilities = call(client, session, "capabilities")
            require("Page.screenshot" in capabilities["methods"], "Page.screenshot is unavailable")
            call(client, session, "action", "activate", LADDER_SECTION)
            previous_frame = None
            for dark, theme in ((False, "light"), (True, "dark")):
                if dark:
                    call(client, session, "action", "activate", "theme")
                frame, snapshot = capture(
                    plan, client, session, f"{name}-{theme}", size, dark, LADDER_SECTION,
                    (*ELEVATIONS, CLIP, CLIPPED_CASTER),
                )
                frames.append(frame)
                ladder_pixels(plan, frame, snapshot)
                if previous_frame:
                    report_check(
                        frame, frame["sha256"] != previous_frame["sha256"], "themes share the same PNG",
                    )
                previous_frame = frame
            if name == "wide" and not plan.ladder_only:
                frames.extend(verify_components(plan, client, session, size))
        finally:
            stop(child)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, default=HERE / "qa")
    parser.add_argument("--target", type=Path, help="Cargo target directory")
    parser.add_argument("--artifacts", type=Path, help="new evidence directory")
    parser.add_argument("--ladder-only", action="store_true", help="skip actual component routes")
    plan = parser.parse_args()
    plan.checkout = plan.checkout.resolve()
    target = Path(plan.target or os.environ.get("CARGO_TARGET_DIR", "target"))
    target = (target if target.is_absolute() else plan.checkout / target) / "debug"
    client = target / "surface-devtools"
    wide = target / "surface-material-gallery"
    compact = target / "examples" / "compact"
    for binary in (client, wide, compact):
        require(binary.is_file() and os.access(binary, os.X_OK), f"Missing executable {binary}")
    if plan.artifacts is None:
        plan.artifacts = Path(tempfile.mkdtemp(prefix="evidence-native-", dir=HERE))
    else:
        plan.artifacts = plan.artifacts.resolve()
        plan.artifacts.mkdir(parents=True, exist_ok=False, mode=0o700)
    print(f"Evidence at {plan.artifacts}", flush=True)
    frames = []
    errors = []
    for name, binary, size in (("wide", wide, (960, 800)), ("compact", compact, (420, 360))):
        try:
            verify_size(plan, client, binary, name, size, frames)
        except (RuntimeError, KeyError, ValueError, subprocess.TimeoutExpired) as error:
            errors.append(f"{name}: {error}")
    errors.extend(error for frame in frames for error in frame["errors"])
    write_json(
        plan.artifacts / "report.json",
        {"capture": "Page.screenshot", "checkout": str(plan.checkout), "frames": frames, "errors": errors},
    )
    require(not errors, "\n".join(errors))
    print(f"Validated {len(frames)} Surface frames", flush=True)


if __name__ == "__main__":
    main()
