#!/usr/bin/env python3
"""Verify centered square image crops and list input on macOS Metal."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import runpy
import struct
import subprocess

HERE = Path(__file__).resolve().parent
ART = runpy.run_path(str(HERE.parents[1] / "surface-md3-list-art.tMqqrw"
                         / "native-list-art" / "verify-native-list-art.py"))
BASE = ART["BASE"]
COMMON, MOTION, QA = (ART[k] for k in ("COMMON", "MOTION", "QA"))
capture, close, color_matches, contains, focus, key, node, rect, center, pixels_for, require, same_rect, sample_points, write_json = (
    ART[k] for k in ("capture", "close", "color_matches", "contains", "focus", "key", "node",
                     "rect", "center", "pixels_for", "require", "same_rect", "sample_points", "write_json")
)
blend, visible_ink, paint_entries, expect_count, pointer, reject, frame_row, complete_bands, all_bands, accessibility = (
    ART[k] for k in ("blend", "visible_ink", "paint_entries", "expect_count", "pointer", "reject",
                     "frame_row", "complete_bands", "all_bands", "accessibility")
)
SECTION, LIST, STATIC, ACTIVE, DISABLED, DIRECTION, SCALE, ACTIVE_NAME = (
    ART[k] for k in ("SECTION", "LIST", "STATIC", "ACTIVE", "DISABLED", "DIRECTION", "SCALE", "ACTIVE_NAME")
)
ROWS, VIEWPORTS, PROFILES = ART["ROWS"], ART["VIEWPORTS"], ART["PROFILES"]
IMAGE, ARTWORK = "list-options-image-toggle", ART["ARTWORK"]
SOURCES = {STATIC: (112., 56.), ACTIVE: (56., 112.), DISABLED: (56., 56.)}
BLUE, GREEN, YELLOW, RED = ([36, 110, 165, 255], [24, 128, 100, 255], [246, 202, 83, 255], [209, 36, 75, 255])


def clip_to(a, b):
    x, y = max(a["x"], b["x"]), max(a["y"], b["y"])
    return {"x": x, "y": y,
            "width": max(0., min(a["x"] + a["width"], b["x"] + b["width"]) - x),
            "height": max(0., min(a["y"] + a["height"], b["y"] + b["height"]) - y)}


def layout(case, snapshot, item, rtl, scale):
    minimum, labels = ROWS[item]
    row = rect(snapshot, item + "-row")
    art = rect(snapshot, item + "-leading-artwork")
    child_id = item + "-leading-artwork-image"
    child = rect(snapshot, child_id)
    slots = {slot: rect(snapshot, item + "-" + slot) for slot in labels}
    minimum = max(minimum, 72.)
    require(BASE["close_width"](rect(snapshot, LIST), row) and row["height"] >= minimum,
            f"{item}: row width or image minimum height is invalid")
    if case.size[0] == 960 and scale == 1:
        close(row["height"], minimum, f"{item}: wide row minimum")
    if case.size[0] == 320:
        close(row["width"], 264., f"{item}: narrow list width")
    for size in ("height", "width"):
        close(art[size], 56., f"{item}: fixed image {size}")
    close(child["width"], SOURCES[item][0], f"{item}: rendered width preserves source aspect")
    close(child["height"], SOURCES[item][1], f"{item}: rendered height preserves source aspect")
    close(center(child)[0], center(art)[0], f"{item}: horizontal crop center")
    close(center(child)[1], center(art)[1], f"{item}: vertical crop center")
    require(contains(row, art) and all(contains(row, box) for box in slots.values()),
            f"{item}: artwork or text extends out of its row")
    start = row["x"] + row["width"] - art["x"] - 56. if rtl else art["x"] - row["x"]
    close(start, 16., f"{item}: logical leading inset")
    body = slots["headline"]
    gap = art["x"] - body["x"] - body["width"] if rtl else body["x"] - art["x"] - 56.
    close(gap, 16., f"{item}: image to body gap")
    if row["height"] >= 88.:
        close(art["y"] - row["y"], 12. if item == DISABLED else 8., f"{item}: tall row top alignment")
    else:
        close(center(art)[1], center(row)[1], f"{item}: compact image vertical center")
    _, ids = COMMON["dom_index"](snapshot)
    require(item + "-leading" not in ids and item + "-leading-artwork-label" not in ids,
            "Exclusive image sample kept a text or avatar slot")
    clip = snapshot["layout"]["nodes"][ids[child_id]]["clip"]
    require(contains(art, clip) or clip["height"] == 0., f"{item}: image's clip leaves the square slot")
    divider = None
    if item != DISABLED:
        divider = rect(snapshot, item + "-divider")
        close(divider["height"], 1., "Optional divider thickness")
        close(divider["y"], row["y"] + row["height"], "Divider stays outside the row hit area")
        close(divider["x"] - row["x"], 0. if rtl else 16., "Mirrored divider inset")
    return row, slots, art, child, divider


def image_points(art, child, width, height, unit):
    raster = {"x": 0., "y": 0., "width": float(width), "height": float(height)}
    source = {name: value * unit for name, value in child.items()}
    tile = {name: value * unit for name, value in art.items()}
    return sample_points(clip_to(source, raster)) | sample_points(tile)


def inspect_image(values, art, child, width, height, unit):
    requested_points = image_points(art, child, width, height, unit)
    red = [p for p in requested_points if color_matches(values[p], RED)]
    require(not red, f"Centered crop leaked a red source strip at {red[:4]}")
    x0, y0 = art["x"] * unit, art["y"] * unit
    filled = 0
    circle = []
    for x in range(math.floor(x0), math.ceil(x0 + 56. * unit)):
        for y in range(math.floor(y0), math.ceil(y0 + 56. * unit)):
            point = (x, y)
            if point not in requested_points:
                continue
            local_x, local_y = (x + .5 - x0) / unit, (y + .5 - y0) / unit
            if not (1.0 <= local_x <= 55.0 and 1.0 <= local_y <= 55.0):
                continue
            color = values[point]
            if color[0] >= 150 and color[1] >= 145 and color[2] <= 145:
                circle.append(point)
            radius = math.hypot(local_x - 28., local_y - 28.)
            expected = YELLOW if radius <= 10.5 else None
            if radius >= 13.5 and abs(local_x - 28.) >= 1.25:
                expected = BLUE if local_x < 28. else GREEN
            if expected is not None:
                require(color_matches(color, expected, 4),
                        f"Crop fill wrong at {(local_x, local_y)}: {color}, expected {expected}")
                filled += 1
    require(filled > 2200 * unit * unit and circle, "The visible 56 dp tile is not filled")
    xs, ys = zip(*circle)
    diameter = max(xs) - min(xs) + 1, max(ys) - min(ys) + 1
    center_px = (min(xs) + max(xs) + 1.) / 2., (min(ys) + max(ys) + 1.) / 2.
    require(all(abs(size - 24. * unit) <= 1. for size in diameter) and abs(diameter[0] - diameter[1]) <= 1.,
            f"Circular fiducial is stretched: {diameter} at {unit}×")
    require(all(abs(a - b) <= 1. for a, b in zip(center_px, (x0 + 28. * unit, y0 + 28. * unit))),
            f"Circular fiducial is not centered: {center_px}")
    point = min(circle, key=lambda p: abs(p[0] - center_px[0]) + abs(p[1] - center_px[1]))
    return {"filled_samples": filled, "red_samples": len(red), "circle_diameter_px": diameter,
            "circle_center_px": center_px, "point": point}


def verify_paint(case, frame, receipt, item, row, slots, art, child, divider, rtl, scale):
    theme = case.plan.palette["dark" if case.dark else "light"]
    bg = theme["surface"]
    normal, secondary = theme["on_surface"], theme["on_surface_variant"]
    if item == DISABLED:
        normal, secondary = blend(bg, normal, .30), blend(bg, normal, .38)
    clip = frame["viewport"]
    runs = paint_entries(receipt, ("Text", "StyledText"))
    groups = {}
    for slot, box in slots.items():
        font, line_height = BASE["TEXT_METRICS"].get(slot, (11., 16.))
        line_count, bands = complete_bands(box, line_height * scale, clip)
        foreground = normal if slot == "headline" else secondary
        if bands:
            label = ROWS[item][1][slot]
            paints = [run for run in runs if run["text"] == label and same_rect(run["rect"], box)]
            require(len(paints) == 1 and paints[0]["color"] == foreground,
                    f"{item}-{slot}: expected scaled visible text")
            close(paints[0]["style"]["font_size"], font * scale, f"{item}-{slot}: actual scaled text")
            close(paints[0]["style"]["line_height"], line_height * scale, f"{item}-{slot}: actual scaled line height")
        groups[slot] = (line_count, bands, foreground)
    wanted = [band for _, bands, _ in groups.values() for band in bands.values()]
    require(receipt["images"][item + "-leading-artwork-image"]["decorative"], "Image loses its decorative semantic flag")
    fully_visible = contains(clip, art)
    image = None
    if fully_visible:
        images = [op for op in paint_entries(receipt, ("Image",)) if same_rect(op["rect"], child)]
        require(len(images) == 1 and same_rect(images[0]["clip"], art), f"{item}: image is not clipped by its 56 dp slot")
        wanted.append(image_points(art, child, frame["width"], frame["height"], 1.))
    separator = None
    if divider and contains(clip, divider):
        x, _ = center(divider)
        gap = row["x"] + (row["width"] - 8. if rtl else 8.)
        band_y = range(math.floor(divider["y"]), math.ceil(divider["y"] + 1.))
        separator = ({(math.floor(x), y) for y in band_y}, {(math.floor(gap), y) for y in band_y})
        wanted.extend(separator)
    values = pixels_for(case.plan.artifacts / frame["file"], frame, set.union(*wanted))
    measured = {}
    for slot, (count, bands, ink) in groups.items():
        observed = {str(index): sum(visible_ink(values[p], ink, bg) for p in band) for index, band in bands.items()}
        require(all(samples >= 4 for samples in observed.values()), f"{item}-{slot}: blank or clipped glyph run")
        measured[slot] = {"total": count, "sampled_ink": observed}
    if fully_visible:
        image = inspect_image(values, art, child, frame["width"], frame["height"], 1.)
    if separator:
        line, gap = separator
        ink = theme["outline_variant"]
        require(any(visible_ink(values[p], ink, bg) for p in line)
                and not any(visible_ink(values[p], ink, bg) for p in gap), "Inset divider pixels differ")
    return {"text": measured, "image": image, "divider_pixels": bool(separator)}


def take(case, stage, item, rtl, scale, count, tail=False, focused=False):
    case.clock.advance(700)
    oversize = frame_row(case, item, tail)
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{stage}",
                              case.size, case.dark, SECTION)
    require(not frame["errors"], str(frame["errors"]))
    expect_count(case, count)
    if focused:
        require(snapshot["interaction"]["focused"] == item + "-row", "Keyboard lost the matching row")
    receipt = json.loads(case.receipt.read_text())
    row, slots, art, child, divider = layout(case, snapshot, item, rtl, scale)
    projected = accessibility(snapshot, receipt, item)
    paint = verify_paint(case, frame, receipt, item, row, slots, art, child, divider, rtl, scale)
    frame.update(stage=stage, item=item, rtl=rtl, text_scale=scale, activations=count, oversize=oversize,
                 row=row, art=art, image_node=child, divider=divider, slots=slots, paint=paint, accesskit=projected)
    case.frames.append(frame)
    return frame


def high_density(case, name, resting):
    path = case.plan.artifacts / f"{case.prefix}-{name}-output-2x.png"
    result = case.call("page", "screenshot", "--scale", "2", "--out", path)
    data = path.read_bytes()
    width, height = struct.unpack(">II", data[16:24])
    require(data.startswith(b"\x89PNG\r\n\x1a\n") and (width, height) == tuple(2 * d for d in case.size),
            "Incorrect PNG raster size at physical 2×")
    require(result["width"] == width and result["height"] == height and result["scale"] == 2.,
            "The PNG metadata disagrees with physical 2× pixel size")
    frame = {"file": path.name, "width": width, "height": height, "bytes": len(data),
             "sha256": hashlib.sha256(data).hexdigest(), "scale": 2.}
    art, child = resting["art"], resting["image_node"]
    values = pixels_for(path, frame, image_points(art, child, width, height, 2.))
    frame["image"] = inspect_image(values, art, child, width, height, 2.)
    return frame


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    _, ids = COMMON["dom_index"](case.snapshot())
    require(ACTIVE + "-leading" in ids and ACTIVE + "-leading-artwork-image" not in ids,
            "Images changed the default baseline list")
    case.call("action", "activate", ARTWORK)
    _, ids = COMMON["dom_index"](case.snapshot())
    require(ACTIVE + "-leading-artwork-label" in ids, "Earlier avatar sample did not load")
    case.call("action", "activate", IMAGE)
    _, ids = COMMON["dom_index"](case.snapshot())
    require(ACTIVE + "-leading-artwork-image" in ids and ACTIVE + "-leading-artwork-label" not in ids,
            "Image sample did not replace the exclusive avatar sample")
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2:
        case.call("action", "activate", SCALE)
    case.point("leave")
    result = {"mcp": None, "output_2x": {}}
    compact = case.size[0] == 320 and case.dark and rtl and scale == 2
    line_counts = {}
    for name, item in (("static", STATIC), ("disabled", DISABLED), ("active", ACTIVE)):
        first = take(case, name, item, rtl, scale, 0)
        require(first["paint"]["image"], f"{item}: top of row did not show a complete image")
        if compact:
            if item == ACTIVE:
                mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
                require((case.plan.artifacts / mcp["file"]).read_bytes() ==
                        (case.plan.artifacts / first["file"]).read_bytes(), "CLI and MCP returned different PNG bytes")
                result["mcp"] = {**mcp, "cli": first["file"]}
            result["output_2x"][name] = high_density(case, name, first)
        if item != ACTIVE:
            pointer(case, first["paint"]["image"]["point"], 0, 0)
        frames = [first]
        if first["oversize"]:
            frames.append(take(case, name + "-tail", item, rtl, scale, 0, tail=True))
        line_counts[name] = all_bands(*frames)
    if case.size[0] == 320 and scale == 2:
        require(line_counts["active"]["supporting"] > 1, "Narrow CJK stopped wrapping")
    for item in (STATIC, ACTIVE, DISABLED):
        for suffix in ("-leading-artwork", "-leading-artwork-image"):
            reject(case, "press", item + suffix, "no live AccessKit press")
    reject(case, "focus", ACTIVE + "-leading-artwork-image", "no live AccessKit focus")
    expect_count(case, 0)
    focus(case, SCALE)
    key(case, "tab", ACTIVE + "-row")
    expect_count(case, 0)
    key(case, "enter", ACTIVE + "-row")
    board = take(case, "keyboard", ACTIVE, rtl, scale, 1, focused=True)
    pointer(case, board["paint"]["image"]["point"], 1, 2)
    pressed = case.call("action", "qa-ax-press", ACTIVE + "-row")
    require(pressed["accesskit"], "AccessKit did not click the active image row")
    take(case, "pointer-and-accesskit", ACTIVE, rtl, scale, 3)
    return {**result, "cjk_line_counts": line_counts,
            "passive_image_pointer_attempts": 2, "denied_image_accesskit_requests": 7}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile")
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--startup-timeout", type=int, default=45)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "runs": {}, "frames": [], "errors": []}
    for viewport, theme, direction, scale in PROFILES:
        name = f"{viewport}-{theme}-{direction}-{scale}x"
        if plan.profile not in (None, name) or plan.theme not in (None, theme):
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, VIEWPORTS[viewport], theme == "dark") as case:
                result = journey(case, direction == "rtl", scale)
            output = (plan.artifacts / f"{name}.log").read_text()
            metal = next((line for line in output.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in metal and "backend: Metal" in metal, f"{name} did not use Metal")
            report["runs"][name] = {**result, "adapter": metal}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(report["errors"][-1], flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"] and report["runs"], "\n".join(report["errors"]) or "No matching journey")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
