#!/usr/bin/env python3
"""Verify Drawer swipes on Metal using isolated Winit mouse and touch event routes."""

import argparse
import json
import math
import os
from pathlib import Path
import runpy
import subprocess
import time
import traceback


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
DRAWER = runpy.run_path(str(WORKSPACE / "surface-md3-navigation-drawer.UG1gs3Lj/native-navigation-drawer/verify-native-navigation-drawer.py"))
COMMON, MAC, MOTION, QA = (DRAWER[name] for name in ("COMMON", "MAC", "MOTION", "QA"))
capture, center, color_matches, focus, ids, key, node, pixels_for, read_png, rect, require, same_rect, write_json = (
    DRAWER[name] for name in ("capture", "center", "color_matches", "focus", "ids", "key", "node", "pixels_for",
                             "read_png", "rect", "require", "same_rect", "write_json")
)
PANEL, LAYER, OPEN, CLOSE, RTL, SCALE, INBOX, HOME, PAGE = (
    DRAWER[name] for name in ("PANEL", "LAYER", "OPEN", "CLOSE", "RTL", "SCALE", "INBOX", "HOME", "PAGE")
)
EDGE = "drawer-demo-swipe-edge"
SECTION = DRAWER["SECTION"]
PROFILES = {
    "wide-light-ltr": ((960, 800), False, False, 1., "mouse"),
    "wide-dark-rtl": ((960, 800), True, True, 1., "mouse"),
    "compact-light-rtl-2x": ((320, 240), False, True, 2., "touch"),
    "compact-dark-rtl-2x": ((320, 240), True, True, 2., "touch"),
}


class Contact:
    def __init__(self, case, kind):
        self.case = case
        self.kind = kind

    def event(self, step, point):
        routed = f"touch-{step}" if self.kind == "touch" else step
        self.case.point(routed, point, 43.)

    def cancel(self, point):
        if self.kind == "touch":
            self.event("cancel", point)
        else:
            self.case.point("capture-cancel", point)


def resize(case, size):
    require(case.call("action", "qa-resize", *map(str, size))["requested"] == list(size),
            "Native window did not accept the resize")
    deadline = time.monotonic() + 8.
    while True:
        viewport = case.snapshot()["layout"]["viewport"]
        if (round(viewport["width"]), round(viewport["height"])) == size:
            case.size = size
            return
        require(time.monotonic() < deadline, f"Native resize did not reach {size}: {viewport}")
        time.sleep(.05)


def visible_bounds(snapshot, id):
    index = ids(snapshot)[id]
    item = snapshot["layout"]["nodes"][index]
    width, height = (snapshot["layout"]["viewport"][axis] for axis in ("width", "height"))
    box, clip = item["bounds"], item["clip"]
    x = max(box["x"], clip["x"], 0.)
    y = max(box["y"], clip["y"], 0.)
    right = min(box["x"] + box["width"], clip["x"] + clip["width"], width)
    bottom = min(box["y"] + box["height"], clip["y"] + clip["height"], height)
    return {"x": x, "y": y, "width": max(0., right - x), "height": max(0., bottom - y)}


def public_scope(case, modal, focus_id, *, complete=False):
    deadline = time.monotonic() + 4.
    while True:
        data = MAC["inspect"](case.child.pid)
        items = data["controls"]
        dialogs = [item for item in items if item["name"] == MAC["DIALOG"] and item["subrole"] == "AXDialog"]
        content = [item for item in items if item["name"] in (MAC["DIALOG"], MAC["NAVIGATION"], MAC["CLOSE"])]
        background = [item for item in items if item["name"] == MAC["OPENER"] and item["role"] == "AXButton"]
        close = [item for item in items if item["name"] == MAC["CLOSE"] and item["role"] == "AXButton"
                 and "AXPress" in item["actions"] and (item["focused"] or item["focus_attr"])]
        navigation = [item for item in items if item["name"] == MAC["NAVIGATION"]
                      and item["subrole"] == "AXLandmarkNavigation" and MAC["DIALOG"] in item["ancestors"]]
        if data["trusted"] and modal:
            if (len(dialogs) == 1 and dialogs[0]["modal"] is True and not background
                    and (not complete or len(close) == len(navigation) == 1)):
                return data
        if data["trusted"] and not modal:
            if not content and len(background) == 1 and "AXPress" in background[0]["actions"]:
                if focus_id != OPEN or background[0]["focused"] or background[0]["focus_attr"]:
                    return data
        require(time.monotonic() < deadline, f"Unexpected public AX scope: {data}")
        time.sleep(.06)


def settle(case):
    case.clock.advance(1100)
    case.snapshot()
    case.clock.advance(1100)


def frame(case, label, rtl, scale, mode, focus_id, page=HOME, presses=()):
    shot, scene = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{label}",
                          case.size, case.dark, SECTION)
    require(not shot["errors"], str(shot["errors"]))
    lookup = ids(scene)
    receipt = json.loads(case.receipt.read_text())
    native = receipt["accesskit"]["nodes"]
    modal = mode in ("open", "dismiss-preview")
    preview = mode in ("open-preview", "dismiss-preview")
    require(scene["interaction"]["focused"] == focus_id,
            f"Focus moved in {label}: {scene['interaction']}")
    require(node(scene, PAGE)["text"] == DRAWER["NAMES"][page], f"Gesture changed the selected page in {label}")
    trace = DRAWER["trace_actions"](receipt)
    require(trace == list(presses), f"A swipe also fired a row or background press: {trace}")
    viewport = shot["viewport"]
    shot.update(stage=label, input=case.plan.input, rtl=rtl, text_scale=scale, phase=mode,
                focus=focus_id, page=page, trace=trace,
                macos=public_scope(case, modal, focus_id, complete=mode == "open"))
    require((PANEL in native) is modal and (not modal or native[PANEL]["modal"]),
            f"Wrong AccessKit modal scope for {label}")
    if mode == "closed":
        require(PANEL not in lookup and LAYER not in lookup, f"Closing or canceling left an overlay in {label}")
        edge = rect(scene, EDGE)
        require(edge["width"] == 24. and edge["height"] == viewport["height"] and edge["y"] == 0.
                and edge["x"] == (viewport["width"] - 24. if rtl else 0.),
                f"Closed start-edge hit region differs in {label}: {edge}")
        edge_semantics = native.get(EDGE)
        require(edge_semantics is None or (edge_semantics["role"] == "GenericContainer"
                    and not any(edge_semantics[key] for key in ("name", "focusable", "press"))),
                f"Invisible gesture edge exposed an accessibility control in {label}: {edge_semantics}")
        shot["edge"] = edge
        shot["edge_accesskit"] = edge_semantics
    else:
        bounds = rect(scene, PANEL)
        visual = visible_bounds(scene, PANEL)
        scrim = node(scene, LAYER)["style"]["background"]
        natural = min(360., viewport["width"])
        require(bounds["width"] == natural and bounds["height"] == viewport["height"]
                and visual["y"] == 0. and visual["height"] == viewport["height"]
                and math.isclose(visual["x"] + visual["width"] if rtl else visual["x"],
                                 viewport["width"] if rtl else 0., abs_tol=.01),
                f"Gesture panel did not follow the logical start at {label}: {bounds} {visual}")
        if preview:
            require(0. < visual["width"] < natural and 0 < scrim[3] < 82
                    and abs(scrim[3] - round(82. * visual["width"] / natural)) <= 1,
                    f"Partial panel and scrim differ at {label}: {visual}, {scrim}")
        else:
            require(visual["width"] == natural and scrim[3] == 82, "Open endpoint did not settle")
        atoms = [op["Legacy"] for op in receipt["presented"]["ops"] if "Legacy" in op]
        style = node(scene, PANEL)["style"]["background"]
        palette = case.plan.palette["dark" if case.dark else "light"]
        require(style == palette["surface_container_low"] and scrim[:3] == palette["scrim"][:3],
                "Drawer uses the wrong Material colors")
        require(any(op.get("color") == scrim and "rect" in op and same_rect(op["rect"], viewport)
                    for wrapper in atoms for op in wrapper.values() if isinstance(op, dict)),
                f"The current scrim is absent from the display list at {label}")
        if not preview:
            title = rect(scene, DRAWER["TITLE"])
            paint = [op["StyledText"] for op in atoms if "StyledText" in op]
            title_runs = [run for run in paint if run["text"] == MAC["DIALOG"] and same_rect(run["rect"], title)]
            require(len(title_runs) == 1 and title_runs[0]["style"]["font_size"] == 14. * scale
                    and title_runs[0]["rect"]["height"] == 20. * scale,
                    f"The painted title did not use {scale:.0%} text scale in {label}")
            shot["title_paint"] = title_runs[0]
        inside = (round(center(visual)[0]), 3)
        raster = pixels_for(case.plan.artifacts / shot["file"], shot, [inside])[inside]
        require(color_matches(raster, style, 4), f"Metal preview did not paint the panel face at {inside}: {raster}")
        shot.update(panel=bounds, visible_panel=visual, scrim=scrim, face_probe=inside,
                    face_pixel=raster, face_color=style)
    case.frames.append(shot)
    return shot


def check_scrim_raster(case, base, partial):
    width = case.size[0]
    x = 13 if partial["rtl"] else width - 13
    points = [(x, y) for y in (10, 17, 27)]
    shots = [pixels_for(case.plan.artifacts / shot["file"], shot, points) for shot in (base, partial)]
    opacity = partial["scrim"][3] / 255.
    for point in points:
        expected = [round(prior * (1. - opacity) + ink * opacity)
                    for prior, ink in zip(shots[0][point][:3], partial["scrim"][:3])] + [255]
        require(color_matches(shots[1][point], expected, 3), f"Actual partial scrim pixel did not match at {point}")
    partial["scrim_samples"] = [{"point": point, "prior": shots[0][point], "observed": shots[1][point]}
                                for point in points]


def sample_stacking(case, base, partial):
    baseline = json.loads((case.plan.artifacts / base["dom"]).read_text())
    fab = rect(baseline, "gallery-fab-toggle")
    point = (round(center(fab)[0]), round(fab["y"] + .77 * fab["height"]))
    prior = pixels_for(case.plan.artifacts / base["file"], base, [point])[point]
    observed = pixels_for(case.plan.artifacts / partial["file"], partial, [point])[point]
    require(color_matches(prior, node(baseline, "gallery-fab-toggle")["style"]["background"], 3),
            f"The stacking probe did not start on the Gallery FAB face at {point}")
    panel = partial["visible_panel"]
    over_panel = panel["x"] <= point[0] < panel["x"] + panel["width"]
    if over_panel:
        expected = partial["face_color"]
    else:
        opacity = partial["scrim"][3] / 255.
        expected = [round(background * (1. - opacity) + ink * opacity)
                    for background, ink in zip(prior[:3], partial["scrim"][:3])] + [255]
    partial["fab_stacking_probe"] = {"point": point, "prior": prior, "observed": observed,
                                    "expected": expected, "panel_occludes_fab": over_panel}


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    if rtl:
        case.call("action", "activate", RTL)
    if scale == 2.:
        case.call("action", "activate", SCALE)
    case.point("leave")
    QA["reveal"](case, OPEN)
    focus(case, OPEN)
    original = case.size
    natural = min(360., case.size[0])
    sign = -1. if rtl else 1.
    edge = (case.size[0] - 8. if rtl else 8., 140.)
    contact = Contact(case, case.plan.input)

    def moved(origin, distance, dy=0.):
        return origin[0] + sign * distance, origin[1] + dy

    def take(label, mode="closed", expected_focus=OPEN, page=HOME, presses=()):
        return frame(case, label, rtl, scale, mode, expected_focus, page, presses)

    baseline = take("initial")
    contact.event("down", edge)
    short = moved(edge, natural * .22)
    contact.event("move", short)
    short_held = take("short-held", "open-preview")
    sample_stacking(case, baseline, short_held)
    case.clock.advance(220)
    contact.event("up", short)
    settle(case)
    take("short-reverted")

    contact.event("down", edge)
    cross = moved(edge, 5., 65.)
    contact.event("move", cross)
    contact.event("up", cross)
    settle(case)
    take("cross-rejected")

    contact.event("down", edge)
    cancelled = moved(edge, natural * .37)
    contact.event("move", cancelled)
    take("before-cancel", "open-preview")
    contact.cancel(cancelled)
    contact.event("up", cancelled)
    settle(case)
    take("capture-cancelled")

    contact.event("down", edge)
    contact.event("move", cancelled)
    resize(case, (original[0] + 20, original[1] + 20))
    contact.event("up", moved(edge, natural * .72))
    settle(case)
    take("resize-cancelled")
    resize(case, original)
    settle(case)

    contact.event("down", edge)
    long = moved(edge, natural * .67)
    contact.event("move", long)
    pending = take("opening-held", "open-preview")
    check_scrim_raster(case, baseline, pending)
    mirror = None
    if case.size[0] == 320 and case.dark:
        other = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
        require(read_png(case.plan.artifacts, pending) == read_png(case.plan.artifacts, other),
                "CLI and MCP differ during the held swipe")
        mirror = {**other, "cli": pending["file"]}
    case.clock.advance(140)
    contact.event("up", long)
    case.snapshot()
    case.clock.advance(62)
    opening_motion = take("opening-settle", "open-preview")
    require(opening_motion["visible_panel"]["width"] > pending["visible_panel"]["width"],
            "Opening settlement did not advance towards the open endpoint")
    settle(case)
    take("gesture-opened", "open", CLOSE)

    key(case, "tab", HOME)
    key(case, "down", INBOX)
    row = center(rect(case.snapshot(), INBOX))
    case.point("down", row)
    case.point("up", row)
    case.point("leave")
    settle(case)
    after_row = take("row-click", page=INBOX, presses=(INBOX,))

    key(case, "enter", CLOSE)
    settle(case)
    take("button-opened", "open", CLOSE, INBOX, (INBOX,))
    panel = rect(case.snapshot(), PANEL)
    inside = (panel["x"] + 8. if rtl else panel["x"] + panel["width"] - 8., 140.)
    contact.event("down", inside)
    dismiss = moved(inside, -natural * .62)
    contact.event("move", dismiss)
    closing = take("dismiss-held", "dismiss-preview", CLOSE, INBOX, (INBOX,))
    check_scrim_raster(case, after_row, closing)
    case.clock.advance(140)
    contact.event("up", dismiss)
    case.snapshot()
    case.clock.advance(62)
    closing_motion = take("closing-settle", "dismiss-preview", CLOSE, INBOX, (INBOX,))
    require(closing_motion["visible_panel"]["width"] < closing["visible_panel"]["width"],
            "Closing settlement did not advance towards the closed endpoint")
    settle(case)
    take("gesture-dismissed", page=INBOX, presses=(INBOX,))
    return mirror


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--checkout", type=Path, default=HERE / "qa-stacking")
    parser.add_argument("--profile", action="append", choices=PROFILES)
    plan = parser.parse_args()
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    plan.checkout = plan.checkout.resolve()
    plan.client = HERE / "binaries/surface-devtools"
    plan.launcher = HERE / "launch-private-swipe.sh"
    plan.palette = json.loads(subprocess.check_output([HERE / "binaries/examples/fab_menu_native", "--palette"]))
    plan.case, plan.startup_timeout = "normal", 30
    require(MAC["AX"]["trusted"](), "Use the Accessibility-authorized terminal for public macOS queries")
    report = {"runs": {}, "frames": [], "errors": [], "touch_input": "Injected Winit WindowEvent::Touch"}
    for name, (size, dark, rtl, scale, input) in PROFILES.items():
        if plan.profile and name not in plan.profile:
            continue
        case = None
        try:
            plan.input = input
            os.environ["SURFACE_QA_SWIPE_TRACE"] = str(plan.artifacts / f"{name}-trace.jsonl")
            with COMMON["gallery"](plan, name, size, dark) as case:
                mirror = journey(case, rtl, scale)
            log = (plan.artifacts / f"{name}.log").read_text()
            adapter = next((line for line in log.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in adapter and "backend: Metal" in adapter, "Expected Apple Metal")
            report["runs"][name] = {"adapter": adapter, "mcp": mirror}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(traceback.format_exc(), flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(report["runs"] and not report["errors"], "Native swipe checks failed")
    print(f"Passed {len(report['frames'])} PNGs across {len(report['runs'])} native swipe journeys")


if __name__ == "__main__":
    main()
