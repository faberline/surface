"""Read public AX attributes of the private Gallery process without input."""

import ctypes


PTR = ctypes.c_void_p
CF_TYPE = ctypes.c_ulong
INDEX = ctypes.c_long
STATUS = ctypes.c_int32
APP_SERVICES = ctypes.CDLL("/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices")
FOUNDATION = ctypes.CDLL("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")


def bind(library, name, returns, *arguments):
    method = getattr(library, name)
    method.argtypes, method.restype = arguments, returns
    return method


trusted = bind(APP_SERVICES, "AXIsProcessTrusted", ctypes.c_bool)
create_application = bind(APP_SERVICES, "AXUIElementCreateApplication", PTR, STATUS)
set_timeout = bind(APP_SERVICES, "AXUIElementSetMessagingTimeout", STATUS, PTR, ctypes.c_float)
attribute = bind(APP_SERVICES, "AXUIElementCopyAttributeValue", STATUS, PTR, PTR, ctypes.POINTER(PTR))
release = bind(FOUNDATION, "CFRelease", None, PTR)
type_id = bind(FOUNDATION, "CFGetTypeID", CF_TYPE, PTR)
string_type = bind(FOUNDATION, "CFStringGetTypeID", CF_TYPE)
string_create = bind(FOUNDATION, "CFStringCreateWithCString", PTR, PTR, ctypes.c_char_p, ctypes.c_uint32)
string_read = bind(FOUNDATION, "CFStringGetCString", ctypes.c_bool, PTR, ctypes.c_char_p, INDEX,
                   ctypes.c_uint32)
number_type = bind(FOUNDATION, "CFNumberGetTypeID", CF_TYPE)
number_read = bind(FOUNDATION, "CFNumberGetValue", ctypes.c_bool, PTR, INDEX, PTR)
array_type = bind(FOUNDATION, "CFArrayGetTypeID", CF_TYPE)
array_count = bind(FOUNDATION, "CFArrayGetCount", INDEX, PTR)
array_item = bind(FOUNDATION, "CFArrayGetValueAtIndex", PTR, PTR, INDEX)
UTF8 = 0x08000100
FLOAT64 = 6


def ax_attribute(element, name):
    out = PTR()
    key = string_create(None, name.encode(), UTF8)
    try:
        code = attribute(element, key, ctypes.byref(out))
    finally:
        release(key)
    return (code, out.value)


def scalar(element, name):
    status, value = ax_attribute(element, name)
    if status != 0 or not value:
        return None
    try:
        kind = type_id(value)
        if kind == string_type():
            output = ctypes.create_string_buffer(4096)
            if string_read(value, output, len(output), UTF8):
                return output.value.decode("utf-8")
        if kind == number_type():
            output = ctypes.c_double()
            if number_read(value, FLOAT64, ctypes.byref(output)):
                return output.value
    finally:
        release(value)
    return None


def read_prices(pid):
    if not trusted():
        return {"trusted": False, "sliders": []}
    app = create_application(pid)
    results = []
    visited = 0

    def walk(element, depth=0):
        nonlocal visited
        visited += 1
        if visited > 2000 or depth > 32:
            raise RuntimeError("The private Gallery AX tree exceeded the probe budget")
        if scalar(element, "AXRole") == "AXSlider":
            names = [scalar(element, name) for name in ("AXTitle", "AXDescription", "AXLabel")]
            name = next((name for name in names if name in ("最低價格", "最高價格")), None)
            if name:
                results.append({"name": name, "value": scalar(element, "AXValue"),
                                "description": scalar(element, "AXValueDescription")})
        status, children = ax_attribute(element, "AXChildren")
        if status != 0 or not children:
            return
        try:
            if type_id(children) == array_type():
                for index in range(array_count(children)):
                    walk(array_item(children, index), depth + 1)
        finally:
            release(children)

    try:
        set_timeout(app, 1.)
        status, windows = ax_attribute(app, "AXWindows")
        if status != 0 or not windows:
            return {"trusted": True, "window_status": status, "sliders": results}
        try:
            for index in range(array_count(windows)):
                walk(array_item(windows, index))
        finally:
            release(windows)
    finally:
        release(app)
    return {"trusted": True, "window_status": 0, "visited": visited, "sliders": results}
