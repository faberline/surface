#!/usr/bin/env python3
"""Exercise the Material navigation rail with native Metal and public macOS AX."""

import argparse
import json
import os
from pathlib import Path
import runpy
import subprocess
import time
import traceback


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
NAV = runpy.run_path(str(WORKSPACE / "surface-md3-nav-badge.al6RSo/native-nav-badge/verify-native-nav-badge.py"))
SEARCH = runpy.run_path(str(WORKSPACE / "surface-md3-search-view.twj574ci/native-search-view/verify-native-search-query-scroll.py"))
AX = runpy.run_path(str(HERE / "read-navigation-rail-ax.py"))
COMMON, MOTION, QA = (NAV[name] for name in ("COMMON", "MOTION", "QA"))
capture, close, color_matches, contains, focus, key, node, pixels_for, require, same_rect, sample_points, write_json = (
    NAV[name] for name in ("capture", "close", "color_matches", "contains", "focus", "key", "node",
                           "pixels_for", "require", "same_rect", "sample_points", "write_json")
)
rect, center, read_png = SEARCH["rect"], SEARCH["center"], SEARCH["RAW"]["read_png"]
SECTION = "section-1"
CARD, LAYOUT, RTL, SCALE, PAGE, RAIL = ("navigation-rail-card", "navigation-rail-layout", "navigation-rail-rtl",
                                        "navigation-rail-scale", "navigation-rail-page", "nav-rail")
HOME, ARCHIVE, INBOX = ITEMS = ("rail-home", "rail-archive", "rail-inbox")
NAMES = dict(zip(ITEMS, ("前往首頁", "封存資料", "收件匣")))
LABELS = dict(zip(ITEMS, ("首頁", "封存", "收件")))
PAGES = {HOME: "瀏覽", INBOX: "收件匣"}
PROFILES = {
    "wide-light-ltr": ((960, 800), False, False, 1.),
    "wide-dark-rtl": ((960, 800), True, True, 1.),
    "compact-light-ltr-2x": ((320, 640), False, False, 2.),
    "compact-dark-rtl-2x": ((320, 640), True, True, 2.),
}


def rail_messages(trace):
    events = [json.loads(line) for line in trace.splitlines()]
    return [record for record in events if record["kind"] == "Message"
            and (record["data"]["source"] or {}).get("id") in ITEMS]


def take(case, stage, rtl, scale, selected, expected_actions, expected_focus=None, *, live=False):
    case.clock.advance(600)
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{stage}",
                              case.size, case.dark, SECTION, (RAIL, *ITEMS))
    require(not frame["errors"], str(frame["errors"]))
    require(node(snapshot, PAGE)["text"] == PAGES[selected], f"Unexpected controlled page in {stage}")
    focus_id = snapshot["interaction"]["focused"]
    if expected_focus is not None:
        require(focus_id == expected_focus, f"Unexpected focus in {stage}: {focus_id}")
    receipt = json.loads(case.receipt.read_text())
    trace = rail_messages(receipt["trace"])
    require([message["data"]["source"]["id"] for message in trace] == list(expected_actions),
            f"Rail delivered wrong app actions in {stage}: {trace}")
    palette = case.plan.palette["dark" if case.dark else "light"]
    rail, outer, page = (rect(snapshot, identity) for identity in (RAIL, LAYOUT, PAGE))
    require(rail["width"] == 80. and contains(outer, rail) and contains(outer, page),
            f"Compact rail or page escaped their layout: {rail}, {outer}, {page}")
    close(rail["x"] + (rail["width"] if rtl else 0.), outer["x"] + (outer["width"] if rtl else 0.),
          "Rail anchors to the logical leading side")
    require((center(page)[0] < center(rail)[0]) is rtl, "The rail does not mirror with the page")
    ax = receipt["accesskit"]
    group = ax["nodes"][RAIL]
    require(group["role"] == "Navigation" and group["name"] == "主導覽"
            and not group["focusable"] and not group["press"], f"Invalid native navigation group {group}")
    named = [entry["name"] for entry in ax["viewport_subtree"] if entry["name"]]
    require(named == ["主導覽", *NAMES.values()], f"Decorations changed native names or order: {named}")
    native = {}
    paint = {}
    rail_color = node(snapshot, RAIL)["style"]["background"]
    entries = receipt["presented"]["ops"]
    legacy = {kind: NAV["paint_entries"](receipt, (kind,)) for kind in ("Shape", "Quad", "Text", "StyledText")}
    paths = [entry["FillPath"] for entry in entries if "FillPath" in entry]
    page_runs = [op for op in legacy["StyledText"]
                 if op["text"] == PAGES[selected] and same_rect(op["rect"], page)]
    require(len(page_runs) == 1 and contains(page_runs[0]["clip"], page)
            and page["height"] == 24. * scale, "The controlled page heading did not fit on one line")
    pixels = {}
    previous_y = -1.
    png = case.plan.artifacts / frame["file"]
    for identity in ITEMS:
        data = node(snapshot, identity)
        item = ax["nodes"][identity]
        disabled = identity == ARCHIVE
        active = identity == selected
        require(data["selected"] is active and item["selected"] is active and item["disabled"] is disabled
                and item["focusable"] is not disabled and item["press"] is not disabled
                and item["focused"] is (focus_id == identity) and item["role"] == "Button"
                and item["name"] == NAMES[identity] and not item["children"],
                f"Invalid AccessKit destination {identity}: {item}")
        native[identity] = item
        target = rect(snapshot, identity)
        indicator = NAV["desc"](snapshot, identity, 1)
        icon = NAV["desc"](snapshot, identity, 2)
        require(contains(rail, target) and contains(target, indicator)
                and target["width"] >= 48. and target["height"] >= 64. and target["y"] > previous_y,
                f"{identity}: wrong target or vertical order {target}")
        require(indicator["width"] == 56. and indicator["height"] == 32.
                and icon["width"] == icon["height"] == 24. and contains(indicator, icon),
                f"{identity}: wrong indicator or icon size {indicator} {icon}")
        close(center(rail)[0], center(icon)[0], f"{identity} icon centering")
        previous_y = target["y"]
        found = [op for op in legacy["Shape"] + legacy["Quad"]
                 if same_rect(op["rect"], indicator) and op["color"] == palette["secondary_container"]]
        require(len(found) == int(active), f"{identity}: selection paint differs")
        point = (round(indicator["x"] + 8.), round(indicator["y"] + 16.))
        icon_color = palette["outline" if disabled else "on_secondary_container" if active else "on_surface_variant"]
        icon_paths = [path for path in paths if same_rect(path["clip"], icon)]
        require(icon_paths and all(path["contour"]["color"] == icon_color for path in icon_paths),
                f"{identity}: expected 24 dp vector ink")
        label_color = palette["outline" if disabled else "on_surface" if active else "on_surface_variant"]
        labels = [op for op in legacy["Text"] + legacy["StyledText"]
                  if op["text"] == LABELS[identity] and contains(target, op["rect"])]
        require(len(labels) == 1 and labels[0]["color"] == label_color
                and contains(labels[0]["clip"], labels[0]["rect"]), f"{identity}: clipped label {labels}")
        label = labels[0]
        size = label.get("font_size") or label["style"]["font_size"]
        close(size, 12. * scale, f"{identity} actual Label Medium size")
        close(label["rect"]["height"], 16. * scale, f"{identity} fits on one line")
        paint[identity] = {"indicator": indicator, "icon": icon, "target": target, "label": label["rect"],
                           "label_color": label_color, "icon_color": icon_color, "label_font_dp": size,
                           "indicator_point": point,
                           "indicator_color": palette["secondary_container"] if active else rail_color}
    probes = {point for row in paint.values() for point in
              sample_points(row["label"]) | sample_points(row["icon"]) | {row["indicator_point"]}}
    raw = pixels_for(png, frame, probes)
    for identity, row in paint.items():
        require(color_matches(raw[row["indicator_point"]], row["indicator_color"], 2),
                f"{identity}: wrong state raster")
        label_ink = {point for point in sample_points(row["label"]) if color_matches(raw[point], row["label_color"], 30)}
        icon_ink = sum(color_matches(raw[point], row["icon_color"], 28) for point in sample_points(row["icon"]))
        label_mid = center(row["label"])[0]
        require(icon_ink >= 8 and len(label_ink) >= 12
                and any(x < label_mid for x, _ in label_ink)
                and any(x >= label_mid for x, _ in label_ink), f"{identity}: missing icon or CJK label glyphs")
        pixels[identity] = {"indicator": raw[row["indicator_point"]], "icon": icon_ink, "label": len(label_ink)}
    targets = [NAV["rectangle_relative"](paint[identity]["target"], rail) for identity in ITEMS]
    if case.frames:
        require(targets == case.frames[0]["targets"], "Rail hit bounds changed during selection or focus")
    frame.update(stage=stage, rtl=rtl, text_scale=scale, selection=selected, focused=focus_id, rail=rail,
                 page=PAGES[selected], page_bounds=page, accessibility=native, trace=trace, paint=paint,
                 pixels=pixels, targets=targets)
    if live and case.plan.verify_os_ax:
        frame["macos"] = live_rail(case.child.pid, focus_id)
    case.frames.append(frame)
    return frame


def live_rail(pid, focused):
    deadline = time.monotonic() + 3.
    while True:
        tree = AX["rail"](pid)
        items = {row["name"]: row for row in tree["controls"] if row["role"] == "AXButton"}
        if set(items) == set(NAMES.values()):
            home, archive, inbox = (items[NAMES[identity]] for identity in ITEMS)
            checks = (home["enabled"] and inbox["enabled"] and archive["enabled"] is False
                      and "AXPress" not in archive["actions"]
                      and "AXPress" in home["actions"] and "AXPress" in inbox["actions"])
            if focused in ITEMS:
                current = items[NAMES[focused]]
                checks &= bool(current["focused"] or current["focus_attr"])
            if checks:
                return tree
        require(time.monotonic() < deadline, f"Public macOS rail semantics differ: {tree}")
        time.sleep(.05)


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    if rtl:
        case.call("action", "activate", RTL)
    if scale == 2.:
        case.call("action", "activate", SCALE)
    case.point("leave")
    QA["reveal"](case, LAYOUT)
    focus(case, SCALE)
    key(case, "tab", HOME)
    take(case, "initial", rtl, scale, HOME, (), HOME, live=True)
    key(case, "down", INBOX)
    take(case, "skip-disabled", rtl, scale, HOME, (), INBOX, live=True)
    key(case, "down", HOME)
    key(case, "up", INBOX)
    key(case, "up", HOME)
    key(case, "end", INBOX)
    key(case, "home", HOME)
    key(case, "end", INBOX)
    take(case, "wrap", rtl, scale, HOME, (), INBOX)
    key(case, "enter", INBOX)
    take(case, "entered", rtl, scale, INBOX, (INBOX,), INBOX, live=True)
    key(case, "tab", SCALE, shift=True)
    key(case, "tab", INBOX)

    target = center(rect(case.snapshot(), ARCHIVE))
    case.point("down", target)
    require(case.snapshot()["interaction"]["pressed"] is None, "Disabled Archive gained a Winit press")
    case.point("up", target)
    case.point("leave")
    if case.plan.verify_os_ax:
        refused = AX["rail"](case.child.pid, activate=NAMES[ARCHIVE])
        case.disabled_ax_status = refused.get("press_status")
    take(case, "disabled", rtl, scale, INBOX, (INBOX,))

    target = center(rect(case.snapshot(), HOME))
    case.point("down", target)
    require(node(case.snapshot(), PAGE)["text"] == PAGES[INBOX], "PointerDown activated Home early")
    case.point("up", target)
    case.point("leave")
    take(case, "pointer", rtl, scale, HOME, (INBOX, HOME), HOME, live=True)
    if not case.plan.verify_os_ax:
        return None
    ax_input = AX["rail"](case.child.pid, activate=NAMES[INBOX])
    require(ax_input.get("press_status") == 0, f"Public AXPress failed: {ax_input}")
    until = time.monotonic() + 3.
    while node(case.snapshot(), PAGE)["text"] != PAGES[INBOX]:
        require(time.monotonic() < until, "Public AXPress never changed the app page")
        time.sleep(.04)
    selected = take(case, "ax-pressed", rtl, scale, INBOX, (INBOX, HOME, INBOX), INBOX, live=True)
    if case.size[0] != 320 or not rtl or not case.dark:
        return None
    mirror = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
    require(read_png(case.plan.artifacts, selected) == read_png(case.plan.artifacts, mirror),
            "CLI and MCP returned different rail PNGs")
    return {**mirror, "cli": selected["file"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile", action="append", choices=PROFILES)
    parser.add_argument("--verify-os-ax", action="store_true")
    plan = parser.parse_args()
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    plan.checkout = HERE / "qa-verified-label"
    plan.client = HERE / "binaries/surface-devtools"
    plan.launcher = HERE / "launch-private-rail.sh"
    plan.palette = json.loads(subprocess.check_output([HERE / "binaries/examples/fab_menu_native", "--palette"]))
    plan.case, plan.startup_timeout = "normal", 30
    if plan.verify_os_ax:
        require(AX["AX"]["trusted"](), "An Accessibility-authorized process is required")
    report = {"runs": {}, "frames": [], "errors": []}
    for name, (size, dark, rtl, scale) in PROFILES.items():
        if plan.profile and name not in plan.profile:
            continue
        case = None
        try:
            os.environ["SURFACE_QA_RAIL_TRACE"] = str(plan.artifacts / f"{name}.jsonl")
            with COMMON["gallery"](plan, name, size, dark) as case:
                case.disabled_ax_status = None
                mcp = journey(case, rtl, scale)
            log = (plan.artifacts / f"{name}.log").read_text()
            adapter = next((line for line in log.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in adapter and "backend: Metal" in adapter, "Expected Apple Metal")
            report["runs"][name] = {"adapter": adapter, "mcp": mcp, "disabled_press_status": case.disabled_ax_status}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            trace = traceback.format_exc()
            report["errors"].append(f"{name}: {error}")
            print(trace, flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(report["runs"] and not report["errors"], "Native rail checks failed")
    print(f"Passed {len(report['frames'])} native Metal PNGs across {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
