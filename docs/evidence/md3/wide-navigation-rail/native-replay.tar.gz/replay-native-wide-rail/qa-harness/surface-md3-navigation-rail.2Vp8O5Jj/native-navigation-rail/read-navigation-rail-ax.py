"""Read and press named controls in the private macOS Gallery's public AX API."""

import ctypes
from pathlib import Path
import runpy


workspace = Path(__file__).resolve().parents[2]
feedback = runpy.run_path(str(workspace / "surface-md3-search-feedback.EobRE56w/native-search-feedback/read-feedback-ax.py"))
AX, ax_bool = feedback["AX"], feedback["ax_bool"]
bind, release, ptr = AX["bind"], AX["release"], AX["PTR"]
service, foundation = AX["APP_SERVICES"], AX["FOUNDATION"]
copy_actions = bind(service, "AXUIElementCopyActionNames", AX["STATUS"], ptr, ctypes.POINTER(ptr))
perform_action = bind(service, "AXUIElementPerformAction", AX["STATUS"], ptr, ptr)
equal = bind(foundation, "CFEqual", ctypes.c_bool, ptr, ptr)
NAMES = ("前往首頁", "封存資料", "收件匣")


def elements(parent, name):
    status, values = AX["ax_attribute"](parent, name)
    if status == 0 and values:
        try:
            if AX["type_id"](values) == AX["array_type"]():
                for index in range(AX["array_count"](values)):
                    yield AX["array_item"](values, index)
        finally:
            release(values)


def actions(element):
    values = ptr()
    status = copy_actions(element, ctypes.byref(values))
    if status != 0 or not values:
        return []
    try:
        names = []
        for index in range(AX["array_count"](values)):
            value = AX["array_item"](values, index)
            text = ctypes.create_string_buffer(512)
            if AX["string_read"](value, text, len(text), AX["UTF8"]):
                names.append(text.value.decode())
        return names
    finally:
        release(values)


def press(element):
    key = AX["string_create"](None, b"AXPress", AX["UTF8"])
    try:
        return perform_action(element, key)
    finally:
        release(key)


def rail(pid, activate=None):
    if not AX["trusted"]():
        return {"trusted": False, "controls": []}
    app = AX["create_application"](pid)
    AX["set_timeout"](app, 1.)
    _, focus = AX["ax_attribute"](app, "AXFocusedUIElement")
    visited = 0
    reply = {"trusted": True, "controls": []}

    def walk(element, depth=0):
        nonlocal visited
        visited += 1
        if visited > 2000 or depth > 32:
            raise RuntimeError("Private Gallery AX tree exceeded its inspection budget")
        scalar = AX["scalar"]
        role = scalar(element, "AXRole")
        labels = [scalar(element, name) for name in ("AXTitle", "AXDescription", "AXLabel")]
        name = next((label for label in labels if label in ("主導覽", *NAMES)), None)
        if name:
            data = {"name": name, "role": role, "enabled": ax_bool(element, "AXEnabled"),
                    "focus_attr": ax_bool(element, "AXFocused"), "focused": bool(focus and equal(element, focus)),
                    "actions": actions(element), "selected": ax_bool(element, "AXSelected")}
            reply["controls"].append(data)
            if activate == name and role == "AXButton" and "press_status" not in reply:
                reply["press_status"] = press(element)
        for child in elements(element, "AXChildren"):
            walk(child, depth + 1)

    try:
        for window in elements(app, "AXWindows"):
            walk(window)
    finally:
        if focus:
            release(focus)
        release(app)
    return reply
