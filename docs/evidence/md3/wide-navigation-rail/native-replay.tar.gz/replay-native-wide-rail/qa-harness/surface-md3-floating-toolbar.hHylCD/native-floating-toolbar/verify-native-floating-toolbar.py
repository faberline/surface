#!/usr/bin/env python3
"""Verify native Floating Toolbar geometry, palette, and keyboard actions."""

import argparse
import json
import math
from pathlib import Path
import runpy
import subprocess
import time


HERE = Path(__file__).resolve().parent
QA = runpy.run_path(str(HERE.parents[1] /
                        "surface-md3-fab-vector.ppAhHk/native-vector/verify-native-fab-vector.py"))
COMMON, MOTION, BASE = QA["COMMON"], QA["MOTION"], QA["BASE"]
require, close, geometry = QA["require"], QA["close"], QA["geometry"]
capture, png_pixels, write_json = QA["capture"], QA["png_pixels"], QA["write_json"]
SECTION = "section-8"
BAR = "floating-toolbar"
NAME = "筆記工具列"
PREVIEW, STATUS, CLEAR = (f"{BAR}-{name}" for name in ("preview", "status", "clear"))
DOCUMENT = f"{BAR}-document"
AXIS, PALETTE, DIRECTION = (f"{BAR}-{name}" for name in ("axis", "palette", "direction"))
UNDO, REDO, CREATE = (f"{BAR}-{name}" for name in ("undo", "redo", "create"))
NAMES = {UNDO: "復原", REDO: "重做", CREATE: "新增筆記"}
TURN = [(3, 11), (10, 4), (10, 8), (17, 8), (21, 12), (21, 19),
        (17, 19), (17, 13), (10, 13), (10, 18)]
SETTLE = 750


def set_modes(case, vertical, vibrant, rtl):
    nodes, index = COMMON["dom_index"](case.snapshot())
    for stable, expected in ((AXIS, vertical), (PALETTE, vibrant), (DIRECTION, rtl)):
        if nodes[index[stable]]["selected"] is not expected:
            case.call("action", "activate", stable)
    case.clock.advance(SETTLE)


def same_rect(first, second):
    return all(math.isclose(first[key], second[key], abs_tol=.03)
               for key in ("x", "y", "width", "height"))


def style_paint(ops, kinds):
    return [paint for op in ops for kind, paint in op.get("Legacy", {}).items() if kind in kinds]


def projected_toolbar(snapshot, projected, vertical):
    nodes, ids = COMMON["dom_index"](snapshot)
    bar = projected[BAR]
    require(bar["name"] == NAME and bar["role"] == "Group"
            and bar["orientation"] == ("vertical" if vertical else "horizontal"),
            f"Incorrect native runtime toolbar metadata: {bar}")
    require(not bar["focusable"] and not bar["press"], "Toolbar container gained a Tab or press action")
    children = list(BASE["descendants"](nodes, ids[BAR]))
    buttons = [nodes[i]["stable_id"] for i in children if nodes[i]["role"] == "Button"]
    require(buttons == list(NAMES), f"Toolbar DOM order changed: {buttons}")
    for stable, name in NAMES.items():
        item = projected[stable]
        enabled = stable != REDO
        require(item["role"] == "Button" and item["name"] == name, f"Incorrect toolbar member {item}")
        require(item["focusable"] is enabled and item["press"] is enabled,
                f"Incorrect native focus/press availability for {stable}")


def samples(case, frame, icon, wanted):
    positions = {label: QA["point_in_pixel"](icon, sample) for label, sample in wanted.items()}
    decoded = png_pixels(case.plan.artifacts / frame["file"], frame, positions.values())
    return {label: {"point": point, "rgba": decoded[point]} for label, point in positions.items()}


def check_icon(case, snapshot, receipt, frame, stable, fill, foreground, expect_focus):
    nodes, ids, target, visible = geometry(snapshot, stable)
    node_id = ids[stable]
    visual_id = nodes[node_id]["first_child"]
    slot_id = nodes[visual_id]["first_child"]
    layout = snapshot["layout"]["nodes"]
    visual, icon = layout[visual_id]["bounds"], layout[slot_id]["bounds"]
    require(same_rect(target, visible), f"{stable}: touch target is clipped")
    for key in ("width", "height"):
        close(target[key], 48., f"{stable}: touch {key}")
        close(visual[key], 40., f"{stable}: state face {key}")
        close(icon[key], 24., f"{stable}: icon {key}")
    for actual, expected in zip(COMMON["center"](icon), COMMON["center"](target)):
        close(actual, expected, f"{stable}: icon centered in the target")

    ops = QA["ops_for"](receipt, snapshot, stable)
    paths = [op["FillPath"] for op in ops if "FillPath" in op]
    require(len(paths) == 1, f"{stable}: expected one vector icon")
    path = paths[0]
    require(same_rect(path["clip"], icon), f"{stable}: contour clip lost the icon viewport")
    ink = path["contour"]["color"]
    require(ink[3] == 255, f"{stable}: opaque theme ink changed")
    if stable == REDO:
        require(0 < QA["color_delta"](ink, fill) < QA["color_delta"](foreground, fill),
                "Disabled icon did not use attenuated theme ink")
    else:
        require(ink == foreground, f"{stable}: enabled vector palette ink differs")

    if stable == CREATE:
        QA["inspect_path"](ops, icon, ink)
        pixels = samples(case, frame, icon, QA["SAMPLES"])
        QA["assert_rest_pixels"](pixels, ink, fill, stable)
    else:
        def orient(x, y):
            return (24 - x, y) if stable == REDO else (x, y)
        measured = {tuple(round((coordinate - icon[axis]), 1) for coordinate, axis in zip(point, ("x", "y")))
                    for point in path["contour"]["points"]}
        require(measured == {orient(x, y) for x, y in TURN}, f"{stable}: turn path or geometry changed")
        pixels = samples(case, frame, icon, {"ink": orient(8, 11), "outside": orient(20, 5)})
        require(QA["color_delta"](pixels["ink"]["rgba"], ink) <= 5, f"{stable}: arrow ink missing")
        require(QA["color_delta"](pixels["outside"]["rgba"], fill) <= 5, f"{stable}: arrow corner filled")

    outline = [stroke for stroke in style_paint(ops, ("Stroke", "ShapeStroke"))
               if same_rect(stroke["rect"], target) and math.isclose(stroke["width"], 2., abs_tol=.03)]
    if expect_focus:
        require(len(outline) == 1 and receipt["projected"][stable]["focused"],
                f"{stable}: native focus ring or focus projection missing")
        point = (math.floor(COMMON["center"](target)[0]), math.ceil(target["y"] + 1.))
        color = png_pixels(case.plan.artifacts / frame["file"], frame, [point])[point]
        require(QA["color_delta"](color, outline[0]["color"]) <= 6, "Focus ring is absent from native PNG")
    return {"touch": target, "visual": visual, "icon": icon, "ink": ink, "samples": pixels,
            "focus_stroke": outline}


def preview_text(case, frame, snapshot, toolbar, preview, possible_overlap):
    nodes, ids = COMMON["dom_index"](snapshot)
    status = geometry(snapshot, STATUS)[2]
    title = geometry(snapshot, DOCUMENT)[2]
    require(status["y"] >= preview["y"] + preview["height"] - .03,
            "Preview result text intersects the toolbar area")
    overlap = COMMON["intersection"](title, toolbar) if possible_overlap else None
    glyph_pixels = None
    if overlap and overlap["width"] > 0. and overlap["height"] > 0.:
        require(overlap["height"] <= 4.03, "Toolbar covers the preview's title")
        x0, y0 = math.ceil(title["x"]), math.ceil(title["y"])
        y1 = math.floor(toolbar["y"])
        if y0 >= 0 and y1 > y0 and x0 >= 0 and x0 + 32 <= frame["width"]:
            points = [(x, y) for x in range(x0, x0 + 32) for y in range(y0, y1)]
            tint = nodes[ids[DOCUMENT]]["style"]["foreground"]
            decoded = png_pixels(case.plan.artifacts / frame["file"], frame, points)
            glyph_pixels = [sum(QA["color_delta"](value, tint) <= 6
                                for (x, _), value in decoded.items() if x0 + 16 * i <= x < x0 + 16 * (i + 1))
                            for i in (0, 1)]
            require(min(glyph_pixels) >= 6, "One of the preview title glyphs was hidden")
    return {"title": title, "status": status, "title_ink_pixels": glyph_pixels}


def take(case, name, vertical, vibrant, rtl, focus=None, visible=True):
    targets = (BAR,) if visible else ()
    shot, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{name}",
                             case.size, case.dark, SECTION, targets)
    require(not shot["errors"], str(shot["errors"]))
    receipt = json.loads(case.receipt.read_text())
    require(receipt["accessibility_frame"], "The native runtime accessibility snapshot is missing")
    projected = receipt["projected"]
    nodes, ids = COMMON["dom_index"](snapshot)
    focused = snapshot["interaction"]["focused"]
    if focus is not None:
        require(focused == focus and projected[focus]["focused"],
                f"{shot['file']}: did not keep focus on {focus}")
    data = {"orientation": "vertical" if vertical else "horizontal",
            "palette": "vibrant" if vibrant else "standard", "rtl": rtl,
            "focused": focused, "status": nodes[ids[STATUS]]["text"], "projected": projected}
    if visible:
        projected_toolbar(snapshot, projected, vertical)
        _, _, box, clipped = geometry(snapshot, BAR)
        preview = geometry(snapshot, PREVIEW)[2]
        require(same_rect(box, clipped), "Toolbar capsule is clipped")
        close(box["width"], 64. if vertical else 168., "bar width")
        close(box["height"], 168. if vertical else 64., "bar height")
        inset_x = box["x"] - preview["x"] if rtl else preview["x"] + preview["width"] - box["x"] - box["width"]
        close(inset_x, 16., "bottom/end inline inset")
        close(preview["y"] + preview["height"] - box["y"] - box["height"], 16., "bottom inset")

        style = nodes[ids[BAR]]["style"]
        fill, foreground = style["background"], style["foreground"]
        stroke = style_paint(QA["ops_for"](receipt, snapshot, BAR), ("Quad", "Shape"))
        require(any(same_rect(shape["rect"], box) and shape["color"] == fill for shape in stroke),
                "Pill fill did not reach the native display list")
        center = COMMON["center"](box)
        sample = (round(box["x"] + 4), round(center[1])) if vertical else (round(center[0]), round(box["y"] + 4))
        observed = png_pixels(case.plan.artifacts / shot["file"], shot, [sample])[sample]
        require(fill[3] == 255 and QA["color_delta"](observed, fill) <= 5,
                "The native PNG does not contain the Material toolbar fill")
        items = {stable: check_icon(case, snapshot, receipt, shot, stable, fill, foreground, focus == stable)
                 for stable in NAMES}
        axis, major, cross, minor = ("y", "height", "x", "width") if vertical else ("x", "width", "y", "height")
        order = list(NAMES) if vertical or not rtl else list(reversed(NAMES))
        for slot, stable in enumerate(order):
            box_item = items[stable]["touch"]
            close(box_item[axis] - box[axis], 8. + slot * 52., f"{stable}: padding, spacing and physical order")
            close(box_item[cross] - box[cross], (box[minor] - box_item[minor]) / 2., f"{stable}: cross-axis center")
            require(box_item[axis] + box_item[major] <= box[axis] + box[major], "A target escaped the capsule")
        data.update(bar=box, preview=preview, fill=fill, foreground=foreground,
                    pill_sample={"point": sample, "rgba": observed}, items=items,
                    preview_text=preview_text(case, shot, snapshot, box, preview, vertical and rtl))
    receipt_path = f"{case.prefix}-{name}.presentation.json"
    write_json(case.plan.artifacts / receipt_path, data)
    shot.update(data, presentation=receipt_path, time_ms=case.clock.now)
    case.frames.append(shot)
    return shot


def send_key(case, key, expected, *, extend=False):
    args = ("--extend",) if extend else ()
    result = case.call("action", "key", key, *args)
    require(result["focused"] == expected,
            f"Key {key} reached {result['focused']}, expected {expected}")
    return {"key": key, "shift": extend, "focused": result["focused"]}


def status(case):
    nodes, ids = COMMON["dom_index"](case.snapshot())
    return nodes[ids[STATUS]]["text"]


def verify_keys(case, vertical, rtl):
    set_modes(case, vertical, True, rtl)
    case.call("action", "activate", CLEAR)
    tab_in = send_key(case, "tab", UNDO, extend=True)
    if vertical:
        forward, backward, orthogonal = "down", "up", "left"
    elif rtl:
        forward, backward, orthogonal = "left", "right", "up"
    else:
        forward, backward, orthogonal = "right", "left", "up"
    keys = [tab_in, send_key(case, orthogonal, UNDO), send_key(case, forward, CREATE),
            send_key(case, forward, UNDO), send_key(case, backward, CREATE),
            send_key(case, "home", UNDO), send_key(case, "end", CREATE)]
    require(status(case) == "尚無操作", "Arrow, Home or End invoked a toolbar action")
    keys.append(send_key(case, "enter", CREATE))
    require(status(case) == "新增筆記 · 1", "Enter did not invoke the focused Create action once")
    QA["reveal"](case, BAR)
    shot = take(case, f"keyboard-{'vertical' if vertical else 'horizontal'}-{'rtl' if rtl else 'ltr'}",
                vertical, True, rtl, focus=CREATE)
    keys.append(send_key(case, "tab", CLEAR))
    keys.append(send_key(case, "tab", UNDO, extend=True))
    keys.append(send_key(case, "tab", DIRECTION, extend=True))
    keys.append(send_key(case, "tab", UNDO))
    QA["reveal"](case, BAR)
    point = COMMON["center"](geometry(case.snapshot(), REDO)[2])
    case.point("down", point)
    case.point("up", point)
    require(status(case) == "新增筆記 · 1", "Disabled Redo action responded to native pointer input")
    return {"keys": keys, "focus_png": shot["file"], "disabled_pointer": point}


def verify_matrix(case):
    colors = {}
    mcp = None
    for vertical in (False, True):
        for rtl in (False, True):
            for vibrant in (False, True):
                set_modes(case, vertical, vibrant, rtl)
                QA["reveal"](case, BAR)
                case.point("leave")
                case.clock.advance(SETTLE)
                title = f"{'vertical' if vertical else 'horizontal'}-{'rtl' if rtl else 'ltr'}-{'vibrant' if vibrant else 'standard'}"
                frame = take(case, title, vertical, vibrant, rtl)
                colors.setdefault(frame["palette"], set()).add(tuple(frame["fill"]))
                if vertical and rtl and vibrant and case.dark and case.size == (320, 240):
                    mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
                    require(mcp["sha256"] == frame["sha256"], "Toolbar CLI and MCP PNGs differ")
                    mcp["cli"] = frame["file"]
    require(all(len(found) == 1 for found in colors.values())
            and colors["standard"] != colors["vibrant"], f"Palette selection did not change fill: {colors}")
    keys = {f"{'vertical' if vertical else 'horizontal'}-{'rtl' if rtl else 'ltr'}": verify_keys(case, vertical, rtl)
            for vertical in (False, True) for rtl in (False, True)}
    return {"colors": {name: list(next(iter(found))) for name, found in colors.items()}, "keys": keys, "mcp": mcp}


def live_ax(case):
    QA["reveal"](case, BAR)
    active = MOTION["make_active"](case.plan.probe, case.child)
    confirmations = {}
    for vertical in (False, True):
        set_modes(case, vertical, True, False)
        QA["reveal"](case, BAR)
        case.call("action", "qa-ax-focus", CREATE)
        expected = "AXVerticalOrientation" if vertical else "AXHorizontalOrientation"
        for _ in range(10):
            observed = BASE["query_ax"](case.plan.probe, case.child, NAME, *NAMES.values())
            bars = [item for item in observed["matches"] if item["role"] == "AXToolbar" and item["label"] == NAME]
            action = [item for item in observed["matches"] if item["role"] == "AXButton" and item["label"] == NAMES[CREATE]]
            if observed["active"] and len(bars) == 1 and len(action) == 1 and action[0]["focused"]:
                break
            time.sleep(.12)
        else:
            raise RuntimeError(f"Native AppKit did not expose one toolbar and focused child: {observed}")
        require(bars[0].get("orientation") == expected, f"Missing real AppKit orientation {expected}")
        require("AXPress" in action[0]["actions"], "AppKit omitted enabled child's AXPress")
        require(any(item["label"] == NAMES[REDO] and not item["enabled"] and "AXPress" not in item["actions"]
                    for item in observed["matches"]), "Native AppKit exposed disabled Redo press")
        previous = status(case)
        pressed = BASE["query_ax"](case.plan.probe, case.child, NAMES[CREATE], "--press")
        require(pressed.get("pressStatus") == 0, "Live AppKit AXPress failed")
        for _ in range(8):
            if status(case) != previous:
                break
            time.sleep(.1)
        else:
            raise RuntimeError("The live toolbar AXPress did not update the action status")
        frame = take(case, f"appkit-{'vertical' if vertical else 'horizontal'}", vertical, True, False, focus=CREATE)
        confirmations[expected] = {"observation": observed, "press": pressed, "file": frame["file"]}
    return {"activation": active, "confirmations": confirmations}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--probe", type=Path)
    parser.add_argument("--viewport", choices=COMMON["VIEWPORTS"])
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--startup-timeout", type=int, default=180)
    parser.add_argument("--case", choices=("matrix", "ax"), default="matrix")
    plan = parser.parse_args()
    if plan.case == "ax" and not plan.probe:
        parser.error("Live AppKit mode requires the Swift probe")
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    report = {"capture": "Surface Page.screenshot", "frames": [], "runs": {}, "errors": []}
    for view, size in COMMON["VIEWPORTS"].items():
        if plan.viewport not in (None, view):
            continue
        for theme in ("light", "dark"):
            if plan.theme not in (None, theme):
                continue
            prefix = f"{view}-{theme}-{plan.case}"
            case = None
            try:
                with COMMON["gallery"](plan, prefix, size, theme == "dark") as case:
                    case.call("action", "activate", SECTION)
                    case.clock.advance(SETTLE)
                    report["runs"][prefix] = live_ax(case) if plan.case == "ax" else verify_matrix(case)
            except (RuntimeError, OSError, KeyError, TypeError, ValueError, subprocess.SubprocessError) as error:
                report["errors"].append(f"{prefix}: {error}")
                print(report["errors"][-1], flush=True)
            finally:
                if case:
                    report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"], "\n".join(report["errors"]))
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} runs")


if __name__ == "__main__":
    main()
