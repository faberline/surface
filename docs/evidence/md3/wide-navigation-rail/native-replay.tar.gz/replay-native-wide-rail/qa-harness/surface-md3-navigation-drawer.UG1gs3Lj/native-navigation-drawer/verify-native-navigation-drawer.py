#!/usr/bin/env python3
"""Exercise a directional Material Drawer on Metal and the public macOS AX API."""

import argparse
import json
import os
from pathlib import Path
import runpy
import subprocess
import time
import traceback


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
RAIL = runpy.run_path(str(WORKSPACE / "surface-md3-navigation-rail.2Vp8O5Jj/native-navigation-rail/verify-native-navigation-rail.py"))
MAC = runpy.run_path(str(HERE / "read-drawer-ax.py"))
COMMON, MOTION, QA = (RAIL[name] for name in ("COMMON", "MOTION", "QA"))
capture, center, color_matches, contains, focus, key, node, pixels_for, read_png, rect, require, same_rect, sample_points, write_json = (
    RAIL[name] for name in ("capture", "center", "color_matches", "contains", "focus", "key", "node",
                           "pixels_for", "read_png", "rect", "require", "same_rect", "sample_points", "write_json")
)
SECTION = "section-1"
PANEL = "drawer-demo"
CARD = "modal-drawer-card"
LAYER, HEADER, TITLE, CLOSE, NAV, OPEN, RTL, SCALE, BACKGROUND, PAGE = (
    f"{PANEL}-{name}" for name in ("layer", "header", "title", "close", "navigation", "open",
                                   "rtl", "scale", "background", "page")
)
HOME, ARCHIVE, INBOX, REPORTS, MEMBERS, SETTINGS = ROWS = tuple(
    f"{PANEL}-{name}" for name in ("home", "archive", "inbox", "reports", "members", "settings")
)
NAMES = {**dict(zip(ROWS, MAC["DESTINATIONS"])), CLOSE: MAC["CLOSE"], OPEN: MAC["OPENER"],
         BACKGROUND: MAC["BACKGROUND"]}
PROFILES = {
    "wide-light-ltr": ((960, 800), False, False, 1.),
    "wide-dark-rtl": ((960, 800), True, True, 1.),
    "compact-light-rtl-2x": ((320, 240), False, True, 2.),
    "compact-dark-rtl-2x": ((320, 240), True, True, 2.),
}
OPEN_STAGES = {"opened", "skip-disabled", "long-label", "wheel-bottom", "last-focus",
               "reopen-escape", "reopen-close", "reopen-scrim"}


def ids(snapshot):
    return COMMON["dom_index"](snapshot)[1]


def layout(snapshot, id):
    return snapshot["layout"]["nodes"][ids(snapshot)[id]]


def visible(snapshot, id):
    geo = layout(snapshot, id)
    return contains(geo["clip"], geo["bounds"]) and geo["bounds"]["height"] > 0.


def trace_actions(receipt):
    records = map(json.loads, receipt["trace"].splitlines())
    return [event["data"]["source"]["id"] for event in records if event["kind"] == "Message"
            and (event["data"]["source"] or {}).get("id") in (*ROWS, CLOSE, BACKGROUND)]


def read_live(case, opened, focus_id):
    deadline = time.monotonic() + 4.
    while True:
        tree = MAC["inspect"](case.child.pid)
        items = tree["controls"]
        focused = [item for item in items if item["name"] == NAMES[focus_id] and item["role"] == "AXButton"]
        dialog = [item for item in items if item["name"] == MAC["DIALOG"] and item["modal"] is True]
        nav = [item for item in items if item["name"] == MAC["NAVIGATION"]
               and item["subrole"] == "AXLandmarkNavigation"]
        outside = [item for item in items if item["name"] in (MAC["BACKGROUND"], MAC["OPENER"])]
        if len(focused) == 1 and (focused[0]["focus_attr"] or focused[0]["focused"]):
            if opened:
                archive = [item for item in items if item["name"] == NAMES[ARCHIVE] and item["role"] == "AXButton"]
                if (len(dialog) == len(nav) == 1 and not outside
                        and MAC["DIALOG"] in nav[0]["ancestors"]
                        and all(item["enabled"] is False and "AXPress" not in item["actions"] for item in archive)
                        and "AXPress" in focused[0]["actions"]):
                    return tree
            elif not dialog and not nav and "AXPress" in focused[0]["actions"]:
                return tree
        require(time.monotonic() < deadline, f"Public macOS modal, navigation or focus differs: {tree}")
        time.sleep(.05)


def same_header(case, frame):
    earlier = next((item for item in case.frames if item["stage"] == "opened"), None)
    require(not earlier or earlier["header"] == frame["header"], "Drawer header moved with the inner list")


def take(case, stage, rtl, scale, focused, page=HOME, actions=(), *, live=False):
    case.clock.advance(450)
    opened = stage in OPEN_STAGES
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{stage}",
                              case.size, case.dark, SECTION, (CLOSE, HEADER, TITLE, NAV) if opened else (OPEN,))
    require(not frame["errors"], str(frame["errors"]))
    lookup = ids(snapshot)
    require((PANEL in lookup) is opened and node(snapshot, OPEN)["expanded"] is opened
            and snapshot["interaction"]["focused"] == focused, f"Drawer moved focus or lost disclosure in {stage}")
    require(node(snapshot, PAGE)["text"] == NAMES[page], f"Drawer moved page without one press in {stage}")
    receipt = json.loads(case.receipt.read_text())
    trace = trace_actions(receipt)
    require(trace == list(actions), f"Drawer emitted incorrect app messages in {stage}: {trace}")
    frame.update(stage=stage, rtl=rtl, text_scale=scale, focus=focused, opened=opened, page=page, trace=trace)
    if opened:
        palette = case.plan.palette["dark" if case.dark else "light"]
        panel, layer, header, title, close_box, nav = (
            rect(snapshot, id) for id in (PANEL, LAYER, HEADER, TITLE, CLOSE, NAV)
        )
        viewport = frame["viewport"]
        require(same_rect(layer, viewport) and panel["width"] == min(360., viewport["width"])
                and panel["height"] == viewport["height"] and panel["y"] == 0.
                and panel["x"] == (viewport["width"] - panel["width"] if rtl else 0.),
                f"Directional drawer has wrong bounds: {panel}, {layer}")
        require(contains(panel, header) and contains(header, title) and contains(header, close_box)
                and contains(panel, nav) and nav["y"] == header["y"] + header["height"]
                and (center(close_box)[0] > center(title)[0]) is rtl, "Header or body is incorrectly placed")
        boundaries = node(snapshot, PANEL)["style"]["corners"]
        rounded = tuple(boundaries[corner] for corner in
                        (("top_left", "bottom_left") if rtl else ("top_right", "bottom_right")))
        square = tuple(boundaries[corner] for corner in
                       (("top_right", "bottom_right") if rtl else ("top_left", "bottom_left")))
        require(rounded == (16., 16.) and square == (0., 0.), "Shape did not mirror at its logical end")
        ax = receipt["accesskit"]["nodes"]
        dialog, navigation = (ax[id] for id in (PANEL, NAV))
        require(dialog["role"] == "Dialog" and dialog["modal"] and dialog["name"] == MAC["DIALOG"]
                and navigation["role"] == "Navigation" and navigation["name"] == MAC["NAVIGATION"]
                and not navigation["press"], f"Modal or inner Navigation semantics differ: {dialog} {navigation}")
        require(OPEN not in ax and BACKGROUND not in ax, "Accessibility reaches the background inside a modal")
        paint = [entry["Legacy"] for entry in receipt["presented"]["ops"] if "Legacy" in entry]
        fills = [entry[kind] for entry in paint for kind in ("Quad", "Shape") if kind in entry]
        styled = [entry["StyledText"] for entry in paint if "StyledText" in entry]
        fill = node(snapshot, LAYER)["style"]["background"]
        require(fill[:3] == palette["scrim"][:3] and fill[3] == 82
                and any(item["color"] == fill and same_rect(item["rect"], layer) for item in fills)
                and any(item["color"] == palette["surface_container_low"] and same_rect(item["rect"], panel)
                        for item in fills), "Material panel or scrim paint is missing")
        title_runs = [run for run in styled if run["text"] == MAC["DIALOG"] and same_rect(run["rect"], title)]
        require(len(title_runs) == 1 and title_runs[0]["style"]["font_size"] == 14. * scale
                and title_runs[0]["rect"]["height"] == 20. * scale, "Header text does not fit or respects no scale")
        row_frames = {}
        for identity in ROWS:
            nodes = node(snapshot, identity)
            row = rect(snapshot, identity)
            icon = RAIL["NAV"]["desc"](snapshot, identity, 1)
            require(row["height"] >= 56. and row["width"] >= 48.
                    and (center(icon)[0] > center(row)[0]) is rtl and icon["width"] == icon["height"] == 24.,
                    f"Destination size or direction differs in {identity}")
            require(nodes["disabled"] is (identity == ARCHIVE) and nodes["selected"] is (identity == page),
                    f"Destination state differs in {identity}")
            if identity in ax:
                button = ax[identity]
                partially_visible = RAIL["NAV"]["overlap_rect"](row, layout(snapshot, identity)["clip"])
                require(button["role"] == "Button" and button["name"] == NAMES[identity]
                        and button["press"] is (partially_visible and identity != ARCHIVE)
                        and not button["children"],
                        f"Destination action duplicated or changed in {identity}: {button}")
            row_frames[identity] = {"target": row, "icon": icon, "fully_visible": visible(snapshot, identity)}
        require(all(row_frames[a]["target"]["y"] < row_frames[b]["target"]["y"] for a, b in zip(ROWS, ROWS[1:])),
                "Drawer destination stacking order changed")
        frame.update(panel=panel, header=header, nav=nav, rows=row_frames, scroll=receipt["scroll"],
                     scrim=fill, dialog=dialog, navigation=navigation, title_paint=title_runs[0])
        same_header(case, frame)
        if stage == "opened":
            require(row_frames[HOME]["fully_visible"] and ax[HOME]["selected"], "Current Home is clipped on open")
            active = row_frames[HOME]["target"]
            require(any(item["color"] == palette["secondary_container"] and same_rect(item["rect"], active)
                        for item in fills), "Active Home indicator did not paint")
        if stage in ("skip-disabled", "long-label", "last-focus"):
            require(row_frames[focused]["fully_visible"], f"Keyboard focus did not reveal {focused}")
        if stage == "long-label":
            target = row_frames[REPORTS]["target"]
            report = [run for run in styled if run["text"] == NAMES[REPORTS] and contains(target, run["rect"])]
            require(len(report) == 1 and contains(report[0]["clip"], report[0]["rect"])
                    and report[0]["style"]["font_size"] == 14. * scale, "Long CJK destination label is clipped")
            run = report[0]
            points = sample_points(run["rect"])
            pixels = pixels_for(case.plan.artifacts / frame["file"], frame, points)
            ink = [point for point in points if color_matches(pixels[point], run["color"], 24)]
            require(len(ink) > 25, "The Metal PNG did not draw the long CJK label")
            if scale == 2.:
                line_end = run["rect"]["y"] + 40.
                require(run["rect"]["height"] >= 80. and any(y < line_end for _, y in ink)
                        and any(y >= line_end for _, y in ink), "Long compact label did not paint both CJK lines")
            frame.update(report_paint=run, report_glyph_pixels=len(ink))
    if live and case.plan.verify_os_ax:
        frame["macos"] = read_live(case, opened, focused)
    case.frames.append(frame)
    return frame


def check_scrim(case, before, opened):
    x = 22 if opened["rtl"] else case.size[0] - 22
    points = [(x, y) for y in (15, 28, 45)]
    colors = [pixels_for(case.plan.artifacts / frame["file"], frame, points) for frame in (before, opened)]
    alpha = opened["scrim"][3] / 255.
    for point in points:
        underlying = colors[0][point]
        expected = [round(from_ * (1. - alpha) + to * alpha)
                    for from_, to in zip(underlying[:3], opened["scrim"][:3])] + [255]
        require(color_matches(colors[1][point], expected, 3),
                f"Expected the actual drawer scrim at {point}, got {colors[1][point]} vs {expected}")
    opened["scrim_samples"] = [{"point": point, "before": colors[0][point], "after": colors[1][point]}
                               for point in points]


def actual_press(case, identity):
    if case.plan.verify_os_ax:
        response = MAC["inspect"](case.child.pid, activate=NAMES[identity])
        require(response.get("press_status") == 0, f"Real AXPress failed for {identity}: {response}")
    else:
        key(case, "enter", OPEN)
    deadline = time.monotonic() + 3.
    while PANEL in ids(case.snapshot()):
        require(time.monotonic() < deadline, "The Drawer did not dismiss")
        time.sleep(.04)


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    if rtl:
        case.call("action", "activate", RTL)
    if scale == 2.:
        case.call("action", "activate", SCALE)
    case.point("leave")
    compact = case.size[0] == 320
    QA["reveal"](case, OPEN if compact else CARD)
    focus(case, OPEN)
    a = take(case, "closed", rtl, scale, OPEN, live=True)
    key(case, "enter", CLOSE)
    b = take(case, "opened", rtl, scale, CLOSE, live=True)
    if not compact:
        check_scrim(case, a, b)
    key(case, "tab", HOME)
    key(case, "down", INBOX)
    take(case, "skip-disabled", rtl, scale, INBOX, live=True)
    key(case, "down", REPORTS)
    reports = take(case, "long-label", rtl, scale, REPORTS, live=True)
    mirror = None
    if compact and case.dark:
        other = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
        require(read_png(case.plan.artifacts, reports) == read_png(case.plan.artifacts, other),
                "CLI and MCP Drawer screenshots differ")
        mirror = {**other, "cli": reports["file"]}
    if compact:
        case.point("scroll", center(rect(case.snapshot(), NAV)), 3000.)
        last = take(case, "wheel-bottom", rtl, scale, REPORTS)
        require(last["scroll"]["at_bottom"] and last["scroll"]["offset"][1] > 0.
                and last["rows"][SETTINGS]["fully_visible"], "Inner Drawer failed to scroll to the last item")
    key(case, "end", SETTINGS)
    take(case, "last-focus", rtl, scale, SETTINGS, live=True)
    key(case, "tab", CLOSE)
    key(case, "tab", HOME)
    key(case, "end", SETTINGS)
    actual_press(case, SETTINGS)
    take(case, "selected", rtl, scale, OPEN, SETTINGS, (SETTINGS,), live=True)

    key(case, "enter", CLOSE)
    take(case, "reopen-escape", rtl, scale, CLOSE, SETTINGS, (SETTINGS,))
    key(case, "escape", OPEN)
    take(case, "escaped", rtl, scale, OPEN, SETTINGS, (SETTINGS,), live=True)
    key(case, "enter", CLOSE)
    take(case, "reopen-close", rtl, scale, CLOSE, SETTINGS, (SETTINGS,))
    actual_press(case, CLOSE)
    take(case, "button-closed", rtl, scale, OPEN, SETTINGS, (SETTINGS, CLOSE), live=True)
    if not compact:
        key(case, "enter", CLOSE)
        take(case, "reopen-scrim", rtl, scale, CLOSE, SETTINGS, (SETTINGS, CLOSE))
        scene = case.snapshot()
        box = rect(scene, BACKGROUND)
        target = center(box)
        panel = rect(scene, PANEL)
        require(visible(scene, BACKGROUND) and not panel["x"] <= target[0] < panel["x"] + panel["width"],
                "The intended background control does not sit behind the scrim")
        case.point("down", target)
        case.point("up", target)
        case.point("leave")
        take(case, "scrim-closed", rtl, scale, OPEN, SETTINGS, (SETTINGS, CLOSE), live=True)
    return mirror


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile", action="append", choices=PROFILES)
    parser.add_argument("--verify-os-ax", action="store_true")
    plan = parser.parse_args()
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    plan.checkout = HERE / "qa-verified-tokens"
    plan.client = HERE / "binaries/surface-devtools"
    plan.launcher = HERE / "launch-private-drawer.sh"
    plan.palette = json.loads(subprocess.check_output([HERE / "binaries/examples/fab_menu_native", "--palette"]))
    plan.case, plan.startup_timeout = "normal", 30
    if plan.verify_os_ax:
        require(MAC["AX"]["trusted"](), "Use the Accessibility-authorized terminal")
    report = {"runs": {}, "frames": [], "errors": []}
    for name, (size, dark, rtl, scale) in PROFILES.items():
        if plan.profile and name not in plan.profile:
            continue
        case = None
        try:
            os.environ["SURFACE_QA_DRAWER_TRACE"] = str(plan.artifacts / f"{name}-trace.jsonl")
            with COMMON["gallery"](plan, name, size, dark) as case:
                mcp = journey(case, rtl, scale)
            log = (plan.artifacts / f"{name}.log").read_text()
            adapter = next((line for line in log.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in adapter and "backend: Metal" in adapter, "Expected Apple Metal")
            report["runs"][name] = {"adapter": adapter, "mcp": mcp}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(traceback.format_exc(), flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(report["runs"] and not report["errors"], "Native Drawer checks failed")
    print(f"Passed {len(report['frames'])} native Metal PNGs across {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
