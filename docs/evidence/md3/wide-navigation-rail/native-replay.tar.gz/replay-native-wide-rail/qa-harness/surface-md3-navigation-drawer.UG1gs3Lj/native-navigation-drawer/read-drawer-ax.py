"""Read or press named controls in the private macOS Gallery's public AX tree."""

from pathlib import Path
import runpy


workspace = Path(__file__).resolve().parents[2]
rail = runpy.run_path(str(workspace / "surface-md3-navigation-rail.2Vp8O5Jj/native-navigation-rail/read-navigation-rail-ax.py"))
AX, actions, ax_bool, elements, equal, press = (
    rail[name] for name in ("AX", "actions", "ax_bool", "elements", "equal", "press")
)
DIALOG = "導覽抽屜"
NAVIGATION = "工作區"
OPENER = "開啟抽屜"
CLOSE = "關閉抽屜"
BACKGROUND = "更新"
DESTINATIONS = ("首頁", "封存", "收件匣", "跨部門協作報告與專案進度總覽", "團隊成員", "設定")


def inspect(pid, activate=None):
    if not AX["trusted"]():
        return {"trusted": False, "controls": []}
    app = AX["create_application"](pid)
    AX["set_timeout"](app, 1.)
    _, focus = AX["ax_attribute"](app, "AXFocusedUIElement")
    visited = 0
    reply = {"trusted": True, "controls": []}
    candidates = (DIALOG, NAVIGATION, OPENER, CLOSE, BACKGROUND, *DESTINATIONS)

    def walk(element, depth=0, ancestors=()):
        nonlocal visited
        visited += 1
        if visited > 2000 or depth > 32:
            raise RuntimeError("Private Gallery AX tree exceeded its inspection budget")
        attr = AX["scalar"]
        role = attr(element, "AXRole")
        subrole = attr(element, "AXSubrole")
        labels = [attr(element, key) for key in ("AXTitle", "AXDescription", "AXLabel")]
        name = next((label for label in labels if label in candidates), None)
        path = (*ancestors, name) if name else ancestors
        if name:
            data = {"name": name, "role": role, "subrole": subrole, "ancestors": list(ancestors),
                    "enabled": ax_bool(element, "AXEnabled"), "focus_attr": ax_bool(element, "AXFocused"),
                    "focused": bool(focus and equal(element, focus)), "actions": actions(element),
                    "modal": ax_bool(element, "AXModal"), "selected": ax_bool(element, "AXSelected")}
            reply["controls"].append(data)
            if activate == name and role == "AXButton" and "press_status" not in reply:
                reply["press_status"] = press(element)
        for child in elements(element, "AXChildren"):
            walk(child, depth + 1, path)

    try:
        for window in elements(app, "AXWindows"):
            walk(window)
    finally:
        if focus:
            AX["release"](focus)
        AX["release"](app)
    return reply
