#!/usr/bin/env python3
"""Check native Material FAB menu motion with a held Surface render clock."""

import argparse
from collections import Counter
from contextlib import contextmanager
import json
import math
import os
from pathlib import Path
import runpy
import subprocess
import tempfile
import time


HERE = Path(__file__).resolve().parent
MOTION = runpy.run_path(str(HERE.parents[1] / "surface-md3-fab-motion.nVkfQU/verify-native-fab-motion.py"))
BASE = MOTION["BASELINE"]
Clock = MOTION["Clock"]
call = MOTION["call"]
capture = MOTION["capture"]
close = MOTION["close"]
dom_index = MOTION["dom_index"]
intersection = MOTION["intersection"]
png_pixels = MOTION["png_pixels"]
require = MOTION["require"]
write_json = MOTION["write_json"]

SECTION = "section-1"
TOGGLE = "gallery-fab-toggle"
DIRECTION = "gallery-fab-direction"
NAMES = {
    "gallery-fab-item-note": "新增筆記",
    "gallery-fab-item-import": "匯入檔案",
    "gallery-fab-item-chat": "新增對話",
}
NOTE, IMPORT, CHAT = NAMES
OPEN, CLOSED = "關閉新增動作", "顯示新增動作"
VIEWPORTS = {"wide": (960, 800), "short": (320, 240), "compact": (160, 112)}
STEPS = (0, 25, 50, 75, 100, 130, 170, 220, 330, 700)


@contextmanager
def gallery(plan, prefix, size, dark, rtl, reduced=False):
    with (
        tempfile.TemporaryDirectory(prefix="surface-fab-menu-", dir="/private/tmp") as scratch,
        (plan.artifacts / f"{prefix}.log").open("wb") as log,
    ):
        session = Path(scratch) / "session.json"
        receipt = Path(scratch) / "capture-receipt.json"
        clock = Clock(Path(scratch) / "frame-time")
        env = dict(os.environ, SURFACE_DEVTOOLS_SESSION=str(session),
                   SURFACE_QA_ANIMATION_TIME=str(clock.path),
                   SURFACE_QA_CAPTURE_RECEIPT=str(receipt),
                   SURFACE_REDUCED_MOTION="1" if reduced else "0")
        for key in ("SURFACE_TRACE", "SURFACE_BRIDGE_SESSION"):
            env.pop(key, None)
        child = subprocess.Popen(
            (plan.launcher, *map(str, size)), cwd=plan.checkout, env=env, stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT,
        )
        try:
            MOTION["wait_for_session"](session, child)
            require("Page.screenshot" in call(plan.client, session, "capabilities")["methods"],
                    "Page.screenshot capability missing")
            nodes, indices = dom_index(call(plan.client, session, "dom", "snapshot"))
            if nodes[indices["theme"]]["checked"] is not dark:
                call(plan.client, session, "action", "activate", "theme")
            call(plan.client, session, "action", "activate", SECTION)
            if rtl:
                call(plan.client, session, "action", "activate", DIRECTION)
            clock.advance(1000)
            yield Case(plan, prefix, size, dark, rtl, child, session, clock, receipt)
        finally:
            MOTION["stop"](child)


def visual_box(op):
    return intersection(op["rect"], op["clip"])


def on_screen(box):
    return box["width"] > .1 and box["height"] > .1


def menu_snapshot(snapshot):
    nodes, lookup = dom_index(snapshot)
    layout = snapshot["layout"]["nodes"]
    result = {}
    for key in (TOGGLE, *NAMES):
        if key not in lookup:
            continue
        index = lookup[key]
        node, computed = nodes[index], layout[index]
        result[key] = {field: node.get(field) for field in ("name", "role", "disabled", "expanded")}
        result[key].update({
            "bounds": computed["bounds"],
            "clip": computed["clip"],
            "visible": intersection(computed["bounds"], computed["clip"]),
            "fill": node["style"].get("background"),
        })
    return result


def edge(rect, rtl):
    return rect["x"] if rtl else rect["x"] + rect["width"]


def body_ops(receipt):
    for item in receipt["paint"]["ops"]:
        for kind, op in item.get("Legacy", {}).items():
            if kind in ("Quad", "Shape") and op["color"][3] > 0:
                yield dict(op, kind=kind)


def locate_face(ops, row, rtl):
    original = row["bounds"]
    fill = row["fill"]
    candidates = [
        op for op in ops
        if tuple(op["color"][:3]) == tuple(fill[:3])
        and abs(op["rect"]["y"] - original["y"]) < 1.
        and abs(op["rect"]["height"] - original["height"]) < 1.
        and abs(edge(op["rect"], rtl) - edge(original, rtl)) < 1.
        and on_screen(visual_box(op))
    ]
    if not candidates:
        return None
    op = max(candidates, key=lambda value: (value["color"][3], visual_box(value)["width"]))
    pieces = [visual_box(piece) for piece in candidates
              if piece["rect"] == op["rect"] and piece["color"] == op["color"]]
    return {"rect": op["rect"], "clip": op["clip"], "painted": visual_box(op), "color": op["color"],
            "pieces": pieces}


class Case:
    def __init__(self, plan, prefix, size, dark, rtl, child, session, clock, receipt):
        self.plan, self.prefix, self.size, self.dark, self.rtl = plan, prefix, size, dark, rtl
        self.child, self.session, self.clock, self.receipt = child, session, clock, receipt
        self.frames = []

    def call(self, *args):
        return call(self.plan.client, self.session, *args)

    def activate(self, key):
        return self.call("action", "activate", key)

    def key(self, value):
        key = "down" if value == "ArrowDown" else value.lower()
        return self.call("action", "key", key)

    def absent(self, key):
        process = subprocess.run(
            (self.plan.client, "--session", self.session, "action", "activate", key),
            capture_output=True, text=True, timeout=10,
        )
        require(process.returncode != 0, f"Hidden {key} accepted direct activation: {process.stdout}")
        return process.stderr.strip()

    def frame(self, name, *, delta=None, references=None):
        details, snapshot = capture(self.plan, self.plan.client, self.session, f"{self.prefix}-{name}",
                                    self.size, self.dark, SECTION)
        require(not details["errors"], str(details["errors"]))
        state = menu_snapshot(snapshot)
        require(TOGGLE in state, "Missing FAB menu trigger")
        receipt = json.loads(self.receipt.read_text())
        require(receipt["accessibility_frame"], "Presented frame has no runtime accessibility snapshot")
        ops = tuple(body_ops(receipt))
        rows = state if references is None else references
        faces = {key: locate_face(ops, rows[key], self.rtl) for key in NAMES if key in rows}
        details.update(name=name, time_ms=self.clock.now, delta_ms=delta, rtl=self.rtl, controls=state,
                       faces={key: face for key, face in faces.items() if face is not None},
                       projected=receipt["projected"], focus=snapshot["interaction"]["focused"],
                       wants_frame=receipt["wants_frame"])
        self.frames.append(details)
        return details

    def timeline(self, phase, *, references=None):
        old = 0
        frames = []
        for timestamp in STEPS:
            self.clock.advance(timestamp - old)
            old = timestamp
            frames.append(self.frame(f"{phase}-{timestamp:03}", delta=timestamp, references=references))
        return frames


def state(frame, expanded):
    toggle = frame["controls"][TOGGLE]
    require(toggle["role"] == "Button" and toggle["disabled"] is False and toggle["expanded"] is expanded,
            f"Unexpected trigger state: {toggle}")
    close(toggle["bounds"]["width"], 56., "trigger width")
    close(toggle["bounds"]["height"], 56., "trigger height")
    if not expanded:
        for menu in (frame["controls"], frame["projected"]):
            require(not any(key in menu for key in NAMES),
                    f"{frame['file']}: dismissed rows remain in the live tree")


def focus(frame, target):
    require(frame["focus"] == target, f"{frame['file']}: focus was {frame['focus']}; expected {target}")
    projected = frame["projected"].get(target, {})
    require(projected.get("focused") and projected.get("press"),
            f"{frame['file']}: focus or press missing from runtime accessibility")
    row = frame["controls"][target]
    for axis in ("width", "height"):
        close(row["visible"][axis], row["bounds"][axis], f"focused {target} fully revealed on {axis}")


def check_first_paint(frames, expected):
    onset = {
        key: next((frame["delta_ms"] for frame in frames if key in frame["faces"]), None)
        for key in expected
    }
    known = [onset[key] for key in expected if onset[key] is not None]
    require(known == sorted(known), f"Opening painted rows out of order: {onset}")
    require(any(frame["faces"] for frame in frames[1:-1]), "No native opening frame painted an action")
    return onset


def check_first_exit(frames, expected, require_ghost):
    starts = frames[0]["faces"]
    onset = {}
    for key in expected:
        if key not in starts:
            continue
        initial = starts[key]
        onset[key] = next((
            frame["delta_ms"] for frame in frames[1:]
            if key not in frame["faces"]
            or frame["faces"][key]["color"][3] < initial["color"][3]
            or frame["faces"][key]["painted"]["width"] < initial["painted"]["width"] - .75
        ), None)
    known = [onset[key] for key in expected if onset.get(key) is not None]
    require(known == sorted(known), f"Dismissal changed visual rows out of order: {onset}")
    require(not require_ghost or starts, "Closing snapshot missing")
    require(not frames[-1]["faces"], "Closing snapshot persisted after settle")
    return onset


def painted_pixel(case, frame, key, background=None):
    face = frame["faces"][key]
    box, rect = face["painted"], face["rect"]
    left, right = math.ceil(box["x"] + 5), math.floor(box["x"] + box["width"] - 4)
    top, bottom = math.ceil(box["y"] + 4), math.floor(box["y"] + box["height"] - 4)
    sample_y = min(max(round(rect["y"] + 12), top), bottom - 1)
    centers = [left + fraction * (right - left) // 4 for fraction in (1, 2, 3)]
    points = {(x, y) for center in centers for x in range(max(left, center - 3), min(right, center + 4))
              for y in range(max(top, sample_y - 1), min(bottom, sample_y + 2))}
    if len(points) < 4:
        return None
    png = case.plan.artifacts
    observed = png_pixels(png / frame["file"], frame, points)
    match = Counter(map(tuple, observed.values())).most_common(1)[0][0]
    rgba = face["color"]
    changed = None
    if rgba[3] == 255:
        require(any(MOTION["rgba_near"](rgba, color, 5) for color in observed.values()),
                f"{frame['file']}: no rendered fill matched {rgba} for {key}")
    elif background is not None:
        before = png_pixels(png / background["file"], background, points)
        changed = sum(observed[p][:3] != before[p][:3] for p in points)
    return {"points": len(points), "changed_points": changed, "observed": match, "paint": rgba}


def verify_matrix(case):
    initial = case.frame("idle")
    state(initial, False)
    close(edge(initial["controls"][TOGGLE]["bounds"], case.rtl),
          16. if case.rtl else case.size[0] - 16., "logical menu edge")
    case.activate(TOGGLE)
    opening = case.timeline("open")
    for frame in opening:
        state(frame, True)
    settled = opening[-1]
    statuses = settled["controls"]
    for key, name in NAMES.items():
        require(statuses[key]["role"] == "MenuItem" and statuses[key]["name"] == name,
                f"Unexpected menu action {statuses[key]}")
        require(statuses[key]["disabled"] is (key == IMPORT), f"Bad disabled state on {key}")
    started = check_first_paint(opening, (CHAT, IMPORT, NOTE) if case.size[1] >= 120 else ())
    fully_visible = [key for key in NAMES if on_screen(statuses[key]["visible"])]
    require(fully_visible, "The open menu has no visible actions")
    intermediate = {}
    for key, body in settled["faces"].items():
        final_width = body["painted"]["width"]
        for frame in opening:
            face = frame["faces"].get(key)
            if face and .1 < face["painted"]["width"] < final_width - 1.:
                intermediate[key] = {"time_ms": frame["delta_ms"], "width": face["painted"]["width"],
                                     "settled_width": final_width, "file": frame["file"]}
                break
    for frame in opening:
        if IMPORT in frame["projected"]:
            require(not frame["projected"][IMPORT]["press"], "Disabled action entered the runtime press set")
    if case.size[1] >= 240:
        shown = [started[key] for key in (CHAT, IMPORT, NOTE)]
        stages = 3 if case.size[1] >= 800 else 2
        require(all(value is not None for value in shown) and len(set(shown)) >= stages,
                f"Native opening has no visible stagger: {started}")
        require(len(intermediate) >= stages, f"Opened rows appear at a fixed width: {intermediate}")

    case.key("Escape")
    absent = case.absent(CHAT)
    closing = case.timeline("close", references=statuses)
    for frame in closing:
        state(frame, False)
    exited = check_first_exit(closing, tuple(NAMES), require_ghost=True)
    fringe = None
    for frame in closing:
        for row in frame["faces"].values():
            toggle = frame["controls"][TOGGLE]["bounds"]
            guard = {"x": toggle["x"] - 4., "y": toggle["y"] - 4.,
                     "width": toggle["width"] + 8., "height": toggle["height"] + 8.}
            for piece in row["pieces"]:
                require(not on_screen(intersection(piece, guard)),
                        f"{frame['file']}: dismissing paint covers the restored toggle focus area")
                if piece["y"] + piece["height"] > toggle["y"] + 1. and fringe is None:
                    fringe = {"file": frame["file"], "piece": piece, "toggle_guard": guard}
    if case.size[1] >= 240:
        require(len(set(value for value in exited.values() if value is not None)) >= stages,
                f"Native closing has no visible stagger: {exited}")
    if case.size[1] < 120:
        require(fringe is not None, "Compact closing lost all paint beside the restored toggle")
    if (case.size, case.dark, case.rtl) == ((320, 240), True, True):
        case.activate(TOGGLE)
        case.clock.advance(75)
        cli = case.frame("transport-cli")
        same_clock = case.frame("transport-repeat")
        mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
        require(cli["sha256"] == same_clock["sha256"] == mcp["sha256"],
                "MCP or repeated Surface CLI changed the held PNG")
        receipt = dict(mcp, cli_file=cli["file"], repeat=same_clock["file"])
    else:
        receipt = None
    pixels = {}
    for key, details in settled["faces"].items():
        if details["painted"]["height"] >= 20.:
            pixels[f"open:{key}"] = painted_pixel(case, settled, key)
    for key in NAMES:
        for mid in closing:
            face = mid["faces"].get(key)
            if face and 0 < face["color"][3] < 250 and face["painted"]["height"] >= 18.:
                value = painted_pixel(case, mid, key, closing[-1])
                if value and value["changed_points"]:
                    pixels[f"closing:{key}"] = dict(value, file=mid["file"])
                    break
    if case.size[1] >= 240:
        require(any(key.startswith("closing:") for key in pixels), "No PNG sample of a fading row")
    return {"first_paint_ms": started, "first_exit_ms": exited, "intermediate_widths": intermediate,
            "settled_visible": fully_visible, "compact_exit_fringe": fringe,
            "rejected_action_at_dismissal": absent, "pixel_samples": pixels, "mcp": receipt}


def verify_keyboard(case):
    keys = []
    activation = MOTION["make_active"](case.plan.probe, case.child)

    def advance(key, expected, expanded, settle=False):
        keys.append({"key": key, "reply": case.key(key)})
        if settle:
            case.clock.advance(700)
        frame = case.frame(f"key-{len(keys)}-{key.lower()}")
        state(frame, expanded)
        focus(frame, expected)
        return frame

    case.call("action", "qa-ax-focus", TOGGLE)
    advance("Space", TOGGLE, True)
    case.clock.advance(75)
    partial = case.frame("key-partial-75")
    require(not partial["projected"].get(NOTE, {}).get("press"),
            "Top item became actionable before its opening phase")
    advance("Tab", CHAT, True)
    case.clock.advance(625)
    rendered = case.frame("key-open-settled")
    focus(rendered, CHAT)
    advance("ArrowDown", TOGGLE, True)
    advance("Tab", NOTE, True)
    advance("ArrowDown", CHAT, True)
    advance("ArrowDown", TOGGLE, True)
    advance("Enter", TOGGLE, False)
    case.clock.advance(700)
    advance("Space", TOGGLE, True, settle=True)
    advance("Tab", NOTE, True)
    advance("Escape", TOGGLE, False)
    return {"activation": activation, "keys": keys}


def verify_ax(case):
    def menu_controls(observation):
        return [item for item in observation["matches"]
                if item["role"] == "AXMenuItem" or item["label"] in (OPEN, CLOSED)]

    def observe(toggle_name, expected):
        for _ in range(9):
            result = BASE["query_ax"](case.plan.probe, case.child, toggle_name, *NAMES.values())
            labels = {item["label"] for item in menu_controls(result)}
            if result["active"] and labels == expected:
                return result
            time.sleep(.12)
        raise RuntimeError(f"Expected live AX labels {sorted(expected)}: {result}")

    activation = MOTION["make_active"](case.plan.probe, case.child)
    case.call("action", "qa-ax-focus", TOGGLE)
    idle = case.frame("ax-idle")
    state(idle, False)
    focus(idle, TOGGLE)
    closed = observe(CLOSED, {CLOSED})
    require(closed["active"] and closed["trusted"], f"Inactive or untrusted AppKit Gallery: {closed}")
    require([item["label"] for item in menu_controls(closed)] == [CLOSED], f"Closed menu in AX: {closed}")
    pressed = BASE["query_ax"](case.plan.probe, case.child, CLOSED, "--press")
    require(pressed.get("pressStatus") == 0, f"Real macOS AXPress failed: {pressed}")
    time.sleep(.12)
    case.clock.advance(700)
    es = case.frame("ax-open")
    state(es, True)
    focus(es, TOGGLE)
    opened = observe(OPEN, {OPEN, *NAMES.values()})
    require(opened["active"], f"AppKit Gallery lost focus: {opened}")
    controls = menu_controls(opened)
    active = {item["label"]: item for item in controls}
    require(set(active) == {OPEN, *NAMES.values()}, f"Open menu in AX: {opened}")
    require(len(controls) == len(active), f"Duplicate live AX actions: {opened}")
    require(active[NAMES[IMPORT]].get("enabled") is False and
            "AXPress" not in active[NAMES[IMPORT]].get("actions", []), f"Disabled AX action: {active}")
    require("AXPress" in active[NAMES[NOTE]].get("actions", []), f"No live item AXPress: {active}")
    case.key("Escape")
    visual = case.frame("ax-closing", references=es["controls"])
    state(visual, False)
    focus(visual, TOGGLE)
    require(visual["faces"], "Live AX closing did not sample outgoing pixels")
    dismissed = observe(CLOSED, {CLOSED})
    require(dismissed["active"], f"AppKit Gallery lost focus during dismissal: {dismissed}")
    require([item["label"] for item in menu_controls(dismissed)] == [CLOSED],
            f"Visual remnants in AX: {dismissed}")
    case.activate(TOGGLE)
    case.clock.advance(700)
    ready = case.frame("ax-item-ready")
    state(ready, True)
    selected = BASE["query_ax"](case.plan.probe, case.child, NAMES[CHAT], "--press")
    require(selected.get("pressStatus") == 0, f"Real macOS menu-item AXPress failed: {selected}")
    time.sleep(.12)
    choice = case.frame("ax-item-selected", references=ready["controls"])
    state(choice, False)
    focus(choice, TOGGLE)
    return {"activation": activation, "closed": closed, "real_press": pressed, "open": opened,
            "closing_visual_only": dismissed, "item_press": selected}


def verify_reduced(case):
    first = case.frame("reduced-closed")
    case.activate(TOGGLE)
    opened = case.frame("reduced-opened")
    state(opened, True)
    require(opened["time_ms"] == first["time_ms"] and len(opened["faces"]) >= 2,
            "Reduce Motion did not publish the settled open target at the same time")
    require(all(face["color"][3] == 255 for face in opened["faces"].values()), "Reduced-motion fade")
    case.key("Escape")
    closed = case.frame("reduced-dismissed", references=opened["controls"])
    state(closed, False)
    require(closed["time_ms"] == first["time_ms"] and not closed["faces"], "Reduced-motion outgoing paint")
    return {"immediate": True, "clock_ms": first["time_ms"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--probe", type=Path)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--viewport", choices=VIEWPORTS)
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--direction", choices=("ltr", "rtl"))
    parser.add_argument("--case", choices=("matrix", "keyboard", "ax", "reduced"), default="matrix")
    plan = parser.parse_args()
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    if plan.case in ("ax", "keyboard") and plan.probe is None:
        parser.error("--probe is required to activate the private native window")
    plan.artifacts.mkdir(parents=True, exist_ok=False)
    receipt = {"capture": "Surface Page.screenshot", "key_route": "Native Surface Action.key",
               "frames": [], "runs": {}, "errors": []}
    default_view = {"ax": "wide", "keyboard": "compact", "reduced": "short"}.get(plan.case)
    default_theme = None if plan.case == "matrix" else "dark"
    default_dir = None if plan.case == "matrix" else "rtl"
    for view, size in VIEWPORTS.items():
        if (plan.viewport or default_view) not in (None, view):
            continue
        for theme in ("light", "dark"):
            if (plan.theme or default_theme) not in (None, theme):
                continue
            for direction in ("ltr", "rtl"):
                if (plan.direction or default_dir) not in (None, direction):
                    continue
                prefix = f"{view}-{theme}-{direction}-{plan.case}"
                current = None
                try:
                    with gallery(plan, prefix, size, theme == "dark", direction == "rtl",
                                 reduced=plan.case == "reduced") as current:
                        verify = {"matrix": verify_matrix, "keyboard": verify_keyboard,
                                  "ax": verify_ax, "reduced": verify_reduced}[plan.case]
                        receipt["runs"][prefix] = verify(current)
                except (RuntimeError, OSError, KeyError, ValueError, TypeError, subprocess.SubprocessError) as error:
                    receipt["errors"].append(f"{prefix}: {error}")
                    print(receipt["errors"][-1], flush=True)
                finally:
                    if current is not None:
                        receipt["frames"].extend(current.frames)
    write_json(plan.artifacts / "report.json", receipt)
    if receipt["errors"]:
        raise SystemExit("\n".join(receipt["errors"]))
    print(f"Passed {len(receipt['frames'])} PNG frames across {len(receipt['runs'])} runs")


if __name__ == "__main__":
    main()
