#!/usr/bin/env python3
"""Exercise the Material radio Gallery card through native Metal and AccessKit."""

import argparse
import json
import math
from pathlib import Path
import runpy
import subprocess


HERE = Path(__file__).resolve().parent
MOTION = runpy.run_path(str(HERE.parents[1] / "surface-md3-switch-motion.xj5QQ1"
                            / "native-switch-motion" / "verify-native-switch-motion.py"))
BASE, COMMON, VIEWPORTS = (MOTION[key] for key in ("BASE", "COMMON", "VIEWPORTS"))
capture, center, close, color_matches, contains, focus, key, node, pixels_for, rect, require = (
    MOTION[k] for k in ("capture", "center", "close", "color_matches", "contains",
                        "focus", "key", "node", "pixels_for", "rect", "require")
)
by_center, frame_row, paint_entries, same_rect, sample_points, write_json = (
    MOTION[k] for k in ("by_center", "frame_row", "paint_entries", "same_rect", "sample_points", "write_json")
)
PROFILES = {name: profile[:4] for name, profile in MOTION["PROFILES"].items() if not profile[4]}
SECTION = "section-0"
CARD, GROUP, LOCKED_GROUP, DIRECTION, SCALE, STATUS, DESKTOP, TEXT, EMAIL, LOCKED = (
    f"radio-baseline-{part}" for part in (
        "card", "group", "locked-group", "direction", "scale", "status", "desktop", "text", "email", "locked"
    )
)
OPTIONS = {
    DESKTOP: "在所有已登入裝置顯示桌面通知",
    TEXT: "簡訊通知",
    EMAIL: "電子郵件通知",
    LOCKED: "停用的選項",
}
DISABLED = {TEXT, LOCKED}


def state(case, expected, selections):
    snapshot = case.snapshot()
    status = node(snapshot, STATUS)
    require((status["text"] or status["name"]) == f"已選擇 {selections} 次", "App action count changed")
    for option in OPTIONS:
        value = node(snapshot, option)
        require(value["checked"] is (option in (expected, LOCKED))
                and value.get("disabled", False) is (option in DISABLED),
                f"{option}: app-owned checked or disabled value changed")
    return snapshot


def geometry(snapshot, id, rtl):
    nodes, ids = COMMON["dom_index"](snapshot)
    layout = snapshot["layout"]["nodes"]
    target_id = ids[id]
    target_node = nodes[target_id]
    ring_id, label_id = target_node["first_child"], target_node["last_child"]
    dot_id = nodes[ring_id]["first_child"]
    require(nodes[ring_id]["role"] == nodes[dot_id]["role"] == "Group"
            and nodes[label_id]["text"] == OPTIONS[id], "Radio visual children or label changed")
    target, ring, dot, label = (layout[idx]["bounds"] for idx in (target_id, ring_id, dot_id, label_id))
    require(min(target["width"], target["height"]) >= 48. and contains(rect(snapshot, CARD), target)
            and contains(target, ring) and contains(target, label), "The radio lost its 48 dp target or content")
    require(ring["width"] == ring["height"] == 20., "The Material ring is not 20 dp")
    require(same_rect(by_center(ring, 10.), dot), "The 10 dp dot is not centered in the ring")
    close(center(ring)[1], center(target)[1], "Ring centered vertically in the target")
    close(center(label)[1], center(target)[1], "CJK label centered vertically in the target")
    leading = target["x"] + target["width"] - ring["x"] - ring["width"] if rtl else ring["x"] - target["x"]
    gap = ring["x"] - label["x"] - label["width"] if rtl else label["x"] - ring["x"] - ring["width"]
    close(leading, 12., "Logical leading inset")
    close(gap, 12., "Logical label gap")
    return {"target": target, "ring": ring, "dot": dot, "label": label}


def intersection(box, clip):
    return [max(box["x"], clip["x"]), max(box["y"], clip["y"]),
            min(box["x"] + box["width"], clip["x"] + clip["width"]),
            min(box["y"] + box["height"], clip["y"] + clip["height"])]


def accessibility(snapshot, receipt, id, selected, target):
    tree = receipt["accesskit"]
    platform = tree["nodes"]
    active = platform[id]
    disabled = id in DISABLED
    group_id = LOCKED_GROUP if id == LOCKED else GROUP
    group = platform[group_id]
    require(group["role"] == "RadioGroup"
            and group["name"] == ("目前停用的通知方式" if id == LOCKED else "通知方式")
            and not (group["focusable"] or group["press"]), "Group lost its localized passive role")
    _, ids = COMMON["dom_index"](snapshot)
    layout = snapshot["layout"]["nodes"]
    members = (LOCKED,) if id == LOCKED else (DESKTOP, TEXT, EMAIL)
    visible = []
    for member in members:
        item = layout[ids[member]]
        x0, y0, x1, y1 = intersection(item["bounds"], item["clip"])
        if x1 > x0 and y1 > y0:
            visible.append(OPTIONS[member])
    require(group["logical_children"] == visible, f"Named AX group changed order or acquired decoration: {group}")
    require(active["role"] == "RadioButton" and active["name"] == OPTIONS[id]
            and active["toggled"] == ("True" if selected else "False") and active["disabled"] is disabled
            and active["focusable"] is not disabled and active["press"] is not disabled
            and active["focused"] is (snapshot["interaction"]["focused"] == id)
            and not active["child_roles"], f"AX option state or action changed: {active}")
    for a, b in zip(active["bounds"], intersection(target, layout[ids[id]]["clip"])):
        close(a, b * tree["scale"], "Native hit bounds")
    require(sum(n["name"] == OPTIONS[id] and (n["press"] or n["focusable"])
                for n in tree["viewport_subtree"]) == int(not disabled),
            "Ring, dot, or label added a focus/press stop")
    return active


def blend(back, ink, alpha=None):
    alpha = ink[3] / 255. if alpha is None else alpha
    return [round(b + (a - b) * alpha) for a, b in zip(ink[:3], back[:3])] + [255]


def ring_samples(ring, label=None):
    x, y = center(ring)
    bands = {name: set() for name in ("ring", "center", "gap", "halo")}
    for px, py in sample_points(by_center(ring, 38.)):
        dx, dy = px + .5 - x, py + .5 - y
        distance = math.hypot(dx, dy)
        if 8.35 <= distance <= 9.65 and min(abs(dx), abs(dy)) <= .55:
            bands["ring"].add((px, py))
        elif distance <= 3.:
            bands["center"].add((px, py))
        elif 5.8 < distance < 7.:
            bands["gap"].add((px, py))
        elif 12. < distance < 16.:
            bands["halo"].add((px, py))
    if label:
        bands["text"] = {(x, y) for x, y in sample_points(label) if x % 2 == 0}
    return bands


def feedback(receipt, ring, ink, phase):
    box = by_center(ring, 40.)
    pulses = [op["Ripple"] for op in receipt["presented"]["ops"]
              if "Ripple" in op and same_rect(op["Ripple"]["bounds"], box)]
    layers = [op for op in paint_entries(receipt, ("Quad", "Shape"))
              if same_rect(op["rect"], box) and op["color"][:3] == ink[:3] and 0 < op["color"][3] <= 31]
    if phase == "hover":
        require(not pulses and len(layers) == 1, "Missing centered 40 dp hover layer")
        return {"kind": "hover", "geometry": box, "ink": layers[0]["color"]}
    if phase == "hold":
        require(len(pulses) == 1 and not layers, "Missing centered 40 dp ripple")
        pulse = pulses[0]["ripple"]
        for a, b in zip((pulse["x"], pulse["y"]), center(ring)):
            close(a, b, "Ripple centers on ring")
        require(pulse["color"][:3] == ink[:3] and pulse["color"][3] > 0, "Ripple palette changed")
        return {"kind": "press", "geometry": box, "ink": pulse["color"]}
    require(not pulses and not layers, "An inactive or disabled radio still paints a state layer")
    return None


def pixel_proof(path, frame, bands, ring_ink, background, selected, active_feedback, secondary, text_ink):
    pixels = pixels_for(path, frame, set().union(*bands.values()))
    under = blend(background, active_feedback["ink"]) if active_feedback else background
    expected_ring = blend(under, ring_ink)
    want_dot = expected_ring if selected else under
    slack = 14 if active_feedback else 8
    bounds = {}
    for name, color in (("ring", expected_ring), ("center", want_dot), ("gap", under)):
        band = bands[name]
        mates = sum(color_matches(pixels[p], color, slack) for p in band)
        require(mates >= .75 * len(band) >= 5, f"{name}: observed {mates}/{len(band)} expected pixels")
        bounds[name] = mates
    halo = sum(not color_matches(pixels[p], background, 4) for p in bands["halo"])
    if active_feedback:
        require(halo >= 10, "The state layer has no coverage in the real PNG")
    bounds["halo"] = halo
    borders = {name: sum(color_matches(pixels[p], secondary, 14) for p in bands[name])
               for name in ("left", "right", "top", "bottom") if name in bands}
    if borders:
        require(min(borders.values()) >= 3, "The focus outline lost a visible edge")
    bounds["focus"] = borders
    if "text" in bands:
        lines = sorted({y for x, y in bands["text"] if color_matches(pixels[x, y], text_ink, 24)})
        clusters = []
        for y in lines:
            if not clusters or y > clusters[-1][-1] + 3:
                clusters.append([])
            clusters[-1].append(y)
        bounds["visible_text_lines"] = sum(len(rows) >= 5 for rows in clusters)
        require(bounds["visible_text_lines"] >= 2, "Large CJK label did not paint its wrapped lines")
    return bounds


def painted_label_size(receipt, id, label, scale):
    ink = [op for op in paint_entries(receipt, ("Text", "StyledText"))
           if same_rect(op["rect"], label) and op.get("text") == OPTIONS[id]]
    require(len(ink) == 1, "Expected a unique painted radio label")
    record = ink[0]
    size = record["font_size"] if "font_size" in record else record["style"]["font_size"]
    close(size, 16. * scale, "Actual rendered radio label text size")
    return size


def take(case, id, tag, rtl, scale, chosen, changes, phase="rest"):
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{tag}",
                              case.size, case.dark, SECTION)
    require(not frame["errors"], str(frame["errors"]))
    state(case, chosen, changes)
    interaction = snapshot["interaction"]
    focused = interaction["focused"] == id
    enabled = id not in DISABLED
    selected = id in (chosen, LOCKED)
    active = enabled and id in (interaction["pressed"], interaction["focused"], interaction["hovered"])
    boxes = geometry(snapshot, id, rtl)
    receipt = json.loads(case.receipt.read_text())
    native = accessibility(snapshot, receipt, id, selected, boxes["target"])
    colors = case.plan.palette["dark" if case.dark else "light"]
    ink = (colors["on_surface"][:3] + [97] if not enabled else colors["primary"] if selected else
           colors["on_surface" if active else "on_surface_variant"])
    ring, dot, label = (boxes[name] for name in ("ring", "dot", "label"))
    visible_strokes = [op for op in paint_entries(receipt, ("Stroke",)) if same_rect(op["rect"], ring)]
    require(len(visible_strokes) == 1 and visible_strokes[0]["radius"] == 10.
            and visible_strokes[0]["width"] == 2. and visible_strokes[0]["color"] == ink,
            "Native display list did not paint the exact 2 dp circular ring and ink")
    fills = paint_entries(receipt, ("Quad", "Shape"))
    dots = [op for op in fills if same_rect(op["rect"], dot) and op["color"][3] > 0]
    require(len(dots) == int(selected) and all(op["color"] == ink and op.get("radius", 5.) == 5. for op in dots),
            "The painted 10 dp selected dot changed")
    card = rect(snapshot, CARD)
    backing = [op["color"] for op in fills if same_rect(op["rect"], card)]
    require(len(backing) == 1 and backing[0][3] == 255, "Unique opaque card backing is required")
    text_ink = colors["on_surface" if enabled else "outline"]
    require(any(same_rect(op["rect"], label) and op["color"] == text_ink
                for op in paint_entries(receipt, ("Text", "StyledText"))), "Readable label lost Material ink")
    font_size = painted_label_size(receipt, id, label, scale)
    effect = feedback(receipt, ring, colors["primary" if selected else "on_surface"], phase)
    edges = BASE["focus_edges"](boxes["target"])
    for edge in edges.values():
        require(sum(op["color"] == colors["secondary"] and same_rect(op["rect"], edge) for op in fills)
                == int(focused), "Focus is not on the whole radio target")
    focus_bands = BASE["focus_samples"](edges, frame["viewport"]) if focused else {}
    require(not focused or len(focus_bands) == 4, "Focus target was clipped by test framing")
    check_label = label if id == DESKTOP and scale == 2 and tag == "desktop-rest" else None
    bands = {**ring_samples(ring, check_label), **focus_bands}
    counts = pixel_proof(case.plan.artifacts / frame["file"], frame, bands, ink, backing[0], selected,
                         effect, colors["secondary"], text_ink)
    frame.update(item=id, stage=tag, phase=phase, rtl=rtl, scale_text=scale, selected=selected,
                 focused=focused, changes=changes, disabled=not enabled, native=native, ring_ink=ink,
                 backing=backing[0], secondary=colors["secondary"], text_ink=text_ink, label_font_dp=font_size,
                 feedback=effect, pixels=counts, **boxes)
    case.frames.append(frame)
    return frame


def reveal(case, id):
    require(not frame_row(case, id), f"{id} is taller than the viewport")


def stable(before, after):
    for field in ("target", "ring", "dot", "label"):
        require(same_rect(before[field], after[field]), f"{field} moved on input")


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2:
        case.call("action", "activate", SCALE)
    case.point("leave")
    reveal(case, DESKTOP)
    case.clock.advance(750)
    take(case, DESKTOP, "desktop-rest", rtl, scale, DESKTOP, 0)
    reveal(case, EMAIL)
    take(case, EMAIL, "email-rest", rtl, scale, DESKTOP, 0)

    for id in (TEXT, LOCKED):
        reveal(case, id)
        point = center(geometry(case.snapshot(), id, rtl)["label"])
        case.point("move", point)
        case.point("down", point)
        require(case.snapshot()["interaction"]["pressed"] is None, "Disabled option took a press")
        take(case, id, "disabled-on" if id == LOCKED else "disabled-off", rtl, scale, DESKTOP, 0)
        case.point("up", point)
        case.point("leave")
        BASE["reject"](case, "press", id, "no live AccessKit press")
        state(case, DESKTOP, 0)

    focus(case, SCALE)
    key(case, "tab", DESKTOP)
    reveal(case, DESKTOP)
    take(case, DESKTOP, "desktop-tab", rtl, scale, DESKTOP, 0)
    for index, (arrow, id) in enumerate((("down", EMAIL), ("down", DESKTOP),
                                         ("up", EMAIL), ("up", DESKTOP)), 1):
        key(case, arrow, id)
        case.clock.advance(750)
        state(case, id, index)
        if index in (1, 2):
            reveal(case, id)
            take(case, id, f"arrow-{index}", rtl, scale, id, index)
    key(case, "tab", SCALE, shift=True)
    state(case, DESKTOP, 4)

    reveal(case, EMAIL)
    split = geometry(case.snapshot(), EMAIL, rtl)
    point = center(split["label"])
    case.point("move", point)
    case.clock.advance(120)
    hovered = take(case, EMAIL, "email-hover", rtl, scale, DESKTOP, 4, "hover")
    require(not hovered["focused"], "Hover moved keyboard focus")
    case.point("touch-start", point)
    require(case.snapshot()["interaction"]["pressed"] == EMAIL, "Label did not reach the one radio target")
    case.clock.advance(100)
    held = take(case, EMAIL, "email-held", rtl, scale, DESKTOP, 4, "hold")
    stable(hovered, held)
    pair = None
    if case.prefix == "narrow-dark-rtl-2x":
        mirror = MOTION["MOTION"]["check_mcp"](case.plan, case.plan.client, case.session, case.size)
        expected_file = case.plan.artifacts / held["file"]
        actual_file = case.plan.artifacts / mirror["file"]
        require(actual_file.read_bytes() == expected_file.read_bytes(), "CLI and MCP returned different PNG bytes")
        pair = {**mirror, "cli": held["file"]}
    case.point("touch-cancel", point)
    case.point("touch-end", point)
    case.point("leave")
    require(case.snapshot()["interaction"]["pressed"] is None, "Cancelled touch left a press")
    case.clock.advance(750)
    cancel = take(case, EMAIL, "email-cancel", rtl, scale, DESKTOP, 4)
    stable(held, cancel)

    point = center(cancel["ring"])
    case.point("move", point)
    case.point("down", point)
    require(case.snapshot()["interaction"]["pressed"] == EMAIL, "Ring did not reach the same radio target")
    case.point("up", point)
    case.point("leave")
    case.clock.advance(750)
    clicked = take(case, EMAIL, "email-clicked", rtl, scale, EMAIL, 5)
    stable(cancel, clicked)
    reveal(case, DESKTOP)
    BASE["press_ax"](case, DESKTOP)
    case.clock.advance(750)
    reveal(case, DESKTOP)
    selected = take(case, DESKTOP, "desktop-ax-press", rtl, scale, DESKTOP, 6)
    require(selected["focused"], "AccessKit Press did not focus the selected radio")
    return {"mcp": pair, "arrows": 4, "pointer": 1, "accessible_press": 1,
            "touch_cancel": 1, "disabled_pointer_attempts": 2, "disabled_ax_attempts": 2, "selections": 6}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", required=True, type=Path)
    parser.add_argument("--debug-dir", required=True, type=Path)
    parser.add_argument("--artifacts", required=True, type=Path)
    parser.add_argument("--profile", choices=PROFILES, action="append")
    parser.add_argument("--startup-timeout", default=45, type=int)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "runs": {}, "frames": [], "errors": []}
    for name, (width, dark, rtl, scale) in PROFILES.items():
        if plan.profile and name not in plan.profile:
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, VIEWPORTS[width], dark) as case:
                result = journey(case, rtl, scale)
            output = (plan.artifacts / (name + ".log")).read_text()
            adapter = next((line for line in output.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in adapter and "backend: Metal" in adapter, "No native Metal adapter")
            report["runs"][name] = {**result, "adapter": adapter}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(report["errors"][-1], flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(report["runs"] and not report["errors"], "\n".join(report["errors"]) or "No profile")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
