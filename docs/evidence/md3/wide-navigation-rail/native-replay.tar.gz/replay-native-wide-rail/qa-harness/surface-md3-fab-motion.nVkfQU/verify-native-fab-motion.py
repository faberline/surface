#!/usr/bin/env python3
"""Verify real native Extended FAB motion with a private fixed-clock Gallery."""

import argparse
from collections import Counter
from contextlib import contextmanager
import math
import os
from pathlib import Path
import runpy
import subprocess
import tempfile
import time


HERE = Path(__file__).resolve().parent
BASELINE = runpy.run_path(str(HERE.parent /
                            "surface-md3-extended-fab.lFaabo/verify-native-extended-fab.py"))
call = BASELINE["call"]
capture = BASELINE["capture"]
check_mcp = BASELINE["check_mcp"]
close = BASELINE["close"]
coords = BASELINE["coords"]
descendants = BASELINE["descendants"]
dom_index = BASELINE["dom_index"]
is_inside = BASELINE["is_inside"]
make_active = BASELINE["make_active"]
overlap = BASELINE["overlap"]
png_pixels = BASELINE["png_pixels"]
read_ax = BASELINE["read_ax"]
require = BASELINE["require"]
rgba_near = BASELINE["rgba_near"]
stop = BASELINE["stop"]
wait_for_session = BASELINE["wait_for_session"]
window_state = BASELINE["window_state"]
write_json = BASELINE["write_json"]
SECTION = BASELINE["SECTION"]
BUTTON = BASELINE["BUTTON"]
DISABLED = BASELINE["DISABLED"]
RTL = BASELINE["RTL"]
NAME = BASELINE["NAME"]
DISABLED_NAME = BASELINE["DISABLED_NAME"]
FIXED = "gallery-fab-toggle"
SETTLE_MS = 1200
EXPAND_MID_MS = 48
COLLAPSE_MID_MS = 55


class WindowFocusInterrupted(RuntimeError):
    pass


class Clock:
    def __init__(self, path):
        self.path = path
        self.now = 100000
        self.focus_log_offset = 0
        self.write()

    def write(self):
        replacement = self.path.with_suffix(".next")
        replacement.write_text(str(self.now))
        replacement.replace(self.path)

    def advance(self, ms):
        self.now += ms
        self.write()


@contextmanager
def gallery(plan, client, binary, label, dark, rtl, reduced=False):
    with (
        tempfile.TemporaryDirectory(prefix="surface-fab-motion-", dir="/private/tmp") as folder,
        (plan.artifacts / f"{label}.log").open("wb") as log,
    ):
        session = Path(folder) / "session.json"
        clock = Clock(Path(folder) / "frame-time")
        env = dict(os.environ, SURFACE_DEVTOOLS_SESSION=str(session),
                   SURFACE_QA_ANIMATION_TIME=str(clock.path),
                   SURFACE_REDUCED_MOTION="1" if reduced else "0")
        for key in ("SURFACE_TRACE", "SURFACE_BRIDGE_SESSION"):
            env.pop(key, None)
        child = subprocess.Popen(
            (binary,), cwd=HERE / "native-qa", env=env, stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT,
        )
        try:
            wait_for_session(session, child)
            require("Page.screenshot" in call(client, session, "capabilities")["methods"],
                    "Page.screenshot capability missing")
            nodes, index = dom_index(call(client, session, "dom", "snapshot"))
            if nodes[index["theme"]]["checked"] is not dark:
                call(client, session, "action", "activate", "theme")
            call(client, session, "action", "activate", SECTION)
            if rtl:
                call(client, session, "action", "activate", RTL)
            yield session, child, clock
        finally:
            stop(child)


def intersection(first, second):
    x = max(first["x"], second["x"])
    y = max(first["y"], second["y"])
    size = overlap(first, second)
    return {"x": x, "y": y, **size}


def shrink(rect, amount):
    return {"x": rect["x"] + amount, "y": rect["y"] + amount,
            "width": max(0., rect["width"] - 2. * amount),
            "height": max(0., rect["height"] - 2. * amount)}


def geom(snapshot, rtl):
    nodes, index = dom_index(snapshot)
    layout = snapshot["layout"]["nodes"]
    button = index[BUTTON]
    action = nodes[button]
    disabled = nodes[index[DISABLED]]
    require(action["role"] == "Button" and action["name"] == NAME and not action["disabled"]
            and action.get("expanded") is None and action.get("checked") is None,
            "enabled FAB must stay one named action")
    require(disabled["role"] == "Button" and disabled["name"] == DISABLED_NAME and disabled["disabled"],
            "disabled sample has unexpected semantics")
    children = list(descendants(nodes, button))
    labels = [child for child in children if nodes[child].get("text") == NAME]
    glyphs = [child for child in children if nodes[child].get("text") == "+"]
    require(len(labels) == 1 and len(glyphs) == 1,
            f"expected one retained visual label and glyph, got labels={labels}, glyphs={glyphs}")
    label, glyph = labels[0], glyphs[0]
    require(not nodes[label]["name"], "visual label became an extra accessible name")
    hit = layout[button]["bounds"]
    label_rect = layout[label]["bounds"]
    label_visible = intersection(label_rect, layout[label]["clip"])
    icon = layout[nodes[glyph]["parent"]]["bounds"]
    for extent in ("height", "width"):
        close(icon[extent], 24., f"icon {extent}")
    close(hit["height"], 56., "FAB height")
    close(icon["y"] - hit["y"], 16., "vertical icon position")
    require(is_inside(icon, hit), f"glyph escapes body: {icon} in {hit}")
    require(snapshot["interaction"]["focused"] == BUTTON, "FAB lost focus")
    if label_visible["width"] > 0.1 and label_visible["height"] > 0.1:
        logical_start_offset = (
            label_rect["x"] + label_rect["width"]
            - label_visible["x"] - label_visible["width"]
            if rtl else label_visible["x"] - label_rect["x"]
        )
        close(logical_start_offset, 0., "label clip starts at the logical edge")
        require(is_inside(label_visible, hit), f"label clip escapes body: {label_visible} in {hit}")
    return {
        "hit": hit, "hit_clip": layout[button]["clip"], "label_rect": label_rect,
        "label_clip": label_visible, "icon": icon, "focus": snapshot["interaction"]["focused"],
        "rtl": rtl, "fill": action["style"]["background"],
        "glyph_ink": nodes[glyph]["style"]["foreground"],
        "label_ink": nodes[label]["style"]["foreground"],
        "fixed_overlay_overlap": overlap(hit, layout[index[FIXED]]["bounds"]),
        "hover": snapshot["interaction"]["hovered"],
    }


def linear(channel):
    value = channel / 255.
    return value / 12.92 if value <= .04045 else ((value + .055) / 1.055) ** 2.4


def pixel_evidence(plan, details, geometry):
    hit = geometry["hit"]
    limit = details["width"], details["height"]
    inset = shrink(hit, 3.)
    center = math.floor(hit["x"] + hit["width"] / 2)
    top = math.ceil(hit["y"] + 8)
    body = [(x, y) for y in range(top, top + 4) for x in range(center - 4, center + 5)]
    label = coords(geometry["label_clip"], limit)
    icon = coords(geometry["icon"], limit)
    label_rect = coords(intersection(geometry["label_rect"], inset), limit)
    clip = geometry["label_clip"]
    forbidden = [
        (x, y) for x, y in label_rect
        if (x + .5 < clip["x"] - 1. or x + .5 > clip["x"] + clip["width"] + 1.)
        and not geometry["icon"]["x"] - 2 <= x <= geometry["icon"]["x"] + 26
    ]
    pixels = png_pixels(plan.artifacts / details["file"], details, set(body + label + icon + forbidden))
    backdrop = Counter(tuple(pixels[pos]) for pos in body).most_common(1)[0][0]
    require(rgba_near(geometry["fill"], backdrop, 35 if geometry["hover"] == BUTTON else 5),
            f"surface fill differs from rendered body: {geometry['fill']}, {backdrop}")

    def coverage(pos, target):
        basis = [linear(c) for c in backdrop[:3]]
        direction = [linear(c) - b for c, b in zip(target[:3], basis)]
        diff = [linear(c) - b for c, b in zip(pixels[pos][:3], basis)]
        return sum(a * b for a, b in zip(diff, direction)) / sum(c * c for c in direction)

    interpreted = {
        "label": [coverage(pos, geometry["label_ink"]) for pos in label],
        "glyph": [coverage(pos, geometry["glyph_ink"]) for pos in icon],
        "clipped_label": [coverage(pos, geometry["label_ink"]) for pos in forbidden],
    }
    require(sum(data >= .08 for data in interpreted["glyph"]) >= 5, "PNG has no visible plus glyph")
    require(all(data <= .08 for data in interpreted["clipped_label"]),
            f"PNG paints beyond the label clip: {max(interpreted['clipped_label'], default=0):.3f}")
    return {"painted_fill": backdrop, "label_peak": max(interpreted["label"], default=0.),
            "label_ink_pixels": sum(data >= .08 for data in interpreted["label"]),
            "glyph_peak": max(interpreted["glyph"], default=0.),
            "outside_clip_pixels_checked": len(forbidden)}


def frame(plan, client, session, clock, prefix, key, size, dark, rtl, report,
          pixels=True, visual_child=None):
    log_path = plan.artifacts / f"{prefix}.log"
    log_before = log_path.read_text()
    details, snapshot = capture(plan, client, session, f"{prefix}-{key}", size, dark, SECTION, (BUTTON,))
    if snapshot["interaction"]["focused"] is None:
        new_log = log_path.read_text()[clock.focus_log_offset:]
        if "QA held-frame window blur at " in new_log:
            if visual_child is None:
                raise WindowFocusInterrupted(f"AppKit window blur during {details['file']} at {clock.now} ms")
            interrupted_file = details["file"]
            before_width = details["nodes"][BUTTON]["bounds"]["width"]
            native_window = window_state(plan.probe, visual_child)
            result = call(client, session, "action", "qa-ax-focus", BUTTON)
            require(result["focused"] == BUTTON, "test Gallery reactivation did not restore the FAB")
            details, snapshot = capture(plan, client, session, f"{prefix}-{key}-restored", size,
                                        dark, SECTION, (BUTTON,))
            close(details["nodes"][BUTTON]["bounds"]["width"], before_width,
                  "restoring the native window at the held time preserves FAB width")
            report["window_focus_restorations"].append({
                "interrupted": interrupted_file, "restored": details["file"],
                "time_ms": clock.now, "width": before_width, "native_window": native_window,
            })
            if snapshot["interaction"]["focused"] is None:
                raise WindowFocusInterrupted(f"AppKit blurred the restored {details['file']} at {clock.now} ms")
    geometry = geom(snapshot, rtl)
    clock.focus_log_offset = len(log_before)
    details.update({"time_ms": clock.now, "step": key, "fab": geometry})
    report["frames"].append(details)
    require(not details["errors"], "; ".join(details["errors"]))
    if pixels:
        details["pixels"] = pixel_evidence(plan, details, geometry)
    return details


def hit_width(frame_details):
    return frame_details["fab"]["hit"]["width"]


def check_endpoint(details, expanded):
    geometry = details["fab"]
    hit, icon, label = geometry["hit"], geometry["icon"], geometry["label_rect"]
    if expanded:
        require(hit["width"] >= 80., f"expanded FAB below minimum: {hit}")
        close(geometry["label_clip"]["width"], label["width"], "settled label clip")
        require(details["pixels"]["label_ink_pixels"] >= 20, "expanded PNG missing the label")
        spacing = (
            (hit["x"] + hit["width"] - icon["x"] - icon["width"],
             icon["x"] - label["x"] - label["width"], label["x"] - hit["x"])
            if geometry["rtl"] else
            (icon["x"] - hit["x"], label["x"] - icon["x"] - icon["width"],
             hit["x"] + hit["width"] - label["x"] - label["width"])
        )
        for actual, expected in zip(spacing, (16., 12., 20.)):
            close(actual, expected, "expanded inline spacing")
    else:
        close(hit["width"], 56., "collapsed FAB")
        close(icon["x"] - hit["x"], 16., "collapsed icon center")
        require(geometry["label_clip"]["width"] < .1 or geometry["label_clip"]["height"] < .1,
                "collapsed label has a nonempty clip")
        require(details["pixels"]["label_ink_pixels"] == 0, "collapsed PNG paints label")


def ax_press(plan, client, session, child):
    if not window_state(plan.probe, child)["active"]:
        make_active(plan.probe, child)
    for _ in range(5):
        result = BASELINE["query_ax"](plan.probe, child, NAME, "--press")
        if result.get("pressStatus") == 0:
            break
        require("pressStatus" not in result, f"native AXPress returned an error: {result}")
        time.sleep(.12)
        call(client, session, "dom", "snapshot")
    else:
        raise RuntimeError(f"native AXPress did not run: {result}")
    # Keep the clock held while AppKit queues the accessibility action.
    time.sleep(.08)
    call(client, session, "dom", "snapshot")


def verify_motion(plan, client, binary, width, size, dark, rtl, report, attempt=0):
    prefix = f"{width}-{'dark' if dark else 'light'}-{'rtl' if rtl else 'ltr'}"
    if attempt:
        prefix += f"-retry{attempt}"
    with gallery(plan, client, binary, prefix, dark, rtl) as (session, child, clock):
        def grab(key):
            return frame(plan, client, session, clock, prefix, key, size, dark, rtl, report,
                         visual_child=child)

        def press():
            result = call(client, session, "action", "qa-ax-press", BUTTON)
            require(result["focused"] == BUTTON, f"validated AX action lost focus: {result}")

        call(client, session, "action", "activate", BUTTON)
        clock.advance(SETTLE_MS)
        collapsed = grab("collapsed")
        check_endpoint(collapsed, False)
        press()
        enter_start = grab("expand-0")
        close(hit_width(enter_start), hit_width(collapsed), "expand starts at collapsed geometry")
        if width == "narrow":
            clock.advance(30)
            grab("expand-30")
            clock.advance(EXPAND_MID_MS - 30)
        else:
            clock.advance(EXPAND_MID_MS)
        midpoint = grab(f"expand-{EXPAND_MID_MS}")
        repeated = grab(f"expand-{EXPAND_MID_MS}-repeat")
        require(repeated["sha256"] == midpoint["sha256"], "equal-clock midpoint PNGs differ")
        if (width, dark, rtl) == ("compact", True, True):
            mcp = check_mcp(plan, client, session, size)
            require(mcp["sha256"] == midpoint["sha256"], "CLI and MCP differ at the held midpoint")
            report["mcp"] = {**mcp, "compared_with": midpoint["file"], "time_ms": clock.now}
        clock.advance(SETTLE_MS)
        expanded = grab("expanded")
        check_endpoint(expanded, True)
        require(hit_width(collapsed) < hit_width(midpoint) < hit_width(expanded),
                "real layout has no intermediate expansion width")
        require(1. < midpoint["fab"]["label_clip"]["width"] < expanded["fab"]["label_clip"]["width"] - 1.,
                f"midpoint label is not visibly clipped: {midpoint['fab']['label_clip']}")
        require(.08 < midpoint["pixels"]["label_peak"] < .92 * expanded["pixels"]["label_peak"],
                f"midpoint PNG has no independently faded text: {midpoint['pixels']}")
        press()
        clock.advance(COLLAPSE_MID_MS)
        closing = grab(f"collapse-{COLLAPSE_MID_MS}")
        require(hit_width(collapsed) < hit_width(closing) < hit_width(expanded),
                "real layout has no intermediate collapse width")
        require(closing["pixels"]["label_peak"] < .85 * expanded["pixels"]["label_peak"],
                "collapse did not fade label ink")
        if width == "narrow" and dark and rtl:
            press()
            reversal = grab("reverse-0")
            for name in ("x", "y", "width", "height"):
                close(reversal["fab"]["hit"][name], closing["fab"]["hit"][name], f"retarget {name}")
            require(reversal["sha256"] == closing["sha256"], "reversal changed the held pixels")
            clock.advance(SETTLE_MS)
            check_endpoint(grab("reverse-expanded"), True)
            press()
        clock.advance(SETTLE_MS)
        check_endpoint(grab("collapsed-end"), False)


def gallery_key(plan, client, session, child, key, focus, report):
    if not window_state(plan.probe, child)["active"]:
        make_active(plan.probe, child)
    state = call(client, session, "action", "key", key)
    require(state["focused"] == focus, f"Surface {key} changed focus unexpectedly: {state}")
    report["keys"].append({"key": key, "delivery": "Surface Action.key", "response": state})


def verify_keyboard(plan, client, binary, size, report):
    prefix = "narrow-native-keyboard"
    dark, rtl = False, True
    with gallery(plan, client, binary, prefix, dark, rtl) as (session, child, clock):
        report["activation"] = make_active(plan.probe, child)
        gallery_key(plan, client, session, child, "tab", BUTTON, report)
        expanded = frame(plan, client, session, clock, prefix, "tab", size, dark, rtl, report)
        check_endpoint(expanded, True)
        report["ax"].append({"stage": "tab", **read_ax(plan, child, expanded["fab"]["hit"])})
        disabled = call(client, session, "dom", "snapshot")
        _, ids = dom_index(disabled)
        report["disabled_ax"] = read_ax(
            plan, child, disabled["layout"]["nodes"][ids[DISABLED]]["bounds"], disabled=True,
        )
        gallery_key(plan, client, session, child, "enter", BUTTON, report)
        clock.advance(COLLAPSE_MID_MS)
        middle = frame(plan, client, session, clock, prefix, "enter-midpoint", size, dark, rtl,
                       report, pixels=False)
        require(56. < hit_width(middle) < hit_width(expanded), "native Enter did not animate collapse")
        report["ax"].append({"stage": "enter-midpoint", **read_ax(plan, child, middle["fab"]["hit"])})
        clock.advance(SETTLE_MS)
        collapsed = frame(plan, client, session, clock, prefix, "enter-settled", size, dark, rtl, report)
        check_endpoint(collapsed, False)
        report["ax"].append({"stage": "enter-settled", **read_ax(plan, child, collapsed["fab"]["hit"])})
        gallery_key(plan, client, session, child, "space", BUTTON, report)
        clock.advance(EXPAND_MID_MS)
        middle = frame(plan, client, session, clock, prefix, "space-midpoint", size, dark, rtl,
                       report, pixels=False)
        require(56. < hit_width(middle) < hit_width(expanded), "native Space did not animate expansion")
        report["ax"].append({"stage": "space-midpoint", **read_ax(plan, child, middle["fab"]["hit"])})
        clock.advance(SETTLE_MS)
        opened = frame(plan, client, session, clock, prefix, "space-settled", size, dark, rtl, report)
        check_endpoint(opened, True)
        require(collapsed["fab"]["hit"]["y"] != opened["fab"]["hit"]["y"],
                "native narrow keyboard case did not wrap")
        ax_press(plan, client, session, child)
        clock.advance(COLLAPSE_MID_MS)
        middle = frame(plan, client, session, clock, prefix, "axpress-midpoint", size, dark, rtl, report)
        require(56. < hit_width(middle) < hit_width(expanded), "native AXPress did not animate collapse")
        report["ax"].append({"stage": "axpress-midpoint", **read_ax(plan, child, middle["fab"]["hit"])})
        origin = [(detail["position"]["x"] - f["fab"]["hit"]["x"],
                   detail["position"]["y"] - f["fab"]["hit"]["y"])
                  for detail, f in zip(report["ax"], [
                      expanded, *[item for item in report["frames"]
                                   if item["file"].startswith(prefix)
                                   and item["step"] in ("enter-midpoint", "enter-settled",
                                                        "space-midpoint", "axpress-midpoint")]
                  ])]
        require(len(origin) == 5, "missing midpoint positions from AX")
        for x, y in origin[1:]:
            close(x, origin[0][0], "AX screen origin x")
            close(y, origin[0][1], "AX screen origin y")


def verify_reduced(plan, client, binary, size, report):
    prefix = "compact-reduced-motion"
    with gallery(plan, client, binary, prefix, False, False, reduced=True) as (session, _, clock):
        call(client, session, "action", "activate", BUTTON)
        before = frame(plan, client, session, clock, prefix, "collapse", size, False, False, report)
        check_endpoint(before, False)
        call(client, session, "action", "activate", BUTTON)
        after = frame(plan, client, session, clock, prefix, "expand", size, False, False, report)
        check_endpoint(after, True)
        require(before["time_ms"] == after["time_ms"], "host time moved during reduced-motion check")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--probe", type=Path, required=True)
    parser.add_argument("--viewport", choices=("wide", "compact", "narrow"))
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--direction", choices=("ltr", "rtl"))
    parser.add_argument("--case", choices=("matrix", "keyboard", "reduced", "all"), default="all")
    plan = parser.parse_args()
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    client = plan.debug_dir / "surface-devtools"
    sizes = {
        "wide": (plan.debug_dir / "surface-material-gallery", (960, 800)),
        "compact": (plan.debug_dir / "examples/compact", (420, 360)),
        "narrow": (plan.debug_dir / "examples/extended_fab_narrow", (320, 360)),
    }
    report = {
        "capture": "Surface Page.screenshot", "frames": [], "keys": [], "ax": [], "errors": [],
        "window_interruptions": [],
        "window_focus_restorations": [],
        "matrix_input": "QA DevTools calls the same Runtime::accessibility_activate as AppKit",
    }
    caught = (RuntimeError, KeyError, ValueError, TypeError, OSError, subprocess.SubprocessError)
    if plan.case in ("matrix", "all"):
        for width, (binary, size) in sizes.items():
            if plan.viewport and plan.viewport != width:
                continue
            for dark in (False, True):
                if plan.theme and plan.theme != ("dark" if dark else "light"):
                    continue
                for rtl in (False, True):
                    if plan.direction and plan.direction != ("rtl" if rtl else "ltr"):
                        continue
                    for attempt in range(2):
                        offset = len(report["frames"])
                        try:
                            verify_motion(plan, client, binary, width, size, dark, rtl, report, attempt)
                        except caught as error:
                            if isinstance(error, WindowFocusInterrupted) and attempt == 0:
                                interrupted = report["frames"][offset:]
                                del report["frames"][offset:]
                                report["window_interruptions"].append({
                                    "reason": str(error), "files": [item["file"] for item in interrupted],
                                })
                                print(f"{error}. Retrying the closed case in a fresh Gallery.", flush=True)
                                continue
                            report["errors"].append(f"{width}, dark={dark}, rtl={rtl}: {error}")
                            print(report["errors"][-1], flush=True)
                        break
    if plan.case in ("keyboard", "all"):
        try:
            verify_keyboard(plan, client, *sizes["narrow"], report)
        except caught as error:
            report["errors"].append(f"native keyboard and AX: {error}")
    if plan.case in ("reduced", "all"):
        try:
            verify_reduced(plan, client, *sizes["compact"], report)
        except caught as error:
            report["errors"].append(f"reduced motion: {error}")
    report["overlay_intersections"] = [
        {"file": item["file"], **item["fab"]["fixed_overlay_overlap"]}
        for item in report["frames"]
        if all(v > .01 for v in item["fab"]["fixed_overlay_overlap"].values())
    ]
    if report["overlay_intersections"]:
        report["errors"].append(f"fixed action obstructs sampled FABs: {report['overlay_intersections']}")
    write_json(plan.artifacts / "report.json", report)
    if report["errors"]:
        raise SystemExit("\n".join(report["errors"]))
    print(f"Passed {len(report['frames'])} PNG frames and {len(report['ax'])} live native AX states")


if __name__ == "__main__":
    main()
