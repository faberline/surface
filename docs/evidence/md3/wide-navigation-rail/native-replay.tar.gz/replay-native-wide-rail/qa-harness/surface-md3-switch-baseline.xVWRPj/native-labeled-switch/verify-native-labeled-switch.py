#!/usr/bin/env python3
"""Verify labeled switch geometry and input through native Surface on Metal."""

import argparse
import json
import math
from pathlib import Path
import runpy
import subprocess

HERE = Path(__file__).resolve().parent
TOOLING = runpy.run_path(str(HERE.parents[1] / "surface-md3-list-switch.m5H5kR"
                             / "native-list-switch" / "verify-native-list-switch.py"))
COMMON, MOTION, VIEWPORTS = (TOOLING[k] for k in ("COMMON", "MOTION", "VIEWPORTS"))
capture, center, close, color_matches, contains, focus, key, node, pixels_for, rect, require = (
    TOOLING[k] for k in ("capture", "center", "close", "color_matches", "contains", "focus",
                         "key", "node", "pixels_for", "rect", "require")
)
by_center, complete_bands, frame_row, paint_entries, palette_roles, press_ax, reject, same_rect, sample_points, write_json = (
    TOOLING[k] for k in ("by_center", "complete_bands", "frame_row", "paint_entries", "palette_roles",
                        "press_ax", "reject", "same_rect", "sample_points", "write_json")
)
SECTION = "section-5"
PREFIX = "labeled-switch-"
CARD, DIRECTION, SCALE, STATUS, ON, OFF, DISABLED_ON, DISABLED_OFF = (
    PREFIX + suffix for suffix in ("card", "direction", "scale", "status", "enabled-on",
                                    "enabled-off", "disabled-on", "disabled-off")
)
LEGACY = "enabled"
SWITCHES = {
    ON: ("接收備份完成通知", True, False),
    OFF: ("同步備份檔案", False, False),
    DISABLED_ON: ("已停用的備份通知", True, True),
    DISABLED_OFF: ("停用的安全警示", False, True),
}
PROFILES = [(viewport, theme, direction, scale)
            for viewport, scale in (("wide", 1), ("narrow", 2))
            for theme in ("light", "dark") for direction in ("ltr", "rtl")]


def label_for(id):
    return "啟用通知" if id == LEGACY else SWITCHES[id][0]


def count(case, expected):
    status = node(case.snapshot(), STATUS)
    observed = status["text"] or status["name"]
    require(observed == f"切換 {expected} 次", f"Expected {expected} actions; observed {observed!r}")


def geometry(snapshot, id, rtl, checked):
    nodes, ids = COMMON["dom_index"](snapshot)
    layout = snapshot["layout"]["nodes"]
    target_idx = ids[id]
    track_idx = nodes[target_idx]["first_child"]
    thumb_idx = nodes[track_idx]["first_child"]
    label_idx = nodes[target_idx]["last_child"]
    require(track_idx != label_idx, f"{id}: track and label must both exist")
    require(nodes[label_idx]["text"] == label_for(id), f"{id}: label or logical order changed")
    require(nodes[track_idx]["role"] == nodes[thumb_idx]["role"] == "Group",
            f"{id}: track and thumb must be passive visual groups")
    target, track, thumb, label = (layout[idx]["bounds"] for idx in (target_idx, track_idx, thumb_idx, label_idx))
    require(target["width"] >= 48 and target["height"] >= 48, f"{id}: insufficient hit target")
    require(contains(target, track) and contains(target, label) and contains(track, thumb),
            f"{id}: switch content extends outside its target")
    if id != LEGACY:
        require(contains(rect(snapshot, CARD), target), f"{id}: switch extends outside its Gallery card")

    close(track["width"], 52., "Track width")
    close(track["height"], 32., "Track height")
    diameter = 24. if checked else 16.
    close(thumb["width"], diameter, "Thumb width")
    close(thumb["height"], diameter, "Thumb height")
    offset = 36. if checked else 16.
    if rtl:
        offset = 52. - offset
    close(center(thumb)[0] - track["x"], offset, "Mirrored thumb center")
    close(center(thumb)[1], center(track)[1], "Thumb vertically centered")
    close(center(track)[1], center(target)[1], "Track vertically centered")
    close(center(label)[1], center(target)[1], "Label vertically centered")

    if rtl:
        start = target["x"] + target["width"] - track["x"] - track["width"]
        gap = track["x"] - label["x"] - label["width"]
        end = label["x"] - target["x"]
    else:
        start = track["x"] - target["x"]
        gap = label["x"] - track["x"] - track["width"]
        end = target["x"] + target["width"] - label["x"] - label["width"]
    close(start, 12., "Logical start padding")
    close(gap, 12., "Track-label gap")
    require(end >= 11.5, f"{id}: label crowded the logical end padding")
    return {"target": target, "track": track, "thumb": thumb, "label": label}


def accessibility(snapshot, receipt, id, boxes, checked, disabled):
    tree = receipt["accesskit"]
    control = tree["nodes"][id]
    require(control["role"] == "Switch" and control["name"] == label_for(id)
            and control["toggled"] == ("True" if checked else "False"),
            f"{id}: native Switch role, name or state changed: {control}")
    require(control["disabled"] is disabled and control["focusable"] is not disabled,
            f"{id}: invalid disabled mapping")
    if id != LEGACY:
        require(control["press"] is not disabled, f"{id}: invalid AccessKit Click availability")
    focused = snapshot["interaction"]["focused"] == id
    require(control["focused"] is focused, f"{id}: native focus disagrees with Surface")

    _, ids = COMMON["dom_index"](snapshot)
    clip = snapshot["layout"]["nodes"][ids[id]]["clip"]
    box = boxes["target"]
    logical = [max(box["x"], clip["x"]), max(box["y"], clip["y"]),
               min(box["x"] + box["width"], clip["x"] + clip["width"]),
               min(box["y"] + box["height"], clip["y"] + clip["height"])]
    require(control["bounds"] is not None and len(control["bounds"]) == 4, "Missing native hit bounds")
    for actual, expected in zip(control["bounds"], logical):
        close(actual, expected * tree["scale"], "Native hit bounds")
    if id != LEGACY:
        actionable = [n["name"] for n in tree["viewport_subtree"] if n["press"] or n["focusable"]]
        require(actionable.count(label_for(id)) == int(not disabled),
                f"{id}: extra actionable label or unintended disabled action")
    return control


def focus_edges(box):
    x, y, w, h = (box[k] for k in ("x", "y", "width", "height"))
    return {
        "top": {"x": x, "y": y, "width": w, "height": 2.},
        "bottom": {"x": x, "y": y + h - 2., "width": w, "height": 2.},
        "left": {"x": x, "y": y, "width": 2., "height": h},
        "right": {"x": x + w - 2., "y": y, "width": 2., "height": h},
    }


def focus_samples(edges, clip):
    bands = {}
    for name, box in edges.items():
        x, y = center(box)
        if name in ("top", "bottom"):
            part = {**box, "x": x - 4., "width": 8.}
        else:
            part = {**box, "y": y - 4., "height": 8.}
        if contains(clip, part):
            bands[name] = sample_points(part)
    return bands


def verify_paint(case, frame, receipt, id, boxes, checked, disabled, focused, phase, scale):
    target, track, thumb, label = (boxes[k] for k in ("target", "track", "thumb", "label"))
    palette = case.plan.palette["dark" if case.dark else "light"]
    fill, handle, border = palette_roles(palette, checked, disabled)
    strokes = paint_entries(receipt, ("Stroke", "ShapeStroke"))
    fills = paint_entries(receipt, ("Quad", "Shape"))
    clip = frame["viewport"]
    require(contains(clip, track) and contains(clip, thumb), f"{id}: clipped switch paint")

    for box, color, subject, radius in ((track, fill, "track", 16.), (thumb, handle, "thumb", thumb["width"] / 2)):
        own = [op for op in fills if op["color"] == color and same_rect(op["rect"], box)]
        require(len(own) == 1, f"{id}: wrong {subject} fill")
        if "radius" in own[0]:
            close(own[0]["radius"], radius, f"{id}: {subject} radius")
    track_strokes = [op for op in strokes if same_rect(op["rect"], track)]
    require(len(track_strokes) == int(border is not None), f"{id}: wrong track outline count")
    if border is not None:
        require(track_strokes[0]["color"] == border, f"{id}: wrong off track outline color")
        close(track_strokes[0]["width"], 2., "Off track outline width")

    tx, ty = center(thumb)
    mid = center(track)[0]
    opposite = mid * 2 - tx + (4. if tx < mid else -4.)
    track_pixels = sample_points({"x": opposite - 2., "y": ty - 2., "width": 4., "height": 4.})
    thumb_pixels = sample_points({"x": tx - 2., "y": ty - 2., "width": 4., "height": 4.})
    edge_x = math.floor(mid + (6. if tx < mid else -6.))
    bottom = math.ceil(track["y"] + track["height"])
    outline_pixels = {(x, y) for x in range(edge_x - 1, edge_x + 2) for y in range(bottom - 4, bottom)}

    halo = by_center(thumb, 40.)
    layer_color = palette["primary" if checked else "on_surface"]
    ripple_ops = [op["Ripple"] for op in receipt["presented"]["ops"] if "Ripple" in op
                  and same_rect(op["Ripple"]["bounds"], halo)]
    feedback = None
    if phase == "press":
        require(len(ripple_ops) == 1, f"{id}: missing single centered press ripple")
        ripple = ripple_ops[0]["ripple"]
        close(ripple["x"], tx, "Press radius follows thumb horizontally")
        close(ripple["y"], ty, "Press radius follows thumb vertically")
        require(15. <= ripple["radius"] <= 20. and ripple["color"][:3] == layer_color[:3] and ripple["color"][3] > 0,
                f"{id}: invalid native press layer: {ripple}")
        feedback = {"kind": "ripple", "geometry": halo, "color": ripple["color"]}
    else:
        require(not ripple_ops, f"{id}: unexpected press ripple")
    halo_fills = [op for op in fills if same_rect(op["rect"], halo)
                  and op["color"][:3] == layer_color[:3] and 0 < op["color"][3] < 31]
    if phase == "hover":
        require(len(halo_fills) == 1, f"{id}: missing 40 dp centered hover layer")
        feedback = {"kind": "hover", "geometry": halo, "color": halo_fills[0]["color"]}
    if disabled:
        require(not halo_fills, f"{id}: disabled switch painted a hover layer")

    edges = focus_edges(target)
    focus_ink = palette["secondary"]
    for name, box in edges.items():
        own = [op for op in fills if same_rect(op["rect"], box) and op["color"] == focus_ink]
        require(len(own) == int(focused), f"{id}: wrong Secondary focus outline at {name}")
    focus_bands = focus_samples(edges, clip) if focused else {}
    if focused:
        require(len(focus_bands) == 4, f"{id}: clipped focus outline")
    runs = [op for op in paint_entries(receipt, ("Text", "StyledText"))
            if op["text"] == label_for(id) and same_rect(op["rect"], label)]
    require(len(runs) == 1, f"{id}: missing visible localized label text")
    text_run = runs[0]
    close(text_run["style"]["font_size"], 16. * scale, "Scaled Body Large text size")
    close(text_run["style"]["line_height"], 24. * scale, "Scaled Body Large line height")
    total, label_bands = complete_bands(label, 24. * scale, clip)
    require(len(label_bands) == total, f"{id}: a label band was clipped")

    requested = set.union(track_pixels, thumb_pixels, outline_pixels, *focus_bands.values(), *label_bands.values())
    actual = pixels_for(case.plan.artifacts / frame["file"], frame, requested)
    track_matches = sum(color_matches(actual[p], fill, 10) for p in track_pixels)
    thumb_matches = sum(color_matches(actual[p], handle, 10) for p in thumb_pixels)
    require(track_matches >= .9 * len(track_pixels) >= 8
            and thumb_matches >= .9 * len(thumb_pixels) >= 8,
            f"{id}: incorrect native track or thumb pixels")
    outline_matches = sum(color_matches(actual[p], border, 10) for p in outline_pixels) if border else 0
    if border:
        require(outline_matches >= 1, f"{id}: off outline did not reach native pixels")
    focus_matches = {k: sum(color_matches(actual[p], focus_ink, 14) for p in band)
                     for k, band in focus_bands.items()}
    if focused:
        require(min(focus_matches.values()) >= 3, f"{id}: incomplete Secondary focus pixels")
    label_matches = {str(k): sum(color_matches(actual[p], text_run["color"], 18) for p in band)
                     for k, band in label_bands.items()}
    require(label_matches and min(label_matches.values()) >= 4, f"{id}: label ink missing on a line")
    return {
        "checked": checked, "disabled": disabled, "track_fill": fill, "thumb_fill": handle,
        "outline_color": border, "track_matches": track_matches, "thumb_matches": thumb_matches,
        "outline_matches": outline_matches, "focus_ink_per_edge": focus_matches,
        "label_lines": total, "label_ink_per_line": label_matches, "feedback": feedback,
    }


def take(case, stage, id, rtl, scale, value, actions, phase="rest", section=SECTION):
    if phase == "rest":
        require(not frame_row(case, id), f"{id}: switch taller than tested viewport")
    case.clock.advance({"rest": 700, "hover": 120, "press": 160}[phase])
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{stage}",
                              case.size, case.dark, section)
    require(not frame["errors"], str(frame["errors"]))
    if actions is not None:
        count(case, actions)
    disabled = id != LEGACY and SWITCHES[id][2]
    source = node(snapshot, id)
    require(source.get("checked") is value and source.get("disabled", False) is disabled,
            f"{id}: wrong app-controlled value or disabled state")
    focused = snapshot["interaction"]["focused"] == id
    receipt = json.loads(case.receipt.read_text())
    boxes = geometry(snapshot, id, rtl, value)
    axis = accessibility(snapshot, receipt, id, boxes, value, disabled)
    paint = verify_paint(case, frame, receipt, id, boxes, value, disabled, focused, phase, scale)
    frame.update(stage=stage, item=id, rtl=rtl, text_scale=scale, actions=actions,
                 focused=focused, phase=phase, paint=paint, accesskit=axis, **boxes)
    case.frames.append(frame)
    return frame


def point_for(case, id, rtl, part="label"):
    frame_row(case, id)
    snapshot = case.snapshot()
    checked = node(snapshot, id)["checked"]
    return center(geometry(snapshot, id, rtl, checked)[part])


def stable(before, after):
    for label in ("track", "label", "target"):
        def relative(frame):
            box = frame[label]
            root = frame["target"]
            return {**box, "x": box["x"] - root["x"], "y": box["y"] - root["y"]}
        require(same_rect(relative(before), relative(after)), f"{label}: value changed hit or text allocation")


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2:
        case.call("action", "activate", SCALE)
    case.point("leave")
    rest = {}
    result = {"mcp": None}
    for id, (_, checked, _) in SWITCHES.items():
        stage = id.removeprefix(PREFIX)
        frame = take(case, stage, id, rtl, scale, checked, 0)
        rest[id] = frame
        if id == OFF and case.size[0] == 320 and case.dark and rtl and scale == 2:
            mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
            require((case.plan.artifacts / frame["file"]).read_bytes() ==
                    (case.plan.artifacts / mcp["file"]).read_bytes(), "CLI and MCP returned different PNG bytes")
            result["mcp"] = {**mcp, "cli": frame["file"]}

    for id, value in ((DISABLED_ON, True), (DISABLED_OFF, False)):
        point = point_for(case, id, rtl)
        case.point("move", point)
        case.point("down", point)
        require(case.snapshot()["interaction"]["pressed"] is None, f"{id}: disabled label took native press")
        case.point("up", point)
        case.point("leave")
        require(node(case.snapshot(), id)["checked"] is value, f"{id}: disabled value changed")
        reject(case, "press", id, "no live AccessKit press")
        count(case, 0)

    point = point_for(case, OFF, rtl)
    case.point("touch-start", point)
    require(case.snapshot()["interaction"]["pressed"] == OFF, "Native touch did not reach labeled switch")
    case.point("touch-cancel", point)
    case.point("touch-end", point)
    require(case.snapshot()["interaction"]["pressed"] is None, "Winit cancel left a held press")
    count(case, 0)
    case.point("leave")
    off_base = take(case, "before-pointer", OFF, rtl, scale, False, 0)
    point = center(off_base["label"])

    case.point("move", point)
    require(case.snapshot()["interaction"]["hovered"] == OFF, "Hovering label must target its switch")
    take(case, "label-hover", OFF, rtl, scale, False, 0, phase="hover")
    case.point("down", point)
    require(case.snapshot()["interaction"]["pressed"] == OFF, "Pressing label must target its switch")
    take(case, "label-press", OFF, rtl, scale, False, 0, phase="press")
    case.point("up", point)
    case.point("leave")
    updated = take(case, "after-pointer", OFF, rtl, scale, True, 1)
    stable(off_base, updated)

    focus(case, SCALE)
    key(case, "tab", ON)
    focus_on = take(case, "keyboard-focus", ON, rtl, scale, True, 1)
    require(focus_on["focused"], "Tab did not focus the first enabled switch")
    key(case, "enter", ON)
    stable(rest[ON], take(case, "after-enter", ON, rtl, scale, False, 2))
    key(case, "tab", OFF)
    key(case, "space", OFF)
    stable(rest[OFF], take(case, "after-space", OFF, rtl, scale, False, 3))
    case.call("action", "qa-key", "tab")
    last_focus = case.snapshot()["interaction"]["focused"]
    require(last_focus not in (OFF, DISABLED_ON, DISABLED_OFF),
            f"Tab stayed on the last enabled switch or entered a disabled switch: {last_focus}")
    count(case, 3)

    frame_row(case, ON)
    press_ax(case, ON)
    stable(rest[ON], take(case, "after-accesskit", ON, rtl, scale, True, 4))

    if case.prefix == "wide-light-ltr-1x":
        case.call("action", "activate", "section-0")
        case.point("leave")
        baseline = node(case.snapshot(), LEGACY)["checked"]
        prior = take(case, "legacy", LEGACY, False, 1, baseline, None, section="section-0")
        focus(case, LEGACY)
        key(case, "enter", LEGACY)
        recent = take(case, "legacy-enter", LEGACY, False, 1, not baseline, None, section="section-0")
        stable(prior, recent)
    return {**result, "final": 4, "disabled_pointer_attempts": 2, "denied_accesskit_requests": 2,
            "winit_touch_cancellations": 1, "keyboard_disabled_skips": 2}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile")
    parser.add_argument("--full", action="store_true", help="Run all 24 usual Gallery profiles")
    parser.add_argument("--startup-timeout", type=int, default=45)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "runs": {}, "frames": [], "errors": []}
    for viewport, theme, direction, scale in (TOOLING["PROFILES"] if plan.full else PROFILES):
        name = f"{viewport}-{theme}-{direction}-{scale}x"
        if plan.profile not in (None, name):
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, VIEWPORTS[viewport], theme == "dark") as case:
                result = journey(case, direction == "rtl", scale)
            output = (plan.artifacts / f"{name}.log").read_text()
            metal = next((line for line in output.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in metal and "backend: Metal" in metal, f"{name}: not Metal")
            report["runs"][name] = {**result, "adapter": metal}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(report["errors"][-1], flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"] and report["runs"], "\n".join(report["errors"]) or "No matching profile")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
