#!/usr/bin/env python3
"""Check the saved two-thumb slider images, state transitions and source route."""

import argparse
from collections import Counter
import json
from pathlib import Path
import runpy


HERE = Path(__file__).resolve().parent
RUN = runpy.run_path(str(HERE / "verify-native-range-slider.py"))
BADGE = runpy.run_path(str(HERE.parents[1] / "surface-md3-badged-anchor.3d4V71"
                          / "native-badged-anchor" / "audit-native-badge.py"))
require, pixels_for, color_matches = (RUN[key] for key in ("require", "pixels_for", "color_matches"))
read_png = BADGE["read_png"]
PRICE, DISABLED = (RUN[k] for k in ("PRICE", "DISABLED"))
STAGES = {
    "default": [20, 80], "keyboard-focused": [25, 80], "locked-min": [0, 0],
    "locked-max": [100, 100], "overlap": [50, 50], "no-cross": [65, 65],
    "accesskit-adjusted": [45, 45], "cancelled": [40, 80],
}
ACCESSKIT = [("accesskit/set/lower", [40, 80]), ("accesskit/decrement/upper", [40, 75]),
             ("accesskit/increment/lower", [45, 75]), ("accesskit/set/upper", [45, 45])]


def verify_projection(frame):
    for group, item in frame["groups"].items():
        disabled = group == DISABLED
        low, high = RUN["DEFAULT"] if disabled else frame["pair"]
        for part, numbers in zip(RUN["PARTS"], ((0, low, high), (low, high, 100))):
            node = item["accesskit"][part]
            target = item["geometry"]["thumbs"][part]["target"]
            handle = item["geometry"]["thumbs"][part]["handle"]
            enabled = not disabled and numbers[0] < numbers[2]
            require((target["width"], target["height"], handle["width"], handle["height"]) == (48., 48., 4., 44.)
                    and node["role"] == "Slider" and node["name"] == RUN["NAMES"][part]
                    and node["focusable"] is not disabled and not node["child_roles"],
                    "The named slider target or paint geometry changed")
            require((node["minimum"], node["number"], node["maximum"]) == numbers and node["step"] == 5
                    and all(node[key] is enabled for key in ("set_value", "increment", "decrement")),
                    "A dependent native range or action changed")


def verify_pixels(folder, frame):
    read_png(folder, frame)
    points = {tuple(p) for p, _, _ in frame["probes"]}
    pixels = pixels_for(folder / frame["file"], frame, points)
    for point, expected, label in frame["probes"]:
        require(color_matches(pixels[tuple(point)], expected, 17), f"Saved Metal {label} differs from its palette")


def audit_trace(actions, rtl):
    by_route = dict(actions)
    require(len(actions) == 30 and [values for route, values in actions if route == "lower/end"] ==
            [[80, 80], [100, 100]], "Input route count or changing dependent End bounds changed")
    require([(route, values) for route, values in actions if route.startswith("accesskit/")] == ACCESSKIT,
            "Native AccessKit numeric writes did not preserve the opposite endpoint")
    required = {
        "lower/left" if rtl else "lower/right": [25, 80],
        "lower/end": [100, 100],
        "upper/home": [0, 0],
        "pointer/unlock-min": [0, 35],
        "pointer/unlock-max": [65, 100],
        "pointer/overlap-lower-grab": [50, 50],
        "pointer/overlap-lower": [35, 50],
        "pointer/overlap-upper-grab": [50, 50],
        "pointer/overlap-upper": [50, 65],
        "pointer/nearest-lower-track": [40, 80],
        "pointer/nearest-upper-track": [40, 65],
        "pointer/lower-clamped": [65, 65],
        "pointer/upper-clamped": [20, 20],
        "capture/reject-accesskit-takeover": [20, 80],
        "capture/touch-move": [40, 80],
        "capture/touch-cancel": [40, 80],
        "disabled/lower": [40, 80],
        "disabled/upper": [40, 80],
    }
    for route, wanted in required.items():
        require(by_route.get(route) == wanted, f"{route} control result changed")
    require(all(0 <= lo <= hi <= 100 and lo % 5 == hi % 5 == 0 for _, (lo, hi) in actions),
            "The controlled range violated order or step")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--profile", action="append", choices=RUN["PROFILES"])
    args = parser.parse_args()
    report = json.loads((args.folder / "report.json").read_text())
    expected = set(args.profile or RUN["PROFILES"])
    require(report["capture"] == "Surface Page.screenshot" and not report["errors"]
            and set(report["runs"]) == expected, "The native range fixture is incomplete")
    totals = Counter()
    paired = None
    for profile, (width, dark, rtl, scale) in RUN["PROFILES"].items():
        if profile not in expected:
            continue
        run = report["runs"][profile]
        require("Apple M1 Max" in run["adapter"] and "backend: Metal" in run["adapter"], "Expected native Metal")
        audit_trace(run["actions"], rtl)
        totals.update(input_routes=len(run["actions"]), accesskit_changes=len(ACCESSKIT))
        frames = [f for f in report["frames"] if f["file"].startswith(profile + "-")]
        shots = {f["stage"]: f for f in frames}
        require(len(frames) == len(shots) == len(STAGES) and set(shots) == set(STAGES), "Missing slider capture stage")
        for frame in frames:
            require((frame["width"], frame["height"]) == RUN["VIEWPORTS"][width]
                    and (frame["dark"], frame["rtl"], frame["text_scale"]) == (dark, rtl, scale),
                    "Renderer profile drifted")
            require(frame["pair"] == STAGES[frame["stage"]]
                    and frame["rendered_dp"] == {"title": 16. * scale, "value": 16. * scale},
                    "Value or actual CJK text sizing changed")
            verify_projection(frame)
            verify_pixels(args.folder, frame)
        require(shots["cancelled"]["pressed"] is None, "Touch cancellation left capture")
        totals["cli_pngs"] += len(frames)
        if run["mcp"]:
            paired = run["mcp"]
            require(paired["cli"] == shots["overlap"]["file"]
                    and read_png(args.folder, paired) == read_png(args.folder, shots["overlap"]),
                    "CLI and MCP did not return the same PNG")
    if "narrow-dark-rtl-2x" in expected:
        require(paired, "Missing CLI/MCP comparison")
    require(totals["cli_pngs"] == len(report["frames"]), "Unexpected captured artifacts")
    print(json.dumps({"renderer": "Apple M1 Max Metal", "profiles": len(expected),
                      **totals, "matching_mcp": paired}, indent=2))


if __name__ == "__main__":
    main()
