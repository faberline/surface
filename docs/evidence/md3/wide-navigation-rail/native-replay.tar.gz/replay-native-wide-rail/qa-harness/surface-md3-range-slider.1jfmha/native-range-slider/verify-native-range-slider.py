#!/usr/bin/env python3
"""Verify the Material two-thumb slider on native Metal, Winit and AccessKit."""

import argparse
import json
import math
from pathlib import Path
import re
import runpy
import subprocess


HERE = Path(__file__).resolve().parent
RADIO = runpy.run_path(str(HERE.parents[1] / "surface-md3-radio-baseline.lUZ3Z9"
                            / "native-radio-baseline" / "verify-native-radio.py"))
BASE, COMMON, MOTION = (RADIO[k] for k in ("BASE", "COMMON", "MOTION"))
capture, center, close, color_matches, contains, focus, key, node, paint_entries, pixels_for, rect, require, same_rect, write_json = (
    RADIO[k] for k in ("capture", "center", "close", "color_matches", "contains", "focus", "key", "node",
                       "paint_entries", "pixels_for", "rect", "require", "same_rect", "write_json")
)
PROFILES = RADIO["PROFILES"]
VIEWPORTS = {"wide": (960, 800), "narrow": (320, 640)}
SECTION = "section-0"
CARD, DIRECTION, SCALE, OVERLAP, PRICE, DISABLED, VALUE, TITLE = (
    f"range-slider-{suffix}" for suffix in ("card", "direction", "scale", "overlap", "price", "disabled", "value", "title")
)
LOW, HIGH = (f"{PRICE}-{bound}" for bound in ("lower", "upper"))
DEFAULT = (20, 80)
PARTS = ("lower", "upper")
TRACKS = ("left-track", "active-track", "right-track")
NAMES = {"lower": "最低價格", "upper": "最高價格"}


def state(case, expected):
    snapshot = case.snapshot()
    value = node(snapshot, VALUE)["text"]
    got = re.search(r"最低 (\d+)，最高 (\d+)", value)
    require(got and tuple(map(int, got.groups())) == expected, f"Expected {expected}, received {value!r}")
    return snapshot


def logical_x(rail, value, rtl):
    fraction = (100 - value if rtl else value) / 100.
    return rail["x"] + rail["width"] * fraction


def within_pixel(value, expected, subject):
    require(abs(value - expected) <= 1.05, f"{subject}: observed {value}, expected {expected}")


def geometry(snapshot, group, values, rtl):
    box = rect(snapshot, group)
    rail = rect(snapshot, group + "-rail")
    close(box["height"], 48., "Group height")
    close(rail["height"], 48., "Interactive rail height")
    close(rail["x"], box["x"] + 24., "Rail start inset")
    close(rail["width"], box["width"] - 48., "Rail reserves both thumb halves")
    thumbs = {}
    for part, value in zip(PARTS, values):
        id = f"{group}-{part}"
        target = rect(snapshot, id)
        handle = rect(snapshot, id + "-handle")
        require((target["width"], target["height"], handle["width"], handle["height"]) == (48., 48., 4., 44.)
                and contains(box, target) and contains(target, handle), "Target or visual handle geometry drifted")
        within_pixel(center(target)[0], logical_x(rail, value, rtl), f"{part} logical position")
        close(center(target)[1], center(rail)[1], "Rail vertical center")
        for x, y in zip(center(handle), center(target)):
            close(x, y, "Handle centered in full 48 dp target")
        thumbs[part] = {"target": target, "handle": handle}
    a, b = sorted(center(info["handle"])[0] for info in thumbs.values())
    end = rail["x"] + rail["width"]
    limits = ((rail["x"], a - 8.), (a + 8., b - 8.), (b + 8., end))
    segments = {}
    for suffix, (start, finish) in zip(TRACKS, limits):
        track = rect(snapshot, f"{group}-{suffix}")
        close(track["height"], 16., f"{suffix} height")
        close(center(track)[1], center(rail)[1], f"{suffix} centerline")
        within_pixel(track["x"], start, f"{suffix} physical start")
        within_pixel(track["width"], max(0., finish - start), f"{suffix} painted width")
        segments[suffix] = track
    return {"group": box, "rail": rail, "thumbs": thumbs, "segments": segments}


def projection(snapshot, receipt, group, boxes, values, disabled):
    tree = receipt["accesskit"]
    data = tree["nodes"]
    named = data[group]
    desired_name = "停用的價格範圍" if disabled else "價格範圍"
    require(named["name"] == desired_name and named["role"] in ("Group", "GenericContainer")
            and not named["focusable"] and not named["set_value"], "Named range group projection changed")
    _, ids = COMMON["dom_index"](snapshot)
    layout = snapshot["layout"]["nodes"]
    focuses = snapshot["interaction"]["focused"]
    out = {}
    for part, (minimum, value, maximum) in zip(PARTS, ((0, *values), (*values, 100))):
        id = f"{group}-{part}"
        thumb = data[id]
        can_adjust = not disabled and minimum < maximum
        require(thumb["role"] == "Slider" and thumb["name"] == NAMES[part]
                and (thumb["minimum"], thumb["number"], thumb["maximum"], thumb["step"]) == (minimum, value, maximum, 5)
                and thumb["focusable"] is not disabled and thumb["disabled"] is disabled
                and thumb["focused"] is (focuses == id) and not thumb["press"] and not thumb["child_roles"],
                f"{id}: name, range, focus or disabled projection differs: {thumb}")
        require(all(thumb[action] is can_adjust for action in ("set_value", "increment", "decrement")),
                f"{id}: range capability bypassed locked or disabled state")
        bounds = RADIO["intersection"](boxes["thumbs"][part]["target"], layout[ids[id]]["clip"])
        for actual, point in zip(thumb["bounds"], bounds):
            close(actual, point * tree["scale"], "Projected thumb bounds")
        out[part] = thumb
    for suffix in ("lower-handle", "upper-handle", *TRACKS):
        require(f"{group}-{suffix}" not in data, "Visual-only range art reached AccessKit")
    return out


def screen_point(x, y):
    return (math.floor(x), math.floor(y))


def group_paint(frame, receipt, boxes, native, palette, disabled, backing):
    fills = paint_entries(receipt, ("Quad", "Shape"))
    ink = palette["on_surface"]
    active, inactive = (ink[:3] + [97], ink[:3] + [31]) if disabled else (
        palette["primary"], palette["secondary_container"]
    )
    probes = []
    cy = center(boxes["rail"])[1]
    for part, info in boxes["thumbs"].items():
        handle = info["handle"]
        cx, _ = center(handle)
        require(any(same_rect(fill["rect"], handle) and fill["color"] == active for fill in fills),
                "Missing native handle paint")
        for y in (cy - 12., cy, cy + 12.):
            probes.append((screen_point(cx, y), RADIO["blend"](backing, active), "4×44 handle"))
        for x in (cx - 4., cx + 4.):
            other = boxes["thumbs"]["upper" if part == "lower" else "lower"]["handle"]
            if not other["x"] - .6 < x < other["x"] + other["width"] + .6:
                probes.append((screen_point(x, cy), backing, "6 dp gap"))
        if native[part]["focused"]:
            edges = BASE["focus_edges"](info["target"])
            for edge in edges.values():
                require(any(same_rect(fill["rect"], edge) and fill["color"] == palette["secondary"] for fill in fills),
                        "Native Secondary focus must cover the 48 dp target")
                probes.append((screen_point(*center(edge)), palette["secondary"], "focus edge"))
    for suffix, box in boxes["segments"].items():
        is_active = suffix == "active-track"
        token = active if is_active else inactive
        paint = [entry for entry in fills if same_rect(entry["rect"], box) and entry["color"] == token]
        if box["width"] == 0.:
            require(not paint, f"Empty {suffix} painted over the handle gap")
            continue
        require(len(paint) == 1, f"{suffix} Material track paint missing")
        if box["width"] > 16.:
            x, y = center(box)
            probes.append((screen_point(x, y), RADIO["blend"](backing, token), "16 dp track"))
            if not is_active:
                stop_x = box["x"] + 8. if suffix == "left-track" else box["x"] + box["width"] - 8.
                painted = RADIO["blend"](RADIO["blend"](backing, inactive), active)
                probes.append((screen_point(stop_x, cy), painted, "4 dp stop"))
    return probes


def font_size(snapshot, receipt, id, scale):
    box = rect(snapshot, id)
    name = node(snapshot, id)["text"]
    painted = [op for op in paint_entries(receipt, ("Text", "StyledText"))
               if same_rect(op["rect"], box) and op["text"] == name]
    require(len(painted) == 1, f"Named Chinese label not painted: {name}")
    op = painted[0]
    size = op["font_size"] if "font_size" in op else op["style"]["font_size"]
    close(size, 16. * scale, "Actual rendered CJK font size in dp")
    return box, size, op["color"]


def take(case, tag, rtl, scale, values):
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{tag}",
                              case.size, case.dark, SECTION)
    require(not frame["errors"], str(frame["errors"]))
    state(case, values)
    receipt = json.loads(case.receipt.read_text())
    palette = case.plan.palette["dark" if case.dark else "light"]
    card = rect(snapshot, CARD)
    fills = paint_entries(receipt, ("Quad", "Shape"))
    backing = [op["color"] for op in fills if same_rect(op["rect"], card)]
    require(len(backing) == 1 and backing[0][3] == 255, "Missing opaque card backing")
    projected = {}
    probes = []
    for group in (PRICE, DISABLED):
        disabled = group == DISABLED
        numbers = DEFAULT if disabled else values
        boxes = geometry(snapshot, group, numbers, rtl)
        native = projection(snapshot, receipt, group, boxes, numbers, disabled)
        probes.extend(group_paint(frame, receipt, boxes, native, palette, disabled, backing[0]))
        projected[group] = {"geometry": boxes, "accesskit": native}

    title_box, title_size, title_color = font_size(snapshot, receipt, TITLE, scale)
    value_box, value_size, value_color = font_size(snapshot, receipt, VALUE, scale)
    sample = RADIO["sample_points"]
    text = [(sample(box), ink) for box, ink in ((title_box, title_color), (value_box, value_color))]
    coordinates = {p for p, _, _ in probes} | set().union(*(points for points, _ in text))
    pixels = pixels_for(case.plan.artifacts / frame["file"], frame, coordinates)
    for p, expected, label in probes:
        require(color_matches(pixels[p], expected, 17), f"Metal {label} at {p} is {pixels[p]}, expected {expected}")
    require(all(sum(color_matches(pixels[p], ink, 22) for p in points) >= 10 for points, ink in text),
            "Missing enlarged Chinese title or value texture")
    frame.update(stage=tag, rtl=rtl, text_scale=scale, pair=values, groups=projected,
                 rendered_dp={"title": title_size, "value": value_size}, probes=probes,
                 focused=snapshot["interaction"]["focused"], pressed=snapshot["interaction"]["pressed"])
    case.frames.append(frame)
    return frame


def pointer(case, event, rail, value, rtl, offset=0.):
    case.point(event, (logical_x(rail, value, rtl) + offset, center(rail)[1]))


def preset(case, old, expected):
    if old == expected:
        return
    first = DEFAULT if old[0] == old[1] else (50, 50)
    case.call("action", "activate", OVERLAP)
    state(case, first)
    if expected != first:
        case.call("action", "activate", OVERLAP)
        state(case, expected)


def press(case, at, expected):
    case.point("down", at)
    interaction = case.snapshot()["interaction"]
    require(interaction["focused"] == expected and interaction["pressed"] == expected,
            f"Expected native ownership {expected}, observed {interaction}")


def ax(case, action, id, value=None, capture_blocked=False):
    args = ("action", "qa-ax-" + action, id)
    if value is not None:
        args += (str(value),)
    if capture_blocked:
        result = subprocess.run((case.plan.client, "--session", case.session, *args), check=False,
                                timeout=12, capture_output=True, text=True)
        require(result.returncode == 1 and "AccessKit rejected action" in result.stderr,
                "An accessibility request took over the active native pointer")
    else:
        reply = case.call(*args)
        require(reply["accesskit"], "Native numeric AccessKit request did not dispatch")


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2:
        case.call("action", "activate", SCALE)
    case.point("leave")
    RADIO["reveal"](case, CARD)
    start = take(case, "default", rtl, scale, DEFAULT)
    rail = start["groups"][PRICE]["geometry"]["rail"]
    at = lambda n, delta=0.: (logical_x(rail, n, rtl) + delta, center(rail)[1])
    actions = []

    def verify(route, values):
        state(case, values)
        actions.append((route, values))

    def edit(command, id, values):
        key(case, command, id)
        verify(f"{id.removeprefix(PRICE + '-')}/{command}", values)

    focus(case, OVERLAP)
    key(case, "tab", LOW)
    edit("left" if rtl else "right", LOW, (25, 80))
    take(case, "keyboard-focused", rtl, scale, (25, 80))
    edit("end", LOW, (80, 80))
    edit("home", LOW, (0, 80))
    edit("page-up", LOW, (10, 80))
    edit("down", LOW, (5, 80))
    edit("page-down", LOW, (0, 80))
    key(case, "tab", HIGH)
    edit("home", HIGH, (0, 0))
    focus(case, LOW)
    edit("up", LOW, (0, 0))
    take(case, "locked-min", rtl, scale, (0, 0))
    BASE["reject"](case, "increment", LOW, "no live AccessKit range action")
    press(case, at(0), HIGH)
    pointer(case, "move", rail, 35, rtl)
    pointer(case, "up", rail, 35, rtl)
    verify("pointer/unlock-min", (0, 35))
    edit("end", HIGH, (0, 100))
    focus(case, LOW)
    edit("end", LOW, (100, 100))
    focus(case, HIGH)
    edit("down", HIGH, (100, 100))
    take(case, "locked-max", rtl, scale, (100, 100))
    BASE["reject"](case, "decrement", HIGH, "no live AccessKit range action")
    press(case, at(100), LOW)
    pointer(case, "move", rail, 65, rtl)
    pointer(case, "up", rail, 65, rtl)
    verify("pointer/unlock-max", (65, 100))

    preset(case, (65, 100), (50, 50))
    key(case, "tab", LOW)
    key(case, "tab", HIGH)
    press(case, at(50), HIGH)
    overlap = take(case, "overlap", rtl, scale, (50, 50))
    mcp = None
    if case.prefix == "narrow-dark-rtl-2x":
        mirror = MOTION["MOTION"]["check_mcp"](case.plan, case.plan.client, case.session, case.size)
        a, b = (case.plan.artifacts / f["file"] for f in (overlap, mirror))
        require(a.read_bytes() == b.read_bytes(), "CLI and MCP returned different overlap PNGs")
        mcp = {**mirror, "cli": overlap["file"]}
    case.point("up", at(50))
    axis = -1. if rtl else 1.
    press(case, at(50, -8. * axis), LOW)
    verify("pointer/overlap-lower-grab", (50, 50))
    case.point("move", at(35, -8. * axis))
    case.point("up", at(35, -8. * axis))
    verify("pointer/overlap-lower", (35, 50))
    preset(case, (35, 50), (50, 50))
    press(case, at(50, 8. * axis), HIGH)
    verify("pointer/overlap-upper-grab", (50, 50))
    case.point("move", at(65, 8. * axis))
    case.point("up", at(65, 8. * axis))
    verify("pointer/overlap-upper", (50, 65))

    preset(case, (50, 65), DEFAULT)
    press(case, at(40), LOW)
    case.point("up", at(40))
    verify("pointer/nearest-lower-track", (40, 80))
    press(case, at(65), HIGH)
    case.point("up", at(65))
    verify("pointer/nearest-upper-track", (40, 65))
    press(case, at(40), LOW)
    case.point("move", at(90))
    case.point("up", at(90))
    verify("pointer/lower-clamped", (65, 65))
    take(case, "no-cross", rtl, scale, (65, 65))
    preset(case, (65, 65), DEFAULT)
    press(case, at(80), HIGH)
    case.point("move", at(5))
    case.point("up", at(5))
    verify("pointer/upper-clamped", (20, 20))

    preset(case, (20, 20), DEFAULT)
    before = case.snapshot()["interaction"]["focused"]
    for action, id, value, expected in (
        ("set", LOW, 38, (40, 80)), ("decrement", HIGH, None, (40, 75)),
        ("increment", LOW, None, (45, 75)), ("set", HIGH, 42, (45, 45)),
    ):
        ax(case, action, id, value)
        verify(f"accesskit/{action}/{id.removeprefix(PRICE + '-')}", expected)
        require(case.snapshot()["interaction"]["focused"] == before, "Native numeric AX action stole focus")
    take(case, "accesskit-adjusted", rtl, scale, (45, 45))

    preset(case, (45, 45), DEFAULT)
    case.point("touch-start", at(20))
    require(case.snapshot()["interaction"]["pressed"] == LOW, "Touch did not own the lower thumb")
    ax(case, "increment", HIGH, capture_blocked=True)
    verify("capture/reject-accesskit-takeover", DEFAULT)
    case.point("touch-move", at(40))
    verify("capture/touch-move", (40, 80))
    case.point("touch-cancel", at(40))
    case.point("touch-move", at(65))
    case.point("touch-end", at(65))
    verify("capture/touch-cancel", (40, 80))
    require(case.snapshot()["interaction"]["pressed"] is None, "Cancelled native touch left capture")
    take(case, "cancelled", rtl, scale, (40, 80))

    for part in PARTS:
        id = f"{DISABLED}-{part}"
        laid = rect(case.snapshot(), id)
        down_at = center(laid)
        case.point("down", down_at)
        require(case.snapshot()["interaction"]["pressed"] is None, "Disabled thumb took capture")
        case.point("up", down_at)
        BASE["reject"](case, "increment", id, "no live AccessKit range action")
        verify("disabled/" + part, (40, 80))
    return {"actions": actions, "mcp": mcp}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile", action="append", choices=PROFILES)
    parser.add_argument("--startup-timeout", default=45, type=int)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "runs": {}, "frames": [], "errors": []}
    for name, (size, dark, rtl, scale) in PROFILES.items():
        if plan.profile and name not in plan.profile:
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, VIEWPORTS[size], dark) as case:
                done = journey(case, rtl, scale)
            log = (plan.artifacts / f"{name}.log").read_text()
            adapter = next((line for line in log.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in adapter and "backend: Metal" in adapter, "Expected native Apple Metal")
            report["runs"][name] = {**done, "adapter": adapter}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(report["errors"][-1], flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(report["runs"] and not report["errors"], "\n".join(report["errors"]) or "No matching profile")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
