"""Inspect current-page attributes on the private AppKit process."""

import ctypes
from pathlib import Path
import runpy


workspace = Path(__file__).resolve().parents[2]
RAIL = runpy.run_path(str(workspace / "surface-md3-navigation-rail.2Vp8O5Jj/native-navigation-rail/read-navigation-rail-ax.py"))
AX, actions, ax_bool, elements, equal, press = (
    RAIL[name] for name in ("AX", "actions", "ax_bool", "elements", "equal", "press")
)
copy_attribute_names = AX["bind"](AX["APP_SERVICES"], "AXUIElementCopyAttributeNames", AX["STATUS"],
                                  AX["PTR"], ctypes.POINTER(AX["PTR"]))


def attributes(element):
    values = AX["PTR"]()
    status = copy_attribute_names(element, ctypes.byref(values))
    if status != 0 or not values:
        return []
    try:
        result = []
        for index in range(AX["array_count"](values)):
            value = AX["array_item"](values, index)
            text = ctypes.create_string_buffer(512)
            if AX["string_read"](value, text, len(text), AX["UTF8"]):
                result.append(text.value.decode())
        return result
    finally:
        AX["release"](values)


def inspect(pid, names, activate=None):
    if not AX["trusted"]():
        return {"trusted": False, "buttons": []}
    app = AX["create_application"](pid)
    AX["set_timeout"](app, 1.)
    _, focus = AX["ax_attribute"](app, "AXFocusedUIElement")
    reply = {"trusted": True, "buttons": []}
    visited = 0

    def walk(element, depth=0):
        nonlocal visited
        visited += 1
        if visited > 2000 or depth > 32:
            raise RuntimeError("Private Gallery AX tree exceeded the probe budget")
        attr = AX["scalar"]
        role = attr(element, "AXRole")
        title = attr(element, "AXTitle")
        labels = [title, attr(element, "AXDescription"), attr(element, "AXLabel")]
        name = next((label for label in labels if label in names), None)
        if name and role == "AXButton":
            current = attr(element, "AXARIACurrent")
            button = {
                "name": name, "role": role, "title": title, "subrole": attr(element, "AXSubrole"),
                "current": current, "lists_current": "AXARIACurrent" in attributes(element),
                "actions": actions(element), "enabled": ax_bool(element, "AXEnabled"),
                "focused": bool(focus and equal(element, focus)), "focus_attr": ax_bool(element, "AXFocused"),
            }
            reply["buttons"].append(button)
            if activate == name and "AXPress" in button["actions"] and "press_status" not in reply:
                reply["press_status"] = press(element)
        for child in elements(element, "AXChildren"):
            walk(child, depth + 1)

    try:
        for window in elements(app, "AXWindows"):
            walk(window)
    finally:
        if focus:
            AX["release"](focus)
        AX["release"](app)
    return reply
