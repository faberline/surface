#!/usr/bin/env python3
"""Capture native before/after Material FAB glyphs and verify vector composition."""

import argparse
import json
import math
from pathlib import Path
import runpy
import subprocess
import time


HERE = Path(__file__).resolve().parent
BASELINE = HERE.parents[1] / "surface-md3-fab-visibility.BjJR3c" / "native-visibility"
SCROLL = runpy.run_path(str(BASELINE / "verify-native-fab-visibility.py"))
COMMON, MOTION, BASE = SCROLL["COMMON"], SCROLL["MOTION"], SCROLL["BASE"]
require, close, geometry = SCROLL["require"], SCROLL["close"], SCROLL["geometry"]
capture, png_pixels = MOTION["capture"], MOTION["png_pixels"]
write_json = MOTION["write_json"]

VIEWPORTS, SIZES, IDS = COMMON["VIEWPORTS"], COMMON["SIZES"], COMMON["IDS"]
SECTION, CARD = COMMON["SECTION"], COMMON["CARD"]
STANDARD, DISABLED = IDS["standard"][0], IDS["disabled"][0]
OUTLINE = [(3, 2), (15, 2), (21, 8), (21, 22), (3, 22)]
CUTOUT = [(5, 4), (14, 4), (19, 9), (19, 20), (5, 20)]
ADD = [(8, 11), (11, 11), (11, 8), (13, 8), (13, 11), (16, 11),
       (16, 13), (13, 13), (13, 16), (11, 16), (11, 13), (8, 13)]
SAMPLES = {"rim": (4, 14), "plus": (12, 12), "hole": (7, 17), "corner": (20, 3)}


def capture_case(case, name):
    captured, snapshot = capture(case.plan, case.plan.client, case.session,
                                 f"{case.prefix}-{name}", case.size, case.dark, SECTION)
    require(not captured["errors"], str(captured["errors"]))
    receipt = json.loads(case.receipt.read_text())
    return captured, snapshot, receipt


def reveal(case, stable):
    for _ in range(10):
        snapshot = case.snapshot()
        _, _, bounds, clipped = geometry(snapshot, stable)
        if clipped == bounds and bounds["y"] >= 3. and bounds["y"] + bounds["height"] <= case.size[1] - 3.:
            return
        expected = (case.size[1] - bounds["height"]) / 2.
        case.point("scroll", (12., case.size[1] / 2.), bounds["y"] - expected)
    raise RuntimeError(f"Cannot reveal {stable}: {bounds}, clip {clipped}")


def color_delta(left, right):
    return max(abs(a - b) for a, b in zip(left[:3], right[:3]))


def face_and_icon(snapshot, stable):
    nodes, ids, touch, clipped = geometry(snapshot, stable)
    button_id = ids[stable]
    button = nodes[button_id]
    face_id = button["first_child"]
    icon_id = nodes[face_id]["first_child"]
    face = snapshot["layout"]["nodes"][face_id]["bounds"]
    icon = snapshot["layout"]["nodes"][icon_id]["bounds"]
    base_fill = nodes[face_id]["style"]["background"]
    if base_fill[3] == 0:
        base_fill = button["style"]["background"]
    require(touch == clipped, f"{stable}: FAB is clipped")
    return nodes, ids, button, icon_id, icon, touch, face, base_fill


def ops_for(receipt, snapshot, stable):
    nodes, ids = COMMON["dom_index"](snapshot)
    owned = {ids[stable], *BASE["descendants"](nodes, ids[stable])}
    ops = [entry["op"] for entry in receipt["attributed"]["ops"] if entry["owner"]["node"] in owned]
    presented = receipt["presented"]["ops"]
    for op in ops:
        if "FillPath" in op or "Layer" in op:
            require(op in presented, f"{stable}: attributed vector or layer did not reach native paint")
    return ops


def inspect_path(ops, icon, expected_ink=None, grouped=False):
    layers = [op["Layer"] for op in ops if "Layer" in op]
    require(len(layers) == int(grouped), f"Vector FAB has {len(layers)} compositor layers")
    layer = layers[0] if grouped else None
    effective = layer["ops"] if layer else ops
    fills = [op["FillPath"] for op in effective if "FillPath" in op]
    require(len(fills) == 1, "FAB must use one even-odd contour for the whole icon")
    require(not any("Text" in op.get("Legacy", {}) for op in effective),
            "Vector FAB has a text paint operation")
    contour = fills[0]["contour"]
    origin = icon["x"], icon["y"]
    factor = 24. / icon["width"]
    for key in ("x", "y", "width", "height"):
        require(math.isclose(fills[0]["clip"][key], icon[key], abs_tol=.03),
                f"Vector viewport clip differs from its reserved {key}")
    normalized = {tuple(round((v - o) * factor, 1) for v, o in zip(p, origin))
                  for p in contour["points"]}
    require(normalized == set(OUTLINE + CUTOUT + ADD), f"Unexpected icon path vertices {normalized}")
    if expected_ink is not None:
        require(contour["color"] == expected_ink, f"Icon paint tint is {contour['color']}, expected {expected_ink}")
    require(contour["color"][3] == 255, "Icon paint has unexpected alpha")
    return contour, layer


def point_in_pixel(icon, sample, layer=None):
    coords = [icon["x"] + sample[0] * icon["width"] / 24.,
              icon["y"] + sample[1] * icon["height"] / 24.]
    if layer:
        coords = [origin + (value - origin) * layer["scale"]
                  for value, origin in zip(coords, layer["origin"])]
    return tuple(math.floor(value) for value in coords)


def read_samples(case, frame, icon, layer=None):
    positions = {name: point_in_pixel(icon, sample, layer) for name, sample in SAMPLES.items()}
    decoded = png_pixels(case.plan.artifacts / frame["file"], frame, positions.values())
    return {name: {"point": point, "rgba": decoded[point]} for name, point in positions.items()}


def assert_rest_pixels(samples, tint, fill, label):
    for name in ("rim", "plus", "hole", "corner"):
        measured = samples[name]["rgba"]
        expected = tint if name in ("rim", "plus") else fill
        require(color_delta(measured, expected) <= 5,
                f"{label} {name} at {samples[name]['point']}: {measured} differs from {expected}")


def baseline_frame(case, variant, profile):
    stable, label, _, _ = IDS[profile]
    captured, snapshot, receipt = capture_case(case, f"{variant}-{profile}")
    nodes, _, button, icon_id, icon, touch, face, fill = face_and_icon(snapshot, stable)
    require(button["role"] == "Button" and button["name"] == label, f"{stable}: wrong baseline behavior")
    glyph = nodes[icon_id]
    require(glyph["text"] == "+" and glyph["style"]["font_size"] == SIZES[variant][1],
            "Baseline binary does not use the preceding text FAB")
    ink = glyph["style"]["foreground"]
    require(not any("FillPath" in op for op in ops_for(receipt, snapshot, stable)),
            "Baseline contains an unexpected vector fill")
    captured.update(variant=variant, profile=profile, touch=touch, face=face, icon=icon,
                    tint=ink, fill=fill, text=glyph["text"])
    case.frames.append(captured)


def vector_frame(case, variant, profile, expected):
    stable, label, _, _ = IDS[profile]
    captured, snapshot, receipt = capture_case(case, f"{variant}-{profile}")
    nodes, _, button, icon_id, icon, touch, face, fill = face_and_icon(snapshot, stable)
    disabled = profile == "disabled"
    require(button["role"] == "Button" and button["name"] == label and button["disabled"] is disabled,
            f"{stable}: lost role, name or disabled state")
    projected = receipt["projected"][stable]
    require(projected["press"] is not disabled and projected["focusable"] is not disabled,
            f"{stable}: wrong native AX input availability")
    logical_face, logical_icon = SIZES[variant]
    for axis in ("width", "height"):
        close(touch[axis], max(48., logical_face), f"{stable}: touch {axis}")
        close(face[axis], logical_face, f"{stable}: face {axis}")
        close(icon[axis], logical_icon, f"{stable}: icon {axis}")
        close(touch[axis], expected["touch"][axis], f"{stable}: baseline touch {axis}")
        close(face[axis], expected["face"][axis], f"{stable}: baseline face {axis}")
    for actual, outer in zip(COMMON["center"](icon), COMMON["center"](touch)):
        close(actual, outer, f"{stable}: vector icon center")
    require(nodes[icon_id]["name"] == "" and nodes[icon_id]["text"] is None,
            f"{stable}: vector decoration gained a semantic label")
    require(fill == expected["fill"], f"{stable}: button face color changed")
    ops = ops_for(receipt, snapshot, stable)
    contour, _ = inspect_path(ops, icon, expected["tint"])
    samples = read_samples(case, captured, icon)
    assert_rest_pixels(samples, contour["color"], fill, captured["file"])
    sidecar = f"{case.prefix}-{variant}-{profile}.presentation.json"
    write_json(case.plan.artifacts / sidecar, {"icon": icon, "ops": ops, "accessibility": projected})
    captured.update(variant=variant, profile=profile, touch=touch, face=face, icon=icon,
                    tint=contour["color"], fill=fill, samples=samples, presentation=sidecar,
                    before=expected["file"])
    case.frames.append(captured)
    return captured


def verify_hit_area(case):
    case.select("small")
    reveal(case, STANDARD)
    snapshot = case.snapshot()
    nodes, ids, _, _, _, touch, face, _ = face_and_icon(snapshot, STANDARD)
    before = COMMON["actions"](nodes, ids[CARD])
    point = (touch["x"] + 1.5, COMMON["center"](touch)[1])
    require(point[0] < face["x"], "Small tap must be in the gap between the touch and paint bounds")
    case.point("down", point)
    case.point("up", point)
    nodes, ids = COMMON["dom_index"](case.snapshot())
    after = COMMON["actions"](nodes, ids[CARD])
    require(after == before + 1, "Small vector FAB lost its 48 dp outer hit band")
    return {"point": point, "actions": [before, after]}


def disabled_check(case):
    reveal(case, DISABLED)
    snapshot = case.snapshot()
    nodes, ids, _, _, _, touch, _, _ = face_and_icon(snapshot, DISABLED)
    before = COMMON["actions"](nodes, ids[CARD])
    center = COMMON["center"](touch)
    case.point("down", center)
    case.point("up", center)
    nodes, ids = COMMON["dom_index"](case.snapshot())
    after = COMMON["actions"](nodes, ids[CARD])
    require(after == before, "Disabled vector FAB activated")
    return [before, after]


def ordinary(case, view, theme, baseline=None):
    receipts = {}
    for size in SIZES:
        case.select(size)
        for profile in IDS:
            if baseline is None and profile not in ("standard", "disabled"):
                continue
            reveal(case, IDS[profile][0])
            if baseline is None:
                baseline_frame(case, size, profile)
            else:
                key = profile if profile in ("standard", "disabled") else "standard"
                reference = baseline[(view, theme, size, key)]
                measured = vector_frame(case, size, profile, reference)
                if (view, theme, size, profile) == ("narrow", "dark", "large", "standard"):
                    mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
                    require(mcp["sha256"] == measured["sha256"], "Vector CLI and MCP PNG bytes differ")
                    receipts["mcp"] = {**mcp, "cli": measured["file"]}
    if baseline is not None:
        receipts.update(small_hit=verify_hit_area(case), disabled_inert=disabled_check(case))
    return receipts


def verify_ax(case):
    case.select("small")
    reveal(case, STANDARD)
    active = MOTION["make_active"](case.plan.probe, case.child)
    case.call("action", "qa-ax-focus", STANDARD)
    frame, snapshot, receipt = capture_case(case, "visible")
    nodes, ids, _, _, icon, touch, _, _ = face_and_icon(snapshot, STANDARD)
    inspect_path(ops_for(receipt, snapshot, STANDARD), icon)
    before = COMMON["actions"](nodes, ids[CARD])
    require(receipt["projected"][STANDARD]["focused"], "Vector FAB lost keyboard focus")
    for _ in range(10):
        observed = BASE["query_ax"](case.plan.probe, case.child, IDS["standard"][1])
        candidates = [node for node in observed["matches"] if node["role"] == "AXButton"]
        if observed["active"] and len(candidates) == 1 and candidates[0]["focused"]:
            break
        time.sleep(.1)
    else:
        raise RuntimeError(f"No focused vector FAB in AppKit: {observed}")
    target = candidates[0]
    require(target["enabled"] and "AXPress" in target["actions"], "Enabled vector FAB lacks AXPress")
    for axis in ("width", "height"):
        close(touch[axis], 48., f"Small touch {axis}")
        close(target["size"][axis], 48., f"Small AppKit {axis}")
    pressed = BASE["query_ax"](case.plan.probe, case.child, IDS["standard"][1], "--press")
    require(pressed.get("pressStatus") == 0, f"AppKit AXPress failed: {pressed}")
    for _ in range(9):
        nodes, ids = COMMON["dom_index"](case.snapshot())
        after = COMMON["actions"](nodes, ids[CARD])
        if after == before + 1:
            break
        time.sleep(.1)
    else:
        raise RuntimeError("AppKit AXPress did not invoke the vector FAB")
    reveal(case, DISABLED)
    unavailable = BASE["query_ax"](case.plan.probe, case.child, IDS["disabled"][1])
    require(any(item["role"] == "AXButton" and not item["enabled"] and "AXPress" not in item["actions"]
                for item in unavailable["matches"]), f"Disabled vector FAB exposed AXPress: {unavailable}")
    require(disabled_check(case) == [after, after], "Disabled pointer changed the action counter")
    case.frames.append(frame)
    return {"active": active, "standard": observed, "pressed": pressed, "disabled": unavailable,
            "action_count": [before, after]}


def fade_frame(case, name, available, pose, offset):
    frame = SCROLL["take"](case, name, available, pose=pose, focused=SCROLL["SCROLLER"], offset=offset)
    stable = SCROLL["ACTION"]
    snapshot = case.snapshot()
    _, _, _, _, icon, _, _, fill = face_and_icon(snapshot, stable)
    receipt = json.loads(case.receipt.read_text())
    ops = ops_for(receipt, snapshot, stable)
    frame.update(icon=icon, fill=fill)
    if pose == "hidden":
        require(not ops, f"{name}: hidden vector emitted paint")
        return frame
    path, layer = inspect_path(ops, icon, grouped=pose == "motion")
    frame["tint"] = path["color"]
    frame["samples"] = read_samples(case, frame, icon, layer["layer"] if layer else None)
    return frame


def expand_colors(foreground, background, opacity):
    blend = MOTION["BASELINE"]["COMMON"]["rgb_over"]
    return blend([*foreground[:3], round(255. * opacity)], background)


def verify_fade_pixels(case, frame, hidden, resting):
    require(frame["scroll"]["offset"] == hidden["scroll"]["offset"], "Fading sample has a different backdrop offset")
    require(frame["tint"] == resting["tint"] and frame["fill"] == resting["fill"],
            "An isolated layer changed the source tint or fill")
    opacity = frame["layer"]["opacity"]
    coords = [tuple(sample["point"]) for sample in frame["samples"].values()]
    underlying = png_pixels(case.plan.artifacts / hidden["file"], hidden, coords)
    observations = {}
    for name, sample in frame["samples"].items():
        background = underlying[tuple(sample["point"])]
        rendered = sample["rgba"]
        face_colors = expand_colors(frame["fill"], background, opacity)
        face_distance = min(color_delta(rendered, color) for color in face_colors)
        if name in ("hole", "corner"):
            require(face_distance <= 7, f"{frame['file']} {name} lost negative space: {rendered}, {face_colors}")
        else:
            ink_colors = expand_colors(frame["tint"], background, opacity)
            candidates = [tuple(round(f + (g - f) * coverage / 10.) for f, g in zip(face, ink))
                          for face, ink in zip(face_colors, ink_colors) for coverage in range(3, 11)]
            require(face_distance >= 5 and min(color_delta(rendered, color) for color in candidates) <= 7,
                    f"{frame['file']} {name} lost the composited vector tint: {rendered}, {face_colors}, {ink_colors}")
        observations[name] = {"backdrop": background, "face_delta": face_distance}
    return observations


def fading(case):
    SCROLL["reveal"](case)
    case.call("action", "qa-ax-focus", SCROLL["SCROLLER"])
    shown = fade_frame(case, "visible", True, None, 0.)
    assert_rest_pixels(shown["samples"], shown["tint"], shown["fill"], shown["file"])
    SCROLL["scroll"](case, 44.)
    case.clock.advance(1200)
    hidden44 = fade_frame(case, "hidden-reference-44", False, "hidden", 44.)
    SCROLL["scroll"](case, -44.)
    case.clock.advance(1200)
    SCROLL["scroll"](case, 76.)
    case.clock.advance(24)
    hide24 = fade_frame(case, "hide-024", False, "motion", 76.)
    case.clock.advance(18)
    hide42 = fade_frame(case, "hide-042", False, "motion", 76.)
    case.clock.advance(1200)
    hidden76 = fade_frame(case, "hidden", False, "hidden", 76.)
    SCROLL["scroll"](case, -32.)
    case.clock.advance(42)
    show42 = fade_frame(case, "show-042", False, "motion", 44.)
    case.clock.advance(1200)
    settled = fade_frame(case, "settled", True, None, 44.)
    assert_rest_pixels(settled["samples"], settled["tint"], settled["fill"], settled["file"])
    for shot, reference in ((hide24, hidden76), (hide42, hidden76), (show42, hidden44)):
        shot["composition"] = verify_fade_pixels(case, shot, reference, shown)
    return {"retains_hole": True, "retains_rim_and_plus": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--before-report", type=Path)
    parser.add_argument("--probe", type=Path)
    parser.add_argument("--viewport", choices=VIEWPORTS)
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--case", choices=("before", "after", "fade", "ax"), required=True)
    parser.add_argument("--startup-timeout", type=int, default=180)
    plan = parser.parse_args()
    if plan.case == "after" and not plan.before_report:
        parser.error("after requires a before report")
    if plan.case == "ax" and not plan.probe:
        parser.error("ax requires the AppKit probe")
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    before = None
    if plan.before_report:
        prior = json.loads(plan.before_report.read_text())
        require(not prior["errors"], "Baseline verification must pass")
        before = {(f["view"], f["theme"], f["variant"], f["profile"]): f for f in prior["frames"]}
    report = {"capture": "Surface Page.screenshot", "frames": [], "runs": {}, "errors": []}
    for view, size in VIEWPORTS.items():
        if plan.viewport not in (None, view):
            continue
        for theme in ("light", "dark"):
            if plan.theme not in (None, theme):
                continue
            prefix = f"{view}-{theme}-{plan.case}"
            case = None
            try:
                with COMMON["gallery"](plan, prefix, size, theme == "dark") as case:
                    if plan.case == "ax":
                        result = verify_ax(case)
                    elif plan.case == "fade":
                        result = fading(case)
                    else:
                        result = ordinary(case, view, theme, before)
                    report["runs"][prefix] = result
            except (RuntimeError, OSError, KeyError, TypeError, ValueError, subprocess.SubprocessError) as error:
                report["errors"].append(f"{prefix}: {error}")
                print(report["errors"][-1], flush=True)
            finally:
                if case:
                    for frame in case.frames:
                        report["frames"].append(dict(frame, view=view, theme=theme))
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"], "\n".join(report["errors"]))
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} runs")


if __name__ == "__main__":
    main()
