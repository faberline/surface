#!/usr/bin/env python3
"""Verify rounded Material video thumbnails and parent list input on Metal."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import runpy
import struct
import subprocess

HERE = Path(__file__).resolve().parent
IMAGES = runpy.run_path(str(HERE.parents[1] / "surface-md3-list-image.atctHY"
                            / "native-list-image" / "verify-native-list-image.py"))
BASE = IMAGES["BASE"]
COMMON, MOTION, QA = (IMAGES[k] for k in ("COMMON", "MOTION", "QA"))
capture, close, color_matches, contains, focus, key, node, rect, center, pixels_for, require, same_rect, sample_points, write_json = (
    IMAGES[k] for k in ("capture", "close", "color_matches", "contains", "focus", "key", "node",
                        "rect", "center", "pixels_for", "require", "same_rect", "sample_points", "write_json")
)
blend, visible_ink, paint_entries, expect_count, pointer, reject, frame_row, complete_bands, all_bands, image_points = (
    IMAGES[k] for k in ("blend", "visible_ink", "paint_entries", "expect_count", "pointer", "reject",
                        "frame_row", "complete_bands", "all_bands", "image_points")
)
SECTION, LIST, STATIC, ACTIVE, DISABLED, DIRECTION, SCALE, ACTIVE_NAME, IMAGE, ARTWORK = (
    IMAGES[k] for k in ("SECTION", "LIST", "STATIC", "ACTIVE", "DISABLED", "DIRECTION", "SCALE",
                        "ACTIVE_NAME", "IMAGE", "ARTWORK")
)
BLUE, GREEN, YELLOW, RED = (IMAGES[k] for k in ("BLUE", "GREEN", "YELLOW", "RED"))
VIEWPORTS, PROFILES = IMAGES["VIEWPORTS"], IMAGES["PROFILES"]
VIDEO = "list-options-video-toggle"
ROWS = {item: (minimum, {slot: label for slot, label in labels.items() if slot != "trailing"})
        for item, (minimum, labels) in IMAGES["ROWS"].items()}
SLOTS = {STATIC: (100., 56.), ACTIVE: (114., 64.), DISABLED: (100., 56.)}
SOURCES = {STATIC: (140., 56.), ACTIVE: (114., 104.), DISABLED: (100., 56.)}
STAGES = ("static", "disabled", "active", "keyboard", "pointer-and-accesskit")
RADIUS = 8.


def layout(case, snapshot, item, rtl, scale):
    minimum, labels = ROWS[item]
    row = rect(snapshot, item + "-row")
    art = rect(snapshot, item + "-leading-artwork")
    child_id = item + "-leading-artwork-image"
    source = rect(snapshot, child_id)
    slots = {slot: rect(snapshot, item + "-" + slot) for slot in labels}
    minimum = max(minimum, SLOTS[item][1] + (24. if item == DISABLED else 16.))
    require(BASE["close_width"](rect(snapshot, LIST), row) and row["height"] >= minimum,
            f"{item}: invalid row width or video minimum height")
    if case.size[0] == 960 and scale == 1:
        close(row["height"], minimum, f"{item}: wide video row minimum")
    if case.size[0] == 320:
        close(row["width"], 264., f"{item}: narrow list width")
    for dimension, wanted, crop in zip(("width", "height"), SLOTS[item], SOURCES[item]):
        close(art[dimension], wanted, f"{item}: fixed video {dimension}")
        close(source[dimension], crop, f"{item}: centered image {dimension} preserves source aspect")
    for a, b in zip(center(source), center(art)):
        close(a, b, f"{item}: image crop stays centered")
    require(contains(row, art) and all(contains(row, box) for box in slots.values()),
            f"{item}: video or text exceeds hit row")
    start = (row["x"] + row["width"] - art["x"] - art["width"]) if rtl else art["x"] - row["x"]
    close(start, 16., f"{item}: logical leading inset")
    text = slots["headline"]
    gap = art["x"] - text["x"] - text["width"] if rtl else text["x"] - art["x"] - art["width"]
    close(gap, 16., f"{item}: thumbnail to body gap")
    if row["height"] >= 88.:
        close(art["y"] - row["y"], 12. if item == DISABLED else 8., f"{item}: tall row top alignment")
    else:
        close(center(art)[1], center(row)[1], f"{item}: compact thumbnail vertical center")
    _, ids = COMMON["dom_index"](snapshot)
    require(not any(item + "-" + suffix in ids for suffix in ("leading", "trailing", "leading-artwork-label")),
            "Video mode kept a text side slot or avatar label")
    clip = snapshot["layout"]["nodes"][ids[child_id]]["clip"]
    require(contains(art, clip) or clip["height"] == 0., f"{item}: crop clip leaves the thumbnail slot")
    divider = None
    if item != DISABLED:
        divider = rect(snapshot, item + "-divider")
        close(divider["height"], 1., "Optional divider thickness")
        close(divider["y"], row["y"] + row["height"], "Divider stays outside the hit area")
        close(divider["x"] - row["x"], 0. if rtl else 16., "Mirrored list divider inset")
    return row, slots, art, source, divider


def accessibility(snapshot, receipt, item):
    tree = receipt["accesskit"]
    nodes = tree["nodes"]
    require(nodes[LIST]["role"] == "List" and nodes[LIST]["name"] == "訊息清單",
            "Native list lost its localized name")
    row = nodes[item + "-row"]
    enabled = item == ACTIVE
    name = ACTIVE_NAME if enabled else ROWS[item][1]["headline"]
    require(row["name"] == name and row["press"] is enabled and row["focusable"] is enabled
            and row["disabled"] is (item == DISABLED)
            and row["role"] == ("GenericContainer" if item == STATIC else "Button")
            and row["focused"] is (snapshot["interaction"]["focused"] == item + "-row"),
            f"{item}: unexpected native row {row}")
    require(not any("-leading-artwork" in id or id.endswith("-divider") for id in nodes),
            "A decorative thumbnail or divider entered native accessibility")
    subtree = tree["viewport_subtree"]
    require(sum(entry["press"] for entry in subtree) <= 1, "A thumbnail added another list action")
    if enabled:
        require(sum(entry["name"] == ACTIVE_NAME for entry in subtree) == 1 and nodes[item]["name"] is None,
                "Enabled row no longer presents one combined name")
    for slot, label in ROWS[item][1].items():
        id = item + "-" + slot
        if enabled:
            require(id not in nodes, f"{id}: duplicated the combined name")
        else:
            require(nodes[id]["name"] == label and nodes[id]["role"] == "Label" and not nodes[id]["press"],
                    f"{id}: metadata lost readable semantics")
    return row


def between(color, fill, surface):
    return (not color_matches(color, fill, 3) and not color_matches(color, surface, 3)
            and all(min(a, b) - 3 <= c <= max(a, b) + 3 for c, a, b in zip(color[:3], fill[:3], surface[:3])))


def inspect_video(values, art, source, width, height, density, bg):
    points = image_points(art, source, width, height, density)
    red = [p for p in points if color_matches(values[p], RED)]
    require(not red, f"Cropped media leaked red source stripes at {red[:4]}")
    w, h = art["width"], art["height"]
    x0, y0 = art["x"] * density, art["y"] * density
    exact_body = antialias = 0
    corner_background = [0, 0, 0, 0]
    circle = []
    for point in sample_points({part: val * density for part, val in art.items()}):
        x, y = point
        local_x, local_y = (x + .5 - x0) / density, (y + .5 - y0) / density
        color = values[point]
        x_edge, y_edge = min(local_x, w - local_x), min(local_y, h - local_y)
        distance_to_corner = math.hypot(max(0., RADIUS - x_edge), max(0., RADIUS - y_edge)) - RADIUS
        horizontal_ink = BLUE if local_x < w / 2. else GREEN
        if distance_to_corner >= 1.25:
            require(color_matches(color, bg, 4), f"A corner did not expose the row surface: {color}")
            index = int(local_x > w / 2.) + 2 * int(local_y > h / 2.)
            corner_background[index] += 1
        if abs(distance_to_corner) < 1.25 and min(x_edge, y_edge) >= .5:
            antialias += int(between(color, horizontal_ink, bg))
        if distance_to_corner > -1.25 or min(x_edge, y_edge) < 1.:
            continue
        if color[0] >= 150 and color[1] >= 145 and color[2] <= 145:
            circle.append(point)
        radius = math.hypot(local_x - w / 2., local_y - h / 2.)
        expected = YELLOW if radius <= 10.5 else None
        if radius >= 13.5 and abs(local_x - w / 2.) >= 1.25:
            expected = horizontal_ink
        if expected is not None:
            require(color_matches(color, expected, 4),
                    f"Video crop fill wrong at {(local_x, local_y)}: {color}, expected {expected}")
            exact_body += 1
    require(exact_body >= .78 * w * h * density * density and circle, "Video body is not filled")
    require(all(corner_background) and antialias > 0, "Missing rounded corner cutouts or antialiased edge")
    xs, ys = zip(*circle)
    diameter = max(xs) - min(xs) + 1, max(ys) - min(ys) + 1
    circle_center = (min(xs) + max(xs) + 1.) / 2., (min(ys) + max(ys) + 1.) / 2.
    require(all(abs(a - 24. * density) <= 1. for a in diameter) and abs(diameter[0] - diameter[1]) <= 1.,
            f"Circular fiducial is stretched: {diameter} at {density}×")
    expected_center = x0 + w * density / 2., y0 + h * density / 2.
    require(all(abs(a - b) <= 1. for a, b in zip(circle_center, expected_center)),
            f"Circular fiducial is not centered: {circle_center}")
    point = min(circle, key=lambda p: abs(p[0] - circle_center[0]) + abs(p[1] - circle_center[1]))
    return {"filled_samples": exact_body, "red_samples": len(red), "aa_samples": antialias,
            "corner_background_samples": corner_background, "circle_diameter_px": diameter,
            "circle_center_px": circle_center, "tile_pixels": (round(w * density), round(h * density)),
            "point": point}


def verify_paint(case, frame, receipt, item, row, slots, art, source, divider, rtl, scale):
    theme = case.plan.palette["dark" if case.dark else "light"]
    bg = theme["surface"]
    normal, secondary = theme["on_surface"], theme["on_surface_variant"]
    if item == DISABLED:
        normal, secondary = blend(bg, normal, .30), blend(bg, normal, .38)
    clip = frame["viewport"]
    runs = paint_entries(receipt, ("Text", "StyledText"))
    groups = {}
    for slot, box in slots.items():
        font, line_height = BASE["TEXT_METRICS"].get(slot, (11., 16.))
        line_count, bands = complete_bands(box, line_height * scale, clip)
        foreground = normal if slot == "headline" else secondary
        if bands:
            label = ROWS[item][1][slot]
            paints = [run for run in runs if run["text"] == label and same_rect(run["rect"], box)]
            require(len(paints) == 1 and paints[0]["color"] == foreground,
                    f"{item}-{slot}: expected scaled visible text")
            close(paints[0]["style"]["font_size"], font * scale, f"{item}-{slot}: actual scaled text")
            close(paints[0]["style"]["line_height"], line_height * scale, f"{item}-{slot}: actual scaled line height")
        groups[slot] = (line_count, bands, foreground)
    wanted = [band for _, bands, _ in groups.values() for band in bands.values()]
    require(receipt["images"][item + "-leading-artwork-image"]["decorative"], "Video poster loses decorative semantics")
    fully_visible = contains(clip, art)
    video = None
    if fully_visible:
        images = [op["RoundedImage"] for op in receipt["presented"]["ops"]
                  if "RoundedImage" in op and same_rect(op["RoundedImage"]["rect"], source)]
        require(len(images) == 1 and same_rect(images[0]["clip"], art) and same_rect(images[0]["mask"], art),
                f"{item}: rounded mask and rectangular clip must stay fixed as image moves")
        require(len(images[0]["corners"]) == 4 and all(value == RADIUS for value in images[0]["corners"].values()),
                f"{item}: rounded image emitted the wrong corner radii")
        wanted.append(image_points(art, source, frame["width"], frame["height"], 1.))
    separator = None
    if divider and contains(clip, divider):
        x, _ = center(divider)
        gap = row["x"] + (row["width"] - 8. if rtl else 8.)
        band_y = range(math.floor(divider["y"]), math.ceil(divider["y"] + 1.))
        separator = ({(math.floor(x), y) for y in band_y}, {(math.floor(gap), y) for y in band_y})
        wanted.extend(separator)
    require(wanted, "Scrolled frame contains neither complete text lines nor thumbnail")
    values = pixels_for(case.plan.artifacts / frame["file"], frame, set.union(*wanted))
    measured = {}
    for slot, (count, bands, ink) in groups.items():
        observed = {str(index): sum(visible_ink(values[p], ink, bg) for p in band) for index, band in bands.items()}
        require(all(samples >= 4 for samples in observed.values()), f"{item}-{slot}: blank or clipped glyph run")
        measured[slot] = {"total": count, "sampled_ink": observed}
    if fully_visible:
        video = inspect_video(values, art, source, frame["width"], frame["height"], 1., bg)
    if separator:
        line, gap = separator
        ink = theme["outline_variant"]
        require(any(visible_ink(values[p], ink, bg) for p in line)
                and not any(visible_ink(values[p], ink, bg) for p in gap), "Inset divider pixels differ")
    return {"text": measured, "video": video, "divider_pixels": bool(separator)}


def take(case, stage, item, rtl, scale, count, offset=None, focused=False):
    case.clock.advance(700)
    if offset is None:
        oversize = frame_row(case, item)
    else:
        h = case.size[1]
        y = rect(case.snapshot(), item)["y"]
        case.point("scroll", (12., h / 2.), y - (5. - offset))
        close(rect(case.snapshot(), item)["y"], 5. - offset, f"{item}: scrolled view")
        oversize = True
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{stage}",
                              case.size, case.dark, SECTION)
    require(not frame["errors"], str(frame["errors"]))
    expect_count(case, count)
    if focused:
        require(snapshot["interaction"]["focused"] == item + "-row", "Keyboard lost the enabled video row")
    receipt = json.loads(case.receipt.read_text())
    row, slots, art, source, divider = layout(case, snapshot, item, rtl, scale)
    projected = accessibility(snapshot, receipt, item)
    paint = verify_paint(case, frame, receipt, item, row, slots, art, source, divider, rtl, scale)
    frame.update(stage=stage, item=item, rtl=rtl, text_scale=scale, activations=count, oversize=oversize,
                 row=row, art=art, image_node=source, divider=divider, slots=slots, paint=paint, accesskit=projected)
    case.frames.append(frame)
    return frame


def high_density(case, name, first):
    path = case.plan.artifacts / f"{case.prefix}-{name}-output-2x.png"
    result = case.call("page", "screenshot", "--scale", "2", "--out", path)
    data = path.read_bytes()
    width, height = struct.unpack(">II", data[16:24])
    require(data.startswith(b"\x89PNG\r\n\x1a\n") and (width, height) == tuple(2 * d for d in case.size),
            "Incorrect physical 2× PNG size")
    require(result["width"] == width and result["height"] == height and result["scale"] == 2.,
            "Metadata disagrees with the 2× PNG")
    frame = {"file": path.name, "width": width, "height": height, "bytes": len(data),
             "sha256": hashlib.sha256(data).hexdigest(), "scale": 2.}
    art, source = first["art"], first["image_node"]
    values = pixels_for(path, frame, image_points(art, source, width, height, 2.))
    bg = case.plan.palette["dark" if case.dark else "light"]["surface"]
    frame["video"] = inspect_video(values, art, source, width, height, 2., bg)
    return frame


def read_remaining_lines(case, name, item, first, rtl, scale):
    if not first["oversize"]:
        return all_bands(first)
    h = case.size[1]
    max_scroll = rect(case.snapshot(), item)["height"] - h + 10.
    stride = h - 10. - 24. * scale
    offsets = list(range(round(stride), math.ceil(max_scroll), round(stride)))
    frames = [first]
    for index, offset in enumerate(offsets):
        frames.append(take(case, f"{name}-middle-{index + 1}", item, rtl, scale, 0, offset=offset))
    frames.append(take(case, name + "-tail", item, rtl, scale, 0, offset=max_scroll))
    return all_bands(*frames)


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    _, ids = COMMON["dom_index"](case.snapshot())
    require(ACTIVE + "-leading" in ids and ACTIVE + "-leading-artwork-image" not in ids,
            "Video changed the default text mode")
    case.call("action", "activate", ARTWORK)
    _, ids = COMMON["dom_index"](case.snapshot())
    require(ACTIVE + "-leading-artwork-label" in ids, "Artwork mode no longer shows the initials")
    case.call("action", "activate", IMAGE)
    photo = case.snapshot()
    square = rect(photo, ACTIVE + "-leading-artwork")
    require(square["width"] == square["height"] == 56., "Prior photo mode lost its square slot")
    case.call("action", "activate", VIDEO)
    state = case.snapshot()
    require(node(state, VIDEO)["selected"] and not node(state, IMAGE)["selected"] and not node(state, ARTWORK)["selected"],
            "Gallery video mode is not exclusive")
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2:
        case.call("action", "activate", SCALE)
    case.point("leave")
    result = {"mcp": None, "output_2x": {}}
    compact = case.size[0] == 320 and case.dark and rtl and scale == 2
    lines = {}
    for name, item in (("static", STATIC), ("disabled", DISABLED), ("active", ACTIVE)):
        first = take(case, name, item, rtl, scale, 0)
        require(first["paint"]["video"], f"{item}: initial scroll must show the whole thumbnail")
        if compact:
            if item == ACTIVE:
                mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
                require((case.plan.artifacts / mcp["file"]).read_bytes() ==
                        (case.plan.artifacts / first["file"]).read_bytes(), "CLI and MCP returned different PNG bytes")
                result["mcp"] = {**mcp, "cli": first["file"]}
            result["output_2x"][name] = high_density(case, name, first)
        if item != ACTIVE:
            pointer(case, first["paint"]["video"]["point"], 0, 0)
        lines[name] = read_remaining_lines(case, name, item, first, rtl, scale)
    if case.size[0] == 320 and scale == 2:
        require(lines["active"]["supporting"] > 1, "Narrow CJK did not wrap")
    for item in (STATIC, ACTIVE, DISABLED):
        for suffix in ("-leading-artwork", "-leading-artwork-image"):
            reject(case, "press", item + suffix, "no live AccessKit press")
    reject(case, "focus", ACTIVE + "-leading-artwork-image", "no live AccessKit focus")
    expect_count(case, 0)
    focus(case, SCALE)
    key(case, "tab", ACTIVE + "-row")
    expect_count(case, 0)
    key(case, "enter", ACTIVE + "-row")
    board = take(case, "keyboard", ACTIVE, rtl, scale, 1, focused=True)
    pointer(case, board["paint"]["video"]["point"], 1, 2)
    pressed = case.call("action", "qa-ax-press", ACTIVE + "-row")
    require(pressed["accesskit"], "AccessKit did not click the active video row")
    take(case, "pointer-and-accesskit", ACTIVE, rtl, scale, 3)
    return {**result, "cjk_line_counts": lines,
            "passive_video_pointer_attempts": 2, "denied_video_accesskit_requests": 7}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile")
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--startup-timeout", type=int, default=45)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "runs": {}, "frames": [], "errors": []}
    for viewport, theme, direction, scale in PROFILES:
        name = f"{viewport}-{theme}-{direction}-{scale}x"
        if plan.profile not in (None, name) or plan.theme not in (None, theme):
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, VIEWPORTS[viewport], theme == "dark") as case:
                result = journey(case, direction == "rtl", scale)
            output = (plan.artifacts / f"{name}.log").read_text()
            metal = next((line for line in output.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in metal and "backend: Metal" in metal, f"{name} did not use Metal")
            report["runs"][name] = {**result, "adapter": metal}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(report["errors"][-1], flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"] and report["runs"], "\n".join(report["errors"]) or "No matching journey")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
