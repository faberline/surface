#!/usr/bin/env python3
"""Verify the badge on a Material bottom navigation bar on native Metal."""

import argparse
import itertools
import json
import math
from pathlib import Path
import runpy
import subprocess


HERE = Path(__file__).resolve().parent
BADGES = runpy.run_path(str(HERE.parents[1] / "surface-md3-badged-anchor.3d4V71"
                            / "native-badged-anchor" / "verify-native-badge.py"))
COMMON, MOTION, QA = (BADGES[name] for name in ("COMMON", "MOTION", "QA"))
reject = BADGES["SHARED"]["reject"]
capture, close, color_matches, contains, focus, geometry, key, node, pixels_for, require, same_rect, sample_points, write_json = (
    BADGES[name] for name in ("capture", "close", "color_matches", "contains", "focus",
                             "geometry", "key", "node", "pixels_for", "require",
                             "same_rect", "sample_points", "write_json")
)
SECTION = "section-4"
PREVIEW, BAR, MODE, DIRECTION, SCALE, HOME, INBOX, ARCHIVE, STATUS = (
    f"nav-badge-{part}" for part in (
        "preview", "bar", "mode", "direction", "text-scale", "home", "inbox", "archive", "status"
    )
)
ORDER = (HOME, INBOX, ARCHIVE)
LABELS = dict(zip(ORDER, ("首頁", "收件匣", "封存")))
TYPES = {k: (label, text) for k, (_, label, text) in BADGES["NAMES"].items()}
VIEWPORTS = BADGES["VIEWPORTS"]
PROFILES = tuple(itertools.product(VIEWPORTS, ("light", "dark"), ("ltr", "rtl"), (1, 2)))


def desc(snapshot, id, depth=0):
    nodes, ids = COMMON["dom_index"](snapshot)
    index = ids[id]
    for _ in range(depth):
        index = nodes[index]["first_child"]
    return snapshot["layout"]["nodes"][index]["bounds"]


def status(case):
    data = node(case.snapshot(), STATUS)
    return data["text"] or data["name"]


def expect_status(case, selected, count):
    expected = f"{LABELS[selected]} · 已切換 {count} 次"
    require(status(case) == expected, f"Expected {expected!r}. Got {status(case)!r}")


def rectangle_relative(box, parent):
    return {**box, "x": box["x"] - parent["x"], "y": box["y"] - parent["y"]}


def overlap_rect(first, second):
    return all(first[axis] < second[axis] + second[size] and second[axis] < first[axis] + first[size]
               for axis, size in (("x", "width"), ("y", "height")))


def boxes(snapshot, rtl):
    bar = geometry(snapshot, BAR)[2]
    close(bar["height"], 80., "Bottom navigation bar height")
    targets = {id: geometry(snapshot, id)[2] for id in ORDER}
    by_x = sorted(targets, key=lambda id: targets[id]["x"])
    require(by_x == (list(reversed(ORDER)) if rtl else list(ORDER)), "Navigation item order did not mirror")
    last_x = bar["x"]
    for id in by_x:
        target = targets[id]
        require(contains(bar, target) and target["width"] >= 48., f"{id}: insufficient target {target}")
        close(target["height"], 80., f"{id}: target height")
        close(target["x"], last_x, f"{id}: target gap or overlap")
        last_x += target["width"]
    close(last_x, bar["x"] + bar["width"], "Bar coverage by destination targets")

    indicators = {id: desc(snapshot, id, 1) for id in ORDER}
    for id, indicator in indicators.items():
        close(indicator["width"], 64., f"{id}: indicator width")
        close(indicator["height"], 32., f"{id}: indicator height")
        target = targets[id]
        require(abs(indicator["x"] + 32. - target["x"] - target["width"] / 2.) <= .51,
                f"{id}: indicator is not centered inside its target")
    art = {id: {"x": indicator["x"] + 20., "y": indicator["y"] + 4.,
                "width": 24., "height": 24.} for id, indicator in indicators.items()}
    return bar, targets, indicators, art


def verify_accessibility(receipt, snapshot, badge_name, selected, focused):
    native = receipt["accesskit"]
    group = native["nodes"][BAR]
    require(group["role"] == "Navigation" and group["name"] == "主導覽"
            and not group["focusable"] and not group["press"], f"Incorrect native navigation group: {group}")
    names = {**LABELS, INBOX: badge_name}
    subtree = native["viewport_subtree"]
    require([item["name"] for item in subtree if item["name"]] == ["主導覽", *names.values()],
            f"Duplicate status, extra labels or reordered accessibility nodes: {subtree}")
    require([item["name"] for item in subtree if item["focusable"] or item["press"]] == [names[HOME], names[INBOX]],
            f"Badge added an accessibility action or disabled item became actionable: {subtree}")
    public = {}
    for id in ORDER:
        item = native["nodes"][id]
        raw = node(snapshot, id)
        enabled = id != ARCHIVE
        require(raw["name"] == item["name"] == names[id] and item["role"] == "Button"
                and item["disabled"] is not enabled and item["focusable"] is enabled and item["press"] is enabled
                and raw["selected"] is (id == selected) and item["selected"] is (id == selected)
                and item["focused"] is (id == focused),
                f"Unexpected native state for {id}: {item}")
        public[id] = item
    return public


def paint_entries(receipt, kinds):
    return [tile for op in receipt["presented"]["ops"]
            for kind, tile in op.get("Legacy", {}).items() if kind in kinds]


def verify_rendering(case, frame, receipt, bar, preview, targets, indicators, art, mode, expected_text,
                     selected, rtl, scale):
    theme = case.plan.palette["dark" if case.dark else "light"]
    file = case.plan.artifacts / frame["file"]
    fills = paint_entries(receipt, ("Quad", "Shape"))
    indicator = indicators[selected]
    found = [tile["rect"] for tile in fills if tile["color"] == theme["secondary_container"]
             and contains(bar, tile["rect"])]
    require(len(found) == 1 and same_rect(found[0], indicator), f"Wrong active indicator: {found}")
    # Test the start edge of the indicator, clear of the icon and badge.
    offset = 7. if not rtl or selected != INBOX else indicator["width"] - 7.
    point = (round(indicator["x"] + offset), round(indicator["y"] + 16.))
    observed = pixels_for(file, frame, [point])[point]
    require(color_matches(observed, theme["secondary_container"]), f"Wrong indicator pixel {observed}")

    labels = paint_entries(receipt, ("Text", "StyledText"))
    label_ink = {}
    icon_ink = {}
    paths = [op["FillPath"] for op in receipt["presented"]["ops"] if "FillPath" in op]
    for id in ORDER:
        expected = (theme["outline"] if id == ARCHIVE else
                    theme["on_surface"] if id == selected else theme["on_surface_variant"])
        runs = [tile for tile in labels if tile["text"] == LABELS[id] and contains(targets[id], tile["rect"])]
        require(len(runs) == 1 and runs[0]["color"] == expected and contains(runs[0]["clip"], runs[0]["rect"]),
                f"{id}: visible label does not match its stable label in {mode}: {runs}")
        p = pixels_for(file, frame, sample_points(runs[0]["rect"]))
        label_ink[id] = sum(color_matches(color, expected, 33) for color in p.values())
        require(label_ink[id] >= 2, f"{id}: label has no actual ink in the PNG")
        expected_icon = theme["on_secondary_container"] if id == selected else expected
        artwork = [path for path in paths if same_rect(path["clip"], art[id])]
        require(artwork and all(path["contour"]["color"] == expected_icon for path in artwork),
                f"{id}: destination icon did not draw its 24 dp vector and theme ink")
        p = pixels_for(file, frame, sample_points(art[id]))
        icon_ink[id] = sum(color_matches(color, expected_icon, 26) for color in p.values())
        require(icon_ink[id] >= 4, f"{id}: destination icon has no actual ink in the PNG")

    badge = [tile for tile in fills if tile["color"] == theme["error"] and contains(preview, tile["rect"])]
    require(len(badge) == int(mode != "hidden"), f"Incorrect badge paint: {badge}")
    if not badge:
        return {"indicator": indicator, "indicator_pixel": observed, "label_pixels": label_ink,
                "icon_pixels": icon_ink, "badge": None}
    tile = badge[0]
    rect = tile["rect"]
    require(not any(overlap_rect(rect, art[id]) for id in (HOME, ARCHIVE)),
            f"{mode}: badge covers neighboring artwork")
    anchor = art[INBOX]
    is_dot = mode == "dot"
    end_overlap = 6. if is_dot else 12.
    bottom_overlap = 6. if is_dot else 14.
    end = (rect["x"] + rect["width"] - anchor["x"] if rtl else anchor["x"] + anchor["width"] - rect["x"])
    close(end, end_overlap, "Badge inline overlap on 24 dp icon")
    close(rect["y"] + rect["height"] - anchor["y"], bottom_overlap, "Badge vertical overlap on 24 dp icon")
    require(contains(tile["clip"], rect), f"{mode}: badge paint is clipped")
    badge_pixels = pixels_for(file, frame, sample_points(rect))
    face = {point for point, color in badge_pixels.items() if color_matches(color, theme["error"])}
    require(face, f"{mode}: badge error surface is absent from PNG")
    if is_dot:
        close(rect["width"], 6., "Badge dot width")
        close(rect["height"], 6., "Badge dot height")
        badge_ink = []
    else:
        text = [label for label in labels if label["text"] == expected_text and label["color"] == theme["on_error"]
                and contains(rect, label["rect"])]
        require(len(text) == 1 and contains(text[0]["clip"], text[0]["rect"]),
                f"{mode}: badge text differs from {expected_text!r} or is clipped")
        ink_box = text[0]["rect"]
        ink_region = sample_points(ink_box)
        font_size = text[0].get("font_size") or text[0]["style"]["font_size"]
        close(font_size, 11. * scale, f"{mode}: badge Label Small scale")
        close(rect["height"], 16. * scale, f"{mode}: badge height")
        badge_ink = [point for point, color in badge_pixels.items()
                     if point in ink_region and color_matches(color, theme["on_error"], 26)]
        require(len(badge_ink) >= 2, f"{mode}: badge label has no actual ink in PNG")
        if mode == "label":
            mid = ink_box["x"] + ink_box["width"] / 2.
            require(any(x < mid for x, _ in badge_ink) and any(x >= mid for x, _ in badge_ink),
                    "CJK badge did not paint both characters")
    overlap = face & sample_points(targets[INBOX])
    require(overlap, "No visible badge pixels inside the inbox target")
    inside_point = min(overlap, key=lambda point:
                       abs(point[0] - (anchor["x"] + 12.)) + abs(point[1] - (anchor["y"] + 12.)))
    disabled_overlap = face & sample_points(targets[ARCHIVE])
    return {"indicator": indicator, "indicator_pixel": observed, "label_pixels": label_ink, "icon_pixels": icon_ink,
            "badge": {"rect": rect, "error_pixels": len(face), "text_pixels": len(badge_ink),
                      "overlap": inside_point,
                      "over_disabled": min(disabled_overlap) if disabled_overlap else None}}


def take(case, stage, mode, rtl, scale, selected=HOME, count=0, unread=3, focused="auto"):
    case.clock.advance(700)
    QA["reveal"](case, PREVIEW)
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{stage}",
                              case.size, case.dark, SECTION, (PREVIEW, BAR, *ORDER))
    require(not frame["errors"], str(frame["errors"]))
    expect_status(case, selected, count)
    receipt = json.loads(case.receipt.read_text())
    badge_name, label = TYPES[mode]
    actual_focus = snapshot["interaction"]["focused"]
    if focused != "auto":
        require(actual_focus == focused, f"{stage}: expected focus {focused}, got {actual_focus}")
    accesskit = verify_accessibility(receipt, snapshot, badge_name.format(unread), selected, actual_focus)
    bar, targets, indicators, art = boxes(snapshot, rtl)
    preview = geometry(snapshot, PREVIEW)[2]
    paint = verify_rendering(case, frame, receipt, bar, preview, targets, indicators, art, mode,
                             label.format(unread) if label else None, selected, rtl, scale)
    layout = {id: {"target": rectangle_relative(targets[id], bar),
                   "indicator": rectangle_relative(indicators[id], bar),
                   "icon": rectangle_relative(art[id], bar)} for id in ORDER}
    if case.frames:
        require(layout == case.frames[0]["layout"], f"{stage}: badge, selection or focus resized the bar")
    frame.update(stage=stage, mode=mode, scale=scale, rtl=rtl, paint=paint, layout=layout, bar=bar,
                 selected=selected, focus=actual_focus, accesskit=accesskit, selections=count, unread=unread)
    case.frames.append(frame)
    return frame


def click_once(case, point, before, after):
    case.point("move", point)
    case.point("down", point)
    expect_status(case, INBOX, before)
    case.point("up", point)
    case.point("leave")
    expect_status(case, INBOX, after)


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2:
        case.call("action", "activate", SCALE)
    case.point("leave")
    take(case, "count-default", "count", rtl, scale)
    focus(case, SCALE)
    key(case, "tab", HOME)
    forward, backward = ("left", "right") if rtl else ("right", "left")
    key(case, forward, INBOX)
    key(case, forward, HOME)
    key(case, backward, INBOX)
    key(case, "home", HOME)
    key(case, "end", INBOX)
    take(case, "arrows-skip-disabled", "count", rtl, scale, focused=INBOX)
    key(case, "enter", INBOX)
    take(case, "keyboard", "count", rtl, scale, INBOX, 1, 4, INBOX)
    key(case, "tab", SCALE, shift=True)
    key(case, "tab", INBOX)
    active = take(case, "selected-entry", "count", rtl, scale, INBOX, 1, 4, INBOX)
    click_once(case, active["paint"]["badge"]["overlap"], 1, 2)
    take(case, "pointer", "count", rtl, scale, INBOX, 2, 5)
    pressed = case.call("action", "qa-ax-press", INBOX)
    require(pressed["accesskit"], "Click did not pass through AccessKit")
    take(case, "accesskit", "count", rtl, scale, INBOX, 3, 6)
    denied = reject(case, "press", ARCHIVE, "no live AccessKit press")
    require(denied, "Disabled Archive unexpectedly has an AccessKit action")

    result = {"input_routes": ["native arrows/Tab/Enter", "Winit mouse down/up", "AccessKit Click"],
              "disabled_overlay_press_denied": False, "mcp": None}
    for mode, unread in (("overflow", 1200), ("hidden", 0), ("dot", 0), ("label", 0), ("count", 3)):
        case.call("action", "activate", MODE)
        cap = take(case, "count-again" if mode == "count" else mode, mode, rtl, scale, INBOX, 3, unread)
        if mode != "overflow":
            continue
        point = cap["paint"]["badge"]["over_disabled"]
        if point:
            click_once(case, point, 3, 3)
            result["disabled_overlay_press_denied"] = True
        if case.size[0] == 320 and case.dark and rtl and scale == 2:
            cap = take(case, "held-cli", mode, rtl, scale, INBOX, 3, unread)
            mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
            require((case.plan.artifacts / mcp["file"]).read_bytes() ==
                    (case.plan.artifacts / cap["file"]).read_bytes(), "CLI and MCP returned different PNG bytes")
            result["mcp"] = {**mcp, "cli": cap["file"]}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile")
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--startup-timeout", type=int, default=45)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "runs": {}, "frames": [], "errors": []}
    for viewport, theme, direction, scale in PROFILES:
        name = f"{viewport}-{theme}-{direction}-{scale}x"
        if plan.profile not in (None, name) or plan.theme not in (None, theme):
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, VIEWPORTS[viewport], theme == "dark") as case:
                result = journey(case, direction == "rtl", scale)
            output = (plan.artifacts / f"{name}.log").read_text()
            metal = next((line for line in output.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in metal and "backend: Metal" in metal, f"{name} did not use Metal")
            report["runs"][name] = {**result, "adapter": metal}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(report["errors"][-1], flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"] and report["runs"], "\n".join(report["errors"]) or "No matching journey")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
