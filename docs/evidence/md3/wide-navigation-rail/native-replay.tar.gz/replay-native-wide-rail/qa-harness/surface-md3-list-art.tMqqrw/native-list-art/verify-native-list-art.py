#!/usr/bin/env python3
"""Verify Material list vector and avatar rendering and input on macOS Metal."""

import argparse
import json
import math
from pathlib import Path
import runpy
import subprocess

HERE = Path(__file__).resolve().parent
BASE = runpy.run_path(str(HERE.parents[1] / "surface-md3-list.PWGJUr"
                          / "native-list" / "verify-native-list.py"))
COMMON, MOTION, QA = (BASE[k] for k in ("COMMON", "MOTION", "QA"))
capture, close, color_matches, contains, focus, key, node, rect, center, pixels_for, require, same_rect, sample_points, write_json = (
    BASE[k] for k in ("capture", "close", "color_matches", "contains", "focus", "key", "node",
                      "rect", "center", "pixels_for", "require", "same_rect", "sample_points", "write_json")
)
blend, visible_ink, paint_entries, expect_count, pointer, reject = (
    BASE[k] for k in ("blend", "visible_ink", "paint_entries", "expect_count", "pointer", "reject")
)
SECTION, LIST, STATIC, ACTIVE, DISABLED, DIRECTION, SCALE, ACTIVE_NAME = (
    BASE[k] for k in ("SECTION", "LIST", "STATIC", "ACTIVE", "DISABLED", "DIRECTION", "SCALE", "ACTIVE_NAME")
)
VIEWPORTS, PROFILES = BASE["VIEWPORTS"], BASE["PROFILES"]
ARTWORK = "list-options-artwork-toggle"
INITIALS = "林"
ROWS = {id: (minimum, {slot: text for slot, text in labels.items() if slot != "leading"})
        for id, (minimum, labels) in BASE["ROWS"].items()}


def frame_row(case, item, tail=False):
    box = rect(case.snapshot(), item)
    if box["height"] <= case.size[1] - 8.:
        QA["reveal"](case, item)
        return False
    desired = case.size[1] - box["height"] - 5. if tail else 5.
    case.point("scroll", (12., case.size[1] / 2.), box["y"] - desired)
    close(rect(case.snapshot(), item)["y"], desired, f"{item}: scrolled row framing")
    return True


def layout(case, snapshot, item, rtl, scale):
    minimum, labels = ROWS[item]
    row = rect(snapshot, item + "-row")
    art = rect(snapshot, item + "-leading-artwork")
    slots = {slot: rect(snapshot, item + "-" + slot) for slot in labels}
    require(BASE["close_width"](rect(snapshot, LIST), row) and row["height"] >= minimum,
            f"{item}: row width or height is invalid")
    if case.size[0] == 960 and scale == 1:
        close(row["height"], minimum, f"{item}: wide row minimum")
    if case.size[0] == 320:
        close(row["width"], 264., f"{item}: narrow list width")
    art_size = 40. if item == ACTIVE else 24.
    close(art["height"], art_size, f"{item}: fixed art height")
    close(art["width"], art_size, f"{item}: fixed art width")
    require(contains(row, art) and all(contains(row, box) for box in slots.values()),
            f"{item}: artwork or a text slot extends out of the row")
    start = row["x"] + row["width"] - art["x"] - art["width"] if rtl else art["x"] - row["x"]
    close(start, 16., f"{item}: logical leading inset")
    body = slots["headline"]
    gap = art["x"] - body["x"] - body["width"] if rtl else body["x"] - art["x"] - art["width"]
    close(gap, 16., f"{item}: artwork to body gap")
    if row["height"] >= 88.:
        close(art["y"] - row["y"], 12. if item == DISABLED else 8., f"{item}: tall row top alignment")
    else:
        close(center(art)[1], center(row)[1], f"{item}: compact artwork vertical center")
    _, ids = COMMON["dom_index"](snapshot)
    require(item + "-leading" not in ids, "Old text slot remained beside artwork")
    divider = None
    if item != DISABLED:
        divider = rect(snapshot, item + "-divider")
        close(divider["height"], 1., "Optional divider thickness")
        close(divider["y"], row["y"] + row["height"], "Optional divider stays outside the row hit area")
        close(divider["x"] - row["x"], 0. if rtl else 16., "Mirrored divider inset")
    return row, slots, art, divider


def accessibility(snapshot, receipt, item):
    projection = receipt["accesskit"]
    nodes = projection["nodes"]
    subtree = projection["viewport_subtree"]
    require(nodes[LIST]["role"] == "List" and nodes[LIST]["name"] == "訊息清單", "Native list lost its name")
    row = nodes[item + "-row"]
    enabled = item == ACTIVE
    expected = ACTIVE_NAME if enabled else ROWS[item][1]["headline"]
    require(row["name"] == expected and row["press"] is enabled and row["focusable"] is enabled
            and row["disabled"] is (item == DISABLED)
            and row["role"] == ("GenericContainer" if item == STATIC else "Button")
            and row["focused"] is (snapshot["interaction"]["focused"] == item + "-row"),
            f"{item}: unexpected native row {row}")
    require(not any("artwork" in id and not id.endswith("-toggle") for id in nodes)
            and not any(id.endswith("-divider") for id in nodes), "Decorative art or divider entered native AX")
    require(not any(child["name"] == INITIALS for child in subtree), "Initials became a separate accessible label")
    require(sum(child["press"] for child in subtree) <= 1, "Art introduced another native target")
    names = [child["name"] for child in subtree if child["name"]]
    if enabled:
        require(names.count(ACTIVE_NAME) == 1 and nodes[item]["name"] is None, "Enabled row lost its single combined name")
    for suffix, label in ROWS[item][1].items():
        id = item + "-" + suffix
        if enabled:
            require(id not in nodes, f"{id}: duplicated the combined accessible label")
        else:
            require(nodes[id]["name"] == label and nodes[id]["role"] == "Label" and not nodes[id]["press"],
                    f"{id}: metadata lost readable semantics")
    return row


def complete_bands(box, line_height, clip):
    count = max(1, round(box["height"] / line_height))
    bands = {}
    for index in range(count):
        line = {**box, "y": box["y"] + index * line_height, "height": line_height}
        if contains(clip, line):
            bands[index] = sample_points(line)
    return count, bands


def shape_points(box):
    x, y = center(box)
    inside = {(round(x + a), round(y + b)) for a, b in ((0, -14), (14, 0), (0, 14), (-14, 0))}
    corners = {(round(x + a), round(y + b)) for a, b in ((-18, -18), (18, -18), (-18, 18), (18, 18))}
    return inside, corners


def verify_paint(case, frame, snapshot, receipt, item, row, slots, art, divider, rtl, scale):
    theme = case.plan.palette["dark" if case.dark else "light"]
    bg = theme["surface"]
    normal, secondary = theme["on_surface"], theme["on_surface_variant"]
    if item == DISABLED:
        normal, secondary = blend(bg, normal, .30), blend(bg, normal, .38)
    clip = frame["viewport"]
    runs = paint_entries(receipt, ("Text", "StyledText"))
    fills = paint_entries(receipt, ("Quad", "Shape"))
    groups = {}
    for slot, box in slots.items():
        font, line_height = BASE["TEXT_METRICS"].get(slot, (11., 16.))
        line_count, bands = complete_bands(box, line_height * scale, clip)
        foreground = normal if slot == "headline" else secondary
        if bands:
            label = ROWS[item][1][slot]
            paints = [run for run in runs if run["text"] == label and same_rect(run["rect"], box)]
            require(len(paints) == 1 and paints[0]["color"] == foreground,
                    f"{item}-{slot}: visible text was clipped or used the wrong color")
            close(paints[0]["style"]["font_size"], font * scale, f"{item}-{slot}: actual scaled text")
            close(paints[0]["style"]["line_height"], line_height * scale, f"{item}-{slot}: actual scaled line height")
        groups[slot] = (line_count, bands, foreground)

    wanted = [band for _, bands, _ in groups.values() for band in bands.values()]
    artwork = None
    artwork_checks = None
    if contains(clip, art):
        if item == ACTIVE:
            face = theme["primary_container"]
            ink = theme["on_primary_container"]
            require(any(fill["color"] == face and same_rect(fill["rect"], art) for fill in fills),
                    "Initials avatar has no primary-container paint")
            label_rect = rect(snapshot, item + "-leading-artwork-label")
            require(contains(art, label_rect), "Avatar initials overflow the fixed face")
            require(all(abs(label - face_center) <= .51
                        for label, face_center in zip(center(label_rect), center(art))),
                    "Initials are not centered within layout rounding")
            labels = [run for run in runs if run["text"] == INITIALS and same_rect(run["rect"], label_rect)]
            require(len(labels) == 1 and labels[0]["color"] == ink, "Initials did not use avatar foreground ink")
            close(labels[0]["style"]["font_size"], 16., "Avatar Title Medium size")
            inside, corners = shape_points(art)
            artwork_checks = (inside, corners, sample_points(label_rect), face, ink)
            wanted.extend((inside, corners, artwork_checks[2]))
        else:
            paths = [op["FillPath"] for op in receipt["presented"]["ops"] if "FillPath" in op]
            path_ink = [path for path in paths if same_rect(path["clip"], art)]
            require(path_ink and all(path["contour"]["color"] == secondary for path in path_ink),
                    f"{item}: expected a 24 dp vector using the list item's ink role")
            wanted.append(sample_points(art))
    separator = None
    if divider and contains(clip, divider):
        x, _ = center(divider)
        gap = row["x"] + (row["width"] - 8. if rtl else 8.)
        band_y = range(math.floor(divider["y"]), math.ceil(divider["y"] + 1.))
        separator = ({(math.floor(x), y) for y in band_y}, {(math.floor(gap), y) for y in band_y})
        wanted.extend(separator)
    values = pixels_for(case.plan.artifacts / frame["file"], frame, set.union(*wanted))
    measured = {}
    for slot, (count, bands, ink) in groups.items():
        observed = {str(index): sum(visible_ink(values[point], ink, bg) for point in band)
                    for index, band in bands.items()}
        require(all(samples >= 4 for samples in observed.values()), f"{item}-{slot}: missing ink in line band {observed}")
        measured[slot] = {"total": count, "sampled_ink": observed}
    if artwork_checks:
        inside, corners, initials, face, ink = artwork_checks
        require(all(color_matches(values[p], face) for p in inside)
                and all(color_matches(values[p], bg) for p in corners), "Avatar pixels do not form a round face")
        ink_points = [p for p in initials if visible_ink(values[p], ink, face)]
        require(len(ink_points) > 15, "Initial 林 did not paint inside the avatar")
        x = center(art)[0]
        require(any(p[0] < x for p in ink_points) and any(p[0] >= x for p in ink_points), "Avatar ink is not centered")
        artwork = {"shape": "round-avatar", "ink_pixels": len(ink_points), "point": sorted(inside)[0]}
    elif contains(clip, art):
        art_pixels = [p for p in sample_points(art) if visible_ink(values[p], secondary, bg)]
        require(len(art_pixels) > 12, f"{item}: vector left no visible pixels")
        artwork = {"shape": "vector", "ink_pixels": len(art_pixels), "point": sorted(art_pixels)[len(art_pixels) // 2]}
    if separator:
        line, gap = separator
        ink = theme["outline_variant"]
        require(any(visible_ink(values[p], ink, bg) for p in line)
                and not any(visible_ink(values[p], ink, bg) for p in gap), "Inset divider pixels differ")
    return {"text": measured, "artwork": artwork, "divider_pixels": bool(separator)}


def take(case, stage, item, rtl, scale, count, tail=False, focused=False):
    case.clock.advance(700)
    oversize = frame_row(case, item, tail)
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{stage}",
                              case.size, case.dark, SECTION)
    require(not frame["errors"], str(frame["errors"]))
    expect_count(case, count)
    if focused:
        require(snapshot["interaction"]["focused"] == item + "-row", "Keyboard did not keep focus on the complete row")
    receipt = json.loads(case.receipt.read_text())
    row, slots, art, divider = layout(case, snapshot, item, rtl, scale)
    projected = accessibility(snapshot, receipt, item)
    paint = verify_paint(case, frame, snapshot, receipt, item, row, slots, art, divider, rtl, scale)
    frame.update(stage=stage, item=item, rtl=rtl, text_scale=scale, activations=count, oversize=oversize,
                 row=row, art=art, divider=divider, slots=slots, paint=paint, accesskit=projected)
    case.frames.append(frame)
    return frame


def all_bands(*frames):
    content = frames[0]["paint"]["text"]
    for slot, sums in content.items():
        visible = set.union(*(set(shot["paint"]["text"][slot]["sampled_ink"]) for shot in frames))
        wanted = {str(i) for i in range(sums["total"])}
        require(visible == wanted, f"{frames[0]['item']}-{slot}: not all CJK lines became visible across scroll")
    return {slot: sums["total"] for slot, sums in content.items()}


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    _, ids = COMMON["dom_index"](case.snapshot())
    require(ACTIVE + "-leading" in ids and not any(id.endswith("-leading-artwork") for id in ids),
            "Artwork changed the default baseline list")
    case.call("action", "activate", ARTWORK)
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2:
        case.call("action", "activate", SCALE)
    case.point("leave")
    static = take(case, "static", STATIC, rtl, scale, 0)
    disabled = take(case, "disabled", DISABLED, rtl, scale, 0)
    all_bands(static)
    all_bands(disabled)
    pointer(case, disabled["paint"]["artwork"]["point"], 0, 0)
    frame_row(case, STATIC)
    current = rect(case.snapshot(), STATIC + "-leading-artwork")
    x, y = static["paint"]["artwork"]["point"]
    pointer(case, (x + current["x"] - static["art"]["x"], y + current["y"] - static["art"]["y"]), 0, 0)
    active = take(case, "active", ACTIVE, rtl, scale, 0)
    mcp_result = None
    if case.size[0] == 320 and case.dark and rtl and scale == 2:
        mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
        require((case.plan.artifacts / mcp["file"]).read_bytes() ==
                (case.plan.artifacts / active["file"]).read_bytes(), "CLI and MCP returned different PNG bytes")
        mcp_result = {**mcp, "cli": active["file"]}
    frames = [active]
    if active["oversize"]:
        frames.append(take(case, "active-tail", ACTIVE, rtl, scale, 0, tail=True))
    visible = all_bands(*frames)
    if case.size[0] == 320 and scale == 2:
        require(visible["supporting"] > 1, "Narrow CJK stopped wrapping")
    for id in (STATIC + "-leading-artwork", ACTIVE + "-leading-artwork",
               ACTIVE + "-leading-artwork-label", DISABLED + "-leading-artwork"):
        reject(case, "press", id, "no live AccessKit press")
    reject(case, "focus", ACTIVE + "-leading-artwork", "no live AccessKit focus")
    expect_count(case, 0)
    focus(case, SCALE)
    key(case, "tab", ACTIVE + "-row")
    expect_count(case, 0)
    key(case, "enter", ACTIVE + "-row")
    keyboard = take(case, "keyboard", ACTIVE, rtl, scale, 1, focused=True)
    pointer(case, keyboard["paint"]["artwork"]["point"], 1, 2)
    pressed = case.call("action", "qa-ax-press", ACTIVE + "-row")
    require(pressed["accesskit"], "Parent row did not accept an AccessKit click")
    take(case, "pointer-and-accesskit", ACTIVE, rtl, scale, 3)
    return {"mcp": mcp_result, "cjk_visible_lines": visible, "passive_artwork_pointer_attempts": 2,
            "denied_artwork_accesskit_requests": 5}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile")
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--startup-timeout", type=int, default=45)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "runs": {}, "frames": [], "errors": []}
    for viewport, theme, direction, scale in PROFILES:
        name = f"{viewport}-{theme}-{direction}-{scale}x"
        if plan.profile not in (None, name) or plan.theme not in (None, theme):
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, VIEWPORTS[viewport], theme == "dark") as case:
                result = journey(case, direction == "rtl", scale)
            log = (plan.artifacts / f"{name}.log").read_text()
            metal = next((line for line in log.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in metal and "backend: Metal" in metal, f"{name} did not use Metal")
            report["runs"][name] = {**result, "adapter": metal}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(report["errors"][-1], flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"] and report["runs"], "\n".join(report["errors"]) or "No matching journey")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
