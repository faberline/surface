#!/usr/bin/env python3
"""Exercise responsive Material Search and capture the Metal Gallery window."""

import argparse
import json
from pathlib import Path
import runpy
import subprocess
import time
import traceback


HERE = Path(__file__).resolve().parent
BASELINE = HERE.parents[1] / "surface-md3-range-slider.1jfmha/native-range-slider"
BASE = runpy.run_path(str(BASELINE / "verify-native-range-slider.py"))
RAW = runpy.run_path(str(BASELINE / "audit-native-range-slider.py"))
MAC = runpy.run_path(str(HERE / "read-native-search-ax.py"))
RADIO, COMMON, MOTION = (BASE[name] for name in ("RADIO", "COMMON", "MOTION"))
capture, center, close, contains, focus, key, node, pixels_for, rect, require, color_matches = (
    BASE[name] for name in ("capture", "center", "close", "contains", "focus", "key", "node",
                            "pixels_for", "rect", "require", "color_matches")
)
PANEL = "search-view"
CARD, TITLE, OPEN, CLOSE, DIRECTION, SCALE, QUERY, CLEAR, LEADING, RESULTS, EMPTY, SELECTION = (
    PANEL + "-" + name for name in ("card", "title", "open", "close", "direction", "scale",
                                   "field-input", "field-clear", "field-leading", "results",
                                   "empty", "selection")
)
PREFIX = PANEL + "-result-"
visible_geometry = capture.__globals__["geometry"]
DEFAULT = ("daan-park", "museum", "zoo", "library", "park-228", "creek", "market",
           "station", "observatory", "garden", "riverside", "trail")
FILTERED = ("daan-park", "park-228", "riverside")
HINT = "輸入地點"
MARKED = "ㄍㄨㄥ ㄩㄢˊ"
LONG_MARKED = "ㄍㄨㄥ ㄩㄢˊ ㄉㄚˋ ㄢ ㄍㄨㄥ ㄩㄢˊ ㄊㄞˊ ㄅㄟˇ ㄕˋ"
MATCH = "公園"
ABSENT = "此處沒有這項結果"
PICKED = "已選擇二二八和平紀念公園"
PROFILES = {
    "wide-light-ltr": (False, False, 1., False),
    "wide-dark-rtl": (True, True, 1., False),
    "compact-light-ltr-2x": (False, False, 2., True),
    "compact-dark-rtl-2x": (True, True, 2., True),
}
EXPECTED_STAGES = {
    "closed", "open", "disabled-tap", "skip-disabled", "preedit", "guarded-enter", "committed",
    "clear", "long-preedit", "cancelled-preedit", "result-scroll", "no-match", "highlight-choice",
    "short-after-long", "ime-replacement", "chosen", "reopened", "dismissed",
}


def ids(snapshot):
    return COMMON["dom_index"](snapshot)[1]


def tap(case, stable):
    snapshot = case.snapshot()
    geometry = visible_geometry(snapshot, stable)
    require(geometry["fully_visible"], f"Cannot tap a partly hidden fixture control: {stable} {geometry}")
    target = center(rect(snapshot, stable))
    case.point("down", target)
    case.point("up", target)


def ime(case, event, text=""):
    receipt = case.call("action", "qa-ime", event, text)
    require(receipt == {"posted": True, "route": "WindowEvent::Ime"}, f"Unexpected Winit IME reply: {receipt}")


def resize(case, size):
    require(case.call("action", "qa-resize", *map(str, size))["requested"] == list(size),
            "Native window did not accept resize")
    deadline = time.monotonic() + 8.
    while True:
        viewport = case.snapshot()["layout"]["viewport"]
        if (round(viewport["width"]), round(viewport["height"])) == size:
            case.size = size
            return
        require(time.monotonic() < deadline, f"Native resize did not reach {size}: {viewport}")
        time.sleep(.05)


def live_query(case, expected, disabled_name=None, status_name=None):
    names = {"搜尋地點"} | {name for name in (disabled_name, status_name) if name}
    deadline = time.monotonic() + 4.
    while True:
        tree = MAC["read_named"](case.child.pid, names)
        controls = tree["controls"]
        query = [item for item in controls if item["name"] == "搜尋地點"
                 and item["role"] in ("AXTextField", "AXSearchField")]
        disabled = [item for item in controls if item["name"] == disabled_name and item["enabled"] is False]
        status = [item for item in controls if item["name"] == status_name]
        if (tree["trusted"] and len(query) == 1 and (query[0]["value"] or "") == expected
                and (not disabled_name or disabled) and (not status_name or status)):
            return {"query": query[0], "disabled": disabled, "status": status}
        require(time.monotonic() < deadline, f"Live Gallery AX did not match query or results: {tree}")
        time.sleep(.08)


def query_paint(receipt, query):
    return [entry["op"]["Legacy"]["StyledText"] for entry in receipt["attributed"]["ops"]
            if entry["owner"]["id"] == QUERY and
            entry["op"].get("Legacy", {}).get("StyledText", {}).get("text") == query]


def glyph_samples(rect, marks):
    return {
        (x, y) for x, y in RADIO["sample_points"](rect)
        if not any(mark["x"] - 1. <= x < mark["x"] + mark["width"] + 1.
                   and mark["y"] - 1. <= y < mark["y"] + mark["height"] + 1.
                   for mark in marks)
    }


def foreground_quads(receipt, color):
    return [
        quad["rect"] for entry in receipt["attributed"]["ops"]
        if entry["owner"]["id"] == QUERY
        for quad in [entry["op"].get("Legacy", {}).get("Quad")]
        if quad and quad["color"] == color
    ]


def take(case, tag, rtl, scale, query=None, *, result_keys=DEFAULT, highlighted=None,
         marked=None, focused=QUERY, os_ax=False, selected=False):
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{tag}",
                              case.size, case.dark, BASE["SECTION"], (QUERY,) if query is not None else (OPEN,))
    require(not frame["errors"], str(frame["errors"]))
    receipt = json.loads(case.receipt.read_text())
    index = ids(snapshot)
    actual_focus = snapshot["interaction"]["focused"]
    expanded = node(snapshot, OPEN).get("expanded")
    if expanded is None:
        expanded = node(snapshot, OPEN).get("expanded_state")
    require(expanded is (query is not None), "Search opener did not report its expanded state")
    frame.update(stage=tag, rtl=rtl, text_scale=scale, focus=actual_focus, query=query,
                 opener_expanded=expanded)
    if query is None:
        require(PANEL not in index and QUERY not in index, "Search stayed open")
        require(actual_focus == focused, f"Expected opener focus {focused}, got {actual_focus}")
        title = node(snapshot, SELECTION)["text"] if SELECTION in index else None
        require(title == (PICKED if selected else None), f"Unexpected selection: {title}")
        frame["selection"] = title
    else:
        require(PANEL in index and (SELECTION in index) is selected, "Search closed or chose a result early")
        if focused is not None:
            require(actual_focus == focused, f"Expected focus {focused}, got {actual_focus}")
        require(node(snapshot, QUERY)["text"] == query, "Composing text changed the committed query")
        editor = receipt["editor"]
        require(editor["value"] == query and editor["composing"] is (marked is not None)
                and (editor["preedit"] or None) == marked,
                f"Query editor state differs: {editor}")
        panel, editor_box, leading, close_box = (
            rect(snapshot, stable) for stable in (PANEL, QUERY, LEADING, CLOSE)
        )
        viewport = frame["viewport"]
        require(contains(viewport, panel) and contains(panel, editor_box), "Search escapes the viewport")
        mode = "expanded" if case.size[0] == 320 else "docked"
        if mode == "expanded":
            require(BASE["same_rect"](panel, viewport), "Compact search is not expanded to the viewport")
        else:
            close(panel["width"], 480., "Docked search width")
        require(editor_box["width"] >= 48. and editor_box["height"] >= 48., "Editor hit size too small")
        require((center(leading)[0] > center(editor_box)[0]) is rtl, "Search leading slot did not mirror")
        require((center(close_box)[0] > center(editor_box)[0]) is rtl, "Back slot did not mirror")
        if query:
            clear = rect(snapshot, CLEAR)
            require(clear["width"] == clear["height"] == 48.
                    and (center(clear)[0] < center(editor_box)[0]) is rtl, "Clear slot width or direction")
        else:
            require(CLEAR not in index, "Empty query still has a Clear stop")

        actual_rows = tuple(stable[len(PREFIX):] for stable in index if stable.startswith(PREFIX))
        require(actual_rows == result_keys, f"Expected rows {result_keys}, got {actual_rows}")
        palette = case.plan.palette["dark" if case.dark else "light"]
        active_rows = [stable for stable in index if stable.startswith(PREFIX) and
                       node(snapshot, stable)["style"]["background"] == palette["secondary_container"]]
        require(active_rows == ([PREFIX + highlighted] if highlighted else []), f"Active query row: {active_rows}")
        ax = receipt["accesskit"]["nodes"]
        ax_query, ax_panel = ax[QUERY], ax[PANEL]
        require((ax_panel["role"], ax_panel["name"]) == ("Dialog", "搜尋地點")
                and (ax_query["role"], ax_query["name"]) == ("TextInput", "搜尋地點")
                and (ax_query["text_value"] or "") == query,
                "The native search scope, query name or value differs")
        if not result_keys:
            require(ax[EMPTY]["role"] == "Status" and ax[EMPTY]["name"] == "找不到地點",
                    "Empty state missing native status semantics")
        if "zoo" in result_keys and PREFIX + "zoo" in ax:
            zoo = ax[PREFIX + "zoo"]
            require(zoo["disabled"] and not zoo["focusable"] and not zoo["press"], "Disabled row accepted native action")

        shown = (marked or query) or HINT
        text = query_paint(receipt, shown)
        require(len(text) == 1, f"Expected one rendered query or hint {shown!r}; actual {text}")
        text = text[0]
        close(text["style"]["font_size"], 16. * scale, "Actual query text size")
        close(text["rect"]["height"], 24. * scale, "Single-line query paint area")
        close(editor_box["height"], 24. * scale + 24., "Stable single-line editor height")
        require(text["editable"] is bool(marked or query), "Visual hint is part of editable paint")
        quads = foreground_quads(receipt, text["color"])
        sample = glyph_samples(text["rect"], quads)
        pixels = pixels_for(case.plan.artifacts / frame["file"], frame, sample)
        ink_pixels = sum(color_matches(value, text["color"], 22) for value in pixels.values())
        if not case.plan.accept_clipped_diagnostics:
            require(ink_pixels >= 8, f"Metal query or hint painted no glyphs in {tag}: {text}")
            if tag in ("short-after-long", "highlight-choice", "ime-replacement"):
                require(text["scroll"] == [0., 0.] and ink_pixels >= 40,
                        f"Fitting short query is clipped in {tag}: {text}, {ink_pixels} pixels")
        frame.update(mode=mode, panel=panel, result_rows=actual_rows, highlighted=highlighted,
                     composing=editor, native_query=ax_query, native_panel=ax_panel, scroll=receipt["scroll"],
                     query_font_dp=text["style"]["font_size"], paint_text=shown, ink_pixels=ink_pixels,
                     paint_rect=text["rect"], paint_ink=text["color"], editor_rect=editor_box,
                     results_top=rect(snapshot, RESULTS)["y"], text_scroll=text["scroll"],
                     foreground_quads=quads, frame_time_ms=case.clock.now)
        if os_ax and case.plan.verify_os_ax:
            disabled_name = node(snapshot, PREFIX + "zoo")["name"] if "zoo" in result_keys else None
            frame["os_ax"] = live_query(case, query, disabled_name,
                                        "找不到地點" if not result_keys else None)
    case.frames.append(frame)
    return frame


def journey(case, rtl, scale, compact):
    case.call("action", "activate", BASE["SECTION"])
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2.:
        case.call("action", "activate", SCALE)
    case.point("leave")
    RADIO["reveal"](case, CARD)
    focus(case, OPEN)

    def picture(tag, query=None, **arguments):
        case.clock.advance(250)
        return take(case, tag, rtl, scale, query, **arguments)

    picture("closed", focused=OPEN)
    tap(case, OPEN)
    picture("open", "", os_ax=True)
    tap(case, PREFIX + "zoo")
    picture("disabled-tap", "", focused=None)
    focus(case, QUERY)
    for _ in range(3):
        key(case, "down", QUERY)
    picture("skip-disabled", "", highlighted="library")

    ime(case, "enabled")
    ime(case, "preedit", MARKED)
    picture("preedit", "", highlighted="library", marked=MARKED)
    key(case, "enter", QUERY)
    picture("guarded-enter", "", highlighted="library", marked=MARKED)
    ime(case, "preedit")
    key(case, "down", QUERY)
    key(case, "enter", QUERY)
    ime(case, "commit", MATCH)
    picture("committed", MATCH, result_keys=FILTERED, os_ax=True)

    mcp = None
    if compact:
        resize(case, (320, 640))
        expanded = picture("expanded", MATCH, result_keys=FILTERED, os_ax=True)
        if rtl and case.dark:
            mirror = MOTION["MOTION"]["check_mcp"](case.plan, case.plan.client, case.session, case.size)
            first, second = (case.plan.artifacts / item["file"] for item in (expanded, mirror))
            require(first.read_bytes() == second.read_bytes(), "Compact search CLI and MCP differ")
            mcp = {**mirror, "cli": expanded["file"]}

    tap(case, CLEAR)
    clear = picture("clear", "")
    ime(case, "enabled")
    ime(case, "preedit", LONG_MARKED)
    long_preedit = picture("long-preedit", "", marked=LONG_MARKED)
    ime(case, "disabled")
    cancelled = picture("cancelled-preedit", "")
    results = center(rect(case.snapshot(), RESULTS))
    case.point("scroll", results, 2000.)
    scrolled = picture("result-scroll", "")
    require(scrolled["scroll"]["offset"][1] > 0. and scrolled["scroll"]["at_bottom"],
            "Long result viewport did not scroll to the end")
    require(visible_geometry(case.snapshot(), PREFIX + "trail")["fully_visible"],
            "The last search result is still clipped")

    case.call("action", "fill", QUERY, ABSENT)
    no_match = picture("no-match", ABSENT, result_keys=(), os_ax=True)
    require(all(frame["results_top"] - frame["panel"]["y"] == clear["results_top"] - clear["panel"]["y"]
                and frame["editor_rect"]["height"] == clear["editor_rect"]["height"]
                for frame in (long_preedit, cancelled, scrolled, no_match)),
            "Long query text moved the results header")
    case.call("action", "fill", QUERY, MATCH)
    picture("short-after-long", MATCH, result_keys=FILTERED)
    case.call("action", "fill", QUERY, ABSENT)
    key(case, "home", QUERY)
    key(case, "end", QUERY, shift=True)
    ime(case, "enabled")
    ime(case, "preedit", MARKED)
    ime(case, "commit", MATCH)
    picture("ime-replacement", MATCH, result_keys=FILTERED)
    key(case, "down", QUERY)
    key(case, "down", QUERY)
    picture("highlight-choice", MATCH, result_keys=FILTERED, highlighted="park-228")
    key(case, "enter", OPEN)
    picture("chosen", focused=OPEN, selected=True)
    tap(case, OPEN)
    picture("reopened", MATCH, result_keys=FILTERED, selected=True)
    key(case, "escape", OPEN)
    picture("dismissed", focused=OPEN, selected=True)
    return mcp


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile", action="append", choices=PROFILES)
    parser.add_argument("--startup-timeout", type=int, default=45)
    parser.add_argument("--verify-os-ax", action="store_true")
    parser.add_argument("--accept-clipped-diagnostics", action="store_true")
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    if plan.verify_os_ax:
        require(MAC["AX"]["trusted"](), "Native Accessibility permission is required for OS reads")
    report = {"capture": "Surface Page.screenshot", "ime_input": "Injected Winit WindowEvent::Ime",
              "os_ax_requested": plan.verify_os_ax, "runs": {}, "frames": [], "errors": [],
              "accept_clipped_diagnostics": plan.accept_clipped_diagnostics}
    for name, (dark, rtl, scale, compact) in PROFILES.items():
        if plan.profile and name not in plan.profile:
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, (960, 800), dark) as case:
                mcp = journey(case, rtl, scale, compact)
            log = (plan.artifacts / f"{name}.log").read_text()
            adapter = next((line for line in log.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in adapter and "backend: Metal" in adapter, "Expected native Apple Metal")
            report["runs"][name] = {"mcp": mcp, "adapter": adapter}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            traceback.print_exc()
        finally:
            if case:
                report["frames"].extend(case.frames)
    BASE["write_json"](plan.artifacts / "report.json", report)
    require(report["runs"] and not report["errors"], "\n".join(report["errors"]) or "No matching profile")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
