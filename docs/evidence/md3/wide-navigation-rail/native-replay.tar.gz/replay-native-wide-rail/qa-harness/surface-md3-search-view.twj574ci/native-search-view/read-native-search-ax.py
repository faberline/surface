"""Read named controls in the private Gallery PID through macOS Accessibility."""

from pathlib import Path
import runpy


I = Path(__file__).resolve().parents[2] / "surface-md3-slider-indicators.cpa7nxei/native-slider-indicators"
AX = runpy.run_path(str(I / "read-native-slider-ax.py"))


def ax_bool(element, name):
    status, value = AX["ax_attribute"](element, name)
    if status != 0 or not value:
        return None
    try:
        import ctypes

        kind = AX["bind"](AX["FOUNDATION"], "CFBooleanGetTypeID", ctypes.c_ulong)
        read = AX["bind"](AX["FOUNDATION"], "CFBooleanGetValue", ctypes.c_bool, AX["PTR"])
        return read(value) if AX["type_id"](value) == kind() else None
    finally:
        AX["release"](value)


def read_named(pid, names):
    if not AX["trusted"]():
        return {"trusted": False, "controls": []}
    app = AX["create_application"](pid)
    controls = []
    visited = 0

    def walk(element, depth=0):
        nonlocal visited
        visited += 1
        if visited > 2000 or depth > 32:
            raise RuntimeError("Private Gallery AX tree exceeded the probe budget")
        scalar = AX["scalar"]
        role = scalar(element, "AXRole")
        roles = ("AXTextField", "AXSearchField", "AXGroup", "AXWindow", "AXScrollArea",
                 "AXButton", "AXStaticText", "AXList", "AXRow")
        if role in roles:
            labels = [scalar(element, name) for name in ("AXTitle", "AXDescription", "AXLabel")]
            value = scalar(element, "AXValue")
            name = next((item for item in labels if item in names), None)
            if name is None and role == "AXStaticText" and value in names:
                name = value
            if name:
                controls.append({"name": name, "role": role, "value": value,
                                 "enabled": ax_bool(element, "AXEnabled")})
        status, children = AX["ax_attribute"](element, "AXChildren")
        if status != 0 or not children:
            return
        try:
            if AX["type_id"](children) == AX["array_type"]():
                for index in range(AX["array_count"](children)):
                    walk(AX["array_item"](children, index), depth + 1)
        finally:
            AX["release"](children)

    try:
        AX["set_timeout"](app, 1.)
        status, windows = AX["ax_attribute"](app, "AXWindows")
        if status != 0 or not windows:
            return {"trusted": True, "window_status": status, "controls": controls}
        try:
            for index in range(AX["array_count"](windows)):
                walk(AX["array_item"](windows, index))
        finally:
            AX["release"](windows)
    finally:
        AX["release"](app)
    return {"trusted": True, "window_status": 0, "visited": visited, "controls": controls}
