#!/usr/bin/env python3
"""Verify Material list paint, layout, and accessibility on native Metal."""

import argparse
import json
import math
from pathlib import Path
import runpy
import subprocess

HERE = Path(__file__).resolve().parent
SHARED = runpy.run_path(str(HERE.parents[1] / "surface-md3-badged-anchor.3d4V71"
                             / "native-badged-anchor" / "verify-native-badge.py"))
COMMON, MOTION, QA = (SHARED[key] for key in ("COMMON", "MOTION", "QA"))
capture, close, color_matches, contains, focus, geometry, key, node, pixels_for, require, same_rect, sample_points, write_json = (
    SHARED[key] for key in ("capture", "close", "color_matches", "contains", "focus",
                           "geometry", "key", "node", "pixels_for", "require", "same_rect",
                           "sample_points", "write_json")
)
reject = SHARED["SHARED"]["reject"]
SECTION = "section-5"
PREFIX = "list-options-"
LIST, STATIC, ACTIVE, DISABLED, DIVIDERS, DIRECTION, SCALE, STATUS = (
    PREFIX + part for part in ("rows", "static", "current", "disabled", "divider-toggle",
                                "direction", "text-scale", "status")
)
ACTIVE_NAME = "專案訊息，新，閱讀專案的最新回覆與待辦事項。開啟"
ROWS = {
    STATIC: (56., {"headline": "今日摘要", "trailing": "3 則"}),
    ACTIVE: (72., {"leading": "新", "headline": "專案訊息", "supporting": "閱讀專案的最新回覆與待辦事項。", "trailing": "開啟"}),
    DISABLED: (88., {"leading": "舊", "overline": "歷史", "headline": "封存清單", "supporting": "此分類僅供查閱。", "trailing": "停用"}),
}
VIEWPORTS, PROFILES = SHARED["VIEWPORTS"], SHARED["PROFILES"]
TEXT_METRICS = {"headline": (16., 24.), "supporting": (14., 20.)}


def expect_count(case, count):
    status = node(case.snapshot(), STATUS)
    value = status["text"] or status["name"]
    require(value == f"已開啟 {count} 次", f"Expected {count} openings. Got {value!r}")


def rect(snapshot, id):
    return geometry(snapshot, id)[2]


def center(box):
    return box["x"] + box["width"] / 2., box["y"] + box["height"] / 2.


def row_layout(case, snapshot, item, rtl, scale, dividers):
    minimum, labels = ROWS[item]
    list_box = rect(snapshot, LIST)
    item_box = rect(snapshot, item)
    row = rect(snapshot, item + "-row")
    slots = {slot: rect(snapshot, item + "-" + slot) for slot in labels}
    require(row["height"] >= minimum and close_width(list_box, row), f"{item}: row misses its minimum or width {row}")
    if case.size[0] == 960 and scale == 1:
        close(row["height"], minimum, f"{item}: wide Material minimum")
    if case.size[0] == 320:
        close(row["width"], 264., f"{item}: narrow list width")
    for slot, box in slots.items():
        require(box["width"] > 0. and box["height"] > 0. and contains(row, box),
                f"{item}-{slot}: text slot leaves its row: {box}")

    reading_order = [slot for slot in ("leading", "headline", "trailing") if slot in slots]
    physical_order = sorted(reading_order, key=lambda slot: slots[slot]["x"])
    require(physical_order == (reading_order[::-1] if rtl else reading_order),
            f"{item}: side slots did not mirror: {physical_order}")
    side_start, side_end = slots[physical_order[0]], slots[physical_order[-1]]
    close(side_start["x"] - row["x"], 16., f"{item}: left content inset")
    close(row["x"] + row["width"] - side_end["x"] - side_end["width"], 16., f"{item}: right content inset")
    for first, last in zip(physical_order, physical_order[1:]):
        close(slots[last]["x"] - slots[first]["x"] - slots[first]["width"], 16., f"{item}: side slot gap")
    body = [slots[slot] for slot in ("overline", "headline", "supporting") if slot in slots]
    for top, bottom in zip(body, body[1:]):
        require(top["y"] + top["height"] <= bottom["y"] + .03, f"{item}: text blocks overlap")
    if row["height"] >= 88.:
        top = row["y"] + (12. if minimum >= 88. else 8.)
        for box in [body[0], *(slots[id] for id in ("leading", "trailing") if id in slots)]:
            close(box["y"], top, f"{item}: tall row content aligns at the top")

    divider = None
    _, ids = COMMON["dom_index"](snapshot)
    divider_id = item + "-divider"
    if dividers and item != DISABLED:
        divider = rect(snapshot, divider_id)
        close(divider["y"], row["y"] + row["height"], f"{item}: divider lies below the hit area")
        close(divider["height"], 1., f"{item}: divider thickness")
        close(divider["x"] - row["x"], 0. if rtl else 16., f"{item}: divider physical left inset")
        close(row["x"] + row["width"] - divider["x"] - divider["width"],
              16. if rtl else 0., f"{item}: divider physical right inset")
    else:
        require(divider_id not in ids, f"{item}: unexpected divider")
    close(item_box["height"], row["height"] + (1. if divider else 0.), f"{item}: item includes decoration height")
    return row, slots, divider


def close_width(list_box, row):
    return abs(list_box["width"] - row["width"]) <= .03 and abs(list_box["x"] - row["x"]) <= .03


def verify_accessibility(case, snapshot, receipt, item):
    tree = receipt["accesskit"]
    native = tree["nodes"]
    require(native[LIST]["role"] == "List" and native[LIST]["name"] == "訊息清單",
            "The outer list lost its localized role/name")
    require(not any(id.endswith("-divider") for id in native), "Decorative inset entered the native tree")
    outer = native[item]
    row = native[item + "-row"]
    require(outer["role"] == "ListItem" and not outer["focusable"] and not outer["press"],
            f"{item}: outer list item became an extra target")
    enabled = item == ACTIVE
    disabled = item == DISABLED
    wanted = ACTIVE_NAME if enabled else ROWS[item][1]["headline"]
    require(row["role"] == ("GenericContainer" if item == STATIC else "Button")
            and row["name"] == wanted and row["press"] is enabled and row["focusable"] is enabled
            and row["disabled"] is disabled
            and row["focused"] is (snapshot["interaction"]["focused"] == item + "-row"),
            f"{item}: incorrect named row projection: {row}")
    names = [child["name"] for child in tree["viewport_subtree"] if child["name"]]
    if enabled:
        require(outer["name"] is None and names.count(wanted) == 1,
                "Action row publishes more than one spoken description")
    texts = {}
    for suffix, body in ROWS[item][1].items():
        slot_id = item + "-" + suffix
        if enabled:
            require(slot_id not in native, f"{slot_id}: combined name duplicated in child text")
        else:
            text = native[slot_id]
            require(text["role"] == "Label" and text["name"] == body and not text["press"] and not text["focusable"],
                    f"{slot_id}: static or disabled text lost readable semantics")
            texts[suffix] = text
    require(sum(child["press"] for child in tree["viewport_subtree"]) <= 1,
            "Additional active row inside the list")
    return {"list": native[LIST], "item": outer, "row": row, "text": texts}


def paint_entries(receipt, kinds):
    return [tile for op in receipt["presented"]["ops"]
            for kind, tile in op.get("Legacy", {}).items() if kind in kinds]


def blend(background, front, alpha):
    return [math.floor(a * (1. - alpha) + b * alpha + .5) for a, b in zip(background, front)]


def visible_ink(color, foreground, background):
    strongest = max(range(3), key=lambda channel: abs(foreground[channel] - background[channel]))
    axis = foreground[strongest] - background[strongest]
    amount = (color[strongest] - background[strongest]) / axis
    return .28 <= amount <= 1.15


def glyph_bands(box, line_height):
    count = max(1, round(box["height"] / line_height))
    bands = []
    for i in range(count):
        top, bottom = box["y"] + i * line_height, box["y"] + (i + 1) * line_height
        bands.append(sample_points({**box, "y": top, "height": bottom - top}))
    return bands


def verify_rendering(case, frame, receipt, item, row, slots, divider, rtl, scale):
    palette = case.plan.palette["dark" if case.dark else "light"]
    bg = palette["surface"]
    main = palette["on_surface"]
    secondary = palette["on_surface_variant"]
    if item == DISABLED:
        main = blend(bg, main, .30)
        secondary = blend(bg, palette["on_surface"], .38)
    runs = paint_entries(receipt, ("Text", "StyledText"))
    fills = paint_entries(receipt, ("Quad", "Shape"))
    require(any(fill["color"] == bg and same_rect(fill["rect"], row) for fill in fills),
            f"{item}: list row surface was not painted")
    checked = {}
    for slot, box in slots.items():
        words = ROWS[item][1][slot]
        foreground = main if slot == "headline" else secondary
        font, height = TEXT_METRICS.get(slot, (11., 16.))
        paint = [run for run in runs if run["text"] == words and same_rect(run["rect"], box)]
        require(len(paint) == 1 and contains(paint[0]["clip"], box) and paint[0]["color"] == foreground,
                f"{item}-{slot}: missing, clipped, or wrong color for {words!r}")
        text_style = paint[0]["style"]
        close(text_style["font_size"], font * scale, f"{item}-{slot}: scaled font size")
        close(text_style["line_height"], height * scale, f"{item}-{slot}: scaled line height")
        checked[slot] = {"foreground": foreground, "bands": glyph_bands(box, height * scale)}

    divider_checks = None
    if divider:
        outline = palette["outline_variant"]
        require(any(fill["color"] == outline and same_rect(fill["rect"], divider) for fill in fills),
                f"{item}: no themed divider at its measured bounds")
        scan = range(math.floor(divider["y"]), math.ceil(divider["y"] + divider["height"]))
        mid_x = math.floor(center(divider)[0])
        gap_x = math.floor(row["x"] + (row["width"] - 8. if rtl else 8.))
        divider_checks = ({(mid_x, y) for y in scan}, {(gap_x, y) for y in scan})
    point_sets = [points for entry in checked.values() for points in entry["bands"]]
    if divider_checks:
        point_sets.extend(divider_checks)
    values = pixels_for(case.plan.artifacts / frame["file"], frame, set.union(*point_sets))
    ink = {}
    for slot, entry in checked.items():
        counts = [sum(visible_ink(values[point], entry["foreground"], bg) for point in band) for band in entry["bands"]]
        require(all(count >= 4 for count in counts), f"{item}-{slot}: blank or clipped glyph run {counts}")
        ink[slot] = {"line_bands": len(counts), "sampled_ink": counts, "foreground": entry["foreground"]}
    if item == ACTIVE and case.size[0] == 320 and scale == 2:
        require(ink["supporting"]["line_bands"] >= 2,
                "Native 320 px / 200% supporting CJK text did not wrap")
    if divider_checks:
        stripe, gap = divider_checks
        require(any(visible_ink(values[point], outline, bg) for point in stripe),
                f"{item}: divider ink missing from the actual PNG")
        require(not any(visible_ink(values[point], outline, bg) for point in gap),
                f"{item}: divider painted in the logical inset")
    return {"text": ink, "divider_pixels_checked": bool(divider_checks)}


def take(case, stage, item, rtl, scale, count, dividers=True, focused=False):
    case.clock.advance(700)
    QA["reveal"](case, item)
    needed = (item, item + "-row", *(item + "-" + slot for slot in ROWS[item][1]))
    if dividers and item != DISABLED:
        needed = (*needed, item + "-divider")
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{stage}",
                              case.size, case.dark, SECTION, needed)
    require(not frame["errors"], str(frame["errors"]))
    expect_count(case, count)
    if focused:
        require(snapshot["interaction"]["focused"] == item + "-row", "Active row lost native keyboard focus")
    receipt = json.loads(case.receipt.read_text())
    row, slots, divider = row_layout(case, snapshot, item, rtl, scale, dividers)
    projection = verify_accessibility(case, snapshot, receipt, item)
    paint = verify_rendering(case, frame, receipt, item, row, slots, divider, rtl, scale)
    frame.update(stage=stage, item=item, rtl=rtl, text_scale=scale, activations=count,
                 row=row, divider=divider, slots=slots, axis=projection, paint=paint)
    case.frames.append(frame)
    return frame


def pointer(case, point, before, after):
    case.point("move", point)
    case.point("down", point)
    expect_count(case, before)
    case.point("up", point)
    case.point("leave")
    expect_count(case, after)


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2:
        case.call("action", "activate", SCALE)
    case.point("leave")
    static = take(case, "static", STATIC, rtl, scale, 0)
    pointer(case, center(static["row"]), 0, 0)
    pointer(case, center(static["divider"]), 0, 0)
    reject(case, "press", STATIC + "-row", "no live AccessKit press")
    disabled = take(case, "disabled", DISABLED, rtl, scale, 0)
    pointer(case, center(disabled["row"]), 0, 0)
    reject(case, "focus", DISABLED + "-row", "no live AccessKit focus")
    reject(case, "press", DISABLED + "-row", "no live AccessKit press")
    initial = take(case, "active", ACTIVE, rtl, scale, 0)
    mcp_result = None
    if case.size[0] == 320 and case.dark and rtl and scale == 2:
        mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
        require((case.plan.artifacts / mcp["file"]).read_bytes() ==
                (case.plan.artifacts / initial["file"]).read_bytes(), "CLI and MCP returned different PNG bytes")
        mcp_result = {**mcp, "cli": initial["file"]}
    pointer(case, center(initial["divider"]), 0, 0)
    reject(case, "focus", ACTIVE + "-divider", "no live AccessKit focus")
    reject(case, "press", ACTIVE + "-divider", "no live AccessKit press")
    focus(case, SCALE)
    key(case, "tab", ACTIVE + "-row")
    expect_count(case, 0)
    key(case, "enter", ACTIVE + "-row")
    keyboard = take(case, "keyboard", ACTIVE, rtl, scale, 1, focused=True)
    pointer(case, center(keyboard["row"]), 1, 2)
    pressed = case.call("action", "qa-ax-press", ACTIVE + "-row")
    require(pressed["accesskit"], "Click did not use the AccessKit bridge")
    take(case, "pointer-and-accesskit", ACTIVE, rtl, scale, 3)
    case.call("action", "activate", DIVIDERS)
    without = take(case, "divider-off", ACTIVE, rtl, scale, 3, dividers=False)
    close(without["row"]["height"], initial["row"]["height"], "Divider toggle does not resize the hit target")
    close(without["row"]["width"], initial["row"]["width"], "Divider toggle does not resize the hit target")
    return {"mcp": mcp_result, "input_routes": ["native Tab/Enter", "Winit pointer", "AccessKit Click"],
            "passive_pointer_attempts": 4, "denied_accesskit_requests": 5}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile")
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--startup-timeout", type=int, default=45)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "runs": {}, "frames": [], "errors": []}
    for viewport, theme, direction, scale in PROFILES:
        name = f"{viewport}-{theme}-{direction}-{scale}x"
        if plan.profile not in (None, name) or plan.theme not in (None, theme):
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, VIEWPORTS[viewport], theme == "dark") as case:
                result = journey(case, direction == "rtl", scale)
            log = (plan.artifacts / f"{name}.log").read_text()
            metal = next((line for line in log.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in metal and "backend: Metal" in metal, f"{name} did not use Metal")
            report["runs"][name] = {**result, "adapter": metal}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(report["errors"][-1], flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"] and report["runs"], "\n".join(report["errors"]) or "No matching journey")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
