#!/usr/bin/env python3
"""Exercise native FAB scroll visibility in a held Surface Gallery frame."""

import argparse
import json
import math
from pathlib import Path
import runpy
import subprocess
import time


HERE = Path(__file__).resolve().parent
COMMON = runpy.run_path(str(HERE.parents[1] /
                            "surface-md3-fab-elevation.S4fYhn/native-elevation/verify-native-fab-elevation.py"))
MOTION, BASE = COMMON["MOTION"], COMMON["BASE"]
require = COMMON["require"]
close = COMMON["close"]
dom_index = COMMON["dom_index"]
geometry = COMMON["geometry"]
center = COMMON["center"]

SCROLLER = "fab-visibility-scroll"
BEFORE = "fab-visibility-before"
ACTION = "fab-visibility-action"
AFTER = "fab-visibility-after"
STATUS = "fab-visibility-status"
SCROLLER_NAME = "浮動動作按鈕捲動清單"
ACTION_NAME = "新增項目"
SETTLE = 1200


def expect_absent(case, command, code):
    process = subprocess.run(
        (case.plan.client, "--session", case.session, "action", command, ACTION),
        capture_output=True, text=True, timeout=15,
    )
    error = process.stderr.strip()
    require(process.returncode == 1 and error.startswith(f"error: {code}:"),
            f"{ACTION} did not reject {command} on the native host: {error} {process.stdout}")
    return error


def bounds_for(snapshot, stable_id):
    return geometry(snapshot, stable_id)[2]


def reveal(case):
    for _ in range(12):
        snapshot = case.snapshot()
        _, _, bounds, visible = geometry(snapshot, SCROLLER)
        bottom = bounds["y"] + bounds["height"]
        if visible == bounds and bounds["y"] >= 5 and bottom <= case.size[1] - 6:
            return
        preferred = (case.size[1] - bounds["height"]) / 2
        # This lies in the outer Gallery gutter, outside the nested list.
        case.point("scroll", (bounds["x"] - 4, case.size[1] / 2), bounds["y"] - preferred)
    raise RuntimeError(f"Could not reveal the entire scroller: {bounds}, visible {visible}")


def scroll(case, delta):
    viewport = bounds_for(case.snapshot(), SCROLLER)
    case.point("scroll", (viewport["x"] + 14, center(viewport)[1]), delta)


def tab(case, expected):
    response = case.call("action", "key", "tab")
    require(response["focused"] == expected, f"Wrong Tab target, expected {expected}: {response}")
    return response


def action_count(snapshot):
    nodes, stable = dom_index(snapshot)
    status = nodes[stable[STATUS]]["text"]
    return int(status.rsplit(" ", 1)[-1])


def take(case, name, available, *, pose=None, focused=None, offset=None):
    label = f"{case.prefix}-{name}"
    captured, snapshot = COMMON["COMMON"]["capture"](
        case.plan, case.plan.client, case.session, label, case.size, case.dark, COMMON["SECTION"],
    )
    nodes, stable, rect, clipped = geometry(snapshot, ACTION)
    require(not captured["errors"], f"{label}: {captured['errors']}")
    require(rect == clipped, f"{label}: FAB is clipped: {rect}, {clipped}")
    require(nodes[stable[ACTION]]["role"] == "Button" and nodes[stable[ACTION]]["name"] == ACTION_NAME,
            f"{label}: wrong action name or role")
    require(nodes[stable[SCROLLER]]["role"] == "List"
            and nodes[stable[SCROLLER]]["name"] == SCROLLER_NAME, f"{label}: wrong list semantics")
    viewport = bounds_for(snapshot, SCROLLER)
    for dimension in ("width", "height"):
        close(rect[dimension], 56., f"{label}: stable layout {dimension}")
    close(viewport["height"], 128., f"{label}: stable viewport height")
    for coordinate, dimension in (("x", "width"), ("y", "height")):
        close(viewport[coordinate] + viewport[dimension] - rect[coordinate] - rect[dimension],
              12., f"{label}: fixed {coordinate} inset")

    receipt = json.loads(case.receipt.read_text())
    projected = receipt["projected"]
    actual = projected.get(ACTION, {})
    require(receipt["accessibility_frame"] and projected[SCROLLER]["focusable"],
            f"{label}: scroll region lacks native keyboard focus")
    require(bool(actual.get("focusable")) == available and bool(actual.get("press")) == available,
            f"{label}: unavailable action was reachable, or available action was lost: {actual}")
    actual_focus = snapshot["interaction"]["focused"]
    if focused:
        require(actual_focus == focused and projected[focused]["focused"],
                f"{label}: expected focus {focused}, got {actual_focus}")
    if offset is not None:
        close(receipt["scroll"]["offset"][1], offset, f"{label}: nested offset")

    require(receipt["attributed"]["schema"] == "surface.paint.v6", f"{label}: missing layer export")
    owned = {stable[ACTION], *BASE["descendants"](nodes, stable[ACTION])}
    paints = [item["op"] for item in receipt["attributed"]["ops"] if item["owner"]["node"] in owned]
    layers = [op["Layer"] for op in paints if "Layer" in op]
    presented = [op["Layer"] for op in receipt["presented"]["ops"] if "Layer" in op]
    require(layers == presented, f"{label}: the attributed layer differs from actual native paint")
    require(len(layers) <= 1, f"{label}: FAB subtree split into separate compositing groups")
    if available:
        require(paints and not layers, f"{label}: settled shown FAB failed to paint")
    if pose == "hidden":
        require(not paints, f"{label}: hidden FAB still paints")
    if pose == "motion":
        require(len(layers) == 1 and len(layers[0]["ops"]) >= 2,
                f"{label}: missing composed in-flight FAB face and glyph")
    layer = layers[0]["layer"] if layers else None
    if layer:
        original = [rect["x"] + rect["width"], rect["y"] + rect["height"]]
        for component in range(2):
            close(layer["origin"][component], original[component], f"{label}: bottom/end transform origin")
        require(0. < layer["opacity"] <= 1. and layer["scale"] > 0., f"{label}: invalid pose {layer}")

    evidence = case.plan.artifacts / f"{label}.presentation.json"
    MOTION["write_json"](evidence, {
        "layers": presented, "action_ops": paints, "accessibility": projected, "scroll": receipt["scroll"],
    })
    captured.update(time_ms=case.clock.now, state=name, target=rect, viewport=viewport,
                    scroll=receipt["scroll"], projected=actual, focused=actual_focus,
                    layer=layer, wants_frame=receipt["wants_frame"], actions=action_count(snapshot),
                    fill=nodes[stable[ACTION]]["style"]["background"], presentation=evidence.name)
    case.frames.append(captured)
    return captured


def crop_delta(case, current, reference):
    require(current["scroll"]["offset"] == reference["scroll"]["offset"], "Compare matching list positions")
    first, second = current["target"], reference["target"]
    require((first["width"], first["height"]) == (second["width"], second["height"]),
            "FAB layout changed between PNGs")
    # Restrict comparisons to the stable target. The reference is the same
    # list position. Normalize to the FAB origin if Tab scrolled the outer page.
    width, height = math.floor(first["width"]), math.floor(first["height"])
    def points(rect):
        x0, y0 = round(rect["x"]), round(rect["y"])
        return [(x0 + x, y0 + y) for y in range(height) for x in range(width)]
    left_points, right_points = points(first), points(second)
    left = MOTION["png_pixels"](case.plan.artifacts / current["file"], current, left_points)
    right = MOTION["png_pixels"](case.plan.artifacts / reference["file"], reference, right_points)
    deltas = [sum(abs(a - b) for a, b in zip(left[p][:3], right[q][:3]))
              for p, q in zip(left_points, right_points)]
    solid = sum(max(abs(a - b) for a, b in zip(left[p][:3], current["fill"][:3])) <= 3
                for p in left_points)
    return {"pixels_changed": sum(delta >= 7 for delta in deltas), "delta_total": sum(deltas),
            "solid_fill_pixels": solid}


def phase(case, name, elapsed, pose, offset, *, available=False):
    case.clock.advance(elapsed)
    return take(case, name, available, pose=pose, focused=SCROLLER, offset=offset)


def full_motion(case):
    reveal(case)
    case.call("action", "qa-ax-focus", SCROLLER)
    shown = take(case, "shown", True, focused=SCROLLER, offset=0.)
    for expected in (BEFORE, ACTION, AFTER):
        tab(case, expected)
    # Tab may move the outer page for bottom controls in a short window.
    # Recenter before comparing captures of the same part of the list.
    reveal(case)
    case.call("action", "qa-ax-focus", ACTION)
    scroll(case, 76.)
    hide0 = phase(case, "hide-000", 0, "motion", 76.)
    hide24 = phase(case, "hide-024", 24, "motion", 76.)
    hide42 = phase(case, "hide-042", 18, "motion", 76.)
    check_mcp = case.size == (320, 240) and case.dark
    mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size) if check_mcp else None
    if mcp:
        require(mcp["sha256"] == hide42["sha256"], "Held CLI and MCP PNGs differ")
        mcp["cli_file"] = hide42["file"]
    hidden = phase(case, "hidden", SETTLE, "hidden", 76.)
    require(not hidden["wants_frame"], "Hidden FAB keeps requesting animation frames")
    for sample in (hide0, hide24, hide42):
        sample["pixels"] = crop_delta(case, sample, hidden)
    require(hide0["pixels"]["solid_fill_pixels"] > 1000, "Hide start omitted the settled color")
    for field in ("opacity", "scale"):
        require(hide0["layer"][field] > hide24["layer"][field] > hide42["layer"][field],
                f"Hide {field} does not decrease as the button retracts")
    require(hide0["pixels"]["delta_total"] > hide24["pixels"]["delta_total"]
            > hide42["pixels"]["delta_total"] > 250, "Native hide frames lack visible fade/scale")

    direct = {
        "activate": expect_absent(case, "activate", "outside_modal"),
        "qa-ax-focus": expect_absent(case, "qa-ax-focus", "invalid_params"),
    }
    for expected in (BEFORE, AFTER):
        tab(case, expected)
    old = center(bounds_for(case.snapshot(), ACTION))
    case.point("down", old)
    case.point("up", old)
    require(action_count(case.snapshot()) == hidden["actions"], "Hidden FAB received native click")

    reveal(case)
    case.call("action", "qa-ax-focus", SCROLLER)
    # First get a hidden reference at y=44, then make the same partial return.
    case.call("action", "key", "home")
    case.clock.advance(SETTLE)
    scroll(case, 44.)
    hidden44 = phase(case, "hidden-reference-44", SETTLE, "hidden", 44.)
    scroll(case, 32.)
    scroll(case, -32.)
    entry0 = phase(case, "show-000", 0, "hidden", 44.)
    entry24 = phase(case, "show-024", 24, "motion", 44.)
    entry42 = phase(case, "show-042", 18, "motion", 44.)
    shown44 = phase(case, "shown-at-offset", SETTLE, None, 44., available=True)
    for sample in (entry0, entry24, entry42, shown44):
        sample["pixels"] = crop_delta(case, sample, hidden44)
    require(entry0["pixels"]["delta_total"] == 0 and
            250 < entry24["pixels"]["delta_total"] < entry42["pixels"]["delta_total"]
            < shown44["pixels"]["delta_total"], "Native show frames lack visible fade/scale")
    require(shown44["pixels"]["solid_fill_pixels"] > 1000, "Restored FAB omitted its settled color")
    for field in ("opacity", "scale"):
        require(0 < entry24["layer"][field] < entry42["layer"][field] < 1.,
                f"Show {field} does not increase toward the settled pose")

    scroll(case, 20.)
    leaving = phase(case, "redirect-hide-024", 24, "motion", 64.)
    scroll(case, -20.)
    redirect = phase(case, "redirect-show-000", 0, "motion", 44.)
    for field in ("opacity", "scale"):
        require(math.isclose(leaving["layer"][field], redirect["layer"][field], abs_tol=.0001),
                f"Same-time reversal snapped {field}")
    final = phase(case, "redirect-shown", SETTLE, None, 44., available=True)
    require(crop_delta(case, final, shown44)["delta_total"] == 0,
            "Repeated transition changed the settled FAB pixels")

    case.call("action", "key", "end")
    bottom = phase(case, "keyboard-end", SETTLE, "hidden", None)
    require(bottom["scroll"]["at_bottom"], "End did not scroll the nested list")
    case.call("action", "key", "page_down")
    clamped = phase(case, "keyboard-clamped", 0, "hidden", bottom["scroll"]["offset"][1])
    case.call("action", "key", "home")
    top = phase(case, "keyboard-home", SETTLE, None, 0., available=True)
    require(crop_delta(case, shown, top)["delta_total"] == 0, "Home did not restore the original FAB")
    for expected in (BEFORE, ACTION):
        tab(case, expected)
    case.call("action", "key", "enter")
    entered = take(case, "keyboard-enter", True, focused=ACTION, offset=0.)
    require(entered["actions"] == shown["actions"] + 1, "Keyboard Enter did not activate FAB")
    tab(case, AFTER)
    case.call("action", "key", "enter")
    case.clock.advance(SETTLE)
    jumped = take(case, "jump-bottom", False, pose="hidden", focused=AFTER)
    require(jumped["scroll"]["at_bottom"], "Bottom button did not reach the end of the list")
    case.call("action", "activate", BEFORE)
    case.clock.advance(SETTLE)
    take(case, "jump-top", True, focused=BEFORE, offset=0.)
    return {"mcp": mcp, "rejected": direct, "bottom_clamp": clamped["scroll"],
            "keyboard_actions": [shown["actions"], entered["actions"]]}


def reduced_motion(case):
    reveal(case)
    case.call("action", "qa-ax-focus", SCROLLER)
    shown = take(case, "shown", True, focused=SCROLLER, offset=0.)
    case.call("action", "qa-ax-focus", ACTION)
    scroll(case, 76.)
    hidden = phase(case, "hidden-immediate", 0, "hidden", 76.)
    scroll(case, -76.)
    restored = phase(case, "shown-immediate", 0, None, 0., available=True)
    require(not hidden["wants_frame"] and not restored["wants_frame"], "Reduced Motion scheduled an animation")
    require(crop_delta(case, shown, restored)["delta_total"] == 0, "Reduced Motion restored a changed face")
    return {"immediate": True, "clock_ms": shown["time_ms"]}


def query_ax(case, *arguments):
    return BASE["query_ax"](case.plan.probe, case.child, *arguments)


def wait_ax(case, observe):
    for _ in range(10):
        result = query_ax(case, ACTION_NAME, SCROLLER_NAME)
        if result["active"] and observe(result["matches"]):
            return result
        time.sleep(.1)
    raise RuntimeError(f"Expected AppKit access not observed: {result}")


def live_ax(case):
    reveal(case)
    activated = MOTION["make_active"](case.plan.probe, case.child)
    case.call("action", "qa-ax-focus", ACTION)
    before = take(case, "ax-shown", True, focused=ACTION, offset=0.)
    visible = wait_ax(case, lambda matches: any(
        item["label"] == ACTION_NAME and item["role"] == "AXButton"
        and item["focused"] and item["enabled"] and "AXPress" in item["actions"] for item in matches
    ))
    target = next(item for item in visible["matches"] if item["label"] == ACTION_NAME)
    for axis in ("width", "height"):
        close(target["size"][axis], before["target"][axis], f"AppKit FAB {axis}")
    pressed = query_ax(case, ACTION_NAME, "--press")
    require(pressed.get("pressStatus") == 0, f"AppKit AXPress failed: {pressed}")
    for _ in range(8):
        if action_count(case.snapshot()) == before["actions"] + 1:
            break
        time.sleep(.1)
    else:
        raise RuntimeError("AppKit AXPress did not activate the real button")
    scroll(case, 76.)
    take(case, "ax-hiding", False, pose="motion", focused=SCROLLER, offset=76.)
    hidden = wait_ax(case, lambda matches: (
        not any(item["label"] == ACTION_NAME for item in matches)
        and any(item["label"] == SCROLLER_NAME and item["focused"] for item in matches)
    ))
    phase(case, "ax-hidden", SETTLE, "hidden", 76.)
    scroll(case, -32.)
    phase(case, "ax-showing", 24, "motion", 44.)
    entering = wait_ax(case, lambda matches: not any(item["label"] == ACTION_NAME for item in matches))
    phase(case, "ax-shown-again", SETTLE, None, 44., available=True)
    restored = wait_ax(case, lambda matches: any(
        item["label"] == ACTION_NAME and "AXPress" in item["actions"] for item in matches
    ))
    return {"activation": activated, "visible": visible, "pressed": pressed, "hidden": hidden,
            "entering": entering, "restored": restored}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--probe", type=Path)
    parser.add_argument("--viewport", choices=COMMON["VIEWPORTS"])
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--case", choices=("matrix", "reduced", "ax"), default="matrix")
    parser.add_argument("--startup-timeout", type=int, default=180)
    plan = parser.parse_args()
    if plan.case == "ax" and not plan.probe:
        parser.error("--probe is required for real AppKit accessibility checks")
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    report = {"capture": "Surface Page.screenshot", "scroll_route": "Native Surface Event.Scroll",
              "frames": [], "runs": {}, "errors": []}
    run = {"matrix": full_motion, "reduced": reduced_motion, "ax": live_ax}[plan.case]
    for view, size in COMMON["VIEWPORTS"].items():
        if plan.viewport not in (None, view):
            continue
        for theme in ("light", "dark"):
            if plan.theme not in (None, theme):
                continue
            prefix = f"{view}-{theme}-{plan.case}"
            case = None
            try:
                with COMMON["gallery"](plan, prefix, size, theme == "dark", plan.case == "reduced") as case:
                    report["runs"][prefix] = run(case)
            except (RuntimeError, OSError, KeyError, TypeError, ValueError, subprocess.SubprocessError) as error:
                report["errors"].append(f"{prefix}: {error}")
                print(report["errors"][-1], flush=True)
            finally:
                if case:
                    report["frames"].extend(case.frames)
    MOTION["write_json"](plan.artifacts / "report.json", report)
    require(not report["errors"], "\n".join(report["errors"]))
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} runs")


if __name__ == "__main__":
    main()
