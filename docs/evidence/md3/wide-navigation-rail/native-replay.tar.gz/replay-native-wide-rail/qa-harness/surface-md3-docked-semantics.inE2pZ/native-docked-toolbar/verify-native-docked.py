#!/usr/bin/env python3
"""Verify the docked toolbar on native Metal and the macOS AccessKit bridge."""

import argparse
import json
import math
from pathlib import Path
import runpy
import subprocess


HERE = Path(__file__).resolve().parent
PAIRED = runpy.run_path(str(HERE.parents[1] / "surface-md3-toolbar-fab.MY4AaK"
                           / "native-toolbar-fab" / "verify-native-toolbar-fab.py"))
COMMON, MOTION, QA = (PAIRED[key] for key in ("COMMON", "MOTION", "QA"))
require, close, geometry, capture, same_rect, write_json = (
    PAIRED[key] for key in ("require", "close", "geometry", "capture", "same_rect", "write_json")
)
SECTION = "section-8"
BAR = "docked-toolbar"
PREVIEW, DIRECTION, STATUS, CLEAR, CUT, COPY, PASTE = (
    f"{BAR}-{suffix}" for suffix in ("preview", "direction", "status", "clear", "cut", "copy", "paste")
)
NAMES = {CUT: "剪下", COPY: "複製", PASTE: "貼上"}
CUTOUT_PIXELS = {CUT: ((6., 6.), (6., 18.)), COPY: ((14., 10.),), PASTE: ((17., 16.),)}


def focus(case, id):
    QA["reveal"](case, id)
    if case.snapshot()["interaction"]["focused"] == id:
        return
    result = case.call("action", "qa-ax-focus", id)
    require(result["accesskit"] and result["focused"] == id, f"AccessKit did not focus {id}")


def key(case, name, expected, shift=False):
    modifiers = ("shift",) if shift else ()
    response = case.call("action", "qa-key", name, *modifiers)
    require(response["focused"] == expected, f"Native {name} had wrong focus: {response}")
    return {"key": name, "shift": shift, "focus": response["focused"]}


def status(case):
    nodes, ids = COMMON["dom_index"](case.snapshot())
    return nodes[ids[STATUS]]["text"]


def reject(case, action, id, text):
    result = subprocess.run(
        (case.plan.client, "--session", case.session, "action", f"qa-ax-{action}", id),
        capture_output=True, text=True, check=False, timeout=12,
    )
    diagnostic = result.stderr.strip()
    require(result.returncode == 1 and text in diagnostic,
            f"AccessKit unexpectedly accepted {action} on {id}: {result.returncode} {diagnostic}")
    return diagnostic


def accesskit_state(receipt, focused):
    data = receipt["accesskit"]
    require(data and data["scale"] > 0, "The platform AccessKit projection is missing")
    nodes = data["nodes"]
    toolbar = nodes[BAR]
    require(toolbar["role"] == "Toolbar" and toolbar["name"] == "編輯工具列"
            and toolbar["orientation"] == "Horizontal" and not toolbar["focusable"]
            and not toolbar["press"] and toolbar["children"] == list(NAMES.values()),
            f"AccessKit projected the wrong toolbar: {toolbar}")
    for id, name in NAMES.items():
        button = nodes[id]
        enabled = id != COPY
        require(button["role"] == "Button" and button["name"] == name and not button["children"]
                and button["disabled"] is not enabled
                and button["focusable"] is enabled and button["press"] is enabled,
                f"AccessKit projected the wrong action for {id}: {button}")
        require(button["focused"] == (focused == id),
                f"AccessKit focused the wrong button for {id}: {button}")
    return data


def icon_geometry(snapshot, receipt, id, target, palette):
    ops = QA["ops_for"](receipt, snapshot, id)
    paths = [op["FillPath"] for op in ops if "FillPath" in op]
    require(paths and not any("Text" in op.get("Legacy", {}) for op in ops),
            f"{id} did not render vector artwork")
    box = {"x": target["x"] + 12., "y": target["y"] + 12., "width": 24., "height": 24.}
    ink = paths[0]["contour"]["color"]
    for path in paths:
        require(same_rect(path["clip"], box) and path["contour"]["color"] == ink,
                f"{id} vector escaped its 24 dp icon bounds or tint")
    background, foreground = palette["bar"], palette["docked_ink"]
    if id == COPY:
        require(0 < QA["color_delta"](ink, background) < QA["color_delta"](foreground, background),
                f"{id} did not use visibly attenuated ink")
    else:
        require(ink == foreground, f"{id} vector used the wrong Material role")
    return {"box": box, "ink": ink}


def icon_pixels(case, frame, snapshot, receipt, targets, palette, background_point):
    icons = {id: icon_geometry(snapshot, receipt, id, target, palette)
             for id, target in targets.items()}
    points = {background_point}
    per_icon = {}
    for id, info in icons.items():
        box = info["box"]
        left, top = math.ceil(box["x"]), math.ceil(box["y"])
        right, bottom = math.floor(box["x"] + box["width"]), math.floor(box["y"] + box["height"])
        per_icon[id] = {(x, y) for x in range(left, right) for y in range(top, bottom)}
        points.update(per_icon[id])
    samples = PAIRED["png_pixels"](case.plan.artifacts / frame["file"], frame, points)
    for id, info in icons.items():
        ink = info["ink"]
        matches = sum(QA["color_delta"](samples[point], ink) <= 5 for point in per_icon[id])
        require(matches >= 8, f"{id} path did not produce visible Metal PNG ink")
        info["pixels_with_ink"] = matches
        box = info["box"]
        for x, y in CUTOUT_PIXELS[id]:
            point = (round(box["x"] + x), round(box["y"] + y))
            require(QA["color_delta"](samples[point], palette["bar"]) <= 5,
                    f"{id} expected transparent cutout at local point {(x, y)}")
        info["cutout_pixels_verified"] = len(CUTOUT_PIXELS[id])
    return icons, samples[background_point]


def capture_frame(case, stage, rtl, current_status, focused=None):
    QA["reveal"](case, PREVIEW)
    label = f"{case.prefix}-{stage}"
    frame, snapshot = capture(
        case.plan, case.plan.client, case.session, label, case.size, case.dark, SECTION,
        (PREVIEW, BAR, *NAMES),
    )
    require(not frame["errors"], str(frame["errors"]))
    receipt = json.loads(case.receipt.read_text())
    nodes, ids, preview, _ = geometry(snapshot, PREVIEW)
    _, _, bar, _ = geometry(snapshot, BAR)
    close(bar["x"], preview["x"], "Docked bar left edge")
    close(bar["width"], preview["width"], "Docked bar allocated width")
    close(bar["height"], 64., "Docked bar height")
    close(bar["y"] + bar["height"], preview["y"] + preview["height"], "Docked bar bottom edge")
    targets = {id: geometry(snapshot, id)[2] for id in NAMES}
    for box in targets.values():
        close(box["width"], 48., "Action target width")
        close(box["height"], 48., "Action target height")
        close(box["y"] - bar["y"], 8., "Action block inset")
    sorted_targets = sorted(targets.items(), key=lambda item: item[1]["x"])
    physical = [id for id, _ in sorted_targets]
    require(physical == ([PASTE, COPY, CUT] if rtl else [CUT, COPY, PASTE]), "Physical order was not mirrored")
    boxes = [box for _, box in sorted_targets]
    expected_gap = min(32., (bar["width"] - 184.) / 2. + 4.)
    for left, right in zip(boxes, boxes[1:]):
        close(right["x"] - left["x"] - left["width"], expected_gap, "Docked action gap")
    require(boxes[0]["x"] >= bar["x"] + 16. and boxes[-1]["x"] + boxes[-1]["width"]
            <= bar["x"] + bar["width"] - 16., "Docked action trespassed into the 16 dp side inset")

    palette = case.plan.palette["dark" if case.dark else "light"]["standard"]
    fill = palette["bar"]
    point = (round(bar["x"] + 4.), round(bar["y"] + 4.))
    if stage == "start":
        frame["icons"], pixel = icon_pixels(case, frame, snapshot, receipt, targets, palette, point)
    else:
        pixel = PAIRED["sample"](case, frame, point)
    require(QA["color_delta"](pixel, fill) <= 3, f"{label}: Metal bar background saw {pixel}, expected {fill}")
    heading = nodes[ids[BAR]]
    require(heading["name"] == "編輯工具列" and heading["stable_id"] == BAR,
            "Gallery bar has lost its stable name")
    require(nodes[ids[DIRECTION]]["selected"] is rtl, "Gallery reported the wrong layout direction")
    actual_focus = snapshot["interaction"]["focused"]
    if focused:
        require(actual_focus == focused, f"{label} lost key focus to {actual_focus}")
        ops = QA["ops_for"](receipt, snapshot, focused)
        PAIRED["check_focus"](case, frame, receipt, focused, ops, targets[focused])

    actual_status = nodes[ids[STATUS]]["text"]
    require(actual_status == current_status, f"{label} action count is {actual_status}, expected {current_status}")
    frame.update(
        stage=stage, rtl=rtl, bar=bar, preview=preview, targets=targets, physical=physical,
        status=actual_status, focus=actual_focus, accesskit=accesskit_state(receipt, actual_focus),
        background={"point": point, "rgba": pixel, "role_rgba": fill}, action_gap=expected_gap,
    )
    case.frames.append(frame)
    return frame


def run_case(case, rtl):
    case.call("action", "activate", SECTION)
    nodes, ids = COMMON["dom_index"](case.snapshot())
    if nodes[ids[DIRECTION]]["selected"] is not rtl:
        case.call("action", "activate", DIRECTION)
    case.point("leave")
    case.clock.advance(750)
    capture_frame(case, "start", rtl, "尚無操作")

    focus(case, DIRECTION)
    keys = [key(case, "tab", CUT)]
    capture_frame(case, "tab-cut", rtl, "尚無操作", CUT)
    keys.append(key(case, "up", CUT))
    forward, backward = ("left", "right") if rtl else ("right", "left")
    keys.append(key(case, forward, PASTE))
    capture_frame(case, "arrow-paste", rtl, "尚無操作", PASTE)
    keys.append(key(case, backward, CUT))
    keys.append(key(case, "end", PASTE))
    keys.append(key(case, "home", CUT))
    capture_frame(case, "home-cut", rtl, "尚無操作", CUT)

    keys.append(key(case, "tab", CLEAR))
    keys.append(key(case, "tab", CUT, shift=True))
    keys.append(key(case, "end", PASTE))
    keys.append(key(case, "tab", CLEAR))
    keys.append(key(case, "tab", CUT, shift=True))
    keys.append(key(case, "tab", DIRECTION, shift=True))
    keys.append(key(case, "tab", CUT))
    keys.append(key(case, "enter", CUT))
    capture_frame(case, "key-enter", rtl, "剪下 · 1", CUT)

    denied = [
        reject(case, "press", COPY, "no live AccessKit press"),
        reject(case, "focus", COPY, "no live AccessKit focus"),
        reject(case, "focus", BAR, "no live AccessKit focus"),
    ]
    require(status(case) == "剪下 · 1", "A disabled or group accessibility action reached the app")
    response = case.call("action", "qa-ax-press", PASTE)
    require(response["accesskit"], "Accessible Paste did not run through the macOS AccessKit bridge")
    frame = capture_frame(case, "ax-press", rtl, "貼上 · 2", response["focused"])
    result = {"keys": keys, "denied_accesskit": denied, "accesskit_action": response}
    if case.size == (320, 240) and case.dark and rtl:
        mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
        require((case.plan.artifacts / mcp["file"]).read_bytes() ==
                (case.plan.artifacts / frame["file"]).read_bytes(), "CLI and MCP PNGs differ")
        result["mcp"] = {**mcp, "cli": frame["file"]}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--viewport", choices=COMMON["VIEWPORTS"])
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--direction", choices=("ltr", "rtl"))
    parser.add_argument("--startup-timeout", type=int, default=75)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "frames": [], "runs": {}, "errors": []}
    for view, size in COMMON["VIEWPORTS"].items():
        if plan.viewport not in (None, view):
            continue
        for theme in ("light", "dark"):
            if plan.theme not in (None, theme):
                continue
            for direction in ("ltr", "rtl"):
                if plan.direction not in (None, direction):
                    continue
                prefix = f"{view}-{theme}-{direction}"
                case = None
                try:
                    with COMMON["gallery"](plan, prefix, size, theme == "dark") as case:
                        result = run_case(case, direction == "rtl")
                    adapter = next(
                        (line for line in (plan.artifacts / f"{prefix}.log").read_text().splitlines()
                         if line.startswith("Native QA GPU adapter ")), "",
                    )
                    require("backend: Metal" in adapter, f"{prefix} missing native Metal backend: {adapter}")
                    report["runs"][prefix] = {**result, "adapter": adapter}
                except (RuntimeError, OSError, KeyError, ValueError, TypeError, subprocess.SubprocessError) as error:
                    report["errors"].append(f"{prefix}: {error}")
                    print(report["errors"][-1], flush=True)
                finally:
                    if case:
                        report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"], "\n".join(report["errors"]))
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
