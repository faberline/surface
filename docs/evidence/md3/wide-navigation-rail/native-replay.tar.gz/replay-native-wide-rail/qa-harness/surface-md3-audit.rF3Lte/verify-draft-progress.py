#!/usr/bin/env python3
"""Capture the draft Material circular progress fixtures from a native Gallery."""

import argparse
import base64
import json
import math
import os
from pathlib import Path
import runpy
import subprocess
import tempfile
from types import SimpleNamespace


HERE = Path(__file__).resolve().parent
HELPERS = runpy.run_path(str(HERE.parent / "surface-md3-elevation.a56Yt2/verify-native.py"))
call = HELPERS["call"]
capture = HELPERS["capture"]
dom_index = HELPERS["dom_index"]
png_details = HELPERS["png_details"]
png_pixels = HELPERS["png_pixels"]
require = HELPERS["require"]
stop = HELPERS["stop"]
wait_for_session = HELPERS["wait_for_session"]
write_json = HELPERS["write_json"]

SECTION = "section-3"
ZERO, CURRENT, NEAR, FULL, SPINNER = RINGS = (
    "circular-zero", "circular-current", "circular-near", "circular-full", "circular-indeterminate",
)
MOTION = "circular-progress-motion"
NEXT = "circular-progress-next"


def check_rings(plan, details, snapshot, value):
    nodes, indices = dom_index(snapshot)
    for stable_id in RINGS:
        node = nodes[indices[stable_id]]
        require(node["role"] == "Progress" and node["name"], f"{stable_id} needs a named progress role")
        bounds = details["nodes"][stable_id]["bounds"]
        require((bounds["width"], bounds["height"]) == (40, 40), f"{stable_id} is not 40 × 40")
    require(nodes[indices[CURRENT]]["range"]["value"] == value, "determinate value mismatch")
    require(nodes[indices[SPINNER]].get("range") is None, "indeterminate value must be absent")
    require(not details["errors"], "; ".join(details["errors"]))

    samples = {
        "track": (ZERO, 33, 7),
        "active": (FULL, 33, 7),
        "empty_center": (CURRENT, 20, 20),
        "starts_at_top": (CURRENT, 20, 2),
        "clockwise": (CURRENT, 33, 7),
        "next_quarter": (CURRENT, 33, 33),
        "track_on_left": (CURRENT, 7, 7),
        "cap_before_gap": (CURRENT, 37.5, 21),
        "after_cap_gap": (CURRENT, 37.5, 24),
        "near_finish_gap": (NEAR, 16.5, 2.5),
        "spinner_right": (SPINNER, 38, 20),
        "spinner_top": (SPINNER, 20, 2),
    }
    points = {}
    for key, (stable_id, x, y) in samples.items():
        bounds = details["nodes"][stable_id]["bounds"]
        points[key] = (math.floor(bounds["x"] + x), math.floor(bounds["y"] + y))
    rgba = png_pixels(plan.artifacts / details["file"], details, set(points.values()))
    colors = {key: rgba[point] for key, point in points.items()}
    active, track, backdrop = (colors[key] for key in ("active", "track", "empty_center"))
    require(len({tuple(active), tuple(track), tuple(backdrop)}) == 3, "expected distinct colors")
    for sample, expected in {
        "starts_at_top": active,
        "clockwise": active,
        "next_quarter": active if value == 0.5 else track,
        "track_on_left": track,
        "near_finish_gap": backdrop,
        "spinner_right": active,
        "spinner_top": backdrop,
    }.items():
        require(colors[sample] == expected, f"{details['file']} {sample} {colors[sample]} != {expected}")
    if value == 0.25:
        cap = colors["cap_before_gap"]
        require(
            all(min(a, b) <= c <= max(a, b) for a, b, c in zip(active, backdrop, cap))
            and cap != backdrop,
            f"{details['file']} expected a visible round cap, got {cap}",
        )
        require(colors["after_cap_gap"] == backdrop, f"{details['file']} the visible arc crossed its gap")
    details["pixels"] = colors
    details["determinate"] = value


def check_mcp(plan, client, session, expected):
    requests = [
        {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
            "protocolVersion": "2024-11-05", "capabilities": {},
            "clientInfo": {"name": "surface-gallery-proof", "version": "1"},
        }},
        {"jsonrpc": "2.0", "method": "notifications/initialized"},
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
        {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {
            "name": "page_screenshot", "arguments": {"scale": 1},
        }},
    ]
    result = subprocess.run(
        (client, "--session", session, "mcp"), capture_output=True, text=True, timeout=15,
        input="".join(json.dumps(r) + "\n" for r in requests),
    )
    require(result.returncode == 0, "MCP failed: " + result.stderr)
    replies = {reply["id"]: reply for reply in map(json.loads, result.stdout.splitlines())}
    require(
        "page_screenshot" in {tool["name"] for tool in replies[2]["result"]["tools"]},
        "the MCP server did not list page_screenshot",
    )
    data = replies[3]["result"]
    require(data["isError"] is False, "MCP returned a tool error")
    image, metadata = data["content"]
    require((image["type"], image["mimeType"]) == ("image", "image/png"), "wrong MCP attachment type")
    path = plan.artifacts / "compact-dark-mcp.png"
    path.write_bytes(base64.b64decode(image["data"], validate=True))
    details = png_details(path, json.loads(metadata["text"]))
    require((details["width"], details["height"]) == expected, "wrong MCP PNG size")
    png_pixels(path, details, {(0, 0), (details["width"] - 1, details["height"] - 1)})
    print(f"MCP page_screenshot: image/png, {details['width']} × {details['height']}", flush=True)
    return details


def verify_size(plan, client, binary, label, size, result):
    with (
        tempfile.TemporaryDirectory(prefix="surface-progress-", dir="/private/tmp") as folder,
        (plan.artifacts / f"{label}.log").open("wb") as log,
    ):
        session = Path(folder) / "session.json"
        env = dict(os.environ, SURFACE_DEVTOOLS_SESSION=str(session), SURFACE_REDUCED_MOTION="1")
        env.pop("SURFACE_TRACE", None)
        env.pop("SURFACE_BRIDGE_SESSION", None)
        child = subprocess.Popen(
            (binary,), cwd=plan.checkout, env=env, stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT,
        )
        try:
            wait_for_session(session, child)
            capabilities = call(client, session, "capabilities")
            require("Page.screenshot" in capabilities["methods"], "screenshot capability missing")
            theme = call(client, session, "dom", "snapshot")
            nodes, indices = dom_index(theme)
            if nodes[indices["theme"]]["checked"]:
                call(client, session, "action", "activate", "theme")
            call(client, session, "action", "activate", SECTION)
            for dark, name in ((False, "light"), (True, "dark")):
                if dark:
                    call(client, session, "action", "activate", "theme")
                call(client, session, "action", "activate", MOTION)
                details, dom = capture(plan, client, session, f"{label}-{name}", size, dark, SECTION, RINGS)
                result["frames"].append(details)
                check_rings(plan, details, dom, 0.25)
            if label == "compact":
                result["mcp"] = check_mcp(plan, client, session, size)
                call(client, session, "action", "activate", NEXT)
                details, dom = capture(plan, client, session, f"{label}-dark-50", size, True, SECTION, RINGS)
                result["frames"].append(details)
                check_rings(plan, details, dom, 0.5)
        finally:
            stop(child)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    args = parser.parse_args()
    plan = SimpleNamespace(checkout=HERE / "qa-capture", artifacts=args.artifacts.resolve())
    plan.artifacts.mkdir(parents=True, exist_ok=False, mode=0o700)
    debug = Path("/private/tmp/surface-md3-draft-capture-target/debug")
    client = debug / "surface-devtools"
    result = {"capture": "Surface Page.screenshot", "frames": [], "errors": []}
    for label, binary, size in (
        ("wide", debug / "surface-material-gallery", (960, 800)),
        ("compact", debug / "examples/compact", (420, 360)),
    ):
        try:
            verify_size(plan, client, binary, label, size, result)
        except (RuntimeError, KeyError, ValueError, subprocess.TimeoutExpired) as error:
            result["errors"].append(f"{label}: {error}")
    write_json(plan.artifacts / "report.json", result)
    require(not result["errors"], "\n".join(result["errors"]))


if __name__ == "__main__":
    main()
