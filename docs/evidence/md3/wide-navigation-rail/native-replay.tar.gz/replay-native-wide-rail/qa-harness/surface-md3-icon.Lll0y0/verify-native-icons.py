#!/usr/bin/env python3
"""Verify expressive icon buttons in the standalone native Gallery."""

import argparse
from collections import Counter
from contextlib import contextmanager
import json
import math
import os
from pathlib import Path
import runpy
import subprocess
import tempfile
import time


HERE = Path(__file__).resolve().parent
COMMON = runpy.run_path(str(HERE.parent / "surface-md3-audit.rF3Lte/verify-draft-progress.py"))
call = COMMON["call"]
capture = COMMON["capture"]
check_mcp = COMMON["check_mcp"]
dom_index = COMMON["dom_index"]
png_pixels = COMMON["png_pixels"]
require = COMMON["require"]
stop = COMMON["stop"]
wait_for_session = COMMON["wait_for_session"]
write_json = COMMON["write_json"]

SECTION = "section-3"
CARD = "expressive-icon-specimen"
XS = "expressive-icon-xs"
SMALL = "expressive-icon-small"
MEDIUM = "expressive-icon-medium"
DISABLED = "expressive-icon-disabled"
LARGE = "expressive-icon-large"
XL = "expressive-icon-xl"
SAMPLES = {
    XS: ("播放預覽", (48, 48), (28, 32), "round", False, False),
    SMALL: ("我的最愛", (52, 48), (52, 40), "round", True, False),
    MEDIUM: ("釘選項目", (56, 56), (56, 56), "square", True, False),
    DISABLED: ("無法封存", (48, 48), (32, 32), "square", False, True),
    LARGE: ("下載資料", (64, 96), (64, 96), "square", False, True),
    XL: ("展開預覽", (184, 136), (184, 136), "square", False, True),
}
COMPACT = (XS, SMALL, MEDIUM, DISABLED)
BIG = (LARGE, XL)


@contextmanager
def gallery(plan, client, binary, label):
    with (
        tempfile.TemporaryDirectory(prefix="surface-icon-", dir="/private/tmp") as folder,
        (plan.artifacts / f"{label}.log").open("wb") as log,
    ):
        session = Path(folder) / "session.json"
        env = dict(os.environ, SURFACE_DEVTOOLS_SESSION=str(session), SURFACE_REDUCED_MOTION="1")
        env.pop("SURFACE_TRACE", None)
        env.pop("SURFACE_BRIDGE_SESSION", None)
        child = subprocess.Popen(
            (binary,), cwd=HERE / "qa", env=env, stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT,
        )
        try:
            wait_for_session(session, child)
            methods = call(client, session, "capabilities")["methods"]
            require("Page.screenshot" in methods, "screenshot capability missing")
            nodes, index = dom_index(call(client, session, "dom", "snapshot"))
            if nodes[index["theme"]]["checked"]:
                call(client, session, "action", "activate", "theme")
            call(client, session, "action", "activate", SECTION)
            yield session, child
        finally:
            stop(child)


def dimens(rect):
    return rect["width"], rect["height"]


def rgba_near(a, b, delta=2):
    return all(abs(c - d) <= delta for c, d in zip(a, b))


def rgb_over(foreground, background):
    a = foreground[3] / 255
    linear = lambda ch: ch / 12.92 if ch <= 0.04045 else ((ch + 0.055) / 1.055) ** 2.4
    encoded = lambda ch: ch * 12.92 if ch <= 0.0031308 else 1.055 * ch ** (1 / 2.4) - 0.055
    direct_colors = [round(f * a + b * (1 - a)) for f, b in zip(foreground[:3], background[:3])]
    srgb_colors = [round(encoded(linear(f / 255) * a + linear(b / 255) * (1 - a)) * 255)
                   for f, b in zip(foreground[:3], background[:3])]
    return [tuple(direct_colors + [255]), tuple(srgb_colors + [255])]


def coords(rect, limit):
    x0 = max(0, math.ceil(rect["x"] - 0.5))
    y0 = max(0, math.ceil(rect["y"] - 0.5))
    x1 = min(limit[0], math.ceil(rect["x"] - 0.5 + rect["width"]))
    y1 = min(limit[1], math.ceil(rect["y"] - 0.5 + rect["height"]))
    return [(x, y) for y in range(y0, y1) for x in range(x0, x1)]


def read_samples(plan, details, snapshot, ids, selected):
    require(not details["errors"], "; ".join(details["errors"]))
    nodes, index = dom_index(snapshot)
    layout = snapshot["layout"]["nodes"]
    background = tuple(nodes[index[CARD]]["style"]["background"])
    face_areas = {}
    glyph_areas = {}
    measurements = {}
    limit = details["width"], details["height"]
    for key in ids:
        name, hit_size, face_size, shape, toggle, bordered = SAMPLES[key]
        node_index = index[key]
        node = nodes[node_index]
        role = "Checkbox" if toggle else "Button"
        require((node["role"], node["name"], node["disabled"]) == (role, name, key == DISABLED),
                f"{key} has incorrect button semantics")
        expected_checked = (key in selected) if toggle else None
        require(node.get("checked") is expected_checked,
                f"{key} checked={node.get('checked')}, expected {expected_checked}")
        hit_rect = layout[node_index]["bounds"]
        require(dimens(hit_rect) == hit_size, f"{key} hit bounds {hit_rect} should be {hit_size}")
        face_index = node["first_child"]
        face = nodes[face_index]
        face_rect = layout[face_index]["bounds"]
        require(dimens(face_rect) == face_size, f"{key} face bounds {face_rect} should be {face_size}")
        require(all(math.isclose(hit_rect[axis] + (hit_rect[dimension] - face_rect[dimension]) / 2,
                                 face_rect[axis], abs_tol=0.01)
                    for axis, dimension in (("x", "width"), ("y", "height"))),
                f"{key} face is not centered in its hit target")
        style = face["style"]
        raw_radius = style["corners"]["top_left"] if style["corners"] else style["radius"]
        expected_round = (shape == "round") != (key in selected)
        round_shape = raw_radius >= min(face_size) / 2
        require(round_shape == expected_round,
                f"{key} has corner {raw_radius}, expected {'round' if expected_round else 'square'}")
        require((style["border_width"] > 0) == bordered, f"{key} border {style['border_width']}")
        face_areas[key] = coords(face_rect, limit)
        symbol_index = face["first_child"]
        glyph = nodes[nodes[symbol_index]["first_child"]]
        glyph_rect = layout[symbol_index]["bounds"]
        glyph_areas[key] = coords(glyph_rect, limit)
        measurements[key] = {
            "hit": hit_rect,
            "face": face_rect,
            "corner": raw_radius,
            "round": round_shape,
            "fill": style["background"],
            "border": style["border_color"] if bordered else None,
            "border_width": style["border_width"],
            "glyph": glyph["style"]["foreground"],
            "checked": expected_checked,
            "disabled": node["disabled"],
        }

    points = {point for groups in (face_areas, glyph_areas) for area in groups.values() for point in area}
    rgba = png_pixels(plan.artifacts / details["file"], details, points)
    for key, m in measurements.items():
        face = [tuple(rgba[point]) for point in face_areas[key]]
        glyph = [tuple(rgba[point]) for point in glyph_areas[key]]
        fills = rgb_over(m["fill"], background)
        fill_pixels = sum(any(rgba_near(pixel, fill) for fill in fills) for pixel in face)
        require(fill_pixels >= len(face) * 0.4, f"{key} missing fill/background ({fill_pixels} pixels)")
        if key in (SMALL, MEDIUM):
            require(all(not rgba_near(fill, background) for fill in fills), f"{key} missing emphasis fill")
        borders = rgb_over(m["border"], background) if m["border"] else []
        border_pixels = sum(any(rgba_near(pixel, b, delta=4) for b in borders) for pixel in face)
        if borders:
            require(border_pixels >= 12, f"{key} missing border ({border_pixels} pixels)")
        ink = [color for fill in fills for color in rgb_over(m["glyph"], fill)]
        if m["glyph"][3] == 255:
            glyph_pixels = sum(any(rgba_near(pixel, color, delta=6) for color in ink)
                               for pixel in glyph)
        else:
            # An outline glyph can have fractional coverage along every edge.
            # Test the visible tint along its full-alpha blending range.
            most_contrasting = max(ink, key=lambda color: sum(
                abs(a - b) for a, b in zip(background, color)
            ))
            glyph_pixels = sum(
                any(abs(a - b) >= 12 for a, b in zip(pixel, background))
                and all(min(a, b) - 3 <= channel <= max(a, b) + 3
                        for channel, a, b in zip(pixel, background, most_contrasting))
                for pixel in glyph
            )
        require(glyph_pixels >= 8, f"{key} missing painted glyph ({glyph_pixels} pixels)")
        x0 = math.ceil(m["face"]["x"] - 0.5)
        y0 = math.ceil(m["face"]["y"] - 0.5)
        m["corner_fill_pixels"] = sum(
            any(rgba_near(pixel, fill) for fill in fills)
            for (x, y), pixel in zip(face_areas[key], face)
            if x < x0 + 10 and y < y0 + 10
        )
        m["fill_pixels"] = fill_pixels
        m["border_pixels"] = border_pixels
        m["glyph_pixels"] = glyph_pixels
        m["common_face_pixels"] = Counter(face).most_common(3)
    details["icons"] = measurements


def frame(plan, client, session, label, size, dark, ids, selected=()):
    details, snapshot = capture(plan, client, session, label, size, dark, SECTION, ids)
    read_samples(plan, details, snapshot, ids, selected)
    return details


def focus(client, session, wanted):
    snapshot = call(client, session, "dom", "snapshot")
    actual = snapshot["interaction"]["focused"]
    require(actual == wanted, f"focus was {actual!r}, expected {wanted!r}")
    _, index = dom_index(snapshot)
    layout = snapshot["layout"]["nodes"][index[wanted]]
    r, c = layout["bounds"], layout["clip"]
    require(r["width"] > 0 and r["height"] > 0
            and r["x"] >= c["x"] - 0.01 and r["y"] >= c["y"] - 0.01
            and r["x"] + r["width"] <= c["x"] + c["width"] + 0.01
            and r["y"] + r["height"] <= c["y"] + c["height"] + 0.01,
            f"focused {wanted} is clipped: {layout}")
    return snapshot


def window_state(probe, child, operation="--state"):
    state = json.loads(subprocess.check_output(
        (probe, str(child.pid), operation), text=True, timeout=8,
    ))
    require(state["trusted"], "window diagnostic needs existing AX trust")
    return state


def make_active(probe, child):
    before = window_state(probe, child)
    issued = None
    if not before["active"]:
        issued = window_state(probe, child, "--activate")
    after = window_state(probe, child)
    for _ in range(10):
        if after["active"]:
            break
        time.sleep(0.08)
        after = window_state(probe, child)
    require(after["active"], f"Gallery did not become active: {before}, {issued}, {after}")
    return {"before": before, "activation": issued, "after": after}


def key_step(client, session, probe, child, key, before, after, trace):
    host_before = window_state(probe, child)
    entry = {"key": key, "from": before, "to": after, "host_before": host_before}
    trace.append(entry)
    focus(client, session, before)
    require(host_before["active"], f"Gallery lost app activation before {key}: {entry}")
    entry["response"] = call(client, session, "action", "key", key)
    entry["host_after"] = window_state(probe, child)
    require(entry["host_after"]["active"], f"Gallery lost app activation after {key}: {entry}")
    require(entry["response"]["focused"] == after, f"key {key} focus result: {entry}")
    focus(client, session, after)


def check_interactions(plan, client, session, child, image, report):
    size = (420, 360)
    report["window_activation"] = make_active(plan.window_probe, child)
    call(client, session, "action", "activate", XS)
    trace = []
    report["keyboard_trace"] = trace
    for key, source, target in (
        ("tab", XS, SMALL), ("enter", SMALL, SMALL),
        ("tab", SMALL, MEDIUM), ("enter", MEDIUM, MEDIUM),
    ):
        key_step(client, session, plan.window_probe, child, key, source, target, trace)
    before = frame(plan, client, session, "compact-dark-selected", size, True, COMPACT,
                   selected=(SMALL, MEDIUM))
    report["selected"] = before
    for key in (SMALL, MEDIUM):
        require(image["icons"][key]["round"] != before["icons"][key]["round"]
                and image["icons"][key]["fill"] != before["icons"][key]["fill"],
                f"{key} did not change shape and fill with selection")
    require(before["icons"][SMALL]["corner_fill_pixels"] > image["icons"][SMALL]["corner_fill_pixels"],
            "the selected Small button did not paint its squarer corner")
    require(before["icons"][MEDIUM]["corner_fill_pixels"] < image["icons"][MEDIUM]["corner_fill_pixels"],
            "the selected Medium button did not paint its rounder corner")
    rejected = subprocess.run(
        (client, "--session", session, "action", "activate", DISABLED),
        capture_output=True, text=True, timeout=12,
    )
    require(rejected.returncode and "disabled" in rejected.stderr,
            f"disabled icon accepted activation: {rejected.stdout} {rejected.stderr}")
    focus(client, session, MEDIUM)
    key_step(client, session, plan.window_probe, child, "tab", MEDIUM, LARGE, trace)
    key_step(client, session, plan.window_probe, child, "tab", LARGE, XL, trace)
    report["keyboard"] = {
        "tab_focus": [XS, SMALL, MEDIUM, LARGE, XL],
        "enter_toggled": [SMALL, MEDIUM],
        "disabled_rejected": rejected.stderr.strip(),
    }


def verify_size(plan, client, binary, label, size, report):
    with gallery(plan, client, binary, label) as (session, child):
        for dark, theme in ((False, "light"), (True, "dark")):
            if dark:
                call(client, session, "action", "activate", "theme")
            call(client, session, "action", "activate", XS)
            small = frame(plan, client, session, f"{label}-{theme}", size, dark, COMPACT)
            report["frames"].append(small)
            if dark and label == "compact":
                report["mcp"] = check_mcp(plan, client, session, size)
                require(report["mcp"]["sha256"] == small["sha256"], "MCP and CLI PNG bytes differ")
                check_interactions(plan, client, session, child, small, report)
            else:
                call(client, session, "action", "activate", XL)
            big = frame(plan, client, session, f"{label}-{theme}-large", size, dark, BIG)
            report["frames"].append(big)


def check_ax_sample(probe, child, keys, selected, focused):
    labels = {SAMPLES[key][0]: key for key in keys}
    for _ in range(6):
        reply = json.loads(subprocess.check_output(
            (probe, str(child.pid), *labels), text=True, timeout=12,
        ))
        require(reply["trusted"] and reply["queried"], "the native AX client lacks trust")
        if len(reply["matches"]) >= len(keys):
            break
        time.sleep(0.15)
    actual = {item["label"]: item for item in reply["matches"]}
    errors = []
    if set(actual) != set(labels):
        return reply, [f"unexpected native AX nodes ({reply['visited']} visited): {actual}"]
    for name, key in labels.items():
        item = actual[name]
        _, (w, h), _, _, toggle, _ = SAMPLES[key]
        role = "AXCheckBox" if toggle else "AXButton"
        if item.get("role") != role or item.get("size") != {"width": w, "height": h}:
            errors.append(f"{name} native role/size: {item}")
        should_press = key != DISABLED
        if item.get("enabled") is not should_press or ("AXPress" in item.get("actions", [])) != should_press:
            errors.append(f"{name} native disabled/press: {item}")
        if toggle and item.get("value") != (key in selected):
            errors.append(f"{name} native toggle: {item}")
        if item.get("focused") is not (key == focused):
            errors.append(f"{name} native focus: {item}")
    return reply, errors


def verify_ax(plan, client, binary, probe, report):
    with gallery(plan, client, binary, "ax",) as (session, child):
        report["window_activation"] = make_active(probe, child)
        call(client, session, "action", "activate", XS)
        focus(client, session, XS)
        before, errors = check_ax_sample(probe, child, COMPACT, (), XS)
        report["ax"].append({"phase": "initial", "observation": before})
        require(window_state(probe, child)["active"], "Gallery lost app activation before first toggle")
        call(client, session, "action", "activate", SMALL)
        focus(client, session, SMALL)
        after, later_errors = check_ax_sample(probe, child, COMPACT, (SMALL,), SMALL)
        report["ax"].append({"phase": "first toggle on", "observation": after})
        require(window_state(probe, child)["active"], "Gallery lost app activation before second toggle")
        call(client, session, "action", "activate", MEDIUM)
        focus(client, session, MEDIUM)
        both, end_errors = check_ax_sample(probe, child, COMPACT, (SMALL, MEDIUM), MEDIUM)
        report["ax"].append({"phase": "both toggles on", "observation": both})
        require(not (errors or later_errors or end_errors), "; ".join(errors + later_errors + end_errors))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--ax-probe", type=Path)
    parser.add_argument("--window-probe", type=Path, default=Path("/private/tmp/surface-icon-Lll0y0-ax"))
    args = parser.parse_args()
    args.artifacts = args.artifacts.resolve()
    args.artifacts.mkdir(parents=True, exist_ok=False, mode=0o700)
    debug = args.debug_dir
    client = debug / "surface-devtools"
    compact = debug / "examples/compact"
    report = {"capture": "Surface Page.screenshot", "frames": [], "errors": []}
    if args.ax_probe:
        report["ax"] = []
        try:
            verify_ax(args, client, compact, args.ax_probe, report)
        except (RuntimeError, KeyError, ValueError, TypeError, OSError, subprocess.SubprocessError) as error:
            report["errors"].append(f"AX: {error}")
    else:
        for label, binary, size in (
            ("wide", debug / "surface-material-gallery", (960, 800)),
            ("compact", compact, (420, 360)),
            ("narrow", debug / "examples/icon_narrow", (320, 360)),
        ):
            try:
                verify_size(args, client, binary, label, size, report)
            except (RuntimeError, KeyError, ValueError, TypeError, OSError, subprocess.SubprocessError) as error:
                report["errors"].append(f"{label}: {error}")
    write_json(args.artifacts / "report.json", report)
    require(not report["errors"], "\n".join(report["errors"]))


if __name__ == "__main__":
    main()
