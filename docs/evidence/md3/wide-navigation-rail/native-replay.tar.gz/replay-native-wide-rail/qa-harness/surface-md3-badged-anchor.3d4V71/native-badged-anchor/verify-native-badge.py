#!/usr/bin/env python3
"""Measure anchored Material badges in native Metal screenshots."""

import argparse
import itertools
import json
import math
from pathlib import Path
import runpy
import subprocess


HERE = Path(__file__).resolve().parent
SHARED = runpy.run_path(str(HERE.parents[1] / "surface-md3-docked-semantics.inE2pZ"
                             / "native-docked-toolbar" / "verify-native-docked.py"))
COMMON, MOTION, QA = (SHARED[name] for name in ("COMMON", "MOTION", "QA"))
require, close, geometry, capture, same_rect, write_json, focus, key = (
    SHARED[name] for name in ("require", "close", "geometry", "capture", "same_rect",
                             "write_json", "focus", "key")
)
pixels_for = MOTION["png_pixels"]
SECTION = "section-4"
PREVIEW, MODE, DIRECTION, SCALE, ANCHOR, STATUS = (
    f"anchor-badge-{part}" for part in ("viewport", "mode", "direction", "text-scale", "inbox", "status")
)
NAMES = {
    "hidden": ("無徽章", "收件匣", None),
    "dot": ("圓點徽章", "收件匣，有新通知", None),
    "count": ("數字徽章", "收件匣，{} 則未讀訊息", "{}"),
    "overflow": ("超過上限", "收件匣，{} 則未讀訊息", "999+"),
    "label": ("文字徽章", "收件匣，有新訊息", "新訊"),
}
VIEWPORTS = COMMON["VIEWPORTS"]
PROFILES = tuple(itertools.product(VIEWPORTS, ("light", "dark"), ("ltr", "rtl"), (1, 2)))


def node(snapshot, stable_id):
    nodes, indexes = COMMON["dom_index"](snapshot)
    return nodes[indexes[stable_id]]


def contains(outer, inner):
    return all(outer[axis] - .03 <= inner[axis]
               and outer[axis] + outer[extent] + .03 >= inner[axis] + inner[extent]
               for axis, extent in (("x", "width"), ("y", "height")))


def sample_points(box):
    return {(x, y) for x in range(math.ceil(box["x"]), math.floor(box["x"] + box["width"]))
            for y in range(math.ceil(box["y"]), math.floor(box["y"] + box["height"]))}


def color_matches(actual, expected, tolerance=5):
    return QA["color_delta"](actual, expected) <= tolerance


def status(case):
    observed = node(case.snapshot(), STATUS)
    return observed["text"] or observed["name"]


def expect_count(case, count):
    require(status(case) == f"已開啟 {count} 次", f"Expected {count} operations. Got {status(case)!r}")


def verify_ax(receipt, snapshot, label, focused):
    native = receipt["accesskit"]
    projected = receipt["projected"][ANCHOR]
    inbox = native["nodes"][ANCHOR]
    require(node(snapshot, ANCHOR)["name"] == projected["name"] == inbox["name"] == label,
            f"Accessible name did not follow the badge: {inbox}")
    require(inbox["role"] == "Button" and inbox["focusable"] and inbox["press"] and not inbox["disabled"],
            f"Native inbox changed its button actions: {inbox}")
    require(inbox["focused"] is focused and projected["focused"] is focused,
            f"Native focus did not follow the stable button: {inbox}")
    subtree = native["viewport_subtree"]
    names = [item["name"] for item in subtree if item["name"]]
    actionable = [item for item in subtree if item["focusable"] or item["press"]]
    require(names == [label] and len(actionable) == 1,
            f"Badge published duplicate status or input in the preview subtree: {subtree}")
    return inbox


def verify_paint(case, frame, receipt, anchor, preview, mode, label, rtl, scale):
    theme = case.plan.palette["dark" if case.dark else "light"]
    ops = receipt["presented"]["ops"]
    regions = [paint for op in ops for kind, paint in op.get("Legacy", {}).items()
               if kind in ("Quad", "Shape") and paint["color"] == theme["error"]
               and contains(preview, paint["rect"])]
    require(len(regions) == int(mode != "hidden"), f"{mode}: unexpected badge paint {regions}")
    if not regions:
        area = sample_points(anchor)
        colors = pixels_for(case.plan.artifacts / frame["file"], frame, area)
        require(not any(color_matches(pixel, theme["error"]) for pixel in colors.values()),
                "Hidden badge still painted in the anchor")
        return None

    tile = regions[0]
    rect = tile["rect"]
    require(contains(tile["clip"], rect), f"Badge is clipped: {tile}")
    dot = mode == "dot"
    expected_end = 12. + (6. if dot else 12.)
    end = rect["x"] + rect["width"] - anchor["x"] if rtl else (
        anchor["x"] + anchor["width"] - rect["x"]
    )
    close(end, expected_end, f"{mode}: logical trailing overlap")
    bottom = rect["y"] + rect["height"] - anchor["y"]
    close(bottom, 12. + (6. if dot else 14.), f"{mode}: logical top overlap")
    label_ops = [paint for op in ops for kind, paint in op.get("Legacy", {}).items()
                 if kind in ("Text", "StyledText") and paint["color"] == theme["on_error"]
                 and contains(rect, paint["rect"])]
    actual = pixels_for(case.plan.artifacts / frame["file"], frame, sample_points(rect))
    faces = [point for point, pixel in actual.items() if color_matches(pixel, theme["error"])]
    require(faces, f"{mode}: no error color in the captured PNG")
    if dot:
        close(rect["width"], 6., "Dot width")
        close(rect["height"], 6., "Dot height")
        require(not label_ops, "Dot contains a text operation")
        ink = []
    else:
        require(len(label_ops) == 1, f"{mode}: missing one label paint operation {label_ops}")
        word = label_ops[0]
        require(word["text"] == label and contains(word["clip"], word["rect"]),
                f"{mode}: text paint is clipped or wrong: {word}")
        font_size = word.get("font_size") or word["style"]["font_size"]
        close(font_size, 11. * scale, "Badge Label Small size")
        require(rect["width"] >= 16. and rect["height"] >= (16. if scale == 1 else 31.5),
                f"Badge did not fit the requested text scale: {rect}")
        if scale == 1:
            close(rect["height"], 16., "Label badge resting height")
        ink = [point for point, pixel in actual.items()
               if color_matches(pixel, theme["on_error"], 26) and point in sample_points(word["rect"])]
        require(len(ink) >= 2, f"{mode}: no on-error text ink in the captured PNG")
        if mode == "label":
            mid = word["rect"]["x"] + word["rect"]["width"] / 2.
            require(any(x < mid for x, _ in ink) and any(x >= mid for x, _ in ink),
                    "Native CJK badge did not paint ink for both characters")
    shared = set(faces) & sample_points(anchor)
    require(shared, f"{mode}: no painted pixels actually overlap the hit target")
    overlap = min(shared, key=lambda point:
                  abs(point[0] - (anchor["x"] + anchor["width"] / 2.))
                  + abs(point[1] - (anchor["y"] + anchor["height"] / 2.)))
    outside = sorted(set(faces) - sample_points(anchor))
    return {"rect": rect, "error_pixels": len(faces), "on_error_pixels": len(ink), "overlap": overlap,
            "outside_point": outside[0] if outside else None}


def take(case, stage, mode, rtl, scale, count=0, unread=0, focused=False):
    case.clock.advance(700)
    QA["reveal"](case, PREVIEW)
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{stage}",
                              case.size, case.dark, SECTION, (PREVIEW, ANCHOR))
    require(not frame["errors"], str(frame["errors"]))
    expected_mode, label, text = NAMES[mode]
    label = label.format(unread)
    require(node(snapshot, MODE)["name"] == expected_mode, f"{stage}: wrong badge setting")
    expect_count(case, count)
    receipt = json.loads(case.receipt.read_text())
    ax = verify_ax(receipt, snapshot, label, focused)
    anchor = geometry(snapshot, ANCHOR)[2]
    preview = geometry(snapshot, PREVIEW)[2]
    close(anchor["width"], 48., "Anchor width")
    close(anchor["height"], 48., "Anchor height")
    close(preview["height"], 104., "Preview height")
    paint = verify_paint(case, frame, receipt, anchor, preview, mode,
                         text.format(unread) if text else None, rtl, scale)
    relative = {**anchor, "x": anchor["x"] - preview["x"], "y": anchor["y"] - preview["y"]}
    if case.frames:
        require(same_rect(relative, case.frames[0]["anchor_in_preview"]),
                f"{stage}: changed anchor position or hit target")
    frame.update(stage=stage, mode=mode, scale=scale, rtl=rtl, paint=paint, anchor_in_preview=relative,
                 accesskit=ax, activations=count, unread=unread)
    case.frames.append(frame)
    return frame


def activate_mode(case):
    case.call("action", "activate", MODE)


def check_click(case, point, before, after):
    case.point("move", point)
    case.point("down", point)
    expect_count(case, before)
    case.point("up", point)
    case.point("leave")
    expect_count(case, after)


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2:
        case.call("action", "activate", SCALE)
    case.point("leave")
    take(case, "hidden", "hidden", rtl, scale)
    activate_mode(case)
    take(case, "dot", "dot", rtl, scale)
    activate_mode(case)
    rest = take(case, "count", "count", rtl, scale, unread=3)
    focus(case, SCALE)
    key(case, "tab", ANCHOR)
    expect_count(case, 0)
    key(case, "enter", ANCHOR)
    take(case, "keyboard", "count", rtl, scale, count=1, unread=4, focused=True)
    key(case, "tab", SCALE, shift=True)
    key(case, "tab", ANCHOR)
    frame = take(case, "overlap-target", "count", rtl, scale, count=1, unread=4, focused=True)
    check_click(case, frame["paint"]["overlap"], 1, 2)
    pointer_focus = case.snapshot()["interaction"]["focused"] == ANCHOR
    take(case, "pointer", "count", rtl, scale, count=2, unread=5, focused=pointer_focus)
    activated = case.call("action", "qa-ax-press", ANCHOR)
    require(activated["accesskit"], "The accessible press did not use the AccessKit bridge")
    take(case, "accesskit", "count", rtl, scale, count=3, unread=6, focused=pointer_focus)
    activate_mode(case)
    cap = take(case, "overflow", "overflow", rtl, scale, count=3, unread=1200)
    result = {"input_routes": ["native Tab/Shift+Tab/Enter", "Winit mouse down/up", "AccessKit Click"],
              "outside_badge_press_denied": False, "mcp": None}
    if cap["paint"]["outside_point"] is not None:
        check_click(case, cap["paint"]["outside_point"], 3, 3)
        result["outside_badge_press_denied"] = True
    if case.size[0] == 320 and case.dark and rtl and scale == 2:
        cap = take(case, "held-cli", "overflow", rtl, scale, count=3, unread=1200)
        mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
        require((case.plan.artifacts / mcp["file"]).read_bytes() ==
                (case.plan.artifacts / cap["file"]).read_bytes(), "CLI and MCP returned different PNG bytes")
        result["mcp"] = {**mcp, "cli": cap["file"]}
    activate_mode(case)
    take(case, "label", "label", rtl, scale, count=3)
    activate_mode(case)
    take(case, "hidden-again", "hidden", rtl, scale, count=3)
    result["initial_count_frame"] = rest["file"]
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile")
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--startup-timeout", type=int, default=45)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "runs": {}, "frames": [], "errors": []}
    for viewport, theme, direction, scale in PROFILES:
        name = f"{viewport}-{theme}-{direction}-{scale}x"
        if plan.profile not in (None, name) or plan.theme not in (None, theme):
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, VIEWPORTS[viewport], theme == "dark") as case:
                result = journey(case, direction == "rtl", scale)
            output = (plan.artifacts / f"{name}.log").read_text()
            metal = next((line for line in output.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in metal and "backend: Metal" in metal, f"{name} did not use Metal")
            report["runs"][name] = {**result, "adapter": metal}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(report["errors"][-1], flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"] and report["runs"], "\n".join(report["errors"]) or "No matching journey")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
