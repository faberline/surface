#!/usr/bin/env python3
"""Check the authored native badge matrix and each PNG receipt."""

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import struct


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("badge_matrix", HERE / "verify-native-badge.py")
MATRIX = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MATRIX)
require = MATRIX.require
PREFIX = b"\x89PNG\r\n\x1a\n"
STAGES = (
    "hidden", "dot", "count", "keyboard", "overlap-target", "pointer",
    "accesskit", "overflow", "label", "hidden-again",
)


def read_png(folder, metadata):
    path = folder / metadata["file"]
    data = path.read_bytes()
    require(data.startswith(PREFIX), f"{path}: invalid PNG")
    require(struct.unpack(">II", data[16:24]) == (metadata["width"], metadata["height"]),
            f"{path}: wrong PNG dimensions")
    require(len(data) == metadata["bytes"] and hashlib.sha256(data).hexdigest() == metadata["sha256"],
            f"{path}: PNG differs from the capture receipt")
    return data


def focus_sample(anchor):
    x = round(anchor["x"] + anchor["width"] / 2.)
    y = round(anchor["y"] + anchor["height"])
    # The 40 dp face sits 4 dp inside the fixed 48 dp hit target.
    return [(col, row) for col in range(x - 4, x + 5) for row in range(y - 8, y - 2)]


def check_focus(folder, rest, focus):
    samples = []
    for frame in (rest, focus):
        points = focus_sample(frame["nodes"][MATRIX.ANCHOR]["bounds"])
        pixels = MATRIX.pixels_for(folder / frame["file"], frame, points)
        samples.append([pixels[point] for point in points])
    changed = sum(MATRIX.QA["color_delta"](first, second) >= 30
                  for first, second in zip(*samples))
    require(changed >= 3, f"{focus['file']}: bottom focus ring did not change the PNG")
    return changed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--profile")
    plan = parser.parse_args()
    report = json.loads((plan.folder / "report.json").read_text())
    require(report["capture"] == "Surface Page.screenshot" and not report["errors"],
            "The native matrix has errors")
    expected = {f"{width}-{theme}-{direction}-{scale}x": (width, theme, direction, scale)
                for width, theme, direction, scale in MATRIX.PROFILES}
    if plan.profile is not None:
        expected = {plan.profile: expected[plan.profile]}
    require(set(report["runs"]) == set(expected), "The native matrix is incomplete")
    stage_counts = Counter()
    focuses = []
    outside = 0
    transport = None
    checked = 0
    for profile, (viewport, theme, direction, scale) in expected.items():
        journey = report["runs"][profile]
        require("Apple M1 Max" in journey["adapter"] and "backend: Metal" in journey["adapter"],
                f"{profile} did not use Metal")
        require(len(journey["input_routes"]) == 3, f"{profile} misses an input route")
        shots = {frame["stage"]: frame for frame in report["frames"] if frame["file"].startswith(profile + "-")}
        require(set(shots) == set(STAGES) | ({"held-cli"} if journey["mcp"] else set()),
                f"{profile}: missing PNG stages")
        require(shots["hidden"]["paint"] is None and shots["hidden-again"]["paint"] is None,
                f"{profile}: hidden badge has paint")
        for frame in shots.values():
            require((frame["width"], frame["height"]) == MATRIX.VIEWPORTS[viewport]
                    and frame["dark"] is (theme == "dark") and frame["rtl"] is (direction == "rtl")
                    and frame["scale"] == scale, f"{profile}: capture configuration drifted")
            read_png(plan.folder, frame)
            stage_counts[frame["stage"]] += 1
            checked += 1
        for stage, activations, unread, focused in (("count", 0, 3, False), ("keyboard", 1, 4, True),
                                                     ("pointer", 2, 5, True), ("accesskit", 3, 6, True)):
            frame = shots[stage]
            require((frame["activations"], frame["unread"], frame["accesskit"]["focused"]) ==
                    (activations, unread, focused), f"{profile}: {stage} activation or focus mismatch")
        require(shots["overflow"]["unread"] == 1200 and shots["label"]["paint"]["on_error_pixels"] > 0,
                f"{profile}: cap or translated label missing")
        focuses.append(check_focus(plan.folder, shots["count"], shots["keyboard"]))
        outside += int(journey["outside_badge_press_denied"])
        if journey["mcp"]:
            mcp = journey["mcp"]
            require(read_png(plan.folder, mcp) == read_png(plan.folder, shots["held-cli"]),
                    "CLI and MCP did not return identical captured bytes")
            transport = mcp
    require(checked == len(report["frames"]), "Unrecognized or duplicate frames in the native report")
    print(json.dumps({
        "capture": "Surface Page.screenshot on Apple M1 Max Metal",
        "profiles": len(expected),
        "verified_cli_pngs": checked,
        "stages": dict(stage_counts),
        "focus_ring_changed_pixel_count_minimum": min(focuses),
        "outside_badge_presses_denied": outside,
        "matching_mcp": transport,
    }, indent=2))


if __name__ == "__main__":
    main()
