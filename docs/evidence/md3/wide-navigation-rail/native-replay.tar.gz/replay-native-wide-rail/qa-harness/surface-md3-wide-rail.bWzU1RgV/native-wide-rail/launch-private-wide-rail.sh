#!/bin/sh
set -eu
here=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
binaries=${SURFACE_QA_WIDE_RAIL_BIN_DIR:-$here/binaries}
: "${SURFACE_QA_WIDE_RAIL_TRACE:?Set the private Gallery trace path}"
export SURFACE_TRACE="$SURFACE_QA_WIDE_RAIL_TRACE"
exec "$binaries/examples/fab_menu_native" "$@"
