#!/usr/bin/env python3
"""Test Wide Navigation Rail on a real Metal Gallery and the macOS AX API."""

import argparse
import json
from pathlib import Path
import os
import runpy
import subprocess
import time
import traceback


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
RAIL = runpy.run_path(str(WORKSPACE / "surface-md3-navigation-rail.2Vp8O5Jj/native-navigation-rail/verify-native-navigation-rail.py"))
POINTER = runpy.run_path(str(WORKSPACE / "surface-md3-drawer-swipe.xPpA3Ae4/native-drawer-swipe/verify-native-drawer-swipe.py"))
AX = runpy.run_path(str(HERE / "read-wide-rail-ax.py"))
COMMON, MOTION, QA = (RAIL[name] for name in ("COMMON", "MOTION", "QA"))
capture, center, close, color_matches, contains, focus, key, node, pixels_for, read_png, rect, require, same_rect, sample_points, write_json = (
    RAIL[name] for name in ("capture", "center", "close", "color_matches", "contains", "focus", "key", "node",
                           "pixels_for", "read_png", "rect", "require", "same_rect", "sample_points", "write_json")
)
SECTION = "section-1"
RAIL_ID, BOTTOM, LAYOUT, CONTENT = "wide-rail", "wide-rail-bottom", "wide-rail-layout", "wide-rail-content"
TOGGLE, DIRECTION, SCALE, PAGE = "wide-rail-toggle", "wide-rail-direction", "wide-rail-scale", "wide-rail-page"
GALLERY_FAB = "gallery-fab-toggle"
HOME, ARCHIVE, INBOX = ITEMS = ("wide-rail-home", "wide-rail-archive", "wide-rail-inbox")
NAMES = dict(zip(ITEMS, ("瀏覽首頁", "封存資料", "收件匣")))
LABELS = dict(zip(ITEMS, ("首頁", "封存", "收件")))
LONG_INBOX = "跨部門協作與專案通知收件匣"
DISCLOSURES = {"collapsed": "展開導覽列", "expanded": "收合導覽列"}
PROFILES = {
    "wide-light-ltr": ((960, 800), False, False, 1.),
    "wide-dark-rtl-2x": ((960, 800), True, True, 2.),
    "compact-light-ltr-2x": ((320, 240), False, False, 2.),
    "compact-dark-rtl-2x": ((320, 240), True, True, 2.),
}


def activate_private(case):
    return json.loads(subprocess.check_output([
        case.plan.binaries / "activate-private-gallery", str(case.child.pid),
        case.plan.binaries / "examples/fab_menu_native",
    ], timeout=3))


def public(case, mode, selected, focused, press_names):
    labels = [*NAMES.values()]
    if mode != "bottom":
        labels.append(DISCLOSURES[mode])
    pressed = set(press_names)
    active_name = NAMES[selected]
    focus_name = DISCLOSURES[mode] if focused == TOGGLE else NAMES[focused]
    deadline = time.monotonic() + 5.
    recovery = []
    next_recovery = 0.
    while True:
        result = AX["inspect"](case.child.pid)
        buttons = {item["name"]: item for item in result["buttons"]}
        recover_focus = not result["windows"]
        if (result["trusted"] and not result["modals"] and len(result["navigation"]) == 1
                and len(result["buttons"]) == len(labels) and set(buttons) == set(labels)):
            semantics = all(item["current"] == ("page" if name == active_name else None)
                            and item["lists_current"] is (name == active_name)
                            and item["enabled"] is (name != NAMES[ARCHIVE])
                            and item["actions"].count("AXPress") == int(name in pressed)
                            for name, item in buttons.items())
            focused_item = buttons[focus_name]
            active_focus = focused_item["focused"] or focused_item["focus_attr"]
            if semantics and active_focus:
                if recovery:
                    result["private_activation"] = recovery
                return result
            recover_focus = recover_focus or (semantics and not active_focus)
        now = time.monotonic()
        require(now < deadline, f"Public AppKit navigation/focus differs: {result}; gallery activation={recovery}")
        if recover_focus:
            if len(recovery) < 3 and now >= next_recovery:
                case.point("focus-window")
                recovery.append(activate_private(case))
                next_recovery = now + .4
            case.snapshot()
        time.sleep(.05)


def children(scene, stable):
    nodes, indices = COMMON["dom_index"](scene)
    cursor = nodes[indices[stable]]["first_child"]
    layout = scene["layout"]["nodes"]
    boxes = []
    while cursor is not None:
        boxes.append(layout[cursor]["bounds"])
        cursor = nodes[cursor]["next_sibling"]
    return boxes


def blend(ink, surface):
    opacity = ink[3] / 255.
    return [round(channel * opacity + base * (1. - opacity))
            for channel, base in zip(ink[:3], surface[:3])] + [255]


def visible_label(identity, mode):
    return LONG_INBOX if identity == INBOX and mode != "bottom" else LABELS[identity]


def paint_item(case, frame, scene, receipt, fills, text, identity, mode, selected, scale, base, palette):
    target = rect(scene, identity)
    indicator = children(scene, identity)[1 if mode == "expanded" else 0]
    icons = [
        path for item in receipt["presented"]["ops"] if (path := item.get("FillPath"))
        and contains(indicator, path["clip"]) and path["clip"]["width"] == path["clip"]["height"] == 24.
    ]
    require(icons, f"24 dp vector paint missing from {identity}")
    icon = icons[0]["clip"]
    active = identity == selected
    disabled = identity == ARCHIVE
    expected_ink = (palette["outline"] if mode == "bottom" else [*palette["on_surface_variant"][:3], 97]) if disabled else (
        palette["on_secondary_container"] if active else palette["on_surface_variant"]
    )
    require(all(same_rect(path["clip"], icon) and path["contour"]["color"] == expected_ink for path in icons),
            f"Unexpected vector dimensions or Material color for {identity}: {icons}")
    labels = [op for op in text if op["text"] == visible_label(identity, mode) and contains(target, op["rect"])]
    require(len(labels) == 1 and contains(labels[0]["clip"], labels[0]["rect"]),
            f"Label is missing, duplicated, or clipped for {identity}: {labels}")
    label, = labels
    intended_label = expected_ink
    if active and mode != "expanded":
        intended_label = palette["secondary" if mode == "collapsed" else "on_surface"]
    require(label["color"] == intended_label, f"Unexpected label ink for {identity}: {label}")
    font = label.get("font_size") or label["style"]["font_size"]
    line_dp = (20. if mode == "expanded" else 16.) * scale
    close(font, (14. if mode == "expanded" else 12.) * scale, f"{identity} actual Material text scale")
    lines = round(label["rect"]["height"] / line_dp)
    require(lines >= (2 if identity == INBOX and mode != "bottom" and scale == 2. else 1),
            f"{identity} text failed to wrap at scale {scale}: {label}")
    if identity != INBOX or mode == "bottom":
        require(lines == 1, f"Short destination label wrapped unexpectedly: {label}")
    if mode == "collapsed":
        require(indicator["width"] == 56. and indicator["height"] == 32.,
                f"Collapsed active shape differs: {indicator}")
        close(center(indicator)[0], center(icon)[0], "Centered collapsed icon")
    elif mode == "bottom":
        require(indicator["width"] == 64. and indicator["height"] == 32.,
                f"Navigation bar active shape differs: {indicator}")
    else:
        require((center(icon)[0] > center(label["rect"])[0]) is frame["rtl"]
                and indicator["height"] >= 56., f"Expanded row did not mirror icon and text: {identity}")
    require(contains(target, indicator) and target["width"] >= 48. and target["height"] >= 48.,
            f"Interactive target clipped or below 48 dp: {identity} {target}")
    selected_shape = [op for op in fills if same_rect(op["rect"], indicator) and
                      op["color"] == palette["secondary_container"]]
    require(len(selected_shape) == int(active), f"Current page indicator paint differs: {identity}")
    body = palette["secondary_container"] if active else base
    spot = (round(indicator["x"] + 9.), round(center(indicator)[1]))
    corner = (round(indicator["x"] + 1.), round(indicator["y"] + 1.))
    ink_points = sample_points(icon)
    label_points = sample_points(label["rect"])
    raster = pixels_for(case.plan.artifacts / frame["file"], frame, ink_points | label_points | {spot, corner})
    # The expanded label/icon starts at a 16 dp inset. A mid-edge point
    # verifies the fill, and the clipped corner verifies the pill shape.
    require(color_matches(raster[spot], body, 5) and color_matches(raster[corner], base, 9),
            f"Material shape raster differs at {identity}: fill {raster[spot]}, corner {raster[corner]}")
    icon_pixels = sum(color_matches(raster[point], blend(expected_ink, body), 27) for point in ink_points)
    text_base = body if mode == "expanded" else base
    matched = [point for point in label_points if color_matches(raster[point], blend(intended_label, text_base), 28)]
    occupied = sorted({min(lines - 1, int((y - label["rect"]["y"]) // line_dp)) for _, y in matched})
    require(icon_pixels >= 8 and len(matched) >= 12 and len(occupied) == lines,
            f"Metal raster is missing the vector or some label lines: {identity}, glyphs={len(matched)}, lines={occupied}")
    return {"indicator": indicator, "target": target, "icon": icon, "icon_pixels": icon_pixels,
            "label": label["rect"], "font_dp": font, "line_dp": line_dp, "label_pixels": len(matched),
            "label_lines": occupied, "indicator_pixel": raster[spot], "corner_pixel": raster[corner]}


def take(case, tag, mode, rtl, scale, selected, focused, *, pressed=()):
    case.clock.advance(550)
    navigation = BOTTOM if mode == "bottom" else RAIL_ID
    frame, scene = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{tag}",
                           case.size, case.dark, SECTION, (navigation, *ITEMS))
    require(not frame["errors"] and scene["interaction"]["focused"] == focused,
            f"Capture or focus differs in {tag}: {frame['errors']} {scene['interaction']}")
    require(node(scene, PAGE)["text"] == NAMES[selected], "Controlled page and selection differ")
    receipt = json.loads(case.receipt.read_text())
    ax = receipt["accesskit"]["nodes"]
    require(not any(item["modal"] for item in ax.values()), "The rail opened a modal scope")
    nav = rect(scene, navigation)
    layout, content = rect(scene, LAYOUT), rect(scene, CONTENT)
    require(contains(layout, nav) and contains(layout, content), "Rail reflow escaped the example")
    require(ax[navigation]["role"] == "Navigation" and ax[navigation]["name"] == AX["LANDMARK"]
            and not ax[navigation]["press"], "Wrong AccessKit navigation landmark")
    if mode == "bottom":
        require(TOGGLE not in ax and RAIL_ID not in ax and nav["y"] >= content["y"] + content["height"]
                and 0. < content["height"], "Compact fallback has the wrong geometry or still includes the rail")
    else:
        require(BOTTOM not in ax and ax[TOGGLE]["expanded"] is (mode == "expanded")
                and ax[TOGGLE]["name"] == DISCLOSURES[mode] and ax[TOGGLE]["press"],
                "Disclosure is missing or reports the wrong state")
        require((nav["width"] == 96. if mode == "collapsed" else 220. <= nav["width"] <= 360.)
                and content["width"] > 0. and (center(content)[0] < center(nav)[0]) is rtl,
                f"Nonmodal rail width or direction differs: {nav} {content}")
        close(nav["y"], content["y"], "Adjacent content sits beside the rail")
    pressable = [identity for identity in (*ITEMS, TOGGLE) if identity in ax and ax[identity]["press"]]
    press_names = [DISCLOSURES[mode] if identity == TOGGLE else NAMES[identity] for identity in pressable]
    live = public(case, mode, selected, focused, press_names=press_names)
    entries = [op["Legacy"] for op in receipt["presented"]["ops"] if "Legacy" in op]
    fills = [op[kind] for op in entries for kind in ("Shape", "Quad") if kind in op]
    text = [op[kind] for op in entries for kind in ("Text", "StyledText") if kind in op]
    palette = case.plan.palette["dark" if case.dark else "light"]
    base = palette["surface_container" if mode == "bottom" else "surface"]
    require(node(scene, navigation)["style"]["background"] == base, "Wrong rail Surface token")
    require(not any(0 < op["color"][3] < 255 and op["color"][:3] == palette["scrim"][:3]
                    and same_rect(op["rect"], frame["viewport"]) for op in fills),
            "A full-viewport scrim appeared with nonmodal navigation")
    frame.update(stage=tag, mode=mode, rtl=rtl, text_scale=scale, nav=nav, content=content,
                 focused=focused, selected=selected)
    paint = {}
    for identity in ITEMS:
        item = ax[identity]
        disabled = identity == ARCHIVE
        require(item["role"] == "Button" and item["name"] == NAMES[identity] and not item["children"]
                and item["current_page"] == ("Page" if identity == selected else None)
                and item["selected"] is (identity == selected) and item["disabled"] is disabled
                and item["press"] is not disabled and item["focused"] is (identity == focused),
                f"AccessKit current state or button semantics differ: {identity}: {item}")
        paint[identity] = paint_item(case, frame, scene, receipt, fills, text, identity,
                                     mode, selected, scale, base, palette)
    boxes = [row["target"] for row in paint.values()]
    require(all(contains(nav, target) and contains(layout, target) for target in boxes),
            f"Destination escaped the rail surface: navigation {nav}, targets {boxes}")
    if mode == "bottom":
        fab = rect(scene, GALLERY_FAB)
        require(all(not RAIL["NAV"]["overlap_rect"](target, fab) for target in boxes),
                f"The Gallery FAB overlapped the compact capture: {fab}")
        require((boxes[0]["x"] > boxes[1]["x"] > boxes[2]["x"] if rtl
                 else boxes[0]["x"] < boxes[1]["x"] < boxes[2]["x"]), "Compact ordering differs")
    else:
        require(boxes[0]["y"] < boxes[1]["y"] < boxes[2]["y"], "Vertical ordering differs")
    actions = [json.loads(line) for line in receipt["trace"].splitlines()]
    actual = [(event["data"]["source"] or {}).get("id") for event in actions if event["kind"] == "Message"]
    trace = [identity for identity in actual if identity in ITEMS]
    require(trace == list(pressed), f"Expected exactly one destination action after Press: {trace}")
    samples = [(3, 3), (case.size[0] - 4, 3)]
    backdrop = pixels_for(case.plan.artifacts / frame["file"], frame, samples)
    frame.update(paint=paint, trace=trace, navigation=ax[navigation], accessibility=ax, macos=live,
                 backdrop=[backdrop[point] for point in samples])
    case.frames.append(frame)
    return frame


def reveal(case):
    QA["reveal"](case, LAYOUT)
    if case.size == (320, 240):
        scene = case.snapshot()
        layout, fab = rect(scene, LAYOUT), rect(scene, GALLERY_FAB)
        delta = layout["y"] + layout["height"] - (fab["y"] - 8.)
        if delta > 0.:
            case.point("scroll", (case.size[0] / 2., case.size[1] / 2.), delta)


def await_page(case, expected):
    deadline = time.monotonic() + 3.
    while node(case.snapshot(), PAGE)["text"] != NAMES[expected]:
        require(time.monotonic() < deadline, f"Press did not select {expected}")
        time.sleep(.05)


def press_once(case, label):
    deadline = time.monotonic() + 4.
    recovery = []
    while True:
        result = AX["inspect"](case.child.pid, activate=label)
        if "press_status" in result:
            require(result["press_status"] == 0, f"AppKit AXPress failed: {result}")
            return
        require(time.monotonic() < deadline,
                f"AppKit did not expose {label}: {result}; gallery activation={recovery}")
        if len(recovery) < 2 and not result["windows"]:
            case.point("focus-window")
            recovery.append(activate_private(case))
        time.sleep(.1)


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2.:
        case.call("action", "activate", SCALE)
    case.point("leave")
    reveal(case)
    if case.size[0] < 600:
        focus(case, HOME)
        take(case, "bottom-home", "bottom", rtl, scale, HOME, HOME)
        key(case, "left" if rtl else "right", INBOX)
        take(case, "bottom-arrow", "bottom", rtl, scale, HOME, INBOX)
        key(case, "enter", INBOX)
        capture = take(case, "bottom-pressed", "bottom", rtl, scale, INBOX, INBOX, pressed=(INBOX,))
        if case.dark:
            other = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
            require(read_png(case.plan.artifacts, capture) == read_png(case.plan.artifacts, other),
                    "Same settled CLI and MCP frames differ")
            return {**other, "cli": capture["file"]}
        return None
    focus(case, TOGGLE)
    collapsed = take(case, "collapsed", "collapsed", rtl, scale, HOME, TOGGLE)
    key(case, "enter", TOGGLE)
    reveal(case)
    expanded = take(case, "expanded", "expanded", rtl, scale, HOME, TOGGLE)
    require(expanded["nav"]["width"] > collapsed["nav"]["width"]
            and expanded["content"]["width"] < collapsed["content"]["width"]
            and expanded["backdrop"] == collapsed["backdrop"], "Expand failed to reflow or introduced a scrim")
    key(case, "tab", HOME)
    key(case, "down", INBOX)
    take(case, "arrow", "expanded", rtl, scale, HOME, INBOX)
    press_once(case, NAMES[INBOX])
    await_page(case, INBOX)
    take(case, "pressed", "expanded", rtl, scale, INBOX, INBOX, pressed=(INBOX,))
    if case.dark:
        for width, tag, mode in [(600, "round-trip-600", "expanded"),
                                 (599, "round-trip-599", "bottom"),
                                 (600, "round-trip-returned", "expanded")]:
            POINTER["resize"](case, (width, case.size[1]))
            reveal(case)
            take(case, tag, mode, rtl, scale, INBOX, INBOX, pressed=(INBOX,))
        focus(case, TOGGLE)
        POINTER["resize"](case, (599, case.size[1]))
        reveal(case)
        take(case, "disclosure-focus-restored", "bottom", rtl, scale, INBOX, INBOX, pressed=(INBOX,))
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", required=True, type=Path)
    parser.add_argument("--checkout", type=Path, default=HERE / "qa-exact")
    parser.add_argument("--binaries", type=Path, default=HERE / "binaries")
    parser.add_argument("--profile", choices=PROFILES, action="append")
    plan = parser.parse_args()
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    plan.checkout = plan.checkout.resolve()
    plan.binaries = plan.binaries.resolve()
    plan.client = plan.binaries / "surface-devtools"
    plan.launcher = HERE / "launch-private-wide-rail.sh"
    plan.palette = json.loads(subprocess.check_output([plan.binaries / "examples/fab_menu_native", "--palette"]))
    plan.case, plan.startup_timeout = "normal", 30
    require(AX["AX"]["trusted"](), "Run the private Gallery from an Accessibility-authorized terminal")
    report = {"runs": {}, "frames": [], "errors": []}
    for name, (size, dark, rtl, scale) in PROFILES.items():
        if plan.profile and name not in plan.profile:
            continue
        case = None
        try:
            os.environ["SURFACE_QA_WIDE_RAIL_TRACE"] = str(plan.artifacts / f"{name}-trace.jsonl")
            os.environ["SURFACE_QA_WIDE_RAIL_BIN_DIR"] = str(plan.binaries)
            with COMMON["gallery"](plan, name, size, dark) as case:
                mirror = journey(case, rtl, scale)
            log = (plan.artifacts / f"{name}.log").read_text()
            gpu = next((line for line in log.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in gpu and "backend: Metal" in gpu, "The Gallery did not use Apple Metal")
            report["runs"][name] = {"adapter": gpu, "mcp": mirror}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(traceback.format_exc(), flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(report["runs"] and not report["errors"], "Native Wide Navigation Rail checks failed")
    print(f"Passed {len(report['frames'])} PNGs across {len(report['runs'])} native rail profiles")


if __name__ == "__main__":
    main()
