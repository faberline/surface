"""Read only the named wide-rail landmark in the private Gallery AppKit tree."""

from pathlib import Path
import runpy


WORKSPACE = Path(__file__).resolve().parents[2]
CURRENT = runpy.run_path(str(WORKSPACE / "surface-md3-navigation-current.KN5yRIIv/native-navigation-current/read-current-ax.py"))
AX, attributes, actions, ax_bool, elements, equal, press = (
    CURRENT[name] for name in ("AX", "attributes", "actions", "ax_bool", "elements", "equal", "press")
)
LANDMARK = "工作區導覽"
BUTTONS = ("瀏覽首頁", "封存資料", "收件匣", "展開導覽列", "收合導覽列")


def inspect(pid, activate=None):
    result = {"trusted": AX["trusted"](), "navigation": [], "buttons": [], "modals": [], "windows": 0}
    if not result["trusted"]:
        return result
    app = AX["create_application"](pid)
    AX["set_timeout"](app, 1.)
    _, focus = AX["ax_attribute"](app, "AXFocusedUIElement")
    visited = 0
    attr = AX["scalar"]

    def walk(element, depth=0, inside=False):
        nonlocal visited
        visited += 1
        if visited > 2300 or depth > 35:
            raise RuntimeError("Private Gallery exceeded the AX tree probe budget")
        role, subrole = (attr(element, key) for key in ("AXRole", "AXSubrole"))
        if subrole == "AXDialog" and ax_bool(element, "AXModal"):
            result["modals"].append(attr(element, "AXTitle"))
        below = inside
        if subrole == "AXLandmarkNavigation" or inside and role == "AXButton":
            title = attr(element, "AXTitle")
            names = (title, attr(element, "AXDescription"), attr(element, "AXLabel"))
            if subrole == "AXLandmarkNavigation" and LANDMARK in names:
                result["navigation"].append({"name": LANDMARK, "role": role, "subrole": subrole})
                below = True
            if inside and role == "AXButton" and title in BUTTONS:
                item = {"name": title, "role": role, "enabled": ax_bool(element, "AXEnabled"),
                        "expanded": ax_bool(element, "AXExpanded"),
                        "current": attr(element, "AXARIACurrent"),
                        "lists_current": "AXARIACurrent" in attributes(element),
                        "focused": bool(focus and equal(element, focus)),
                        "focus_attr": ax_bool(element, "AXFocused"), "actions": actions(element)}
                result["buttons"].append(item)
                if activate == title and "AXPress" in item["actions"] and "press_status" not in result:
                    result["press_status"] = press(element)
        for child in elements(element, "AXChildren"):
            walk(child, depth + 1, below)

    try:
        result["window_sources"] = []
        windows_status, array = AX["ax_attribute"](app, "AXWindows")
        result["ax_windows_status"] = windows_status
        if array:
            try:
                if windows_status == 0 and AX["type_id"](array) == AX["array_type"]():
                    for index in range(AX["array_count"](array)):
                        result["windows"] += 1
                        result["window_sources"].append("AXWindows")
                        walk(AX["array_item"](array, index))
            finally:
                AX["release"](array)
        if not result["windows"]:
            for attribute in ("AXFocusedWindow", "AXMainWindow"):
                status, window = AX["ax_attribute"](app, attribute)
                if status == 0 and window:
                    try:
                        result["windows"] = 1
                        result["window_sources"].append(attribute)
                        walk(window)
                    finally:
                        AX["release"](window)
                    break
        result["visited"] = visited
    finally:
        if focus:
            AX["release"](focus)
        AX["release"](app)
    return result
