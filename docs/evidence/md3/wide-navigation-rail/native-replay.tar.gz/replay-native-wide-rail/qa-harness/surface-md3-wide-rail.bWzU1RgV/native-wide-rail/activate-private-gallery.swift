import AppKit
import ApplicationServices
import Foundation

let args = CommandLine.arguments
guard args.count == 3, let pid = pid_t(args[1]), pid > 1,
    let app = NSRunningApplication(processIdentifier: pid),
    let path = app.executableURL?.resolvingSymlinksInPath().path,
    path == URL(fileURLWithPath: args[2]).resolvingSymlinksInPath().path
else {
    exit(EXIT_FAILURE)
}

let accepted = app.activate(options: [])
let target = AXUIElementCreateApplication(pid)
AXUIElementSetMessagingTimeout(target, 0.5)
var value: CFTypeRef?
let status = AXUIElementCopyAttributeValue(target, kAXWindowsAttribute as CFString, &value)
let windows = value as? [AXUIElement] ?? []
var raised = false
if let window = windows.first {
    var windowPid: pid_t = 0
    if AXUIElementGetPid(window, &windowPid) == .success && windowPid == pid {
        raised = AXUIElementPerformAction(window, kAXRaiseAction as CFString) == .success
    }
}
let receipt: [String: Any] = [
    "pid": pid,
    "active": app.isActive,
    "activation_accepted": accepted,
    "raised": raised,
    "window_status": status.rawValue,
    "windows": windows.count,
]
let encoded = try JSONSerialization.data(withJSONObject: receipt)
print(String(decoding: encoded, as: UTF8.self))
