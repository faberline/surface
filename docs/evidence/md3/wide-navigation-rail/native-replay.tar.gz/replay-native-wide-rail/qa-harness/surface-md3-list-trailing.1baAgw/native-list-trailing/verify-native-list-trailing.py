#!/usr/bin/env python3
"""Verify independent list row and trailing icon targets on macOS Metal."""

import argparse
import json
import math
from pathlib import Path
import runpy
import subprocess

HERE = Path(__file__).resolve().parent
VIDEO = runpy.run_path(str(HERE.parents[1] / "surface-md3-list-video.5j4mlr"
                           / "native-list-video" / "verify-native-list-video.py"))
BASE, COMMON, MOTION, QA = (VIDEO[k] for k in ("BASE", "COMMON", "MOTION", "QA"))
capture, close, color_matches, contains, focus, key, node, rect, center, pixels_for, require, same_rect, sample_points, write_json = (
    VIDEO[k] for k in ("capture", "close", "color_matches", "contains", "focus", "key", "node",
                       "rect", "center", "pixels_for", "require", "same_rect", "sample_points", "write_json")
)
blend, visible_ink, paint_entries, reject, frame_row, complete_bands, all_bands = (
    VIDEO[k] for k in ("blend", "visible_ink", "paint_entries", "reject", "frame_row", "complete_bands", "all_bands")
)
VIEWPORTS, PROFILES = VIDEO["VIEWPORTS"], VIDEO["PROFILES"]
SECTION = "section-5"
PREFIX = "list-trailing-"
LIST, DIRECTION, SCALE, STATUS, DECORATIVE, CURRENT, PRIMARY_DISABLED, TAIL_DISABLED = (
    PREFIX + part for part in ("rows", "direction", "scale", "status", "decorative", "current",
                                "primary-disabled", "tail-disabled")
)
ROWS = {
    DECORATIVE: ("開啟專案消息", None, {"headline": "專案消息"}),
    CURRENT: ("開啟專案", "儲存專案", {"headline": "專案總覽", "supporting": "開啟專案可查看最新回覆與待辦事項。"}),
    PRIMARY_DISABLED: ("開啟封存", "還原封存", {"headline": "已封存"}),
    TAIL_DISABLED: ("開啟唯讀文件", "編輯唯讀文件", {"headline": "唯讀文件"}),
}
REST = {item: item.removeprefix(PREFIX) for item in ROWS}


def expect_count(case, opens, actions):
    label = node(case.snapshot(), STATUS)
    expected = f"開啟 {opens} 次，尾端操作 {actions} 次"
    require((label["text"] or label["name"]) == expected,
            f"Expected {expected!r}, observed {label['text'] or label['name']!r}")


def layout(case, snapshot, item, rtl, scale):
    primary = rect(snapshot, item + "-row")
    icon = rect(snapshot, item + "-trailing-icon")
    tail = rect(snapshot, item + "-trailing-action") if item != DECORATIVE else None
    body = {suffix: rect(snapshot, item + "-" + suffix) for suffix in ROWS[item][2]}
    item_box = rect(snapshot, item)
    list_box = rect(snapshot, LIST)
    close(item_box["width"], list_box["width"], "List item spans container")
    if case.size[0] == 320:
        require(item_box["width"] >= 216., "Narrow list lost usable width")
    require(primary["width"] >= 48. and primary["height"] >= 48. and contains(item_box, primary),
            f"{item}: primary control misses 48 dp or its row")
    require(all(contains(primary, box) for box in body.values()), f"{item}: text exceeds its hit area")
    close(icon["width"], 24., "Fixed trailing vector width")
    close(icon["height"], 24., "Fixed trailing vector height")
    target = tail or icon
    edge = ((target["x"] - item_box["x"]) if rtl else
            (item_box["x"] + item_box["width"] - target["x"] - target["width"]))
    close(edge, 16., "Mirrored logical tail inset")
    headline = body["headline"]
    gap = headline["x"] - target["x"] - target["width"] if rtl else target["x"] - headline["x"] - headline["width"]
    close(gap, 16., "Visual space between body and tail")
    if tail:
        close(tail["width"], 48., "Independent tail hit width")
        close(tail["height"], 48., "Independent tail hit height")
        face_index = node(snapshot, item + "-trailing-action")["first_child"]
        face = snapshot["layout"]["nodes"][face_index]["bounds"]
        close(face["width"], 40., "Circular state face width")
        close(face["height"], 40., "Circular state face height")
        separate = primary["x"] - tail["x"] - tail["width"] if rtl else tail["x"] - primary["x"] - primary["width"]
        require(separate > 0. and contains(item_box, tail), "Tail and primary hit targets overlap")
        require(all(abs(a - b) <= .51 for a, b in zip(center(tail), center(icon))),
                "Tail icon is not centered in its 48 dp hit area")
        require(all(abs(a - b) <= .51 for a, b in zip(center(tail), center(face))),
                "State face is not centered in the independent target")
        vertical = item_box["y"] if primary["height"] >= 88. else center(primary)[1] - 24.
        close(tail["y"], vertical, "Tail alignment in measured row")
    else:
        require(contains(primary, icon), "Decorative artwork must be inside primary target")
    if scale == 1 and case.size[0] == 960:
        close(primary["height"], 72. if item == CURRENT else 56., "Wide baseline row height")
    divider = None
    if item != TAIL_DISABLED:
        divider = rect(snapshot, item + "-divider")
        close(divider["y"], primary["y"] + primary["height"], "Divider below the hit areas")
        close(divider["height"], 1., "Divider thickness")
        close(divider["x"] - item_box["x"], 0. if rtl else 16., "Mirrored divider inset")
        close(item_box["x"] + item_box["width"] - divider["x"] - divider["width"],
              16. if rtl else 0., "Mirrored divider far edge")
    return primary, tail, icon, body, divider, item_box


def verify_axis(snapshot, receipt, item, primary, tail):
    ax = receipt["accesskit"]
    native = ax["nodes"]
    require(native[LIST]["role"] == "List" and native[LIST]["name"] == "專案操作清單",
            "Native list lost its localized name")
    require(not any(id.endswith(("-trailing-icon", "-divider", "-leading-artwork")) for id in native),
            "Decorative vector or divider entered native AX")
    require(native[item]["role"] == "ListItem" and native[item]["name"] is None
            and not native[item]["disabled"] and not native[item]["press"], "Container disabled its independent targets")
    focus_id = snapshot["interaction"]["focused"]
    views = {}
    primary_name, tail_name = ROWS[item][:2]
    for suffix, name, box, disabled in (
        ("-row", primary_name, primary, item == PRIMARY_DISABLED),
        ("-trailing-action", tail_name, tail, item == TAIL_DISABLED),
    ):
        if box is None:
            require(item + suffix not in native, f"{item}: extra action")
            continue
        # A supplemental scrolled frame can move the smaller target off-screen.
        clip = snapshot["layout"]["viewport"]
        if box["y"] + box["height"] <= clip["y"] or box["y"] >= clip["y"] + clip["height"]:
            require(item + suffix not in native or not native[item + suffix]["press"], "Offscreen control accepted clicks")
            continue
        control = native[item + suffix]
        require(control["role"] == "Button" and control["name"] == name
                and control["disabled"] is disabled and control["press"] is not disabled
                and control["focusable"] is not disabled and control["focused"] is (focus_id == item + suffix),
                f"{item}{suffix}: wrong AccessKit action or name {control}")
        _, ids = COMMON["dom_index"](snapshot)
        clip = snapshot["layout"]["nodes"][ids[item + suffix]]["clip"]
        expected = [max(box["x"], clip["x"]), max(box["y"], clip["y"]),
                    min(box["x"] + box["width"], clip["x"] + clip["width"]),
                    min(box["y"] + box["height"], clip["y"] + clip["height"])]
        require(control["bounds"] is not None and len(control["bounds"]) == 4,
                f"{item}{suffix}: missing AccessKit target bounds")
        for point, logical in zip(control["bounds"], expected):
            close(point, logical * ax["scale"], f"{item}{suffix}: native physical target bounds")
        views[suffix] = control
    names = [child["name"] for child in ax["viewport_subtree"]]
    if "-row" in views and "-trailing-action" in views:
        require(names.count(primary_name) == names.count(tail_name) == 1 and names.index(primary_name) < names.index(tail_name),
                "Native reading order did not keep primary before tail")
    return views


def verify_paint(case, frame, receipt, item, primary, tail, icon, body, divider, count_scale, focus_id):
    palette = case.plan.palette["dark" if case.dark else "light"]
    bg = palette["surface"]
    normal, secondary = palette["on_surface"], palette["on_surface_variant"]
    if item == PRIMARY_DISABLED:
        normal, secondary = blend(bg, normal, .30), blend(bg, normal, .38)
    clip = frame["viewport"]
    label_runs = paint_entries(receipt, ("Text", "StyledText"))
    text_slots = {}
    for slot, box in body.items():
        font, height = BASE["TEXT_METRICS"][slot]
        lines, bands = complete_bands(box, height * count_scale, clip)
        ink = normal if slot == "headline" else secondary
        if bands:
            text = ROWS[item][2][slot]
            paints = [op for op in label_runs if op["text"] == text and same_rect(op["rect"], box)]
            require(len(paints) == 1 and paints[0]["color"] == ink, f"{item}: missing scaled readable {slot}")
            close(paints[0]["style"]["font_size"], font * count_scale, f"{slot}: actual scaled font")
            close(paints[0]["style"]["line_height"], height * count_scale, f"{slot}: actual scaled line height")
        text_slots[slot] = (lines, bands, ink)
    wanted = [band for _, bands, _ in text_slots.values() for band in bands.values()]
    vector = None
    if contains(clip, icon):
        vector = sample_points(icon)
        expected = blend(bg, palette["on_surface"], .38) if item == TAIL_DISABLED else palette["on_surface_variant"]
        paths = [op["FillPath"] for op in receipt["presented"]["ops"] if "FillPath" in op]
        own = [op for op in paths if same_rect(op["clip"], icon)]
        require(own and all(op["contour"]["color"] == expected for op in own), f"{item}: tail vector has the wrong ink")
        wanted.append(vector)
    ruler = None
    if divider and contains(clip, divider):
        require(any(op["color"] == palette["outline_variant"] and same_rect(op["rect"], divider)
                    for op in paint_entries(receipt, ("Quad", "Shape"))), "Missing inset divider paint")
        x, _ = center(divider)
        ruler = {(math.floor(x), y) for y in range(math.floor(divider["y"]), math.ceil(divider["y"] + 1))}
        wanted.append(ruler)
    focused_ring = None
    rings = paint_entries(receipt, ("Stroke", "ShapeStroke"))
    quads = paint_entries(receipt, ("Quad",))
    local = {item + "-row": primary}
    if tail:
        local[item + "-trailing-action"] = tail
    for id, box in local.items():
        if id.endswith("-row"):
            edge = {**box, "width": 2.}
            own = [op for op in quads if same_rect(op["rect"], edge) and op["color"] == normal]
        else:
            own = [op for op in rings if same_rect(op["rect"], box) and abs(op["width"] - 2.) < .03]
        should_paint = focus_id == id
        require(bool(own) is should_paint, f"{id}: focus ring affected another hit target")
        if should_paint:
            focused_ring = {"id": id, "color": own[0]["color"], "bounds": box}
            y = math.floor(center(box)[1])
            if y < 6 or y >= frame["height"] - 6:
                y = math.floor(max(box["y"] + 8., clip["y"] + 8.))
            x = math.ceil(box["x"])
            ring_band = {(col, row) for col in range(x, x + 4) for row in range(y - 3, y + 4)}
            wanted.append(ring_band)
    require(wanted, "No visible row text or control")
    values = pixels_for(case.plan.artifacts / frame["file"], frame, set.union(*wanted))
    text = {}
    for slot, (total, bands, ink) in text_slots.items():
        observed = {str(index): sum(visible_ink(values[p], ink, bg) for p in band) for index, band in bands.items()}
        require(all(samples >= 4 for samples in observed.values()), f"{item}-{slot}: missing letter pixels")
        text[slot] = {"total": total, "sampled_ink": observed}
    icon_evidence = None
    if vector:
        painted = [p for p in vector if visible_ink(values[p], expected, bg)]
        require(len(painted) >= 10, "Trailing vector did not reach PNG pixels")
        middle = center(icon)
        icon_evidence = {"pixels": len(painted), "color": expected,
                         "point": min(painted, key=lambda p: math.dist(p, middle))}
    if ruler:
        require(any(visible_ink(values[p], palette["outline_variant"], bg) for p in ruler),
                "The inset divider did not reach the PNG")
    if focused_ring:
        observed = sum(color_matches(values[p], focused_ring["color"], 14) for p in ring_band)
        require(observed >= 3, f"{focused_ring['id']}: focus ring has no visible pixels")
        focused_ring["ink_pixels"] = observed
    return {"text": text, "icon": icon_evidence, "divider_pixels": bool(ruler), "focus_ring": focused_ring}


def take(case, stage, item, rtl, scale, counts=(0, 0), offset=None, focused=None):
    case.clock.advance(700)
    if offset is None:
        oversize = frame_row(case, item)
    else:
        y = rect(case.snapshot(), item)["y"]
        case.point("scroll", (12., case.size[1] / 2.), y - (5. - offset))
        close(rect(case.snapshot(), item)["y"], 5. - offset, f"{item}: scrolled view")
        oversize = True
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{stage}",
                              case.size, case.dark, SECTION)
    require(not frame["errors"], str(frame["errors"]))
    expect_count(case, *counts)
    focus_id = snapshot["interaction"]["focused"]
    if focused:
        require(focus_id == focused, f"Focus {focus_id!r} did not reach {focused}")
    receipt = json.loads(case.receipt.read_text())
    primary, tail, icon, body, divider, item_box = layout(case, snapshot, item, rtl, scale)
    axis = verify_axis(snapshot, receipt, item, primary, tail)
    paint = verify_paint(case, frame, receipt, item, primary, tail, icon, body, divider, scale, focus_id)
    frame.update(stage=stage, item=item, rtl=rtl, text_scale=scale, counts=counts, focused=focus_id,
                 oversize=oversize, primary=primary, tail=tail, icon=icon, body=body,
                 divider=divider, item_box=item_box, paint=paint, accesskit=axis)
    case.frames.append(frame)
    return frame


def current_points(case, item):
    frame_row(case, item)
    view = case.snapshot()
    primary = rect(view, item + "-row")
    label = rect(view, item + "-headline")
    # Even when the whole row is taller than the viewport, its first text line is visible.
    p = center(label)
    t = center(rect(view, item + "-trailing-action")) if item != DECORATIVE else None
    require(contains(primary, {"x": p[0], "y": p[1], "width": 1., "height": 1.}),
            "Primary probe is outside its hit rectangle")
    return p, t


def click(case, point, before, after, masked=False):
    case.point("move", point)
    case.point("down", point)
    expect_count(case, *before)
    if masked:
        require(case.snapshot()["interaction"]["pressed"] is None, "Inactive area captured the pointer")
    case.point("up", point)
    case.point("leave")
    expect_count(case, *after)


def cross_release(case, first, second, id, counts):
    case.point("move", first)
    case.point("down", first)
    require(case.snapshot()["interaction"]["pressed"] == id, f"{id}: wrong press owner")
    case.point("move", second)
    case.point("up", second)
    case.point("leave")
    expect_count(case, *counts)
    require(case.snapshot()["interaction"]["pressed"] is None, "Cross-target release left a held press")


def cancel_touch(case, point, id, counts):
    case.point("touch-start", point)
    require(case.snapshot()["interaction"]["pressed"] == id, f"{id}: wrong Winit touch owner")
    case.point("touch-cancel", point)
    case.point("touch-end", point)
    expect_count(case, *counts)
    require(case.snapshot()["interaction"]["pressed"] is None, "Winit TouchPhase::Cancelled left a held press")


def press_ax(case, id):
    reply = case.call("action", "qa-ax-press", id)
    require(reply["accesskit"], f"Mac native AccessKit did not activate {id}")


def journey(case, rtl, scale):
    case.call("action", "activate", SECTION)
    if rtl:
        case.call("action", "activate", DIRECTION)
    if scale == 2:
        case.call("action", "activate", SCALE)
    case.point("leave")
    result = {"mcp": None}
    row_positions = {}
    cjk = {}
    for item, stage in REST.items():
        first = take(case, stage, item, rtl, scale)
        require(first["paint"]["icon"], f"{item}: initial placement must show entire icon")
        row_positions[item] = first
        if item == CURRENT and case.size[0] == 320 and case.dark and rtl and scale == 2:
            mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
            require((case.plan.artifacts / mcp["file"]).read_bytes() ==
                    (case.plan.artifacts / first["file"]).read_bytes(), "CLI and MCP returned different PNG bytes")
            result["mcp"] = {**mcp, "cli": first["file"]}
        frames = [first]
        if first["oversize"]:
            h = case.size[1]
            max_scroll = first["item_box"]["height"] - h + 10.
            increment = round(h - 10. - 24. * scale)
            for number, offset in enumerate(range(increment, math.ceil(max_scroll), increment), start=1):
                frames.append(take(case, f"{stage}-middle-{number}", item, rtl, scale, offset=offset))
            frames.append(take(case, stage + "-tail", item, rtl, scale, offset=max_scroll))
        cjk[stage] = all_bands(*frames)
        if item != TAIL_DISABLED:
            click(case, center(frames[-1]["divider"]), (0, 0), (0, 0), masked=True)

    frame_row(case, DECORATIVE)
    saved = row_positions[DECORATIVE]
    live_icon = rect(case.snapshot(), DECORATIVE + "-trailing-icon")
    x, y = saved["paint"]["icon"]["point"]
    click(case, (x + live_icon["x"] - saved["icon"]["x"], y + live_icon["y"] - saved["icon"]["y"]), (0, 0), (1, 0))
    reject(case, "focus", DECORATIVE + "-trailing-icon", "no live AccessKit focus")
    reject(case, "press", DECORATIVE + "-trailing-icon", "no live AccessKit press")

    p, t = current_points(case, CURRENT)
    cross_release(case, p, t, CURRENT + "-row", (1, 0))
    cross_release(case, t, p, CURRENT + "-trailing-action", (1, 0))
    cancel_touch(case, p, CURRENT + "-row", (1, 0))
    cancel_touch(case, t, CURRENT + "-trailing-action", (1, 0))
    click(case, p, (1, 0), (2, 0))
    click(case, t, (2, 0), (2, 1))

    p, t = current_points(case, PRIMARY_DISABLED)
    click(case, p, (2, 1), (2, 1), masked=True)
    reject(case, "press", PRIMARY_DISABLED + "-row", "no live AccessKit press")
    click(case, t, (2, 1), (2, 2))
    p, t = current_points(case, TAIL_DISABLED)
    click(case, t, (2, 2), (2, 2), masked=True)
    reject(case, "press", TAIL_DISABLED + "-trailing-action", "no live AccessKit press")
    click(case, p, (2, 2), (3, 2))

    focus(case, SCALE)
    key(case, "tab", DECORATIVE + "-row")
    key(case, "tab", CURRENT + "-row")
    expect_count(case, 3, 2)
    key(case, "enter", CURRENT + "-row")
    take(case, "focus-primary", CURRENT, rtl, scale, (4, 2), focused=CURRENT + "-row")
    key(case, "tab", CURRENT + "-trailing-action")
    expect_count(case, 4, 2)
    key(case, "enter", CURRENT + "-trailing-action")
    take(case, "focus-tail", CURRENT, rtl, scale, (4, 3), focused=CURRENT + "-trailing-action")
    key(case, "tab", PRIMARY_DISABLED + "-trailing-action")
    key(case, "enter", PRIMARY_DISABLED + "-trailing-action")
    expect_count(case, 4, 4)
    key(case, "tab", TAIL_DISABLED + "-row")
    key(case, "enter", TAIL_DISABLED + "-row")
    expect_count(case, 5, 4)

    frame_row(case, CURRENT)
    press_ax(case, CURRENT + "-row")
    expect_count(case, 6, 4)
    press_ax(case, CURRENT + "-trailing-action")
    expect_count(case, 6, 5)
    frame_row(case, PRIMARY_DISABLED)
    press_ax(case, PRIMARY_DISABLED + "-trailing-action")
    expect_count(case, 6, 6)
    frame_row(case, TAIL_DISABLED)
    press_ax(case, TAIL_DISABLED + "-row")
    expect_count(case, 7, 6)
    return {**result, "cjk_visible_lines": cjk, "final": [7, 6], "cross_target_releases": 2,
            "winit_touch_cancellations": 2, "passive_pointer_attempts": 5, "denied_accesskit_requests": 4}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile")
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--startup-timeout", type=int, default=45)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "runs": {}, "frames": [], "errors": []}
    for viewport, theme, direction, scale in PROFILES:
        name = f"{viewport}-{theme}-{direction}-{scale}x"
        if plan.profile not in (None, name) or plan.theme not in (None, theme):
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, VIEWPORTS[viewport], theme == "dark") as case:
                result = journey(case, direction == "rtl", scale)
            output = (plan.artifacts / f"{name}.log").read_text()
            metal = next((line for line in output.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in metal and "backend: Metal" in metal, f"{name} did not use Metal")
            report["runs"][name] = {**result, "adapter": metal}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(report["errors"][-1], flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"] and report["runs"], "\n".join(report["errors"]) or "No matching journey")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
