#!/usr/bin/env python3
"""Measure the paired floating toolbar in a private native Surface Gallery."""

import argparse
import itertools
import json
import math
from pathlib import Path
import runpy
import subprocess


HERE = Path(__file__).resolve().parent
BASELINE = HERE.parents[1] / "surface-md3-floating-toolbar.hHylCD/native-floating-toolbar"
FLOATING = runpy.run_path(str(BASELINE / "verify-native-floating-toolbar.py"))
COMMON, MOTION, BASE = FLOATING["COMMON"], FLOATING["MOTION"], FLOATING["BASE"]
QA = FLOATING["QA"]
require, close, geometry = FLOATING["require"], FLOATING["close"], FLOATING["geometry"]
capture, png_pixels, write_json = FLOATING["capture"], FLOATING["png_pixels"], FLOATING["write_json"]
same_rect, style_paint = FLOATING["same_rect"], FLOATING["style_paint"]
SECTION = FLOATING["SECTION"]
BAR = "paired-toolbar"
PAIR, PREVIEW, FAB, LEADING, EXPANDED, STATUS = (
    f"{BAR}-{part}" for part in ("pair", "preview", "primary", "leading", "expanded", "status")
)
UNDO, REDO, HISTORY = (f"{BAR}-{part}" for part in ("undo", "redo", "history"))
RAIL = (UNDO, REDO, HISTORY)
SETTLE = 750
FULL = 232.


def state(case):
    snapshot = case.snapshot()
    nodes, ids = COMMON["dom_index"](snapshot)
    return snapshot, nodes, ids


def status(case):
    _, nodes, ids = state(case)
    return nodes[ids[STATUS]]["text"]


def set_selected(case, control, value):
    _, nodes, ids = state(case)
    if nodes[ids[control]]["selected"] is not value:
        case.call("action", "activate", control)


def configure(case, vertical, vibrant, rtl, leading, expanded=True):
    FLOATING["set_modes"](case, vertical, vibrant, rtl)
    set_selected(case, LEADING, leading)
    set_selected(case, EXPANDED, expanded)
    case.point("leave")
    case.clock.advance(SETTLE)
    # The paired layout needs 16 dp on each side. Its 232 dp horizontal
    # envelope does not fit the 232 dp-wide preview at 320 dp.
    return vertical or case.size[0] == 320


def measured(snapshot, stable):
    return geometry(snapshot, stable)[2]


def require_visible(snapshot, stable):
    _, _, box, clip = geometry(snapshot, stable)
    require(same_rect(box, clip), f"{stable} is clipped: {box} vs {clip}")
    return box


def center(rect):
    x, y = COMMON["center"](rect)
    return round(x), round(y)


def sample(case, frame, point):
    return png_pixels(case.plan.artifacts / frame["file"], frame, [point])[point]


def check_fill(case, frame, snapshot, receipt, stable, outer, expected):
    ops = QA["ops_for"](receipt, snapshot, stable)
    pills = style_paint(ops, ("Quad", "Shape"))
    face = next((tile["rect"] for tile in pills if tile["color"] == expected
                 and same_rect(tile["rect"], outer)), None)
    require(face is not None, f"{stable} did not paint the expected opaque theme fill {expected}")
    x, _ = center(face)
    point = (x, math.ceil(face["y"] + 5.))
    observed = sample(case, frame, point)
    require(QA["color_delta"](observed, expected) <= 5,
            f"{stable} pixel {point} is {observed}, expected {expected}")
    return {"box": face, "fill": expected, "pixel": {"point": point, "rgba": observed}}, ops


def check_focus(case, frame, receipt, stable, ops, outer):
    require(receipt["projected"][stable]["focused"], f"{stable} lost native runtime focus")
    outlines = [item for item in style_paint(ops, ("Stroke", "ShapeStroke"))
                if same_rect(item["rect"], outer) and math.isclose(item["width"], 2., abs_tol=.03)]
    require(len(outlines) == 1, f"{stable} did not paint one named focus outline")
    x, _ = center(outer)
    pixel = sample(case, frame, (x, math.ceil(outer["y"] + 1.)))
    require(QA["color_delta"](pixel, outlines[0]["color"]) <= 6,
            f"{stable} outline exists in geometry but was absent from PNG")


def check_primary_icon(case, frame, ops, outer, ink, fill):
    vectors = [op["FillPath"] for op in ops if "FillPath" in op]
    require(vectors and all(path["contour"]["color"] == ink for path in vectors),
            "Primary action is missing theme-tinted native vector paint")
    bounds = vectors[0]["clip"]
    close(bounds["width"], bounds["height"], "Primary icon aspect")
    for actual, expected in zip(COMMON["center"](bounds), COMMON["center"](outer)):
        require(abs(actual - expected) <= .51, f"Primary vector is off-center: {bounds} vs {outer}")
    close(bounds["width"], 24., "Primary icon allocation")
    samples = QA["read_samples"](case, frame, bounds)
    QA["assert_rest_pixels"](samples, ink, fill, FAB)
    return {"box": bounds, "ink": ink, "samples": samples}


def check_clock_icon(case, frame, snapshot, receipt, ink, fill):
    ops = QA["ops_for"](receipt, snapshot, HISTORY)
    vectors = [op["FillPath"] for op in ops if "FillPath" in op]
    require(len(vectors) == 1 and vectors[0]["contour"]["color"] == ink,
            "History must paint one themed clock contour")
    box = vectors[0]["clip"]
    close(box["width"], 24., "Clock icon width")
    close(box["height"], 24., "Clock icon height")
    marks = {"ring": (12., 4.), "vertical_hand": (11.6, 9.1), "horizontal_hand": (14.4, 11.4),
             "cutout": (8.1, 15.1), "outside": (2., 2.)}
    locations = {name: QA["point_in_pixel"](box, point) for name, point in marks.items()}
    pixels = png_pixels(case.plan.artifacts / frame["file"], frame, locations.values())
    for name, point in locations.items():
        color = fill if name in ("cutout", "outside") else ink
        require(QA["color_delta"](pixels[point], color) <= 5,
                f"Clock {name} pixel {point} is {pixels[point]}, expected {color}")
    return {name: {"point": point, "rgba": pixels[point]} for name, point in locations.items()}


def axes(vertical):
    return ("y", "height", "x", "width") if vertical else ("x", "width", "y", "height")


def far(rect, origin, extent):
    return rect[origin] + rect[extent]


def relative(box, outer):
    return {**box, "x": box["x"] - outer["x"], "y": box["y"] - outer["y"]}


def check_cap_pixels(case, frame, snapshot, receipt, bar):
    ops = QA["ops_for"](receipt, snapshot, BAR)
    inks = {tuple(op["FillPath"]["contour"]["color"]) for op in ops if "FillPath" in op}
    if not inks:
        return {"pixels": 0, "inks": 0}
    radius = min(bar["width"], bar["height"]) / 2.
    left, right = bar["x"] + radius, far(bar, "x", "width") - radius
    top, bottom = bar["y"] + radius, far(bar, "y", "height") - radius
    points = []
    for y in range(math.ceil(bar["y"]), math.floor(far(bar, "y", "height"))):
        dy = max(top - y - .5, y + .5 - bottom, 0.)
        for x in range(math.ceil(bar["x"]), math.floor(far(bar, "x", "width"))):
            dx = max(left - x - .5, x + .5 - right, 0.)
            # The outline can use fractional pixel coverage. Check clearly
            # outside the round cap at the centers of actual PNG pixels.
            if math.hypot(dx, dy) > radius + .65:
                points.append((x, y))
    pixels = png_pixels(case.plan.artifacts / frame["file"], frame, points)
    leaks = {point: pixel for point, pixel in pixels.items()
             if any(QA["color_delta"](pixel, ink) <= 6 for ink in inks)}
    require(not leaks, f"Toolbar artwork crossed a rounded cap: {list(leaks.items())[:6]}")
    return {"pixels": len(pixels), "inks": len(inks)}


def take(case, name, vertical, vibrant, rtl, leading, phase, focus=None, *, interactive=True):
    tag = f"{case.prefix}-{name}"
    frame, snapshot = capture(case.plan, case.plan.client, case.session, tag, case.size,
                              case.dark, SECTION, (PAIR, FAB))
    require(not frame["errors"], str(frame["errors"]))
    receipt = json.loads(case.receipt.read_text())
    require(receipt["accessibility_frame"], "The native runtime accessibility snapshot is missing")
    projected = receipt["projected"]
    nodes, ids = COMMON["dom_index"](snapshot)
    pair, fab = (require_visible(snapshot, stable) for stable in (PAIR, FAB))
    preview = measured(snapshot, PREVIEW)
    require(measured(snapshot, STATUS)["y"] >= far(preview, "y", "height") - .03,
            "Status overlaps the paired preview")
    axis, extent, cross, thickness = axes(vertical)
    close(pair[extent], FULL, "stable main-axis allocation")
    close(pair[thickness], 80., "stable cross-axis allocation")
    close(far(preview, "y", "height") - far(pair, "y", "height"), 16., "pair bottom inset")
    inline = pair["x"] - preview["x"] if rtl else far(preview, "x", "width") - far(pair, "x", "width")
    close(inline, 16., "pair inline end inset")
    close(fab["width"], fab["height"], "square primary touch target")
    require(56. <= fab[extent] <= 80., f"Primary action has invalid target size {fab}")
    physical_start = leading if vertical else leading != rtl
    if physical_start:
        close(fab[axis], pair[axis], "fixed FAB edge at the start")
    else:
        close(far(fab, axis, extent), far(pair, axis, extent), "fixed FAB edge at the end")
    require(abs((fab[cross] - pair[cross]) - (80. - fab[thickness]) / 2.) <= .51,
            "FAB did not remain centered on the stable cross axis")
    palette = "vibrant" if vibrant else "standard"
    colors = case.plan.palette["dark" if case.dark else "light"][palette]
    primary = projected[FAB]
    require(primary["role"] == "Button" and primary["name"] == "建立筆記"
            and primary["focusable"] and primary["press"], f"Invalid primary semantic action {primary}")
    actual_focus = snapshot["interaction"]["focused"]
    if focus is not None:
        require(actual_focus == focus and projected[focus]["focused"],
                f"{tag}: focus moved to {actual_focus}, expected {focus}")
    fab_paint, fab_ops = check_fill(case, frame, snapshot, receipt, FAB, fab, colors["face"])
    fab_paint["icon"] = check_primary_icon(case, frame, fab_ops, fab, colors["primary"], colors["face"])
    if focus == FAB:
        check_focus(case, frame, receipt, FAB, fab_ops, fab)

    bar = measured(snapshot, BAR) if BAR in ids else None
    if phase == "expanded":
        close(fab[extent], 56., "expanded FAB size")
        bar = require_visible(snapshot, BAR)
        close(bar[extent], 168., "expanded capsule extent")
        close(bar[thickness], 64., "expanded capsule thickness")
        close((bar[axis] - far(fab, axis, extent)) if physical_start
              else (fab[axis] - far(bar, axis, extent)), 8., "FAB gap beside the visible rail")
        close(bar[cross] - pair[cross], 8., "capsule cross-axis centering")
        metadata = projected[BAR]
        require(metadata["orientation"] == ("vertical" if vertical else "horizontal")
                and metadata["name"] == "編輯工具列" and not metadata["focusable"] and not metadata["press"],
                f"Incorrect named toolbar projection {metadata}")
        rail_nodes = [nodes[i]["stable_id"] for i in BASE["descendants"](nodes, ids[BAR])
                      if nodes[i]["role"] == "Button"]
        require(tuple(rail_nodes) == RAIL, f"Logical rail reading order changed: {rail_nodes}")
        for slot, stable in enumerate(RAIL if vertical or not rtl else tuple(reversed(RAIL))):
            target = require_visible(snapshot, stable)
            close(target[extent], 48., f"{stable} main-axis touch target")
            close(target[thickness], 48., f"{stable} cross-axis touch target")
            close(target[axis] - bar[axis], 8. + slot * 52., f"{stable} physical order and spacing")
            entry = projected[stable]
            require(entry["role"] == "Button" and entry["disabled"] == (stable == REDO)
                    and entry["press"] == (stable != REDO)
                    and entry["focusable"] == (stable != REDO), f"Invalid rail action {stable}: {entry}")
        rail_paint, _ = check_fill(case, frame, snapshot, receipt, BAR, bar, colors["bar"])
        rail_paint["clock_icon"] = check_clock_icon(case, frame, snapshot, receipt,
                                                   colors["rail"], colors["bar"])
        if focus in RAIL:
            rail_box = require_visible(snapshot, focus)
            rail_ops = QA["ops_for"](receipt, snapshot, focus)
            check_focus(case, frame, receipt, focus, rail_ops, rail_box)
    else:
        rail_paint = None
        if phase == "collapsed":
            close(fab[extent], 80., "collapsed FAB size")
            require(bar is None or bar[extent] <= .03, f"Collapsed rail still occupies {bar}")
        for stable in RAIL:
            entry = projected.get(stable, {})
            if not interactive or phase == "collapsed":
                require(not entry.get("focusable") and not entry.get("press"),
                        f"{stable} is still actionable as its rail closes")
            elif entry.get("press") or entry.get("focusable"):
                rail_target = require_visible(snapshot, stable)
                close(rail_target[extent], 48., f"{stable}: partially revealed tile became actionable")

    data = dict(orientation="vertical" if vertical else "horizontal", palette=palette, rtl=rtl,
                leading=leading, phase=phase, pair=pair, preview=preview, fab=fab_paint, bar=bar, rail=rail_paint,
                projected=projected, focused=actual_focus, status=nodes[ids[STATUS]]["text"],
                time_ms=case.clock.now)
    if phase == "moving" and bar is not None:
        data["cap_guard"] = check_cap_pixels(case, frame, snapshot, receipt, bar)
    path = f"{tag}.presentation.json"
    write_json(case.plan.artifacts / path, data)
    frame.update(data, presentation=path)
    case.frames.append(frame)
    return frame


def matrix(case):
    frames, transport = [], None
    axes_to_request = (False,) if case.size[0] == 320 else (False, True)
    for wanted, vibrant, rtl, leading in itertools.product(
            axes_to_request, (False, True), (False, True), (False, True)):
        vertical = configure(case, wanted, vibrant, rtl, leading)
        label = "-".join(("vertical" if vertical else "horizontal",
                          "vibrant" if vibrant else "standard", "rtl" if rtl else "ltr",
                          "leading" if leading else "trailing"))
        QA["reveal"](case, PAIR)
        expanded = take(case, f"{label}-expanded", vertical, vibrant, rtl, leading, "expanded")
        set_selected(case, EXPANDED, False)
        case.clock.advance(SETTLE)
        QA["reveal"](case, PAIR)
        closed = take(case, f"{label}-collapsed", vertical, vibrant, rtl, leading, "collapsed")
        require(same_rect(relative(expanded["pair"], expanded["preview"]),
                          relative(closed["pair"], closed["preview"])),
                "Pair moved within the preview when its rail collapsed")
        frames.extend((expanded["file"], closed["file"]))
        if case.size == (320, 240) and case.dark and vibrant and rtl and not leading:
            transport = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
            require(transport["sha256"] == closed["sha256"], "CLI and MCP PNG bytes differ")
            require((case.plan.artifacts / transport["file"]).read_bytes()
                    == (case.plan.artifacts / closed["file"]).read_bytes(), "CLI/MCP comparison failed")
            transport["cli"] = closed["file"]
    return {"endpoint_pngs": frames, "mcp": transport}


def focused(case, stable):
    snapshot = case.snapshot()
    result = snapshot["interaction"]["focused"]
    require(result == stable, f"Expected focus {stable}, got {result}")


def send_key(case, key, expected, *, extend=False):
    args = ("shift",) if extend else ()
    result = case.call("action", "qa-key", key, *args)
    require(result["focused"] == expected, f"Key {key} reached {result['focused']}, expected {expected}")
    return {"key": key, "shift": extend, "focused": result["focused"]}


def key_journey(case, leading):
    vibrant, rtl = True, case.dark
    vertical = configure(case, case.size[0] != 960, vibrant, rtl, leading)
    QA["reveal"](case, EXPANDED)
    case.call("action", "qa-ax-focus", EXPANDED)
    keys = []
    if leading:
        keys.append(send_key(case, "tab", FAB))
    keys.append(send_key(case, "tab", UNDO))
    previous = status(case)
    across = "down" if vertical else ("left" if rtl else "right")
    orthogonal = "left" if vertical else "up"
    keys.extend((send_key(case, orthogonal, UNDO), send_key(case, across, HISTORY),
                 send_key(case, "home", UNDO), send_key(case, "end", HISTORY)))
    require(status(case) == previous, "Keyboard navigation invoked a toolbar command")
    QA["reveal"](case, PAIR)
    undo_target = require_visible(case.snapshot(), REDO)
    point = COMMON["center"](undo_target)
    case.point("down", point)
    case.point("up", point)
    require(status(case) == previous, "Disabled Redo reacted to a native pointer press")
    # The pointer route may clear keyboard focus when the target is disabled.
    # Restore the rail focus before testing the independent Escape journey.
    case.call("action", "qa-ax-focus", HISTORY)
    focused(case, HISTORY)
    if not leading:
        keys.extend((send_key(case, "tab", FAB), send_key(case, "tab", UNDO, extend=True),
                     send_key(case, across, HISTORY)))
    case.point("leave")
    case.clock.advance(SETTLE)
    QA["reveal"](case, PAIR)
    before = take(case, f"keyboard-{'leading' if leading else 'trailing'}-before",
                  vertical, vibrant, rtl, leading, "expanded", focus=HISTORY)
    keys.append(send_key(case, "escape", FAB))
    focused(case, FAB)
    require(status(case) == previous, "Escape or fallback activated the primary action")
    case.clock.advance(SETTLE)
    QA["reveal"](case, PAIR)
    after = take(case, f"keyboard-{'leading' if leading else 'trailing'}-after",
                 vertical, vibrant, rtl, leading, "collapsed", focus=FAB)
    keys.append(send_key(case, "enter", FAB))
    new_status = status(case)
    previous_count = int(previous.rsplit(" ", 1)[-1]) if " · " in previous else 0
    require(new_status == f"建立筆記 · {previous_count + 1}",
            f"Enter didn't invoke primary action once: {new_status!r}")
    case.call("action", "qa-ax-press", FAB)
    ax_status = status(case)
    require(ax_status.startswith("建立筆記 · ")
            and int(ax_status.rsplit(" ", 1)[-1]) == int(new_status.rsplit(" ", 1)[-1]) + 1,
            "Native runtime accessible press did not activate once")
    return {"keys": keys, "before": before["file"], "after": after["file"],
            "enter_status": new_status, "accessible_press_status": ax_status}


def motion(case, reduced=False):
    leading, vibrant, rtl = case.size[0] == 420, True, case.dark
    vertical = configure(case, case.size[0] != 960, vibrant, rtl, leading)
    QA["reveal"](case, PAIR)
    before = take(case, "motion-open", vertical, vibrant, rtl, leading, "expanded")
    set_selected(case, EXPANDED, False)
    QA["reveal"](case, PAIR)
    if reduced:
        closed = take(case, "reduce-motion-closed", vertical, vibrant, rtl, leading, "collapsed")
        set_selected(case, EXPANDED, True)
        QA["reveal"](case, PAIR)
        reopened = take(case, "reduce-motion-open", vertical, vibrant, rtl, leading, "expanded")
        require(before["time_ms"] == closed["time_ms"] == reopened["time_ms"],
                "Reduced Motion endpoints did not happen at the held timestamp")
        return {"reduced_motion": True, "closed": closed["file"], "reopened": reopened["file"]}

    case.clock.advance(0)
    during = [take(case, "motion-close-000", vertical, vibrant, rtl, leading,
                   "moving", interactive=False)]
    for sample_ms, step in ((16, 16), (40, 24), (48, 8), (64, 16)):
        case.clock.advance(step)
        during.append(take(case, f"motion-close-{sample_ms:03}", vertical, vibrant, rtl,
                           leading, "moving", interactive=False))
    _, extent, _, _ = axes(vertical)
    fab_widths = [entry["fab"]["box"][extent] for entry in during]
    rail_widths = [entry["bar"][extent] if entry["bar"] else 0. for entry in during]
    require(fab_widths[0] == 56. and any(56. < fp < 80. for fp in fab_widths[1:])
            and rail_widths[0] == 168. and any(0. < w < 168. for w in rail_widths[1:]),
            f"Held closing frames did not show coupled rail/FAB motion: {fab_widths}, {rail_widths}")
    require(fab_widths == sorted(fab_widths) and rail_widths == sorted(rail_widths, reverse=True),
            "Rail and FAB did not travel in opposing directions")
    require(during[3]["cap_guard"]["pixels"] > 0 and during[3]["cap_guard"]["inks"] > 0,
            "The 48 ms regression frame must check cap pixels with visible artwork")
    set_selected(case, EXPANDED, True)
    QA["reveal"](case, PAIR)
    turned = take(case, "motion-reversed-000", vertical, vibrant, rtl, leading, "moving")
    last = during[-1]
    require(same_rect(relative(last["fab"]["box"], last["pair"]),
                      relative(turned["fab"]["box"], turned["pair"]))
            and same_rect(relative(last["bar"], last["pair"]),
                          relative(turned["bar"], turned["pair"])),
            "Changing the target jumped at the held clock timestamp")
    for ms, step in ((16, 16), (56, 40), (128, 72)):
        case.clock.advance(step)
        during.append(take(case, f"motion-reversed-{ms:03}", vertical, vibrant, rtl, leading, "moving"))
    case.clock.advance(SETTLE)
    finished = take(case, "motion-reopened", vertical, vibrant, rtl, leading, "expanded")
    return {"fab_samples": fab_widths, "rail_samples": rail_widths, "reversed_frame": turned["file"],
            "reopened": finished["file"], "frames": [entry["file"] for entry in during]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--viewport", choices=COMMON["VIEWPORTS"])
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--startup-timeout", type=int, default=180)
    parser.add_argument("--case", choices=("all", "matrix", "motion", "reduced", "keys"), default="all")
    plan = parser.parse_args()
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "theme_roles": plan.palette,
              "frames": [], "runs": {}, "errors": []}
    for view, size in COMMON["VIEWPORTS"].items():
        if plan.viewport not in (None, view):
            continue
        for theme in ("light", "dark"):
            if plan.theme not in (None, theme):
                continue
            prefix = f"{view}-{theme}-{plan.case}"
            case = None
            try:
                with COMMON["gallery"](plan, prefix, size, theme == "dark", reduced=plan.case == "reduced") as case:
                    case.call("action", "activate", SECTION)
                    case.clock.advance(SETTLE)
                    recorded = {}
                    if plan.case in ("all", "matrix"):
                        recorded["matrix"] = matrix(case)
                    if plan.case in ("all", "keys"):
                        recorded["keys"] = {str(leading): key_journey(case, leading) for leading in (False, True)}
                    if plan.case in ("all", "motion", "reduced"):
                        recorded["motion"] = motion(case, reduced=plan.case == "reduced")
                adapter = next((line for line in (plan.artifacts / f"{prefix}.log").read_text().splitlines()
                                if line.startswith("Native QA GPU adapter ")), "")
                require("backend: Metal" in adapter, f"{prefix}: native Metal adapter missing: {adapter}")
                recorded["adapter"] = adapter
                report["runs"][prefix] = recorded
            except (RuntimeError, OSError, KeyError, ValueError, TypeError, subprocess.SubprocessError) as error:
                report["errors"].append(f"{prefix}: {error}")
                print(report["errors"][-1], flush=True)
            finally:
                if case:
                    report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"], "\n".join(report["errors"]))
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} viewport/theme runs")


if __name__ == "__main__":
    main()
