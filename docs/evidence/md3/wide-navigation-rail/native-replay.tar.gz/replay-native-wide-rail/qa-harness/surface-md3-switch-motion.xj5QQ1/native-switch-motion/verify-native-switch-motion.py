#!/usr/bin/env python3
"""Measure labeled and trailing switch motion on the native Metal frame clock."""

import argparse
from dataclasses import dataclass
import json
import math
from pathlib import Path
import runpy
import subprocess

HERE = Path(__file__).resolve().parent
BASE = runpy.run_path(str(HERE.parents[1] / "surface-md3-switch-baseline.xVWRPj"
                          / "native-labeled-switch" / "verify-native-labeled-switch.py"))
LIST = BASE["TOOLING"]
COMMON, MOTION, VIEWPORTS = (BASE[k] for k in ("COMMON", "MOTION", "VIEWPORTS"))
capture, center, close, color_matches, contains, focus, key, node, pixels_for, rect, require = (
    BASE[k] for k in ("capture", "center", "close", "color_matches", "contains", "focus",
                      "key", "node", "pixels_for", "rect", "require")
)
by_center, frame_row, paint_entries, palette_roles, same_rect, sample_points, write_json = (
    BASE[k] for k in ("by_center", "frame_row", "paint_entries", "palette_roles",
                      "same_rect", "sample_points", "write_json")
)
SECTION = "section-5"
MOVING = (0, 16, 32, 60, 140, 750)
REDUCED = (0, 32, 750)
PROFILES = {
    "wide-light-ltr-1x": ("wide", False, False, 1, False),
    "wide-dark-rtl-1x": ("wide", True, True, 1, False),
    "narrow-light-ltr-2x": ("narrow", False, False, 2, False),
    "narrow-dark-rtl-2x": ("narrow", True, True, 2, False),
    "wide-light-ltr-1x-reduced": ("wide", False, False, 1, True),
    "narrow-dark-rtl-2x-reduced": ("narrow", True, True, 2, True),
}


@dataclass(frozen=True)
class Spec:
    family: str
    base: str
    disabled: bool = False
    selected: bool = False

    @property
    def id(self):
        return self.base if self.family == "labeled" else self.base + LIST["SWITCH"]

    @property
    def scale(self):
        return BASE["SCALE"] if self.family == "labeled" else LIST["SCALE"]


ENABLED = (
    Spec("labeled", BASE["OFF"]),
    Spec("trailing", LIST["FILE"]),
)
DISABLED = (
    Spec("labeled", BASE["DISABLED_ON"], disabled=True, selected=True),
    Spec("trailing", LIST["DISABLED"], disabled=True),
)


def expected_center(checked, rtl):
    value = 36. if checked else 16.
    return 52. - value if rtl else value


def scalar_spring(milliseconds):
    rate = math.sqrt(1400.)
    damping = rate * .9
    frequency = rate * math.sqrt(1. - .9 ** 2)
    weight = damping / frequency
    settle = math.floor(math.log(math.hypot(1., weight) / .01) / damping * 1000.)
    tc = milliseconds / 1000.
    if milliseconds >= settle:
        return 1.
    return 1. - math.exp(-damping * tc) * (math.cos(frequency * tc) + weight * math.sin(frequency * tc))


def value_count(case, spec, actions):
    if spec.family == "labeled":
        BASE["count"](case, actions)
    else:
        LIST["count"](case, (0, actions))


def geometry(snapshot, spec, rtl):
    nodes, ids = COMMON["dom_index"](snapshot)
    target = nodes[ids[spec.id]]
    layout = snapshot["layout"]["nodes"]
    if spec.family == "labeled":
        track_id = target["first_child"]
        thumb_id = nodes[track_id]["first_child"]
        label_id = target["last_child"]
        require(nodes[label_id]["text"] == BASE["label_for"](spec.id),
                "The visible label or logical track-label order changed")
        label = layout[label_id]["bounds"]
    else:
        track_id = ids[spec.base + LIST["TRACK"]]
        thumb_id = ids[spec.base + LIST["THUMB"]]
        label = rect(snapshot, spec.base + "-headline")
    box, track, thumb = (layout[idx]["bounds"] for idx in (ids[spec.id], track_id, thumb_id))
    require(min(box["width"], box["height"]) >= 48. and contains(box, track) and contains(track, thumb),
            f"{spec.id}: switch or thumb escapes its hit target")
    close(track["width"], 52., "Track width")
    close(track["height"], 32., "Track height")
    close(thumb["height"], thumb["width"], "Circular thumb geometry")
    close(center(thumb)[1], center(track)[1], "Thumb vertical center")
    close(center(track)[1], center(box)[1], "Track centered in hit target")
    if spec.family == "labeled":
        require(contains(box, label), "Visible label left the labeled hit target")
        if rtl:
            lead = box["x"] + box["width"] - track["x"] - track["width"]
            gap = track["x"] - label["x"] - label["width"]
        else:
            lead = track["x"] - box["x"]
            gap = label["x"] - track["x"] - track["width"]
        close(lead, 12., "Logical track start padding")
        close(gap, 12., "Logical label gap")
    else:
        close(box["width"], 52., "Trailing hit width")
        close(box["height"], 48., "Trailing hit height")
        close(center(track)[0], center(box)[0], "Trailing track centered in its hit target")
        primary = rect(snapshot, spec.base + LIST["PRIMARY"])
        separated = primary["x"] >= box["x"] + box["width"] if rtl else (
            box["x"] >= primary["x"] + primary["width"])
        require(contains(primary, label) and separated, "Trailing and primary target hit areas overlap")
    return {"target": box, "track": track, "thumb": thumb, "label": label}


def near_track(box, track):
    x, y = center(box)
    return (abs(box["width"] - 40.) < .03 and abs(box["height"] - 40.) < .03
            and abs(y - center(track)[1]) < 1.
            and track["x"] <= x <= track["x"] + 52.)


def feedback(receipt, boxes, palette, checked, phase, reduced, disabled):
    track, thumb = boxes["track"], boxes["thumb"]
    wanted = by_center(thumb, 40.)
    color = palette["primary" if checked else "on_surface"]
    # Release or keyboard activation can sample the state-layer color
    # transition. Its geometry still follows the exact presented center.
    def matching_ink(ink):
        if phase not in ("release", "app"):
            return ink[:3] == color[:3]
        return all(min(a, b) <= value <= max(a, b)
                   for value, a, b in zip(ink[:3], palette["primary"], palette["on_surface"]))
    ripples = [op["Ripple"] for op in receipt["presented"]["ops"]
               if "Ripple" in op and near_track(op["Ripple"]["bounds"], track)]
    static = [op for op in paint_entries(receipt, ("Quad", "Shape"))
              if near_track(op["rect"], track) and matching_ink(op["color"]) and 0 < op["color"][3] <= 31]
    require(len(ripples) + len(static) <= 1, "Duplicate local feedback")
    for pulse in ripples:
        require(same_rect(pulse["bounds"], wanted), "Ripple halo stayed at an old thumb position")
        ink = pulse["ripple"]
        close(ink["x"], center(thumb)[0], "Ripple center X")
        close(ink["y"], center(thumb)[1], "Ripple center Y")
        require(matching_ink(ink["color"]) and ink["color"][3] > 0,
                f"Unexpected ripple ink {ink['color']}")
    for layer in static:
        require(same_rect(layer["rect"], wanted), "Static feedback did not follow the moving thumb")
    if disabled or phase in ("rest", "focus", "sibling"):
        require(not ripples and not static, f"{phase}: unexpected switch feedback")
    if phase == "hover":
        require(static and not ripples, "Missing centered hover layer")
    if phase in ("press", "cancel-held"):
        require((bool(static) and not ripples) if reduced else (bool(ripples) and not static),
                "Expected the current desktop motion policy for a held press")
    if reduced:
        require(not ripples, "Reduced Motion painted an animated ripple")
    if ripples:
        return {"type": "ripple", "bounds": wanted, "color": ripples[0]["ripple"]["color"]}
    if static:
        return {"type": "static", "bounds": wanted, "color": static[0]["color"]}
    return None


def focus_proof(frame, receipt, spec, box, palette, focused):
    secondary = palette["secondary"]
    if spec.family == "labeled":
        edges = BASE["focus_edges"](box)
        fills = paint_entries(receipt, ("Quad", "Shape"))
        for name, edge in edges.items():
            own = [op for op in fills if op["color"] == secondary and same_rect(op["rect"], edge)]
            require(len(own) == int(focused), f"Labeled Secondary focus outline {name} changed")
        return BASE["focus_samples"](edges, frame["viewport"]) if focused else {}
    strokes = paint_entries(receipt, ("Stroke", "ShapeStroke"))
    own = [op for op in strokes if op["color"] == secondary and same_rect(op["rect"], box)]
    require(len(own) == int(focused), "Trailing Secondary focus outline changed")
    return LIST["ring_bands"](frame, box, True) if focused else {}


def raster_proof(case, frame, receipt, spec, boxes, checked, active, focused, phase, reduced, steady):
    track, visual, label = (boxes[k] for k in ("track", "thumb", "label"))
    palette = case.plan.palette["dark" if case.dark else "light"]
    track_color, thumb_color, border = palette_roles(palette, checked, spec.disabled)
    if active and not spec.disabled:
        thumb_color = palette["primary_container" if checked else "on_surface_variant"]
    fills = paint_entries(receipt, ("Quad", "Shape"))
    strokes = paint_entries(receipt, ("Stroke", "ShapeStroke"))
    track_ops = [op for op in fills if same_rect(op["rect"], track)]
    thumb_ops = [op for op in fills if same_rect(op["rect"], visual) and op["color"] == thumb_color]
    require(len(track_ops) == len(thumb_ops) == 1, f"{spec.id}: actual thumb or track fill missing")
    if "radius" in thumb_ops[0]:
        close(thumb_ops[0]["radius"], visual["width"] / 2, "Painted thumb radius")
    if steady:
        require(track_ops[0]["color"] == track_color, "Settled track color changed")
        own_border = [op for op in strokes if same_rect(op["rect"], track)]
        require(len(own_border) == int(border is not None), "Settled track stroke changed")
        if border:
            require(own_border[0]["color"] == border, "Off track stroke uses wrong color")
            close(own_border[0]["width"], 2., "Off track stroke width")
    proof = feedback(receipt, boxes, palette, checked, phase, reduced, spec.disabled)
    bands = focus_proof(frame, receipt, spec, boxes["target"], palette, focused)
    if focused:
        require(len(bands) == 4, "Focus target was clipped during capture")

    tx, ty = center(visual)
    scan_y = math.floor(ty)
    usable_left = math.ceil(track["x"] + 2.)
    usable_right = math.floor(track["x"] + track["width"] - 2.)
    scan = {(x, scan_y) for x in range(usable_left, usable_right)}
    middle = sample_points({"x": tx - 2., "y": ty - 2., "width": 4., "height": 4.})
    label_runs = [op for op in paint_entries(receipt, ("Text", "StyledText")) if same_rect(op["rect"], label)]
    require(label_runs, f"{spec.id}: missing label paint")
    pixels = pixels_for(case.plan.artifacts / frame["file"], frame, set.union(scan, middle, *bands.values()))
    require(sum(color_matches(pixels[p], thumb_color, 10) for p in middle) >= .9 * len(middle) >= 8,
            f"{spec.id}: current rendered thumb ink missing")
    # Use the contiguous qualifying span containing the presented center.
    # Off outline segments at the outer edges cannot lengthen this span.
    ink_columns = {x for x, y in scan if color_matches(pixels[(x, y)], thumb_color, 10)}
    pivot = min(ink_columns, key=lambda x: abs(x + .5 - tx))
    lo = hi = pivot
    while lo - 1 in ink_columns:
        lo -= 1
    while hi + 1 in ink_columns:
        hi += 1
    actual_width = hi - lo + 1
    actual_center = (lo + hi + 1.) / 2.
    require(abs(actual_width - visual["width"]) <= 3. and abs(actual_center - tx) <= 1.5,
            f"{spec.id}: PNG span {actual_width} at {actual_center}, presented width {visual['width']} at {tx}")
    focus_pixels = {name: sum(color_matches(pixels[p], palette["secondary"], 14) for p in band)
                    for name, band in bands.items()}
    if focused:
        require(min(focus_pixels.values()) >= 3, "Secondary focus did not reach all four edges")
    return {"thumb_fill": thumb_color, "track_fill": track_ops[0]["color"], "focus_edges": focus_pixels,
            "feedback": proof, "ink_span": [lo, hi], "ink_width": actual_width,
            "ink_center_x": actual_center}


def take(case, spec, tag, rtl, scale, checked, actions, reduced, phase="rest", steady=True, elapsed=None):
    frame, snapshot = capture(case.plan, case.plan.client, case.session, f"{case.prefix}-{spec.family}-{tag}",
                              case.size, case.dark, SECTION)
    require(not frame["errors"], str(frame["errors"]))
    value_count(case, spec, actions)
    state = node(snapshot, spec.id)
    require(state["checked"] is checked and state.get("disabled", False) is spec.disabled,
            f"{spec.id}: value changed outside the application action")
    interaction = snapshot["interaction"]
    active = spec.id in (interaction["focused"], interaction["hovered"], interaction["pressed"])
    if phase in ("rest", "sibling") or spec.disabled:
        require(not active, f"{spec.id}: unrelated input changed its active style")
    if phase == "focus":
        require(interaction["focused"] == spec.id and interaction["hovered"] != spec.id,
                "Keyboard-only focus did not isolate the active thumb color")
    if phase == "hover":
        require(interaction["hovered"] == spec.id and interaction["focused"] != spec.id,
                "Hover did not isolate the active thumb color")
    focused = interaction["focused"] == spec.id
    boxes = geometry(snapshot, spec, rtl)
    receipt = json.loads(case.receipt.read_text())
    if spec.family == "labeled":
        axis = BASE["accessibility"](snapshot, receipt, spec.id, boxes, checked, spec.disabled)
    else:
        primary = rect(snapshot, spec.base + LIST["PRIMARY"])
        axis = LIST["a11y"](snapshot, receipt, spec.base, primary, boxes["target"], "True" if checked else "False")
    raster = raster_proof(case, frame, receipt, spec, boxes, checked, active, focused, phase, reduced, steady)
    frame.update(stage=tag, family=spec.family, item=spec.id, phase=phase, rtl=rtl, text_scale=scale,
                 reduced=reduced, sampled_at_ms=case.clock.now, offset_ms=elapsed,
                 checked=checked, actions=actions, focused=focused, active=active,
                 accessibility=axis, raster=raster, **boxes)
    case.frames.append(frame)
    return frame


def expected_pose(frame, center_offset, width, tolerance=.53):
    box, track = frame["thumb"], frame["track"]
    require(abs(box["width"] - width) <= tolerance, f"Thumb width {box['width']} differs from {width}")
    observed = center(box)[0] - track["x"]
    require(abs(observed - center_offset) <= tolerance, f"Thumb center {observed} differs from {center_offset}")


def stable(before, after):
    for part in ("target", "track", "label"):
        require(same_rect(before[part], after[part]), f"{part} moved during thumb presentation")


def sequence(case, spec, name, rtl, scale, selected, count, reduced, preceding):
    old_offset = center(preceding["thumb"])[0] - preceding["track"]["x"]
    old_size = preceding["thumb"]["width"]
    new_offset = expected_center(selected, rtl)
    new_size = 24. if selected else 16.
    phases = REDUCED if reduced else MOVING
    frames = []
    previous_ms = 0
    start = case.clock.now
    for elapsed in phases:
        case.clock.advance(elapsed - previous_ms)
        previous_ms = elapsed
        frame = take(case, spec, f"{name}-{elapsed:03}", rtl, scale, selected, count, reduced,
                     phase=name, steady=reduced or elapsed == phases[-1], elapsed=elapsed)
        require(frame["sampled_at_ms"] == start + elapsed, "Fixed frame clock lost its monotonic sample time")
        stable(preceding, frame)
        require(frame["focused"] == preceding["focused"], "Thumb travel changed focus ownership")
        p = 1. if reduced else scalar_spring(elapsed)
        width = old_size + (new_size - old_size) * p
        x = old_offset + (new_offset - old_offset) * p
        x = min(52. - width / 2., max(width / 2., x))
        expected_pose(frame, x, width)
        frames.append(frame)
    if not reduced:
        early = frames[1:4]
        require(any(abs(f["thumb"]["width"] - old_size) > 1. for f in early),
                f"{name}: no intermediate thumb size")
        if name != "cancel":
            require(any(abs(center(f["thumb"])[0] - f["track"]["x"] - old_offset) > 1. for f in early),
                    f"{name}: no intermediate thumb position")
        if name == "release":
            require(all(frame["raster"]["feedback"] for frame in early),
                    "Release feedback did not follow the moving thumb")
    return frames[-1]


def held_mcp(case, spec, shot):
    metadata = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
    mcp = case.plan.artifacts / metadata["file"]
    cli = case.plan.artifacts / shot["file"]
    require(mcp.read_bytes() == cli.read_bytes(), "Held CLI and MCP PNG bytes differ")
    path = mcp.with_name(f"{spec.family}-held-mcp.png")
    mcp.rename(path)
    return {**metadata, "file": path.name, "cli": shot["file"]}


def run_enabled(case, spec, rtl, scale, reduced):
    require(not frame_row(case, spec.base), "Enabled switch taller than the tested viewport")
    case.point("leave")
    case.clock.advance(750)
    idle = take(case, spec, "rest", rtl, scale, False, 0, reduced)
    p = expected_center(False, rtl)
    expected_pose(idle, p, 16.)
    if spec.family == "trailing":
        case.point("move", center(idle["label"]))
        case.clock.advance(120)
        take(case, spec, "sibling-hover", rtl, scale, False, 0, reduced, phase="sibling")
        case.point("leave")
        case.clock.advance(750)

    focus(case, spec.id)
    case.clock.advance(120)
    focused = take(case, spec, "focus", rtl, scale, False, 0, reduced, phase="focus")
    expected_pose(focused, p, 16.)
    stable(idle, focused)
    focus(case, spec.scale)
    frame_row(case, spec.base)
    current = geometry(case.snapshot(), spec, rtl)
    point = center(current["label" if spec.family == "labeled" else "target"])

    case.point("move", point)
    case.clock.advance(120)
    hovered = take(case, spec, "hover", rtl, scale, False, 0, reduced, phase="hover")
    expected_pose(hovered, p, 16.)
    case.point("down", point)
    case.clock.advance(90)
    held = take(case, spec, "held", rtl, scale, False, 0, reduced, phase="press")
    expected_pose(held, p, 28.)
    stable(hovered, held)
    require(held["focused"], "Held switch lost keyboard focus")
    mirror = None
    if case.prefix == "narrow-dark-rtl-2x":
        mirror = held_mcp(case, spec, held)

    case.point("up", point)
    on = sequence(case, spec, "release", rtl, scale, True, 1, reduced, held)
    case.point("leave")
    case.clock.advance(750)
    before_key = take(case, spec, "before-key", rtl, scale, True, 1, reduced, phase="focus")
    expected_pose(before_key, expected_center(True, rtl), 24.)
    stable(on, before_key)
    key(case, "enter", spec.id)
    off = sequence(case, spec, "app", rtl, scale, False, 2, reduced, before_key)

    case.point("touch-start", point)
    require(case.snapshot()["interaction"]["pressed"] == spec.id, "Native touch missed switch")
    case.clock.advance(90)
    held_again = take(case, spec, "cancel-held", rtl, scale, False, 2, reduced, phase="cancel-held")
    expected_pose(held_again, p, 28.)
    stable(off, held_again)
    case.point("touch-cancel", point)
    case.point("touch-end", point)
    require(case.snapshot()["interaction"]["pressed"] is None, "Cancelled touch left a held press")
    sequence(case, spec, "cancel", rtl, scale, False, 2, reduced, held_again)
    return mirror


def run_disabled(case, spec, rtl, scale, reduced):
    require(not frame_row(case, spec.base), "Disabled switch taller than the tested viewport")
    case.point("leave")
    case.clock.advance(750)
    off = take(case, spec, "disabled-rest", rtl, scale, spec.selected, 2, reduced)
    point = center(off["label" if spec.family == "labeled" else "target"])
    case.point("move", point)
    case.point("down", point)
    case.clock.advance(120)
    require(case.snapshot()["interaction"]["pressed"] is None, "Disabled switch claimed a press")
    shot = take(case, spec, "disabled-held", rtl, scale, spec.selected, 2, reduced)
    expected_pose(shot, expected_center(spec.selected, rtl), 24. if spec.selected else 16.)
    stable(off, shot)
    case.point("up", point)
    case.point("leave")
    value_count(case, spec, 2)


def journey(case, rtl, scale, reduced):
    case.call("action", "activate", SECTION)
    if rtl:
        for id in (BASE["DIRECTION"], LIST["DIRECTION"]):
            case.call("action", "activate", id)
    if scale == 2:
        case.call("action", "activate", BASE["SCALE"])
    pairs = {}
    for enabled, disabled in zip(ENABLED, DISABLED):
        pair = run_enabled(case, enabled, rtl, scale, reduced)
        run_disabled(case, disabled, rtl, scale, reduced)
        if pair:
            pairs[enabled.family] = pair
    return {"mcp": pairs, "final": {"labeled": 2, "trailing": 2},
            "disabled_pointer_attempts": 2, "winit_touch_cancellations": 2}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile", choices=PROFILES, action="append")
    parser.add_argument("--startup-timeout", type=int, default=45)
    plan = parser.parse_args()
    plan.case = "normal"
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(parents=True, mode=0o700)
    plan.palette = json.loads(subprocess.check_output([plan.launcher, "--palette"]))
    report = {"capture": "Surface Page.screenshot", "runs": {}, "frames": [], "errors": []}
    for name, (width, dark, rtl, scale, reduced) in PROFILES.items():
        if plan.profile and name not in plan.profile:
            continue
        case = None
        try:
            with COMMON["gallery"](plan, name, VIEWPORTS[width], dark, reduced=reduced) as case:
                result = journey(case, rtl, scale, reduced)
            output = (plan.artifacts / f"{name}.log").read_text()
            metal = next((line for line in output.splitlines() if line.startswith("Native QA GPU adapter ")), "")
            require("Apple M1 Max" in metal and "backend: Metal" in metal, f"{name}: not Metal")
            report["runs"][name] = {**result, "adapter": metal}
        except (RuntimeError, KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
            report["errors"].append(f"{name}: {error}")
            print(report["errors"][-1], flush=True)
        finally:
            if case:
                report["frames"].extend(case.frames)
    write_json(plan.artifacts / "report.json", report)
    require(not report["errors"] and report["runs"], "\n".join(report["errors"]) or "No matching profile")
    print(f"Passed {len(report['frames'])} native PNGs in {len(report['runs'])} journeys")


if __name__ == "__main__":
    main()
