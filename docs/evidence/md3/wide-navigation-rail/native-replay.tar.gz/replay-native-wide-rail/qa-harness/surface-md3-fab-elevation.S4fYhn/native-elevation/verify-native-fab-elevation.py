#!/usr/bin/env python3
"""Measure held-frame FAB shadows in a private native Surface Gallery."""

import argparse
from contextlib import contextmanager
import json
import math
import os
from pathlib import Path
import runpy
import subprocess
import tempfile
import time


HERE = Path(__file__).resolve().parent
COMMON = runpy.run_path(str(HERE.parents[1] /
                            "surface-md3-fab-menu-motion.zw6TaD/native-menu/verify-native-fab-menu.py"))
MOTION = COMMON["MOTION"]
BASE = COMMON["BASE"]
require = COMMON["require"]
close = COMMON["close"]
intersection = COMMON["intersection"]
dom_index = COMMON["dom_index"]
SECTION = "section-3"
CARD = "fab-elevation-card"
IDS = {
    "standard": ("fab-elevation-standard", "標準陰影", 3, 4),
    "lowered": ("fab-elevation-lowered", "低陰影", 1, 2),
    "bottom-app-bar": ("fab-elevation-bottom-app-bar", "底部應用列", 0, 0),
    "disabled": ("fab-elevation-disabled", "停用", 0, 0),
}
SIZES = {"small": (40., 24.), "regular": (56., 24.),
         "medium": (80., 28.), "large": (96., 36.)}
VIEWPORTS = {"wide": (960, 800), "middle": (420, 360), "narrow": (320, 240)}
# Material Web ambient then key layer, each (offset_y, blur, spread, alpha).
LEVELS = {
    0: ((0., 0., 0., 0), (0., 0., 0., 0)),
    1: ((1., 3., 1., 38), (1., 2., 0., 77)),
    2: ((2., 6., 2., 38), (1., 2., 0., 77)),
    3: ((4., 8., 3., 38), (1., 3., 0., 77)),
    4: ((6., 10., 4., 38), (2., 3., 0., 77)),
}


def cubic_half(x1, x2):
    def curve(t, a, b):
        return 3 * (1 - t) ** 2 * t * a + 3 * (1 - t) * t ** 2 * b + t ** 3

    low, high = 0., 1.
    for _ in range(30):
        middle = (low + high) / 2
        if curve(middle, x1, x2) < .5:
            low = middle
        else:
            high = middle
    return curve((low + high) / 2, 0., 1.)


INCOMING_HALF = cubic_half(.4, .2)
HOVER_OUTGOING_HALF = cubic_half(.4, .6)


def mix(first, second, amount):
    return tuple(tuple(a + (b - a) * amount for a, b in zip(left, right))
                 for left, right in zip(first, second))


def expect_layers(frame, expected):
    for index, (actual, target) in enumerate(zip(frame["layers"], expected)):
        require(actual["offset_x"] == 0., "FAB shadow drifted horizontally")
        got = (actual["offset_y"], actual["blur"], actual["spread"], actual["color"][3])
        require(all(math.isclose(x, y, abs_tol=.002) for x, y in zip(got, target)),
                f"{frame['file']}: shadow layer {index} is {got}, expected {target}")


def geometry(snapshot, stable_id):
    nodes, index = dom_index(snapshot)
    layout = snapshot["layout"]["nodes"]
    root = index[stable_id]
    box = layout[root]
    return nodes, index, box["bounds"], intersection(box["bounds"], box["clip"])


def center(rect):
    return rect["x"] + rect["width"] / 2, rect["y"] + rect["height"] / 2


def assert_frame_geometry(before, after):
    require(before["touch"] == after["touch"] and before["face"] == after["face"],
            f"{after['file']}: shadow changed the touch or painted face bounds")


class Case:
    def __init__(self, plan, prefix, size, dark, child, session, clock, receipt):
        self.plan, self.prefix, self.size, self.dark = plan, prefix, size, dark
        self.child, self.session, self.clock, self.receipt = child, session, clock, receipt
        self.frames = []

    def call(self, *args):
        return COMMON["call"](self.plan.client, self.session, *args)

    def point(self, kind, coords=(0., 0.), delta=0.):
        reply = self.call("action", "qa-pointer", kind, *map(str, (*coords, delta)))
        require(reply["posted"], f"Native route lost {kind}: {reply}")

    def snapshot(self):
        return self.call("dom", "snapshot")

    def reveal(self, stable_id):
        for _ in range(8):
            snapshot = self.snapshot()
            _, _, bounds, visible = geometry(snapshot, stable_id)
            bottom = bounds["y"] + bounds["height"]
            if visible == bounds and bounds["y"] >= 5 and bottom + 6 < self.size[1]:
                return (center(bounds), snapshot)
            preferred = (self.size[1] - bounds["height"]) / 2
            self.point("scroll", (self.size[0] / 2, self.size[1] / 2), bounds["y"] - preferred)
        raise RuntimeError(f"Could not reveal {stable_id}: {bounds}, visible {visible}")

    def frame(self, variant, stage, profile):
        stable, label, _, _ = IDS[profile]
        path = f"{self.prefix}-{variant}-{profile}-{stage}"
        frame, snapshot = COMMON["capture"](
            self.plan, self.plan.client, self.session, path, self.size, self.dark, SECTION,
        )
        require(not frame["errors"], str(frame["errors"]))
        nodes, index, hit, visible = geometry(snapshot, stable)
        layout = snapshot["layout"]["nodes"]
        button = nodes[index[stable]]
        face_id = button["first_child"]
        face = layout[face_id]["bounds"]
        glyph_id = nodes[face_id]["first_child"]
        face_size, icon_dp = SIZES[variant]
        require(button["role"] == "Button" and button["name"] == label
                and button["disabled"] is (profile == "disabled"), f"{path}: FAB semantics changed")
        for axis in ("width", "height"):
            close(face[axis], face_size, f"{path}: painted face {axis}")
            close(hit[axis], max(face_size, 48.), f"{path}: touch target {axis}")
        close(nodes[glyph_id]["style"]["font_size"], icon_dp, f"{path}: icon size")
        require(visible == hit, f"{path}: measured FAB is clipped ({hit}, {visible})")
        receipt = json.loads(self.receipt.read_text())
        projected = receipt["projected"].get(stable, {})
        require(receipt["accessibility_frame"] and bool(projected.get("press")) is (profile != "disabled"),
                f"{path}: invalid native runtime AX press state ({projected})")
        motion = receipt["sampled"][stable]
        inset = (max(face_size, 48.) - face_size) / 2 if profile != "disabled" else 0.
        close(motion["shadow_inset"], inset, f"{path}: shadow caster inset")
        patches = shadow_pixels(self.plan.artifacts / frame["file"], frame, face,
                                nodes[index[CARD]]["style"]["background"])
        focus = []
        if snapshot["interaction"]["focused"] == stable:
            focus = [
                tile for operation in receipt["paint"]["ops"]
                for kind, tile in operation.get("Legacy", {}).items()
                if kind in ("Stroke", "ShapeStroke") and tile["rect"] == hit
                and math.isclose(tile["width"], 2., abs_tol=.01)
            ]
        frame.update(time_ms=self.clock.now, variant=variant, profile=profile, stage=stage,
                     layers=motion["box_shadows"], shadow_inset=motion["shadow_inset"],
                     interaction=snapshot["interaction"], name=label, touch=hit, face=face,
                     projected=projected, pixels=patches, focus_outline=focus,
                     wants_frame=receipt["wants_frame"], actions=actions(nodes, index[CARD]))
        self.frames.append(frame)
        return frame

    def select(self, variant):
        self.point("leave")
        self.call("action", "activate", f"fab-elevation-size-{variant}")
        self.clock.advance(750)


def actions(nodes, card):
    for i in BASE["descendants"](nodes, card):
        text = nodes[i].get("text") or ""
        if text.startswith("執行次數 "):
            return int(text.rsplit(" ", 1)[-1])
    raise RuntimeError("Gallery action counter unavailable")


def shadow_pixels(path, frame, face, card_fill):
    x, _ = center(face)
    bottom = math.ceil(face["y"] + face["height"])
    points = {(col, row) for col in range(round(x) - 6, round(x) + 7)
              for row in range(bottom + 1, min(bottom + 6, frame["height"]))
              if 0 <= col < frame["width"]}
    require(len(points) >= 30, f"{path}: shadow band is clipped")
    observed = COMMON["png_pixels"](path, frame, points)
    differences = [sum(abs(x - y) for x, y in zip(pixel[:3], card_fill[:3]))
                   for pixel in observed.values()]
    return {"different": sum(delta >= 4 for delta in differences), "difference_total": sum(differences)}


def wait_for_session(session, child, seconds):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if child.poll() is not None:
            raise RuntimeError(f"Gallery exited before initializing DevTools: {child.returncode}")
        try:
            endpoint = json.loads(session.read_text())
        except (FileNotFoundError, json.JSONDecodeError):
            time.sleep(.08)
            continue
        require(endpoint["pid"] == child.pid and endpoint["endpoint"].startswith("127.0.0.1:"),
                "DevTools session does not belong to the private local Gallery")
        require(session.stat().st_mode & 0o077 == 0, "DevTools session is not private")
        return
    raise RuntimeError(f"Gallery process {child.pid} did not publish DevTools within {seconds} s")


@contextmanager
def gallery(plan, prefix, size, dark, reduced=False):
    with (tempfile.TemporaryDirectory(prefix="surface-ordinary-fab-", dir="/private/tmp") as tmp,
          (plan.artifacts / f"{prefix}.log").open("wb") as log):
        session = Path(tmp) / "session.json"
        receipt = Path(tmp) / "presented.json"
        clock = COMMON["Clock"](Path(tmp) / "frame-time")
        env = dict(os.environ, SURFACE_DEVTOOLS_SESSION=str(session),
                   SURFACE_QA_ANIMATION_TIME=str(clock.path),
                   SURFACE_QA_CAPTURE_RECEIPT=str(receipt),
                   SURFACE_REDUCED_MOTION="1" if reduced else "0")
        for key in ("SURFACE_TRACE", "SURFACE_BRIDGE_SESSION"):
            env.pop(key, None)
        env.pop("SURFACE_QA_POINTER_AUTOMATION", None)
        if plan.case != "ax":
            env["SURFACE_QA_POINTER_AUTOMATION"] = "1"
        child = subprocess.Popen((plan.launcher, *map(str, size)), cwd=plan.checkout, env=env,
                                 stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
        print(f"{prefix}: spawned Gallery PID {child.pid}", flush=True)
        try:
            start = time.monotonic()
            wait_for_session(session, child, plan.startup_timeout)
            case = Case(plan, prefix, size, dark, child, session, clock, receipt)
            print(f"{prefix}: DevTools ready in {time.monotonic() - start:.1f} s", flush=True)
            start = time.monotonic()
            result = subprocess.run(
                (plan.client, "--session", session, "capabilities"), capture_output=True,
                text=True, timeout=plan.startup_timeout,
            )
            require(result.returncode == 0, f"Native capability request failed: {result.stderr}")
            require("Page.screenshot" in json.loads(result.stdout)["methods"], "Native capture missing")
            print(f"{prefix}: first CLI reply in {time.monotonic() - start:.1f} s", flush=True)
            nodes, index = dom_index(case.snapshot())
            if nodes[index["theme"]]["checked"] is not dark:
                case.call("action", "activate", "theme")
            case.call("action", "activate", SECTION)
            clock.advance(1000)
            yield case
        finally:
            MOTION["stop"](child)


def hover_and_exit(case, variant, profile):
    stable, _, low, high = IDS[profile]
    start, target = LEVELS[low], LEVELS[high]
    point, _ = case.reveal(stable)
    case.point("leave")
    case.clock.advance(160)
    resting = case.frame(variant, "rest", profile)
    expect_layers(resting, start)
    case.point("move", point)
    incoming = []
    mcp = None
    for sample, elapsed, progress in ((0, 0, 0.), (60, 60, INCOMING_HALF), (120, 60, 1.)):
        case.clock.advance(elapsed)
        frame = case.frame(variant, f"hover-{sample:03}", profile)
        expect_layers(frame, mix(start, target, progress))
        assert_frame_geometry(resting, frame)
        expected_hover = None if profile == "disabled" else stable
        require((frame["interaction"]["hovered"] == stable) == (expected_hover is not None),
                f"{frame['file']}: native hover did not follow semantics")
        incoming.append(frame)
        if (case.size, case.dark, variant, profile, sample) == ((320, 240), True, "medium", "standard", 60):
            mcp = MOTION["check_mcp"](case.plan, case.plan.client, case.session, case.size)
            require(mcp["sha256"] == frame["sha256"], "Held CLI and MCP PNGs differ")
            mcp.update(cli_file=frame["file"])
    if high > low:
        difference = [shot["pixels"]["difference_total"] for shot in (resting, *incoming)]
        require(difference[0] < difference[2] < difference[3],
                f"{incoming[-1]['file']}: PNG shadow gradient {difference}")
    else:
        require(all(shot["pixels"]["difference_total"] < 12 for shot in incoming),
                f"{incoming[-1]['file']}: zero elevation painted shadow pixels")
    case.point("leave")
    for sample, elapsed, progress in ((0, 0, 0.), (60, 60, HOVER_OUTGOING_HALF), (120, 60, 1.)):
        case.clock.advance(elapsed)
        frame = case.frame(variant, f"leave-{sample:03}", profile)
        expect_layers(frame, mix(target, start, progress))
        assert_frame_geometry(resting, frame)
    return {"label": resting["name"], "rest_to_hover": [low, high], "mcp": mcp}


def redirect(case, variant, profile):
    stable, _, low, high = IDS[profile]
    point, _ = case.reveal(stable)
    case.point("leave")
    case.clock.advance(160)
    rest = LEVELS[low]
    case.point("move", point)
    case.clock.advance(60)
    mid = case.frame(variant, "redirect-hover-060", profile)
    sampled = mix(rest, LEVELS[high], INCOMING_HALF)
    expect_layers(mid, sampled)
    case.point("down", point)
    held = case.frame(variant, "redirect-press-000", profile)
    require(held["layers"] == mid["layers"], "Same-time press changed sampled shadow")
    require(held["interaction"]["pressed"] == stable, "Native pointer did not press FAB")
    assert_frame_geometry(mid, held)
    case.clock.advance(60)
    halfway = case.frame(variant, "redirect-press-060", profile)
    expect_layers(halfway, mix(sampled, rest, INCOMING_HALF))
    case.clock.advance(60)
    bound = case.frame(variant, "redirect-press-120", profile)
    expect_layers(bound, rest)
    case.point("leave")
    case.point("cancel")
    cancelled = case.frame(variant, "redirect-cancel", profile)
    expect_layers(cancelled, rest)
    require(cancelled["interaction"]["pressed"] is None, "Cancel left a live press")
    case.point("up", point)
    released = case.frame(variant, "redirect-release", profile)
    require(released["actions"] == mid["actions"], "Canceled FAB press activated on release")
    return {"before": mid["layers"], "redirect": held["layers"]}


def disabled_pointer(case, variant):
    point, _ = case.reveal(IDS["disabled"][0])
    before = case.frame(variant, "inert-start", "disabled")
    case.point("move", point)
    case.point("down", point)
    case.point("up", point)
    after = case.frame(variant, "inert-release", "disabled")
    require(before["actions"] == after["actions"] and after["interaction"]["pressed"] is None
            and after["interaction"]["hovered"] != IDS["disabled"][0],
            "Disabled FAB accepted native input")
    expect_layers(after, LEVELS[0])
    return {"inert": True}


def reduced(case, variant):
    case.select(variant)
    point, _ = case.reveal(IDS["standard"][0])
    idle = case.frame(variant, "reduced-rest", "standard")
    case.point("move", point)
    hovered = case.frame(variant, "reduced-hover", "standard")
    case.point("down", point)
    pressed = case.frame(variant, "reduced-press", "standard")
    require(all(frame["time_ms"] == idle["time_ms"] for frame in (hovered, pressed)),
            "Reduced Motion advanced the held clock")
    expect_layers(idle, LEVELS[3])
    expect_layers(hovered, LEVELS[4])
    expect_layers(pressed, LEVELS[3])
    case.point("cancel")
    return {"clock_ms": idle["time_ms"], "immediate": True}


def live_ax(case, variant, profile):
    case.select(variant)
    stable, label, low, _ = IDS[profile]
    case.reveal(stable)
    active = MOTION["make_active"](case.plan.probe, case.child)
    case.call("action", "qa-ax-focus", stable)
    case.clock.advance(160)
    frame = case.frame(variant, "ax-focus", profile)
    expect_layers(frame, LEVELS[low])
    require(frame["interaction"]["focused"] == stable and frame["projected"]["focused"],
            "Surface did not publish native focus")
    require(len(frame["focus_outline"]) == 1, "Native frame has no sampled FAB focus stroke")
    x, _ = center(frame["touch"])
    y = math.ceil(frame["touch"]["y"] + 1)
    points = {(col, y) for col in range(round(x) - 3, round(x) + 4)}
    pixels = COMMON["png_pixels"](case.plan.artifacts / frame["file"], frame, points)
    ink = frame["focus_outline"][0]["color"]
    require(sum(all(abs(c - own) <= 6 for c, own in zip(p[:3], ink[:3]))
                for p in pixels.values()) >= 4, "FAB focus stroke absent from captured pixels")
    for _ in range(9):
        observation = BASE["query_ax"](case.plan.probe, case.child, label)
        matches = [node for node in observation["matches"] if node["role"] == "AXButton"]
        if observation["active"] and len(matches) == 1 and matches[0]["focused"]:
            box = matches[0]["size"]
            for axis in ("width", "height"):
                close(box[axis], frame["touch"][axis], "live AppKit focus bounds")
            break
        time.sleep(.12)
    else:
        raise RuntimeError(f"Live AppKit focus not available: {observation}")
    pressed = BASE["query_ax"](case.plan.probe, case.child, label, "--press")
    require(pressed.get("pressStatus") == 0, f"Native FAB AXPress failed: {pressed}")
    time.sleep(.12)
    after = case.frame(variant, "ax-pressed", profile)
    require(after["actions"] == frame["actions"] + 1, "Native AXPress did not activate FAB")
    case.reveal(IDS["disabled"][0])
    disabled = BASE["query_ax"](case.plan.probe, case.child, IDS["disabled"][1])
    candidates = [node for node in disabled["matches"] if node["role"] == "AXButton"]
    require(any(not node["enabled"] and "AXPress" not in node["actions"] for node in candidates),
            f"Disabled FAB exposed AXPress: {disabled}")
    return {"activation": active, "focus": observation, "press": pressed, "disabled": disabled}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--debug-dir", type=Path, required=True)
    parser.add_argument("--probe", type=Path)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--viewport", choices=VIEWPORTS)
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--variant", choices=SIZES)
    parser.add_argument("--profile", choices=IDS)
    parser.add_argument("--case", choices=("matrix", "reduced", "ax"), default="matrix")
    parser.add_argument("--startup-timeout", type=int, default=180)
    plan = parser.parse_args()
    if plan.startup_timeout < 1:
        parser.error("--startup-timeout must be positive")
    plan.client = plan.debug_dir / "surface-devtools"
    plan.launcher = plan.debug_dir / "examples/fab_menu_native"
    if plan.case == "ax" and (plan.probe is None or plan.profile == "disabled"):
        parser.error("AX mode needs a Swift probe and an enabled FAB")
    plan.artifacts.mkdir(parents=True, exist_ok=False)
    report = {"capture": "Surface Page.screenshot", "frames": [], "runs": {}, "errors": []}
    for view, size in VIEWPORTS.items():
        if (plan.viewport or ("wide" if plan.case == "ax" else None)) not in (None, view):
            continue
        for theme in ("light", "dark"):
            if (plan.theme or ("dark" if plan.case == "ax" else None)) not in (None, theme):
                continue
            prefix = f"{view}-{theme}-{plan.case}"
            case = None
            try:
                with gallery(plan, prefix, size, theme == "dark", reduced=plan.case == "reduced") as case:
                    for variant in SIZES:
                        if (plan.variant or ("medium" if plan.case == "ax" else None)) not in (None, variant):
                            continue
                        if plan.case == "reduced":
                            report["runs"][f"{prefix}-{variant}"] = reduced(case, variant)
                        elif plan.case == "ax":
                            profile = plan.profile or "standard"
                            report["runs"][f"{prefix}-{variant}"] = live_ax(case, variant, profile)
                        else:
                            case.select(variant)
                            for profile in IDS:
                                if plan.profile not in (None, profile):
                                    continue
                                key = f"{prefix}-{variant}-{profile}"
                                report["runs"][key] = hover_and_exit(case, variant, profile)
                            if (view, theme, variant) == ("wide", "dark", "medium"):
                                for profile in ("standard", "lowered"):
                                    if plan.profile in (None, profile):
                                        report["runs"][f"{prefix}-{variant}-{profile}-redirect"] = redirect(case, variant, profile)
                                if plan.profile in (None, "disabled"):
                                    report["runs"][f"{prefix}-{variant}-disabled-pointer"] = disabled_pointer(case, variant)
            except (RuntimeError, OSError, KeyError, TypeError, ValueError, subprocess.SubprocessError) as error:
                report["errors"].append(f"{prefix}: {error}")
                print(report["errors"][-1], flush=True)
            finally:
                if case:
                    report["frames"].extend(case.frames)
    COMMON["write_json"](plan.artifacts / "report.json", report)
    if report["errors"]:
        raise SystemExit("\n".join(report["errors"]))
    print(f"Passed {len(report['frames'])} PNGs in {len(report['runs'])} runs")


if __name__ == "__main__":
    main()
