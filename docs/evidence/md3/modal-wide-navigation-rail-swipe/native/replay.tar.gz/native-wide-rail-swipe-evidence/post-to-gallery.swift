import AppKit
import ApplicationServices
import CoreGraphics

private enum CaptureError: Error {
    case usage
    case postingUnavailable
    case wrongProcess
    case noMatchingWindow
    case invalidLocalPoint
    case cannotMakeEvent
}

private func attribute(_ element: AXUIElement, _ name: String) -> CFTypeRef? {
    var result: CFTypeRef?
    return AXUIElementCopyAttributeValue(element, name as CFString, &result) == .success
        ? result : nil
}

private func contentOrigin(pid: pid_t, width: Double, height: Double) throws -> CGPoint {
    let app = AXUIElementCreateApplication(pid)
    AXUIElementSetMessagingTimeout(app, 0.5)
    let windows = attribute(app, "AXWindows") as? [AXUIElement] ?? []
    for window in windows {
        guard let sizeValue = attribute(window, "AXSize"),
              let originValue = attribute(window, "AXPosition"),
              CFGetTypeID(sizeValue) == AXValueGetTypeID(),
              CFGetTypeID(originValue) == AXValueGetTypeID() else { continue }
        var outer = CGSize.zero
        var origin = CGPoint.zero
        guard AXValueGetValue(unsafeBitCast(sizeValue, to: AXValue.self), .cgSize, &outer),
              AXValueGetValue(unsafeBitCast(originValue, to: AXValue.self), .cgPoint, &origin),
              abs(outer.width - width) < 0.5,
              outer.height >= height, outer.height < height + 60 else { continue }
        return CGPoint(x: origin.x, y: origin.y + outer.height - height)
    }
    throw CaptureError.noMatchingWindow
}

private func run() throws {
    let args = Array(CommandLine.arguments.dropFirst())
    if args == ["--preflight"] {
        print(CGPreflightPostEventAccess() && AXIsProcessTrusted())
        return
    }
    guard args.count == 7,
          let pid = pid_t(args[0]), pid > 1,
          let width = Double(args[2]), let height = Double(args[3]),
          (1...4096).contains(width), (1...4096).contains(height),
          let x = Double(args[5]), let y = Double(args[6]) else { throw CaptureError.usage }
    guard CGPreflightPostEventAccess() && AXIsProcessTrusted() else {
        throw CaptureError.postingUnavailable
    }

    // Deliberately address one expected scratch binary. Never send unscoped
    // system-wide mouse events or bring a different application forward.
    let expected = URL(fileURLWithPath: args[1]).resolvingSymlinksInPath()
    guard expected.path.hasPrefix("/private/tmp/surface-md3-wide-rail-swipe-native."),
          expected.lastPathComponent == "public_screenshot_gallery",
          let process = NSRunningApplication(processIdentifier: pid),
          process.executableURL?.resolvingSymlinksInPath().path == expected.path,
          process.isActive else { throw CaptureError.wrongProcess }
    guard x.isFinite, y.isFinite, x >= 0, y >= 0, x < width, y < height else {
        throw CaptureError.invalidLocalPoint
    }

    let kind: CGEventType
    switch args[4] {
        case "move": kind = .mouseMoved
        case "down": kind = .leftMouseDown
        case "drag": kind = .leftMouseDragged
        case "up": kind = .leftMouseUp
        default: throw CaptureError.usage
    }
    let origin = try contentOrigin(pid: pid, width: width, height: height)
    let point = CGPoint(x: origin.x + x, y: origin.y + y)
    guard let event = CGEvent(mouseEventSource: nil, mouseType: kind,
                              mouseCursorPosition: point, mouseButton: .left) else {
        throw CaptureError.cannotMakeEvent
    }
    event.setIntegerValueField(.mouseEventButtonNumber, value: 0)
    if kind != .mouseMoved {
        event.setIntegerValueField(.mouseEventClickState, value: 1)
    }
    event.postToPid(pid)
}

try run()
