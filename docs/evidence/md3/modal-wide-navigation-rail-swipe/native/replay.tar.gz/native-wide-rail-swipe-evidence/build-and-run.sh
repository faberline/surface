#!/bin/sh
set -eu

if [ "$#" -ne 2 ]; then
    echo "Usage: build-and-run.sh VERIFIED_SOURCE NEW_CAPTURE_DIR" >&2
    exit 2
fi
bundle=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
source=$(CDPATH='' cd -- "$1" && pwd)
output=$2
work=$(mktemp -d /tmp/surface-md3-wide-rail-swipe-native.XXXXXXXX)
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/tmp/cargo-target/surface-$(basename "$work")}"
digest=94d55d3426a0b9c2e790a728876e1a688b9b03e58920c733984455bc65308579
sh "$bundle/build-production.sh" "$source" "$bundle/product.sha256" "$digest" "$work/production"

cp -cR "$work/production/repo" "$work/scripted"
(
    cd "$work/scripted"
    shasum -a 256 -c "$bundle/product.sha256"
    python3 -B "$bundle/add-qa-overlay.py" "$PWD"
    shasum -a 256 -c "$bundle/scripted-source.sha256"
    cap cargo build --locked -p surface-material-gallery \
        --features surface-material-gallery/devtools,surface-platform/macos-accessibility \
        --example public_screenshot_gallery
)
mkdir "$work/scripted-bin"
cp "$CARGO_TARGET_DIR/debug/examples/public_screenshot_gallery" "$work/scripted-bin/"
python3 -B "$bundle/verify-swipe-native.py" \
    --gallery "$work/scripted-bin/public_screenshot_gallery" \
    --cli "$work/production/bin/surface-devtools" \
    --ax-reader "$work/production/bin/read-modal-gallery-ax" --artifacts "$output"
