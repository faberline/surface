#!/usr/bin/env python3
"""Probe process-targeted programmatic mouse events on the unmodified Gallery."""

import argparse
import json
from pathlib import Path
import runpy
import subprocess
import time


HERE = Path(__file__).resolve().parent
S = runpy.run_path(str(HERE / "verify-swipe-native.py"))
P = S["P"]
MODAL = S["MODAL"]
require, bounds = S["require"], S["bounds"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gallery", type=Path, required=True)
    parser.add_argument("--cli", type=Path, required=True)
    parser.add_argument("--driver", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    plan = parser.parse_args()
    width, height = 704, 512
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    plan.reduced_motion = False
    with P["start_gallery"](plan, "stock-pointer", width, height) as app:
        S["setup"](app, (width,height), False)
        app.key("enter")
        opened = S["wait_dom"](
            app, lambda s: S["stable_id"](s, MODAL) and
            abs(S["visible_width"](s, width) - bounds(s, MODAL)["width"]) <= 0.5, "stock opening"
        )
        panel = bounds(opened, MODAL)
        span = panel["width"]
        y = 12
        x0 = panel["x"] + 0.78 * span
        x1 = x0 - 0.34 * span

        def post(kind, x):
            require(app.proc.poll() is None, "Spawned Gallery exited")
            subprocess.run([plan.driver, str(app.proc.pid), plan.gallery, str(width), str(height),
                            kind, str(x), str(y)], check=True, timeout=5)

        post("move", x0)
        post("down", x0)
        try:
            post("drag", x1)
            held = S["wait_dom"](
                app, lambda s: S["stable_id"](s, MODAL) and
                abs(S["visible_width"](s, width) - span * 0.66) < 2, "stock held move"
            )
            S["expect_open"](held, S["CLOSE"])
            png, _ = S["take"](app, plan, "stock-pid-mouse-held", width, height, True)
        finally:
            post("up", x1)
        settled = S["wait_dom"](
            app, lambda s: S["stable_id"](s, MODAL) and
            abs(S["visible_width"](s, width) - span) <= 0.5, "stock subthreshold anchor"
        )
        S["expect_open"](settled, S["CLOSE"])
        report = {"input": "programmatic CGEventPostToPid", "compiled_winit_adapter": False,
                  "visible_width_dp": S["visible_width"](held, width),
                  "open_modal_width_dp": span, "subthreshold_return": True, "held_capture": png}
        (plan.artifacts/"report.json").write_text(json.dumps(report, indent=2) + "\n")
        print("Verified stock process-targeted mouse hold and return.", flush=True)


if __name__ == "__main__":
    main()
