#!/bin/sh
set -eu

if [ "$#" -ne 4 ]; then
    echo "Usage: build-production.sh PRODUCT_SOURCE MANIFEST MANIFEST_DIGEST NEW_BUILD_DIR" >&2
    exit 2
fi
helper=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
source=$(CDPATH='' cd -- "$1" && pwd)
manifest_dir=$(CDPATH='' cd -- "$(dirname -- "$2")" && pwd)
manifest="$manifest_dir/$(basename -- "$2")"
digest=$3
target=$4
case "$target" in
    /tmp/*|/private/tmp/*) ;;
    *) echo "Use a new build directory under /tmp" >&2; exit 2 ;;
esac
test "$(shasum -a 256 "$manifest" | awk '{print $1}')" = "$digest"
(cd "$helper" && shasum -a 256 -c helper-inputs.sha256)
mkdir "$target"
mkdir "$target/repo" "$target/bin"
rsync -a --exclude='/.git' --exclude='/target' --exclude='/artifacts' "$source/" "$target/repo/"
cp "$manifest" "$target/product.sha256"
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/tmp/cargo-target/surface-$(basename "$target")}"
case "$CARGO_TARGET_DIR" in
    /tmp/cargo-target/*) ;;
    *) echo "Cargo target must be under /tmp/cargo-target" >&2; exit 2 ;;
esac
cd "$target/repo"
shasum -a 256 -c "$target/product.sha256"
mkdir -p examples/material-gallery/examples
cp "$helper/public_screenshot_gallery.rs" examples/material-gallery/examples/
cap cargo build --locked -p surface-material-gallery \
    --features surface-material-gallery/devtools,surface-platform/macos-accessibility \
    --example public_screenshot_gallery --example compact --bin surface-material-gallery \
    -p surface-devtools --bin surface-devtools
shasum -a 256 -c "$target/product.sha256"
cmp examples/material-gallery/examples/public_screenshot_gallery.rs "$helper/public_screenshot_gallery.rs"
cp "$CARGO_TARGET_DIR/debug/surface-material-gallery" "$CARGO_TARGET_DIR/debug/surface-devtools" \
    "$CARGO_TARGET_DIR/debug/examples/compact" "$CARGO_TARGET_DIR/debug/examples/public_screenshot_gallery" "$target/bin/"
swiftc -module-cache-path "$target/swift-cache" "$helper/read-modal-gallery-ax.swift" -o "$target/bin/read-modal-gallery-ax"
swiftc -module-cache-path "$target/swift-cache" "$helper/post-to-gallery.swift" -o "$target/bin/post-to-gallery"
shasum -a 256 "$target/bin/"* > "$target/binaries.sha256"
