"""Add only a private Winit event adapter to a disposable product copy."""

from pathlib import Path
import sys


helper = Path(__file__).resolve().parent
source = Path(sys.argv[1]).resolve()
assert Path("/private/tmp") in source.parents or Path("/tmp") in source.parents, source
platform = source / "crates" / "surface-platform" / "src"
root = platform / "lib.rs"
driver = platform / "qa_swipe.rs"
assert not driver.exists()
source_text = root.read_text()
needle = "        if request.method == PAGE_SCREENSHOT {"
assert source_text.count(needle) == 1
intercept = """        if request.method == "QA.swipeInput" && std::env::var_os("SURFACE_QA_SWIPE").is_some() {
            let response = match qa_swipe::dispatch(self, event_loop, &request.params) {
                Ok(()) => Reply::ok(request.id, serde_json::Value::Null),
                Err(message) => Reply::error(request.id, ErrorCode::InvalidParams, message),
            };
            reply.send(response);
            return;
        }
"""
assert "QA.swipeInput" not in source_text
root.write_text(source_text.replace(needle, intercept + needle) + """
#[cfg(all(feature = "devtools", not(target_arch = "wasm32")))]
mod qa_swipe;
""")
driver.write_bytes((helper / driver.name).read_bytes())
