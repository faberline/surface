"""Collect ordered Page.screenshot replies on one public DevTools connection."""

from contextlib import contextmanager
import ipaddress
import json
import socket
import stat
import time
from urllib.parse import urlsplit


MAX_REPLY = 16 * 1024 * 1024


@contextmanager
def open_session(path, pid):
    if stat.S_IMODE(path.stat().st_mode) != 0o600:
        raise RuntimeError("Expected a private DevTools session file")
    session = json.loads(path.read_text())
    if (session["protocol"], session["version"], session["pid"]) != ("surface-devtools", 1, pid):
        raise RuntimeError("Session does not identify the spawned Surface process")
    endpoint = urlsplit("//" + session["endpoint"])
    if not ipaddress.ip_address(endpoint.hostname).is_loopback:
        raise RuntimeError("Expected a loopback DevTools endpoint")
    with socket.create_connection((endpoint.hostname, endpoint.port), timeout=7) as connection:
        connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        with connection.makefile("rb") as replies:
            yield FrameConnection(connection, replies, session["token"])


class FrameConnection:
    def __init__(self, socket, replies, token):
        self.socket = socket
        self.replies = replies
        self.token = token
        self.next_id = 1

    def exchange(self, calls):
        """Queue actions/captures in order and read the replies before decoding PNGs."""
        calls = list(calls)
        if not calls:
            raise ValueError("Expected at least one DevTools request")
        ids = range(self.next_id, self.next_id + len(calls))
        self.next_id += len(calls)
        requests = []
        for request_id, (method, params) in zip(ids, calls):
            request = {"v": 1, "id": request_id, "method": method,
                       "params": params, "token": self.token}
            requests.append(json.dumps(request, allow_nan=False).encode("utf-8") + b"\n")
        sent = time.monotonic_ns()
        self.socket.sendall(b"".join(requests))
        captured_lines = []
        for _ in calls:
            line = self.replies.readline(MAX_REPLY + 1)
            if not line.endswith(b"\n") or len(line) > MAX_REPLY:
                raise RuntimeError("DevTools reply was closed, incomplete, or over its response cap")
            captured_lines.append((line, time.monotonic_ns()))
        payloads = []
        for request_id, (method, _), (line, received) in zip(ids, calls, captured_lines):
            reply = json.loads(line)
            if reply.get("id") != request_id:
                raise RuntimeError("DevTools reply does not match the request order")
            payloads.append(
                {"method": method, "client_receive_ms": (received - sent) / 1e6,
                 "ok": reply["ok"], "result": reply.get("result"),
                 "error_code": reply.get("error", {}).get("code")}
            )
        return payloads

    def call(self, method, params):
        return self.exchange([(method, params)])[0]


def screenshot_requests(count, scale=0.5):
    return [("Page.screenshot", {"scale": scale}) for _ in range(count)]
