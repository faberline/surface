"""Measure representative archived native item-motion PNGs."""

from pathlib import Path
import json
import runpy
import sys


HERE = Path(__file__).resolve().parent
PNG = runpy.run_path(str(HERE / "verify-public-screenshot.py"))


def bounds(points):
    x, y = zip(*points)
    return [min(x), min(y), max(x), max(y)]


def sample(path, theme):
    width, height, rows = PNG["read_png"](path.read_bytes())
    assert (width, height) == (352, 256), path.name
    dark = theme == "dark"
    pill_color = bytes((74, 68, 88, 255) if dark else (232, 222, 248, 255))
    icon_color = bytes((232, 222, 248, 255) if dark else (30, 25, 43, 255))
    pill_x = range(270, 324) if dark else range(27, 80)
    pill_y = range(141, 178) if dark else range(201, 232)
    label_x = range(272, 313) if dark else range(27, 80)
    bands = (163, 179, 195, 211, 227) if dark else (227, 235)
    band_h = 12 if dark else 7

    def pixel(x, y):
        return rows[y][x * 4:x * 4 + 4]

    pill = bounds([(x, y) for y in pill_y for x in pill_x if pixel(x, y) == pill_color])
    icon = bounds([(x, y) for y in range(pill[1], pill[3] + 1)
                   for x in range(pill[0], pill[2] + 1) if pixel(x, y) == icon_color])
    ink = []
    for y0 in bands:
        points = []
        for y in range(y0, y0 + band_h):
            for x in label_x:
                red = pixel(x, y)[0]
                is_ink = 53 < red < 195 if dark else red < 205
                if is_ink:
                    points.append((x, y))
        assert len(points) >= 40, path.name
        ink.append({"bounds_inclusive_px": bounds(points), "ink_pixels": len(points)})
    assert ink[0]["bounds_inclusive_px"][1] > pill[3]
    assert ink[-1]["bounds_inclusive_px"][3] < height
    return {"png": path.name, "paint_scale": 0.5, "pill": pill, "icon_ink": icon,
            "text_ink_bands": ink}


captures = Path(sys.argv[1])
light = [sample(captures / name, "light") for name in (
    "light-ltr-collapse-3-2-118dp.png", "light-ltr-collapse-1-2-128dp.png")]
dark = [sample(captures / name, "dark") for name in (
    "dark-rtl-200-collapse-2-2-118dp.png", "dark-rtl-200-collapse-1-2-130dp.png")]
assert light[0]["pill"] != light[1]["pill"] and light[0]["icon_ink"] != light[1]["icon_ink"]
assert dark[0]["pill"] != dark[1]["pill"] and dark[0]["icon_ink"] != dark[1]["icon_ink"]
print(json.dumps({"light_ltr": light, "dark_rtl_200": dark}, indent=2))
