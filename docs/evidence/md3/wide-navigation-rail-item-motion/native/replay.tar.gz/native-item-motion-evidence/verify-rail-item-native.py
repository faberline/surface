#!/usr/bin/env python3
"""Capture the narrow portion of real inline rail motion on private Gallery windows."""

import argparse
import json
from pathlib import Path
import runpy
import time

from public_frame_burst import open_session, screenshot_requests


HERE = Path(__file__).resolve().parent
MOTION = runpy.run_path(str(HERE / "verify-wide-rail-motion.py"))
BASE = MOTION["BASE"]
MODAL_QA = MOTION["MODAL_QA"]
require, node, bounds = (BASE[key] for key in ("require", "node", "bounds"))
WIDTH, HEIGHT = 704, 512
WIDE = "wide-rail"
TOGGLE = WIDE + "-toggle"
INBOX = WIDE + "-inbox"
ARCHIVE = WIDE + "-archive"


def ax_read(plan, app, expanded):
    plan.ax_window = (WIDTH, HEIGHT, "inline")
    receipt = BASE["appkit"](plan, app.proc.pid)
    require(receipt.get("trusted"), "Native AppKit collector has no read access")
    require(receipt["windows"] == receipt["navigation_landmarks"] == 1, "Native rail landmark missing")
    in_rail = [button for button in receipt["buttons"] if button["in_rail_or_dialog"]]
    inbox = [button for button in in_rail if button["title"] == "收件匣"]
    require(len(inbox) == 1 and inbox[0].get("current") == "page", f"Duplicate or non-current AX Inbox: {in_rail}")
    toggle = next(button for button in in_rail if button["title"] in ("收合導覽列", "展開導覽列"))
    require(toggle.get("expanded") == expanded, "AppKit disclosure state differs")
    return receipt


def assert_endpoint(snapshot, expanded, rtl):
    wide = bounds(snapshot, WIDE)
    require(MOTION["viewport"](snapshot) == (WIDTH, HEIGHT), "Wrong native viewport")
    require((220 <= wide["width"] <= 360) if expanded else wide["width"] == 96, f"Endpoint rail width differs: {wide}")
    nodes = snapshot["dom"]["nodes"]
    matches = [item for item in nodes if item.get("stable_id") == INBOX]
    require(len(matches) == 1 and matches[0].get("current_page"), "Inbox ID or current semantics changed")
    require(node(snapshot, ARCHIVE)[0]["disabled"], "Archive should remain disabled")
    require(node(snapshot, TOGGLE)[0].get("expanded") == expanded, "Disclosure semantics differ")
    pane = bounds(snapshot, WIDE + "-content")
    require((pane["x"] < wide["x"]) == rtl, "Inline rail is on the wrong edge")


def raster_group(plan, name, app, connection, opened, closed, rtl):
    evidence = []
    measure = MOTION["inline_measure"](opened, closed, rtl)
    phases = ("collapse", "expand")
    # A middle capture already costs real Metal time. Vary the first request
    # modestly so a later round can catch a different near-collapsed width.
    delays = (0, 0.023, 0.050, 0.082)
    endpoint_states = (opened, closed)
    reached = set()
    for sweep, close_delay in enumerate(delays):
        for phase, endpoint in zip(phases, endpoint_states):
            trigger = ("Action.key", {"key": "enter"})
            if phase == "collapse" and close_delay:
                reply = connection.call(*trigger)
                time.sleep(close_delay)
                shot = connection.exchange(screenshot_requests(4, scale=0.5))
            else:
                reply, *shot = connection.exchange([trigger, *screenshot_requests(4, scale=0.5)])
            focused = MOTION["result"](reply)["focused"]
            require(focused == TOGGLE, "Semantic key did not keep disclosure focus")
            time.sleep(0.4)
            actual = app.dom()
            assert_endpoint(actual, phase == "expand", rtl)
            report, images = MOTION["sample_images"](shot, measure)
            for index, (sample, image) in enumerate(zip(report, images)):
                width = sample["visible_rail_dp"]
                sample["phase"] = phase
                sample["sweep"] = sweep
                sample["first_capture_delay_ms"] = round(1000 * (close_delay if phase == "collapse" else 0))
                if 99 <= width <= 150 or (index == 0 and width != bounds(endpoint, WIDE)["width"]):
                    filename = f"{name}-{phase}-{sweep + 1}-{index + 1}-{width:g}dp.png"
                    (plan.artifacts / filename).write_bytes(image)
                    sample["png"] = filename
                if 105 <= width <= 130:
                    reached.add(phase)
            evidence.extend(report)
        if set(phases) <= reached:
            break
    return evidence, sorted(reached)


def profile(plan, name, rtl):
    dimensions = (WIDTH, HEIGHT)
    with BASE["start_gallery"](plan, name, *dimensions) as app:
        MOTION["prepare_gallery"](app, WIDE, rtl, rtl)
        app.activate(WIDE + "-home")
        app.key("down")
        require(MOTION["focus"](app.dom()) == INBOX, "Arrow did not skip disabled Archive")
        app.key("enter")
        closed = app.dom()
        assert_endpoint(closed, False, rtl)
        closed_image, _ = MODAL_QA["snapshot_pixels"](app, plan, name + "-settled-closed", dimensions, True)
        closed_ax = ax_read(plan, app, False)
        app.activate(TOGGLE)
        time.sleep(0.55)
        opened = app.dom()
        assert_endpoint(opened, True, rtl)
        open_image, _ = MODAL_QA["snapshot_pixels"](app, plan, name + "-settled-open", dimensions, True)
        open_ax = ax_read(plan, app, True)
        with open_session(app.session_path, app.proc.pid) as connection:
            samples, reached = raster_group(plan, name, app, connection, opened, closed, rtl)
        return {"profile": name, "width_dp": WIDTH, "height_dp": HEIGHT, "rtl": rtl,
                "page_label_font_dp": node(opened, WIDE + "-page")[0]["style"]["font_size"],
                "target_widths_hit": reached, "raster": samples,
                "closed": {"capture": closed_image, "ax": closed_ax},
                "open": {"capture": open_image, "ax": open_ax}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gallery", type=Path, required=True)
    parser.add_argument("--cli", type=Path, required=True)
    parser.add_argument("--ax-reader", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile", action="append", choices=("light-ltr", "dark-rtl-200"))
    plan = parser.parse_args()
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    plan.reduced_motion = False
    report = []
    for name in plan.profile or ("light-ltr", "dark-rtl-200"):
        report.append(profile(plan, name, name == "dark-rtl-200"))
        (plan.artifacts / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
        print(f"Verified {name}, 105–130 dp observed during {report[-1]['target_widths_hit']}.", flush=True)


if __name__ == "__main__":
    main()
