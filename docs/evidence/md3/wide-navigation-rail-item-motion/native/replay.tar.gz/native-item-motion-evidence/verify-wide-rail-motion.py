#!/usr/bin/env python3
"""Verify the real native Surface rail animation from public DevTools PNGs."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import runpy
from statistics import median
import time

from public_frame_burst import open_session, screenshot_requests


HERE = Path(__file__).resolve().parent
BASE = runpy.run_path(str(HERE / "verify-public-screenshot.py"))
MODAL_QA = runpy.run_path(str(HERE / "verify-modal-wide-rail.py"))
require, node, bounds, contains, read_png, png_payload = (
    BASE[name] for name in ("require", "node", "bounds", "contains", "read_png", "png_payload")
)
WIDE = "wide-rail"
MODAL = "modal-wide-rail"
CLOSING = MODAL + "-closing"
OPEN = MODAL + "-open"
NAV = MODAL + "-navigation"
HEADER = MODAL + "-header"
CLOSE = MODAL + "-close"
HOME = MODAL + "-home"
INBOX = MODAL + "-inbox"
RETAIN = MODAL + "-retain"
FRAME_COUNT = 8
PROFILES = {
    "light-wide": (960, 800, False, False, "inline"),
    "light-wide-inline": (704, 512, False, False, "inline"),
    "dark-rtl-inline": (704, 512, True, True, "inline"),
    "light-wide-modal": (960, 800, False, False, "modal-hide"),
    "dark-rtl-wide": (960, 800, True, True, "modal"),
    "dark-rtl-compact": (320, 240, True, True, "compact"),
    "dark-rtl-compact-retained": (320, 240, True, True, "modal-retained"),
    "reduced-light-wide": (960, 800, False, False, "inline"),
    "reduced-dark-rtl-compact": (320, 240, True, True, "compact"),
}


def result(value):
    require(value["ok"], f"Public {value['method']} failed: {value['error_code']}")
    return value["result"]


def focus(scene):
    return scene["interaction"]["focused"]


def visible_id(scene, stable_id):
    return any(item.get("stable_id") == stable_id for item in scene["dom"]["nodes"])


def viewport(scene):
    rect = scene["layout"]["viewport"]
    return (rect["width"], rect["height"])


def capture_series(connection, trigger, capture_during=()):
    before = connection.call("Page.screenshot", {"scale": 0.5})
    requests = [trigger, *screenshot_requests(FRAME_COUNT, scale=0.5)]
    requests[2:2] = capture_during
    replies = connection.exchange(requests)
    time.sleep(0.55)
    after = connection.call("Page.screenshot", {"scale": 0.5})
    shoot = [before, *(r for r in replies if r["method"] == "Page.screenshot"), after]
    checks = [result(reply) for reply in replies if reply["method"] != "Page.screenshot"]
    return checks, shoot


def sample_images(shoot, measure):
    evidence = []
    images = []
    for response in shoot:
        payload = result(response)
        raster = png_payload(payload)
        width, height, pixels = read_png(raster)
        require((payload["width"], payload["height"]) == (width, height),
                "Wire metadata and image dimensions differ")
        images.append(raster)
        evidence.append({"client_receive_ms": round(response["client_receive_ms"], 3),
                         "png_sha256": hashlib.sha256(raster).hexdigest(),
                         **measure(pixels, payload["scale"])})
    return evidence, images


def within_color(pixel, color, tolerance=3):
    return all(abs(x - y) <= tolerance for x, y in zip(pixel, color))


def pixel(pixels, x, y):
    return pixels[y][4 * x:4 * x + 4]


def inline_measure(before, after, rtl=False):
    start = bounds(before, WIDE)
    end = bounds(after, WIDE)
    if rtl:
        require(start["x"] + start["width"] == end["x"] + end["width"],
                "RTL rail moved away from its anchored edge")
        left = viewport(before)[0] - (start["x"] + start["width"])
    else:
        require(start["x"] == end["x"], "LTR rail moved away from its anchored edge")
        left = start["x"]
    begin_y = max(start["y"], end["y"]) + 12
    end_y = min(start["y"] + start["height"], end["y"] + end["height"]) - 12
    color = node(after, WIDE)[0]["style"]["background"]
    content_color = node(after, WIDE + "-content")[0]["style"]["background"]
    require(end_y - begin_y > 80, "Rail plates do not share a visible vertical region")

    def measure(rows, scale):
        screen_right = (len(rows[0]) // 4) - 1
        def color_at(x, y):
            return pixel(rows, screen_right - x if rtl else x, y)
        widths = []
        for y in range(round(begin_y * scale), min(len(rows), round(end_y * scale)), 4):
            x = round(left * scale)
            if not within_color(color_at(x + 2, y), color, 1):
                continue
            first_other = next((j + 1 for j in range(round((left + 370) * scale), x + 9, -1)
                                if within_color(color_at(j, y), color, 1)
                                and within_color(color_at(j - 2, y), color, 1)
                                and within_color(color_at(j + 8, y), content_color, 1)
                                and not within_color(color_at(j + 8, y), color, 1)), None)
            if first_other is not None:
                widths.append((first_other - x) / scale)
        require(widths, "Could not measure the inline rail on the raster")
        return {"visible_rail_dp": median(widths)}
    return measure


def modal_measure(open_scene, rtl):
    color = node(open_scene, MODAL)[0]["style"]["background"]

    def measure(rows, scale):
        height, width = len(rows), len(rows[0]) // 4
        runs = []
        axis = list(range(width - 1, -1, -1)) if rtl else list(range(width))
        # Sample the panel through text-free rows near the header. A focused
        # 200% item in the lower half can paint across nearly the full width.
        for y in range(max(3, height // 25), max(5, height * 53 // 100), 2):
            # Use two-pixel continuity to ignore isolated glyph/edge pixels.
            count = 0
            misses = 0
            for x in axis:
                if within_color(pixel(rows, x, y), color, 1):
                    misses = 0
                else:
                    misses += 1
                    if misses >= 2:
                        break
                count += 1
            runs.append(max(0, count - misses) / scale)
        # A visible scrim strip exists only when the viewport is wider than the panel.
        measure_x = 14 if rtl else width - 15
        brightness = median(sum(pixel(rows, measure_x, y)[:3])
                            for y in range(8, height - 7, max(3, height // 43))) / 3
        return {"visible_rail_dp": sorted(runs)[len(runs) * 4 // 5],
                "outside_mean_rgb": round(brightness, 3)}
    return measure


def check_motion(samples, field, start, end, reduced, tolerance=4):
    values = [item[field] for item in samples]
    require(abs(values[0] - start) <= tolerance and abs(values[-1] - end) <= tolerance,
            f"Wrong {field} endpoints: expected {start} → {end}; saw {values}")
    low, high = sorted((start, end))
    interior = sorted({value for value in values[1:-1] if low + tolerance < value < high - tolerance})
    if reduced:
        require(all(abs(value - end) <= tolerance for value in values[1:]),
                f"Reduce Motion printed an intermediate value in {field}: {values}")
    else:
        require(interior, f"No {field} motion captured: {values}")
    return interior


def retain_examples(plan, name, samples, images):
    ordered = sorted(range(1, len(samples) - 1), key=lambda i: samples[i]["visible_rail_dp"])
    indexes = {0, 1, 2, 3, len(samples) - 1}
    indexes.update(ordered[int((len(ordered) - 1) * q)] for q in (0.15, 0.85))
    for i in sorted(indexes):
        path = plan.artifacts / f"{name}-{i:02}.png"
        path.write_bytes(images[i])
        samples[i]["png"] = path.name


def prepare_gallery(app, theme_id, dark, rtl):
    ready = app.dom()
    if bool(node(ready, "theme")[0].get("checked")) != dark:
        app.activate("theme")
    app.activate("section-1")
    if rtl:
        app.activate(theme_id + "-direction")
        app.activate(theme_id + "-scale")


def inline_profile(plan, app, connection, name, dimensions, dark, rtl):
    prepare_gallery(app, WIDE, dark, rtl)
    app.activate(WIDE + "-home")
    app.key("down")
    app.key("enter")
    before = app.dom()
    require(viewport(before) == dimensions, "Inline viewport differs")
    require(node(before, WIDE + "-inbox")[0]["current_page"], "Inline Inbox is not current before reflow")
    phases = {}
    toggle = ("Action.activate", {"id": WIDE + "-toggle"})
    for stage in ("expand", "collapse"):
        checks, captures = capture_series(connection, toggle)
        require(checks[0]["focused"] == WIDE + "-toggle", "Inline disclosure lost focus")
        after = app.dom()
        require(node(after, WIDE + "-inbox")[0]["current_page"], "Inline motion changed the selected page")
        require(node(after, WIDE + "-toggle")[0].get("expanded") == (stage == "expand"),
                "Disclosure semantic endpoint differs")
        a, b = [bounds(state, WIDE)["width"] for state in (before, after)]
        c, d = [bounds(state, WIDE + "-content")["width"] for state in (before, after)]
        require(math.isclose(b - a, c - d, abs_tol=1), "Inline sibling did not reflow with width")
        samples, images = sample_images(captures, inline_measure(before, after, rtl))
        retain_examples(plan, name + "-" + stage, samples, images)
        diagnostic = plan.artifacts / f"{name}-{stage}-samples.json"
        diagnostic.write_text(json.dumps({"samples": samples, "start": bounds(before, WIDE),
                                          "end": bounds(after, WIDE)}, indent=2) + "\n")
        interior = check_motion(samples, "visible_rail_dp", a, b, plan.reduced_motion)
        phases[stage] = {"raster": samples, "interior_widths_dp": interior,
                         "panel_endpoint_dp": [a, b], "page_endpoint_dp": [c, d]}
        before = after
    static, _ = MODAL_QA["snapshot_pixels"](app, plan, name + "-settled", dimensions, check_mcp=True)
    return {"phases": phases, "settled_png": static}


def modal_profile(plan, app, connection, name, dimensions, dark, rtl, retained):
    plan.ax_window = dimensions
    prepare_gallery(app, MODAL, dark, rtl)
    app.activate(RETAIN)
    if not retained:
        app.activate(RETAIN)
    app.key("tab")
    initial = app.dom()
    require(viewport(initial) == dimensions and focus(initial) == OPEN, "Modal opener not focused")
    inline = MODAL + "-inline"
    scope = ("DOM.query", {"id": OPEN})
    opened, opening = capture_series(connection, ("Action.key", {"key": "enter"}))
    require(opened[0]["focused"] == CLOSE, "Opening did not focus Close")
    open_scene = app.dom()
    panel = MODAL_QA["assert_open"](open_scene, dimensions, rtl, "home")
    app.wire("Action.activate", {"id": RETAIN}, expected_error="outside_modal")
    if retained:
        require(bounds(initial, inline)["width"] == bounds(open_scene, inline)["width"] == 96,
                "The retained underlay collapsed width changed")
    open_ax = MODAL_QA["ax_dialog"](plan, app.proc.pid, *dimensions, "關閉導覽列", "首頁")
    app.key("tab")
    app.key("down")
    focused = app.dom()
    require(focus(focused) == INBOX and node(focused, HOME)[0]["current_page"],
            "Arrow did not skip Archive while preserving the current page")
    kept_header = bounds(open_scene, HEADER) == bounds(focused, HEADER)
    require(kept_header, "Modal header moved with the scrolling destination")
    raster, rows = MODAL_QA["snapshot_pixels"](app, plan, name + "-focused", dimensions, check_mcp=True)
    if dimensions[0] == 320:
        require(contains(bounds(focused, NAV), bounds(focused, INBOX)), "Narrow focused target is clipped")
        raster.update(MODAL_QA["assert_raster_label"](
            focused, rows, MODAL_QA["INBOX_NAME"], INBOX, bounds(focused, NAV)
        ))
    extra = [scope]
    if dimensions[0] == 320 and not plan.reduced_motion:
        extra.insert(0, ("DOM.snapshot", {}) if retained else ("DOM.query", {"id": INBOX}))
    closed, closing = capture_series(connection, ("Action.key", {"key": "escape"}), capture_during=extra)
    require(closed[0]["focused"] == OPEN, "The Escape reply did not restore the opener")
    require(closed[-1]["matches"][0]["in_scope"], "Closing paint kept the background opener inert")
    retired_y = None
    offsets = None
    if len(extra) == 2 and retained and visible_id(closed[1], CLOSING):
        retired = closed[1]
        require(focus(retired) == OPEN and not visible_id(retired, MODAL),
                "Retained closing paint did not release modal scope")
        offsets = [bounds(state, NAV)["y"] - bounds(state, HOME)["y"]
                   for state in (focused, retired)]
        require(math.isclose(*offsets, abs_tol=0.5), f"Retained destination scroll changed: {offsets}")
        retired_y = bounds(retired, INBOX)["y"]
    elif len(extra) == 2 and not retained and closed[1]["matches"]:
        visual_item = closed[1]["matches"][0]
        retired_y = visual_item["layout"]["bounds"]["y"]
        require(not visual_item["in_scope"], "Closing visual leaves a destination interactive")
        require(math.isclose(retired_y, bounds(focused, INBOX)["y"], abs_tol=0.5),
                f"Closing Inbox lost its scroll y-offset: {retired_y}")
    closed_scene = app.dom()
    require(focus(closed_scene) == OPEN and not visible_id(closed_scene, MODAL)
            and not visible_id(closed_scene, CLOSING), "The closing rail did not retire")
    measure = modal_measure(open_scene, rtl)
    a, a_images = sample_images(opening, measure)
    b, b_images = sample_images(closing, measure)
    retain_examples(plan, name + "-open", a, a_images)
    retain_examples(plan, name + "-escape", b, b_images)
    diagnostic = plan.artifacts / f"{name}-samples.json"
    diagnostic.write_text(json.dumps({"opening": a, "closing": b, "retiring_inbox_y_dp": retired_y,
                                      "retained_scroll_offsets_dp": offsets},
                                     indent=2) + "\n")
    start = a[0]["visible_rail_dp"]
    end = panel["width"]
    tolerance = 12 if retained else 6
    # A retained rail exposes its narrow inline background in both closed frames.
    if retained:
        open_segment = a[1:]
        high = [value["visible_rail_dp"] for value in open_segment]
        interior = sorted({x for x in high if 96 + 8 < x < end - 8})
        if plan.reduced_motion:
            require(all(abs(x - end) <= tolerance for x in high), f"Reduce Motion width differed: {high}")
        else:
            require(interior, f"Retained width did not animate: {high}")
        open_interior = interior
        close_interior = sorted({x["visible_rail_dp"] for x in b[1:-1]
                                 if 96 + 8 < x["visible_rail_dp"] < end - 8})
        if not plan.reduced_motion:
            require(close_interior, f"Retained closing width did not animate: {b}")
    else:
        open_interior = check_motion(a, "visible_rail_dp", start, end, plan.reduced_motion, tolerance)
        close_interior = check_motion(b, "visible_rail_dp", end, start, plan.reduced_motion, tolerance)
    scrim = []
    if dimensions[0] >= 600:
        for phase in (a, b):
            dark0, dark1 = [s["outside_mean_rgb"] for s in (phase[0], phase[-1])]
            require(abs(dark0 - dark1) >= 3.0, "Wide backdrop did not change brightness")
            scrim.append(check_motion(phase, "outside_mean_rgb", dark0, dark1, plan.reduced_motion, 0.75))
    return {"settled_png": raster, "open_ax": open_ax, "modal_endpoint_dp": panel,
            "retained_inline_rail": retained, "escape_restored_opener": True,
            "retiring_inbox_y_dp": retired_y,
            "retained_scroll_offsets_dp": offsets,
            "open_inbox_y_dp": bounds(focused, INBOX)["y"],
            "opening": a, "closing": b, "open_interior_dp": open_interior,
            "close_interior_dp": close_interior, "scrim_interior_rgb": scrim}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gallery", type=Path, required=True)
    parser.add_argument("--cli", type=Path, required=True)
    parser.add_argument("--ax-reader", type=Path)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile", action="append", choices=PROFILES)
    plan = parser.parse_args()
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    report = []
    for name, (width, height, dark, rtl, kind) in PROFILES.items():
        if plan.profile and name not in plan.profile:
            continue
        plan.reduced_motion = name.startswith("reduced-")
        retained_flags = {"modal": (False, True), "modal-retained": (True,)}.get(kind, (False,))
        for retained in retained_flags:
            label = name + ("-retained" if kind == "modal" and retained else "")
            with BASE["start_gallery"](plan, label, width, height) as app:
                dimensions = (width, height)
                with open_session(app.session_path, app.proc.pid) as connection:
                    if kind == "inline":
                        case = inline_profile(plan, app, connection, label, dimensions, dark, rtl)
                    else:
                        case = modal_profile(plan, app, connection, label, dimensions, dark, rtl, retained)
                report.append({"profile": label, "viewport_dp": dimensions,
                               "reduced_motion": plan.reduced_motion, **case})
                print(f"Verified {label}.", flush=True)
                (plan.artifacts / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
