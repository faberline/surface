import ApplicationServices
import Foundation

func attribute(_ element: AXUIElement, _ key: String) -> Any? {
    var value: CFTypeRef?
    let result = AXUIElementCopyAttributeValue(element, key as CFString, &value)
    return result == .success ? value : nil
}

func children(_ element: AXUIElement, _ key: String) -> [AXUIElement] {
    return attribute(element, key) as? [AXUIElement] ?? []
}

let landmarkTitle = "工作區導覽"
let labels: Set<String> = ["瀏覽首頁", "封存資料", "收件匣", "展開導覽列", "收合導覽列"]
let trusted = AXIsProcessTrusted()
var windows: [AXUIElement] = []
var sizes: [[String: Double]] = []
var buttons: [[String: Any]] = []
var navigationLandmarks = 0
var visited = 0
func walk(_ element: AXUIElement, _ depth: Int, _ inside: Bool) {
    visited += 1
    guard depth <= 35 && visited <= 3000 else { return }
    let role = attribute(element, "AXRole") as? String
    let subrole = attribute(element, "AXSubrole") as? String
    let landmark = subrole == "AXLandmarkNavigation"
        && ["AXTitle", "AXDescription", "AXLabel"].contains {
            attribute(element, $0) as? String == landmarkTitle
        }
    if landmark {
        navigationLandmarks += 1
    }
    if inside, role == "AXButton", let title = attribute(element, "AXTitle") as? String,
       labels.contains(title) {
        var button: [String: Any] = ["title": title, "role": "AXButton"]
        if let current = attribute(element, "AXARIACurrent") as? String {
            button["current"] = current
        }
        if let expanded = attribute(element, "AXExpanded") as? Bool {
            button["expanded"] = expanded
        }
        if let focused = attribute(element, "AXFocused") as? Bool {
            button["focused"] = focused
        }
        buttons.append(button)
    }
    for child in children(element, "AXChildren") {
        walk(child, depth + 1, inside || landmark)
    }
}

if trusted, CommandLine.arguments.count == 2,
   let pid = pid_t(CommandLine.arguments[1]), pid > 1 {
    let app = AXUIElementCreateApplication(pid)
    AXUIElementSetMessagingTimeout(app, 0.5)
    _ = attribute(app, "AXFocusedUIElement")
    windows = children(app, "AXWindows")
    if windows.isEmpty, let value = attribute(app, "AXFocusedWindow") {
        let ref = value as CFTypeRef
        if CFGetTypeID(ref) == AXUIElementGetTypeID() {
            windows = [unsafeBitCast(ref, to: AXUIElement.self)]
        }
    }
    for window in windows {
        if let value = attribute(window, "AXSize") {
            let ref = value as CFTypeRef
            if CFGetTypeID(ref) == AXValueGetTypeID() {
                let sizeValue = unsafeBitCast(ref, to: AXValue.self)
                var size = CGSize.zero
                if AXValueGetValue(sizeValue, .cgSize, &size) {
                    sizes.append(["width": size.width, "height": size.height])
                }
            }
        }
        walk(window, 0, false)
    }
}

let result: [String: Any] = [
    "trusted": trusted,
    "windows": windows.count,
    "window_sizes_pt": sizes,
    "navigation_landmarks": navigationLandmarks,
    "buttons": buttons,
]
let encoded = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
print(String(decoding: encoded, as: UTF8.self))
