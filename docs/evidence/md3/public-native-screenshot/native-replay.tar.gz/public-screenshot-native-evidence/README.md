# Surface native screenshot replay

This packet verifies the public `Page.screenshot` method on a visible macOS Surface Gallery window. The Gallery uses the production GPU renderer and production DevTools server. The launcher selects the initial window size through `surface_platform::Options`. The runner uses public `Action.activate` and `Action.key` requests to change the Gallery. The Swift helper only reads the spawned Gallery’s AppKit accessibility data.

## Source and build

- The screenshot change is based on the exact Surface Wide Navigation Rail product checkpoint. Its 19 changed paths are pinned in `screenshot-source.sha256`. The SHA-256 of that manifest is `fa6ccdfdc5cf1eed654ac3c7951ded91b6672524411d0c94c46bfd77bb8e2825`. The SHA-256 of the screenshot source patch is `81174d053fbd59fd895d877d68e8925d32746b4b192519966f494c558fa4f79d`.
- `public_screenshot_gallery.rs` is the only extra Rust source file. Its SHA-256 is `261a40b5635a8df17fa9456187831bac96bb43e412ed6130ad661c5359c69295`.
- Cap builds the Gallery example and `surface-devtools` from a disposable copy of the supplied source. The build enables `surface-material-gallery/devtools` and `surface-platform/macos-accessibility` and uses Cargo’s `--locked` mode, two build jobs and a separate target directory under `/tmp/cargo-target`.
- The host was Apple M1 Max running macOS 27.2.1 (26B131) with Rust 1.96.1. Use an active macOS desktop with Metal available. The AppKit helper reports whether the local process has permission to read accessibility data.

```sh
shasum -a 256 -c evidence.sha256
bash build-and-run.sh /path/to/verified-surface-checkout /tmp/new-surface-captures
```

The runner creates separate localhost DevTools sessions in disposable private directories. `SURFACE_REDUCED_MOTION=1` keeps the static frames stable for byte comparison. The SHA-256 values are for this run. Font rasterization and system settings can affect PNG bytes on a different Mac.

## What the runner verifies

| Gallery profile | Logical viewport | PNG at scale 1 |
| --- | --- | --- |
| Light, expanded LTR rail | 960 × 800 dp | 960 × 800 px |
| Dark, expanded RTL rail, 200% text | 960 × 800 dp | 960 × 800 px |
| Dark, compact RTL bottom navigation, 200% text | 320 × 240 dp | 320 × 240 px |

For all three profiles an arrow key moved focus to Inbox and skipped the disabled Archive item. Enter then selected Inbox. Each raw DevTools reply produced the same PNG bytes as `surface-devtools page screenshot --out`. The compact profile also used MCP `tools/list` and `tools/call`. The `page_screenshot` tool returned an `image/png` block with byte-identical PNG data and a text block with matching metadata.

AppKit reported one native window and one `工作區導覽` navigation landmark for each profile. The `收件匣` button was focused and current in all three. The two wide profiles exposed an expanded disclosure. The outer window sizes were 960 × 832 pt for both wide profiles and 320 × 272 pt for the compact profile. The 32 pt difference in height is the macOS title bar. `captures/report.json` contains these values with the protocol and image measurements.

The runner checks the PNG signature, metadata, chunk checksums, RGBA8 scanlines and the drawn navigation surface. It also checks the live capabilities and tests the scale and size limit. In the compact profile the 120 px long-side limit returned 120 × 90 px at effective scale 0.375. The server rejected scale 0 and a size limit of 8193. The CLI rejected size 8193 with exit 2 and preserved an existing destination with exit 3.

The compact capture shows the stock Gallery’s floating add button across the right edge of the bottom navigation. The rail was already at the end of the scroll range. Public Page Down and End left the rail at y132–212 dp. The source PNGs preserve the rendered frame as returned by `Page.screenshot`.
