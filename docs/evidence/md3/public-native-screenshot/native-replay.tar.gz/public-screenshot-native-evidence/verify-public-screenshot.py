#!/usr/bin/env python3
"""Capture production Surface Gallery frames using its public interfaces."""

import argparse
import base64
from contextlib import contextmanager
import hashlib
import ipaddress
import json
import math
import os
from pathlib import Path
import socket
import stat
import struct
import subprocess
import tempfile
import time
from urllib.parse import urlsplit
import zlib


PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
SCREENSHOT = "Page.screenshot"
PROFILES = {
    "light-expanded": (960, 800, False, False, False),
    "dark-rtl-200": (960, 800, True, True, False),
    "compact-dark-rtl-200": (320, 240, True, True, True),
}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def read_png(data):
    require(data[:8] == PNG_SIGNATURE, "PNG signature failed")
    width, height = None, None
    compressed = []
    offset = 8
    closed = False
    while offset + 12 <= len(data):
        size, kind = struct.unpack_from(">I4s", data, offset)
        start, end = offset + 8, offset + 8 + size
        require(end + 4 <= len(data), "PNG chunk was truncated")
        content = data[start:end]
        expected_crc = struct.unpack_from(">I", data, end)[0]
        require(zlib.crc32(kind + content) == expected_crc, "PNG chunk CRC failed")
        offset = end + 4
        if kind == b"IHDR":
            width, height, depth, color, comp, filtering, interlace = struct.unpack(">IIBBBBB", content)
            require((depth, color, comp, filtering, interlace) == (8, 6, 0, 0, 0),
                    "Screenshot must use non-interlaced RGBA8")
        elif kind == b"IDAT":
            compressed.append(content)
        elif kind == b"IEND":
            closed = True
            break
    require(closed and offset == len(data) and compressed and width and height,
            "Incomplete PNG")
    decoded = zlib.decompress(b"".join(compressed))
    stride = width * 4
    require(len(decoded) == (stride + 1) * height, "PNG scanline sizes differ")
    previous = bytes(stride)
    rows = []
    for y in range(height):
        origin = y * (stride + 1)
        filter_type = decoded[origin]
        result = bytearray(decoded[origin + 1 : origin + 1 + stride])
        require(filter_type < 5, "Unknown PNG row filter")
        if filter_type:
            for x in range(stride):
                a = result[x - 4] if x >= 4 else 0
                b = previous[x]
                c = previous[x - 4] if x >= 4 else 0
                if filter_type == 1:
                    predictor = a
                elif filter_type == 2:
                    predictor = b
                elif filter_type == 3:
                    predictor = (a + b) // 2
                else:
                    p = a + b - c
                    distance = (abs(p - a), abs(p - b), abs(p - c))
                    predictor = (a, b, c)[distance.index(min(distance))]
                result[x] = (result[x] + predictor) & 255
        previous = result
        rows.append(bytes(result))
    return width, height, rows


def metadata(result):
    return {key: result[key] for key in ("format", "width", "height", "scale")}


def png_payload(result):
    require(result.get("format") == "png", "Wrong reply image format")
    data = base64.b64decode(result["data_base64"], validate=True)
    return data


class Gallery:
    def __init__(self, plan, session, proc):
        self.plan = plan
        self.session_path = session
        self.proc = proc

    def wire(self, method, params, expected_error=None):
        session = json.loads(self.session_path.read_text())
        require(session["pid"] == self.proc.pid and session["protocol"] == "surface-devtools"
                and session["version"] == 1, "Session does not match the launched Gallery")
        endpoint = urlsplit("//" + session["endpoint"])
        require(ipaddress.ip_address(endpoint.hostname).is_loopback,
                "The private session must use loopback")
        token = session["token"]
        request = {"v": 1, "id": 1, "method": method, "params": params, "token": token}
        # The credential is only sent over the application's localhost transport.
        with socket.create_connection((endpoint.hostname, endpoint.port), timeout=5) as connection:
            with connection.makefile("rwb") as stream:
                stream.write(json.dumps(request, allow_nan=False).encode("utf-8") + b"\n")
                stream.flush()
                reply = json.loads(stream.readline(16 * 1024 * 1024))
        require(reply.get("id") == 1, "Wire reply identifier mismatch")
        if expected_error:
            require(not reply.get("ok") and reply.get("error", {}).get("code") == expected_error,
                    f"Unexpected wire result for {method} limit check")
            return expected_error
        require(reply.get("ok"), f"Wire request {method} returned a protocol error")
        return reply.get("result")

    def cli(self, args, want_status=0):
        run = subprocess.run([self.plan.cli, "--session", self.session_path, *args],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
        if run.returncode != want_status:
            # Never expose raw connection messages, tokens, or private session paths.
            raise RuntimeError(f"CLI command {args[:2]} returned exit {run.returncode}")
        if want_status == 0:
            return json.loads(run.stdout)
        return want_status

    def dom(self):
        deadline = time.monotonic() + 3
        while True:
            snapshot = self.wire("DOM.snapshot", {})
            if snapshot.get("layout") is not None:
                return snapshot
            require(time.monotonic() < deadline, "Gallery did not lay out the current frame")
            time.sleep(0.025)

    def activate(self, stable_id):
        result = self.cli(["action", "activate", stable_id])
        require(result.get("changed"), f"Activation made no change for {stable_id}")

    def key(self, key):
        return self.cli(["action", "key", key])

    def mcp(self, params):
        requests = [
            {"jsonrpc": "2.0", "id": 1, "method": "initialize",
             "params": {"protocolVersion": "2025-03-26", "capabilities": {},
                        "clientInfo": {"name": "surface-screenshot-evidence", "version": "1"}}},
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}},
            {"jsonrpc": "2.0", "id": 3, "method": "tools/call",
             "params": {"name": "page_screenshot", "arguments": params}},
        ]
        payload = "".join(json.dumps(request) + "\n" for request in requests)
        result = subprocess.run([self.plan.cli, "--session", self.session_path, "mcp"],
                                input=payload.encode("utf-8"), stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=25)
        require(result.returncode == 0, "MCP process failed")
        replies = [json.loads(line) for line in result.stdout.splitlines()]
        require([value.get("id") for value in replies] == [1, 2, 3], "Invalid MCP reply sequence")
        tool = next(tool for tool in replies[1]["result"]["tools"] if tool["name"] == "page_screenshot")
        limits = tool["inputSchema"]["properties"]["max_side"]
        require((limits["minimum"], limits["maximum"], limits["default"]) == (1, 8192, 4096),
                "MCP screenshot limits do not match the schema")
        expected = replies[2]["result"]
        require(not expected.get("isError"), "MCP screenshot returned a tool error")
        image, text = expected["content"]
        require(image["type"] == "image" and image["mimeType"] == "image/png"
                and text["type"] == "text", "MCP content blocks are incorrect")
        return base64.b64decode(image["data"], validate=True), json.loads(text["text"]), tool


@contextmanager
def start_gallery(plan, profile, width, height):
    # Session files and raw host diagnostics live only in disposable private storage.
    with tempfile.TemporaryDirectory(dir="/tmp", prefix="surface-screenshot-session-") as temp:
        private = Path(temp)
        session = private / "session"
        env = os.environ.copy()
        env.pop("SURFACE_TRACE", None)
        env.pop("SURFACE_BRIDGE_SESSION", None)
        env["SURFACE_REDUCED_MOTION"] = "1"
        env["SURFACE_DEVTOOLS_SESSION"] = str(session)
        with (private / "gallery.log").open("wb") as log:
            proc = subprocess.Popen([plan.gallery, str(width), str(height)], env=env,
                                    stdout=log, stderr=subprocess.STDOUT)
            try:
                app = Gallery(plan, session, proc)
                deadline = time.monotonic() + 22
                last = None
                while time.monotonic() < deadline:
                    require(proc.poll() is None, f"{profile} Gallery process exited before readiness")
                    if session.is_file():
                        try:
                            last = app.dom()
                        except (OSError, ValueError, RuntimeError):
                            pass
                        if last is not None and last.get("layout") is not None:
                            break
                    time.sleep(0.10)
                require(last is not None and last.get("layout") is not None, f"{profile} did not become ready")
                require(stat.S_IMODE(session.stat().st_mode) == 0o600, "Session file access is too broad")
                yield app
            finally:
                if proc.poll() is None:
                    proc.terminate()
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        proc.wait(timeout=5)


def node(snapshot, key):
    nodes = snapshot["dom"]["nodes"]
    index, desc = next((index, value) for index, value in enumerate(nodes) if value.get("stable_id") == key)
    return desc, snapshot["layout"]["nodes"][index]


def bounds(snapshot, key):
    return node(snapshot, key)[1]["bounds"]


def contains(parent, child):
    return all(child[axis] >= parent[axis] - 0.5
               and child[axis] + child[size] <= parent[axis] + parent[size] + 0.5
               for axis, size in (("x", "width"), ("y", "height")))


def screen_box(snapshot, key):
    area = bounds(snapshot, key)
    viewport = snapshot["layout"]["viewport"]
    require(contains(viewport, area), f"{key} is not fully visible")
    return area


def image_color_match(rows, rect, rgba):
    # Sample the actual drawn region on a grid, paying attention to the expected Surface token.
    width, height = len(rows[0]) // 4, len(rows)
    left, top = max(0, math.ceil(rect["x"])), max(0, math.ceil(rect["y"]))
    right = min(width, math.floor(rect["x"] + rect["width"]))
    bottom = min(height, math.floor(rect["y"] + rect["height"]))
    hits = 0
    for y in range(top + 4, bottom - 4, 6):
        for x in range(left + 4, right - 4, 6):
            sample = rows[y][x * 4 : x * 4 + 4]
            if all(abs(a - b) <= 3 for a, b in zip(sample, rgba)):
                hits += 1
    return hits


def appkit(plan, pid):
    if not plan.ax_reader:
        return {"unavailable": "optional read-only AppKit collector was not supplied"}
    deadline = time.monotonic() + 3
    while True:
        result = subprocess.run([plan.ax_reader, str(pid)], stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=10)
        require(result.returncode == 0, "AppKit collector failed")
        reported = json.loads(result.stdout)
        if not reported["trusted"] or reported["buttons"] or time.monotonic() >= deadline:
            return reported
        # A read first asks AccessKit to publish its live tree.
        time.sleep(0.2)


def aim_gallery(app, wide, dark, rtl):
    snapshot = app.dom()
    theme = node(snapshot, "theme")[0]
    if bool(theme.get("checked")) != dark:
        app.activate("theme")
    app.activate("section-1")
    if rtl:
        app.activate("wide-rail-direction")
        app.activate("wide-rail-scale")
    if wide:
        app.activate("wide-rail-toggle")
    app.activate("wide-rail-home")
    app.key("down" if wide else "left")
    after_key = app.dom()
    require(after_key["interaction"]["focused"] == "wide-rail-inbox",
            "Public key did not focus the next enabled destination")
    require(node(after_key, "wide-rail-home")[0].get("current_page"),
            "Arrow changed the current page")
    app.key("enter")
    final = app.dom()
    require(node(final, "wide-rail-inbox")[0].get("current_page"), "Enter did not select Inbox")
    require(final["interaction"]["focused"] == "wide-rail-inbox", "Inbox does not have logical focus")
    return final


def prove_profile(plan, name, width, height, dark, rtl, compact):
    with start_gallery(plan, name, width, height) as app:
        snapshot = aim_gallery(app, not compact, dark, rtl)
        viewport = snapshot["layout"]["viewport"]
        require((viewport["width"], viewport["height"]) == (width, height),
                "The application viewport dimensions differ from the profile")
        rail = "wide-rail-bottom" if compact else "wide-rail"
        area = screen_box(snapshot, rail)
        cabin = bounds(snapshot, "wide-rail-content")
        owner = screen_box(snapshot, "wide-rail-inbox")
        require(contains(area, owner), "Inbox overflows the navigation rail")
        if not compact:
            require(220 <= area["width"] <= 360 and math.isclose(area["height"], cabin["height"]),
                    "Expanded rail does not reflow")
            require((cabin["x"] < area["x"]) == rtl, "Wrong logical rail side")
        else:
            require(area["y"] > cabin["y"], "Compact viewport has no bottom navigation")
        if dark and not compact:
            require(owner["height"] >= 100, "The 200% expanded label did not wrap")

        capability = app.cli(["capabilities"])
        require(SCREENSHOT in capability["methods"] and "Page" in capability["domains"],
                "Screenshot is not advertised by the real native host")
        require(capability["limits"]["response_bytes"] > 0, "No response budget advertised")
        require(capability == app.wire("Devtools.capabilities", {}), "CLI and wire capabilities differ")
        params = {"scale": 1}
        capture = app.wire(SCREENSHOT, params)
        raw = png_payload(capture)
        image_width, image_height, rows = read_png(raw)
        expected = {"format": "png", "width": width, "height": height, "scale": 1}
        require(metadata(capture) == expected and (image_width, image_height) == (width, height),
                "Wire metadata or PNG dimensions differ from the actual viewport")
        outfile = plan.artifacts / f"{name}.png"
        cli = app.cli(["page", "screenshot", "--scale", "1", "--out", str(outfile)])
        require(metadata(cli) == expected and outfile.read_bytes() == raw,
                "CLI PNG differs from the wire capture")
        require(stat.S_IMODE(outfile.stat().st_mode) == 0o600, "PNG output permissions are too broad")
        rendered = image_color_match(rows, area, node(snapshot, rail)[0]["style"]["background"])
        require(rendered >= 6, "Raster does not show the expected navigation rail Surface token")
        require(len({rows[y][x * 4 : (x + 1) * 4]
                     for y in range(0, height, 12) for x in range(0, width, 12)}) > 8,
                "Screenshot contains too little visual content")
        result = {"profile": name, "png": outfile.name, "sha256": hashlib.sha256(raw).hexdigest(),
                  "pixels": [width, height], "viewport_dp": [width, height], "scale": 1,
                  "active_destination": "wide-rail-inbox", "raster_surface_samples": rendered,
                  "rail_bounds_dp": area, "destination_bounds_dp": owner,
                  "manifest": {"methods": capability["methods"], "limits": capability["limits"]},
                  "appkit": appkit(plan, app.proc.pid), "raw_cli_png_equal": True}
        if compact:
            picture, description, schema = app.mcp(params)
            require(picture == raw and metadata(description) == expected, "Compact CLI and MCP PNG differ")
            mcp_path = plan.artifacts / f"{name}-mcp.png"
            with os.fdopen(os.open(mcp_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "wb") as file:
                file.write(picture)
            result.update(mcp_png=mcp_path.name, mcp_png_equal=True, mcp_schema=schema["inputSchema"])
            scaled = app.wire(SCREENSHOT, {"scale": 2, "max_side": 120})
            small = png_payload(scaled)
            w, h, _ = read_png(small)
            require((w, h, scaled["width"], scaled["height"]) == (120, 90, 120, 90)
                    and math.isclose(scaled["scale"], 0.375), "Long-side cap was not honored")
            result["bounded_png"] = metadata(scaled)
            result["wire_invalid_scale"] = app.wire(SCREENSHOT, {"scale": 0}, "invalid_params")
            result["wire_invalid_max_side"] = app.wire(SCREENSHOT, {"max_side": 8193}, "invalid_params")
            result["cli_invalid_max_side_exit"] = app.cli(["page", "screenshot", "--max-side", "8193"], 2)
            result["cli_existing_file_exit"] = app.cli(
                ["page", "screenshot", "--scale", "1", "--out", str(outfile)], 3)
            require(outfile.read_bytes() == raw, "CLI modified an existing file")
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gallery", required=True, type=Path)
    parser.add_argument("--cli", required=True, type=Path)
    parser.add_argument("--ax-reader", type=Path)
    parser.add_argument("--artifacts", required=True, type=Path)
    parser.add_argument("--profile", action="append", choices=PROFILES)
    plan = parser.parse_args()
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    result = []
    for name, values in PROFILES.items():
        if plan.profile and name not in plan.profile:
            continue
        result.append(prove_profile(plan, name, *values))
        print(f"Verified {name} using the production screenshot transport.", flush=True)
        (plan.artifacts / "report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
