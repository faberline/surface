#!/usr/bin/env python3
"""Add stock Gallery sizing, opt-in Winit input, and extended Metal readback to a disposable copy."""
from pathlib import Path
import shutil
import sys

bundle = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve()
if Path("/private/tmp") not in repo.parents:
    raise SystemExit("Replay only in a disposable /tmp checkout")


def replace(source, old, new):
    if source.count(old) != 1:
        raise ValueError(f"Source does not uniquely match {old}")
    return source.replace(old, new)


platform = repo / "crates/surface-platform"
host = platform / "src/lib.rs"
manifest = platform / "Cargo.toml"
renderer = repo / "crates/surface-wgpu/src/lib.rs"
examples = repo / "examples/material-gallery/examples"
examples.mkdir(exist_ok=True)
shutil.copyfile(bundle / "public_screenshot_gallery.rs", examples / "public_screenshot_gallery.rs")
for filename in ("qa_capture.rs", "qa_swipe.rs"):
    shutil.copyfile(bundle / filename, platform / "src" / filename)

code = host.read_text()
code += """
#[cfg(all(feature = "devtools", target_os = "macos"))]
mod qa_capture;
#[cfg(all(feature = "devtools", target_os = "macos"))]
mod qa_swipe;
"""
code = replace(code, "        let mut config = surface\n", """        if std::env::var_os("SURFACE_RAIL_QA").is_some() {
            let info = adapter.get_info();
            eprintln!("Surface rail QA adapter: {} ({:?})", info.name, info.backend);
        }
        let mut config = surface
""")
code = replace(code, """        use surface_devtools_protocol::{ErrorCode, Reply};
        if self.gpu.is_none()""", """        use surface_devtools_protocol::{ErrorCode, Reply};
        #[cfg(target_os = "macos")]
        if std::env::var_os("SURFACE_RAIL_QA").is_some() {
            match request.method.as_str() {
                "Page.screenshot" => {
                    reply.send(qa_capture::capture(self, event_loop, request));
                    return;
                }
                "QA.swipeInput" => {
                    let result = match qa_swipe::dispatch(self, event_loop, &request.params) {
                        Ok(()) => Reply::ok(request.id, serde_json::Value::Null),
                        Err(message) => Reply::error(request.id, ErrorCode::InvalidParams, message),
                    };
                    reply.send(result);
                    return;
                }
                _ => {}
            }
        }
        if self.gpu.is_none()""")
code = replace(code, "    fn draw(&mut self, event_loop: &ActiveEventLoop) {", """    fn draw(&mut self, event_loop: &ActiveEventLoop) {
        self.draw_frame(event_loop, None);
    }
    fn draw_frame(
        &mut self,
        event_loop: &ActiveEventLoop,
        presented: Option<&mut Option<surface::ExtendedDisplayList>>,
    ) {""")
code = replace(code, "        frame.present();\n", """        frame.present();
        if let Some(presented) = presented {
            *presented = Some(list);
        }
""")
host.write_text(code)

code = manifest.read_text()
code = replace(code, '"dep:surface-devtools-protocol"]', '"dep:surface-devtools-protocol", "dep:base64", "dep:png"]')
code = replace(code, '[target.\'cfg(target_os = "macos")\'.dependencies]\n', """[target.'cfg(target_os = "macos")'.dependencies]
base64 = { version = "0.22", optional = true }
png = { version = "0.18", optional = true }
""")
manifest.write_text(code)

code = renderer.read_text()
code = replace(code, '''    ) -> Result<Capture, RenderError> {
        Capture::check_size(width, height)?;''', '''    ) -> Result<Capture, RenderError> {
        self.capture_with(width, height, |renderer, target| {
            renderer.render(list, target, width, height, scale)
        })
    }

    #[doc(hidden)]
    pub fn capture_extended_qa(
        &mut self,
        list: &ExtendedDisplayList,
        width: u32,
        height: u32,
        scale: f32,
    ) -> Result<Capture, ExtendedRenderError> {
        self.capture_with(width, height, |renderer, target| {
            renderer.render_extended(list, target, width, height, scale)
        })
    }

    fn capture_with<E: From<RenderError>>(
        &mut self,
        width: u32,
        height: u32,
        draw: impl FnOnce(&mut Self, &wgpu::TextureView) -> Result<(), E>,
    ) -> Result<Capture, E> {
        Capture::check_size(width, height)?;''')
code = replace(code, """                max: limit,
            });""", """                max: limit,
            }.into());""")
code = replace(code, """        self.render(
            list,
            &texture.create_view(&Default::default()),
            width,
            height,
            scale,
        )?;""", """        draw(self, &texture.create_view(&Default::default()))?;""")
renderer.write_text(code)

lock = repo / "Cargo.lock"
code = lock.read_text()
header = '\nname = "surface-platform"\n'
start = code.index(header) + len(header)
end = code.index("\n[[package]]", start)
package = code[start:end]
package = replace(package, ' "arboard",\n', ' "arboard",\n "base64 0.22.1",\n')
package = replace(package, ' "objc2-foundation 0.3.2",\n', ' "objc2-foundation 0.3.2",\n "png 0.18.1",\n')
lock.write_text(code[:start] + package + code[end:])
