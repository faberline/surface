import ApplicationServices
import Foundation

func attribute(_ element: AXUIElement, _ key: String) -> Any? {
    var value: CFTypeRef?
    let result = AXUIElementCopyAttributeValue(element, key as CFString, &value)
    return result == .success ? value : nil
}

func children(_ element: AXUIElement, _ key: String) -> [AXUIElement] {
    return attribute(element, key) as? [AXUIElement] ?? []
}

let inline = CommandLine.arguments.count == 5 && CommandLine.arguments[4] == "inline"
let landmarkTitle = inline ? "工作區導覽" : "工作區目的地"
let dialogTitle = "模態導覽列"
let labels: Set<String> = [
    "首頁", "封存", "收件匣", "跨部門協作與專案通知收件匣", "報告", "設定", "關閉導覽列",
    "開啟導覽列", "瀏覽首頁", "封存資料", "收合導覽列", "展開導覽列",
]
let trusted = AXIsProcessTrusted()
var windows: [AXUIElement] = []
var measuredWindows = 0
var sizes: [[String: Double]] = []
var buttons: [[String: Any]] = []
var dialogs: [[String: Any]] = []
var navigationLandmarks = 0
var visited = 0
func walk(_ element: AXUIElement, _ depth: Int, _ inside: Bool) {
    visited += 1
    guard depth <= 35 && visited <= 3000 else { return }
    let role = attribute(element, "AXRole") as? String
    let subrole = attribute(element, "AXSubrole") as? String
    let dialog = subrole == "AXDialog"
        && ["AXTitle", "AXDescription", "AXLabel"].contains {
            attribute(element, $0) as? String == dialogTitle
        }
    if dialog {
        dialogs.append(["name": dialogTitle, "modal": attribute(element, "AXModal") as? Bool ?? false])
    }
    let landmark = subrole == "AXLandmarkNavigation"
        && ["AXTitle", "AXDescription", "AXLabel"].contains {
            attribute(element, $0) as? String == landmarkTitle
        }
    if landmark {
        navigationLandmarks += 1
    }
    if role == "AXButton", let title = attribute(element, "AXTitle") as? String,
       labels.contains(title) {
        var button: [String: Any] = ["title": title, "role": "AXButton", "in_rail_or_dialog": inside]
        if let enabled = attribute(element, "AXEnabled") as? Bool {
            button["enabled"] = enabled
        }
        if let current = attribute(element, "AXARIACurrent") as? String {
            button["current"] = current
        }
        if let expanded = attribute(element, "AXExpanded") as? Bool {
            button["expanded"] = expanded
        }
        if let focused = attribute(element, "AXFocused") as? Bool {
            button["focused"] = focused
        }
        buttons.append(button)
    }
    for child in children(element, "AXChildren") {
        walk(child, depth + 1, inside || landmark || dialog)
    }
}

if trusted, [2, 4, 5].contains(CommandLine.arguments.count),
   let pid = pid_t(CommandLine.arguments[1]), pid > 1 {
    let w = CommandLine.arguments.count >= 4 ? Double(CommandLine.arguments[2]) : nil
    let h = CommandLine.arguments.count >= 4 ? Double(CommandLine.arguments[3]) : nil
    let app = AXUIElementCreateApplication(pid)
    AXUIElementSetMessagingTimeout(app, 0.5)
    _ = attribute(app, "AXFocusedUIElement")
    windows = children(app, "AXWindows")
    if windows.isEmpty, let value = attribute(app, "AXFocusedWindow") {
        let ref = value as CFTypeRef
        if CFGetTypeID(ref) == AXUIElementGetTypeID() {
            windows = [unsafeBitCast(ref, to: AXUIElement.self)]
        }
    }
    for window in windows {
        var matches = w == nil
        if let value = attribute(window, "AXSize") {
            let ref = value as CFTypeRef
            if CFGetTypeID(ref) == AXValueGetTypeID() {
                let sizeValue = unsafeBitCast(ref, to: AXValue.self)
                var size = CGSize.zero
                if AXValueGetValue(sizeValue, .cgSize, &size) {
                    if let w = w, let h = h {
                        matches = abs(size.width - w) < 0.5 && size.height >= h && size.height < h + 60
                    }
                    if matches {
                        sizes.append(["width": size.width, "height": size.height])
                    }
                }
            }
        }
        if matches {
            measuredWindows += 1
            walk(window, 0, false)
        }
    }
}

let result: [String: Any] = [
    "trusted": trusted,
    "windows": measuredWindows,
    "window_sizes_pt": sizes,
    "navigation_landmarks": navigationLandmarks,
    "buttons": buttons,
    "dialogs": dialogs,
]
let encoded = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
print(String(decoding: encoded, as: UTF8.self))
