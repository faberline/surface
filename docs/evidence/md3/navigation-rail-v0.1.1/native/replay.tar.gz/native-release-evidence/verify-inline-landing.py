#!/usr/bin/env python3
"""Inspect exact landing Classic and adaptive Wide Rail with the same native fixture."""
import argparse
import json
import os
from pathlib import Path
import runpy

SWIPE = runpy.run_path(str(Path(__file__).with_name("verify-swipe-native.py")))
P = SWIPE["P"]
bounds, node, require = SWIPE["bounds"], SWIPE["node"], SWIPE["require"]
take, wait_dom = SWIPE["take"], SWIPE["wait_dom"]


def classic(plan):
    name = "classic-light-704"
    with P["start_gallery"](plan, name, 704, 512) as app:
        if node(app.dom(), "theme")[0].get("checked"):
            app.activate("theme")
        app.activate("section-1")
        app.activate("rail-home")
        app.key("down")
        before = app.dom()
        require(before["interaction"]["focused"] == "rail-search", "Classic rail did not use Down")
        require(node(before, "rail-home")[0]["current_page"], "Down unexpectedly selected another page")
        app.key("enter")
        scene = app.dom()
        require(bounds(scene, "nav-rail")["width"] == 80 and bounds(scene, "rail-search")["height"] == 64,
                "Classic rail dimensions differ")
        require(node(scene, "rail-search")[0]["current_page"], "Classic Enter did not select Search")
        app.wire("QA.swipeInput", {"kind": "scroll", "x": 350, "y": 400, "dy": 100})
        scene = app.dom()
        rail = P["screen_box"](scene, "nav-rail")
        frame, pixels = take(app, plan, name, 704, 512, settled=True)
        layout = scene["layout"]["nodes"]
        owner = node(scene, "rail-search")[1]["id"]
        indicator = next((entry, layout[index]["bounds"])
                         for index, entry in enumerate(scene["dom"]["nodes"]) if entry["parent"] == owner)
        hits = P["image_color_match"](pixels, indicator[1], indicator[0]["style"]["background"])
        require(hits >= 8, "Classic selected pill did not render")
        return {"profile": name, "rail_width_dp": 80, "item_height_dp": 64, "visible_rail": rail,
                "selected_pill_pixel_samples": hits, "keyboard_current": "rail-search",
                "metal_adapter": app.adapter, "frame": frame}


def adaptive(plan, name, width, height, dark):
    expanded = width >= 600
    with P["start_gallery"](plan, name, width, height) as app:
        scene = P["aim_gallery"](app, wide=expanded, dark=dark, rtl=dark)
        rail = "wide-rail" if expanded else "wide-rail-bottom"
        if expanded:
            scene = wait_dom(app, lambda value: bounds(value, rail)["width"] >= 220,
                             "inline rail expanded to its minimum width")
        else:
            require(not SWIPE["stable_id"](scene, "wide-rail-toggle"), "Compact retained wide control")
            home, inbox = (bounds(scene, item) for item in ("wide-rail-home", "wide-rail-inbox"))
            require((home["x"] > inbox["x"]) == dark, "Compact item order differs from its direction")
            require(min(home["width"], inbox["width"]) >= 48, "Compact target is below 48 dp")
        frame, _ = take(app, plan, name, width, height, settled=True)
        return {"profile": name, "rtl": dark, "text_percent": 200 if dark else 100,
                "rail": rail, "rail_bounds": bounds(scene, rail), "keyboard_current": "wide-rail-inbox",
                "metal_adapter": app.adapter, "frame": frame}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gallery", type=Path, required=True)
    parser.add_argument("--cli", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    plan = parser.parse_args()
    plan.artifacts.mkdir(mode=0o700)
    plan.reduced_motion = False
    os.environ["SURFACE_RAIL_QA"] = "1"
    result = []
    proofs = [lambda: classic(plan),
              lambda: adaptive(plan, "inline-light-704-expanded", 704, 512, False),
              lambda: adaptive(plan, "inline-dark-rtl-320-compact", 320, 240, True)]
    for prove in proofs:
        report = prove()
        result.append(report)
        (plan.artifacts / "report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
        print(f"Verified {report['profile']}.", flush=True)


if __name__ == "__main__":
    main()
