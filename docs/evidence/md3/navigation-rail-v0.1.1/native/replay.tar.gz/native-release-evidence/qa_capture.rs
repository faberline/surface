use super::{drawable_size, Host};
use base64::prelude::{Engine, BASE64_STANDARD};
use serde_json::json;
use surface_app::Application;
use surface_devtools_protocol::{ErrorCode, Reply, Request};
use winit::event_loop::ActiveEventLoop;

pub(super) fn capture<A: Application>(
    host: &mut Host<A>,
    event_loop: &ActiveEventLoop,
    request: Request,
) -> Reply {
    let failure = |code, message: &str| Reply::error(request.id, code, message);
    if request.params != json!({ "scale": 1 }) {
        return failure(ErrorCode::InvalidParams, "QA replay needs scale 1");
    }
    let Some(window) = &host.window else {
        return failure(ErrorCode::NotReady, "no live window");
    };
    let (size, scale) = drawable_size(window);
    // The tested window is small and native macOS uses a whole-number scale.
    if !matches!(scale, 1. | 2.) || size.width == 0 || size.height == 0 {
        return failure(ErrorCode::NotReady, "no supported drawable size");
    }
    let width = (size.width as f32 / scale).round() as u32;
    let height = (size.height as f32 / scale).round() as u32;
    if width > 1024 || height > 1024 {
        return failure(ErrorCode::TooLarge, "QA readback is limited to 1024 px per side");
    }
    let mut presented = None;
    host.draw_frame(event_loop, Some(&mut presented));
    let (Some(frame), Some(gpu)) = (presented, &mut host.gpu) else {
        return failure(ErrorCode::NotReady, "no newly presented frame");
    };
    let result = (|| -> Result<_, Box<dyn std::error::Error>> {
        let image = gpu.renderer.capture_extended_qa(&frame, width, height, 1.)?;
        let mut bytes = Vec::new();
        let mut encoder = png::Encoder::new(&mut bytes, width, height);
        encoder.set_color(png::ColorType::Rgba);
        encoder.set_depth(png::BitDepth::Eight);
        let mut writer = encoder.write_header()?;
        writer.write_image_data(&image.rgba)?;
        writer.finish()?;
        Ok(BASE64_STANDARD.encode(bytes))
    })();
    match result {
        Ok(encoded) => Reply::ok(request.id, json!({
            "format": "png", "width": width, "height": height, "scale": 1,
            "data_base64": encoded,
        })),
        Err(error) => failure(ErrorCode::RenderFailed, &error.to_string()),
    }
}
