#!/usr/bin/env python3
"""Audit standalone modal wide rail dismissal using Metal and public DevTools PNGs."""

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import runpy
from statistics import median
import subprocess
import time


HERE = Path(__file__).resolve().parent
P = runpy.run_path(str(HERE / "verify-public-screenshot.py"))
M = runpy.run_path(str(HERE / "verify-modal-wide-rail.py"))
require, node, bounds = (P[name] for name in ("require", "node", "bounds"))
MODAL = "modal-wide-rail"
LAYER = MODAL + "-layer"
OPEN = MODAL + "-open"
CLOSE = MODAL + "-close"
NAV = MODAL + "-navigation"
INBOX = MODAL + "-inbox"
HOME = MODAL + "-home"
RETAIN = MODAL + "-retain"
PROFILES = {
    "light-704": (704, 512, False, "winit-mouse"),
    "dark-rtl-704-200": (704, 512, True, "winit-mouse"),
    "dark-rtl-320-200": (320, 240, True, "winit-touch"),
}


def stable_id(scene, stable):
    return any(entry.get("stable_id") == stable for entry in scene["dom"]["nodes"])


def focus(scene):
    return scene["interaction"]["focused"]


def wait_dom(app, predicate, description):
    timeout = time.monotonic() + 3
    while time.monotonic() < timeout:
        scene = app.dom()
        if predicate(scene):
            return scene
        time.sleep(0.04)
    raise RuntimeError(f"Timed out waiting for {description}")


def visible_width(scene, width):
    b = bounds(scene, MODAL)
    return max(0, min(width, b["x"] + b["width"]) - max(0, b["x"]))


def alpha(scene):
    return node(scene, LAYER)[0]["style"]["background"][3]


def scroll_offset(scene):
    return bounds(scene, NAV)["y"] - bounds(scene, HOME)["y"]


class Contact:
    def __init__(self, app, route, point):
        self.app, self.route, self.point, self.count = app, route, point, 0

    def send(self, kind, point, **fields):
        self.app.wire("QA.swipeInput", {"kind": kind, "x": point[0], "y": point[1], **fields})

    def step(self, kind, point):
        if self.route == "winit-touch":
            self.send("touch-" + kind, point, contact=self.count)
        else:
            self.send(kind if kind != "cancel" else "capture-cancel", point)

    def start(self):
        self.count += 1
        if self.route == "winit-mouse":
            self.send("move", self.point)
        self.step("down", self.point)

    def move(self, point):
        self.step("move", point)

    def release(self, point):
        if self.route == "winit-mouse":
            self.send("move", point)
        self.step("up", point)

    def cancel(self, point):
        self.step("cancel", point)


def expect_open(scene, active_focus):
    require(focus(scene) == active_focus, f"Open rail focus differs: {focus(scene)}")
    require(node(scene, HOME)[0]["current_page"], "Pointer gesture selected a destination")
    require(node(scene, MODAL)[0]["name"] == "模態導覽列", "Modal role differs")


def expect_closed(scene):
    return not stable_id(scene, MODAL) and not stable_id(scene, MODAL + "-closing")


def setup(app, dimensions, rtl):
    if bool(node(app.dom(), "theme")[0].get("checked")) != rtl:
        app.activate("theme")
    app.activate("section-1")
    if rtl:
        app.activate(MODAL + "-direction")
        app.activate(MODAL + "-scale")
    app.activate(RETAIN)
    app.activate(RETAIN)
    app.key("tab")
    scene = app.dom()
    require(focus(scene) == OPEN, "Gallery opener is not focused")
    view = scene["layout"]["viewport"]
    require((view["width"], view["height"]) == dimensions, "Native viewport size differs")
    return scene


def pixel_audit(closed, opened, held, area, full_width, rtl, background):
    w, h = len(held[0]) // 4, len(held)
    # Use quiet rows around the title to find the translated Surface fill.
    def at(rows, x, y):
        return rows[y][x * 4:x * 4 + 4]
    x_values = list(range(w - 1, -1, -1)) if rtl else list(range(w))
    widths = []
    for y in range(12, min(116, h // 2), 3):
        count = 0
        for x in x_values:
            if not all(abs(a - b) <= 2 for a, b in zip(at(held, x, y), background)):
                break
            count += 1
        widths.append(count)
    widths.sort()
    actual = widths[len(widths) * 4 // 5]
    require(abs(actual - area) <= 6, f"Metal panel width differs from viewport intersection: {actual} vs {area}")
    x = 22 if rtl else w - 23
    values = [round(median(sum(at(rows, x, y)[:3]) / 3 for y in range(12, h - 20, 4)), 3)
              for rows in (closed, opened, held)]
    if full_width < w - 40:
        require(values[1] < values[2] < values[0], f"Metal scrim did not track the hold: {values}")
    else:
        require(values[2] < values[0], f"Metal compact exposed backdrop did not darken: {values}")
    return {"held_panel_pixels": actual, "outside_rgb_mean_uncovered_open_held": values}


def take(app, plan, name, width, height, settled=False):
    if settled:
        time.sleep(0.15)
    reply = app.wire("Page.screenshot", {"scale": 1})
    expected = {"format": "png", "width": width, "height": height, "scale": 1}
    require(P["metadata"](reply) == expected, "QA wire capture dimensions differ")
    raw = P["png_payload"](reply)
    png_width, png_height, rows = P["read_png"](raw)
    require((png_width, png_height) == (width, height), "PNG dimensions differ from metadata")
    path = plan.artifacts / (name + ".png")
    path.write_bytes(raw)
    return {"png": path.name, "sha256": hashlib.sha256(raw).hexdigest(), "pixels": [width, height]}, rows


def prove(plan, name, width, height, rtl, route):
    dimensions = (width, height)
    plan.ax_window = dimensions
    with P["start_gallery"](plan, name, *dimensions) as app:
        setup(app, dimensions, rtl)
        test_adapter = app.adapter
        closed, closed_pixels = take(app, plan, name + "-closed", *dimensions, settled=True)
        app.activate(OPEN)
        open_scene = wait_dom(app, lambda s: stable_id(s, MODAL) and
                              abs(visible_width(s, width) - bounds(s, MODAL)["width"]) < 0.5,
                              "full modal opening")
        panel = M["assert_open"](open_scene, dimensions, rtl, "home")
        M["ax_dialog"](plan, app.proc.pid, *dimensions, "關閉導覽列", "首頁")
        expect_open(open_scene, CLOSE)
        app.key("tab")
        app.key("down")
        focused = app.dom()
        expect_open(focused, INBOX)
        ax_open = M["ax_dialog"](plan, app.proc.pid, *dimensions, M["INBOX_NAME"], "首頁")
        opened, open_pixels = take(app, plan, name + "-open", *dimensions, settled=True)
        if width == 320:
            opened.update(M["assert_raster_label"](focused, open_pixels, M["INBOX_NAME"], INBOX, bounds(focused, NAV)))
        span = panel["width"]
        x0 = panel["x"] + (0.22 if rtl else 0.78) * span
        # Start on the panel's top spacer. A pointer press on a destination
        # can change focus before the drag recognizer has acquired it.
        y = 12
        origin = (x0, y)
        point = lambda portion: (x0 + (1 if rtl else -1) * span * portion, y)
        contact = Contact(app, route, origin)
        scroll = None
        if width == 320:
            old = scroll_offset(focused)
            nav_y = min(height - 18, bounds(focused, NAV)["y"] + 45)
            scroll_point = (x0, nav_y)
            contact.send("scroll", scroll_point, dy=-90)
            wheeled = app.dom()
            moved = scroll_offset(wheeled)
            require(abs(old - moved) >= 25, f"Independent list wheel did not move destinations: {old}, {moved}")
            require(bounds(wheeled, MODAL + "-header") == bounds(focused, MODAL + "-header"), "Wheel moved header")
            touch = Contact(app, route, scroll_point)
            touch.start()
            vertical = (x0 + 3., nav_y - 42.)
            touch.move(vertical)
            touch.release(vertical)
            expect_open(app.dom(), INBOX)
            scroll = {"arrow_to_inbox_dp": old, "after_wheel_dp": moved,
                      "vertical_touch_did_not_dismiss_or_activate": True}

        full_alpha = alpha(open_scene)
        contact.start()
        hold = point(0.34)
        contact.move(hold)
        held_scene = app.dom()
        expect_open(held_scene, INBOX)
        app.wire("Action.activate", {"id": RETAIN}, "outside_modal")
        held_width = visible_width(held_scene, width)
        require(math.isclose(held_width, span * 0.66, abs_tol=1.5),
                f"Held panel does not track 34% of its measured width: {held_width}/{span}")
        held_alpha = alpha(held_scene)
        require(abs(held_alpha - full_alpha * (held_width / span)) <= 1.5, "Held scrim drifted from panel progress")
        held, held_pixels = take(app, plan, name + "-held", *dimensions, settled=True)
        pixels = pixel_audit(closed_pixels, open_pixels, held_pixels, held_width, span, rtl,
                             node(open_scene, MODAL)[0]["style"]["background"])
        ax_held = M["ax_dialog"](plan, app.proc.pid, *dimensions, M["INBOX_NAME"], "首頁")
        contact.cancel(hold)
        contact.release(hold)
        restored = wait_dom(app, lambda s: stable_id(s, MODAL)
                            and abs(visible_width(s, width) - span) <= 0.5 and alpha(s) == full_alpha,
                            "cancel returning to the opening anchor")
        expect_open(restored, INBOX)
        cancelled, _ = take(app, plan, name + "-cancelled", *dimensions)
        time.sleep(0.40)
        contact.start()
        contact.move(point(0.28))
        short_hold = app.dom()
        require(math.isclose(visible_width(short_hold, width), span * 0.72, abs_tol=1.5),
                "Second contact did not acquire the restored rail")
        time.sleep(0.18)
        contact.release(point(0.28))
        short = wait_dom(app, lambda s: stable_id(s, MODAL)
                         and abs(visible_width(s, width) - span) <= 0.5,
                         "subthreshold release returning to the opening anchor")
        expect_open(short, INBOX)
        short_returned, _ = take(app, plan, name + "-short-returned", *dimensions)
        time.sleep(0.40)
        contact.start()
        contact.move(point(0.64))
        committed_hold = app.dom()
        require(math.isclose(visible_width(committed_hold, width), span * 0.36, abs_tol=1.5),
                f"Third contact did not acquire the restored rail: {visible_width(committed_hold, width)}")
        time.sleep(0.18)
        contact.release(point(0.64))
        settling = app.dom()
        if stable_id(settling, MODAL):
            expect_open(settling, INBOX)
        settled = wait_dom(app, expect_closed, "committed dismissal")
        require(focus(settled) == OPEN, "Committed release did not restore opener focus")
        require(node(settled, MODAL + "-page")[0]["text"] == "目前頁面：首頁",
                "Dismissal changed the selected page")
        finished, _ = take(app, plan, name + "-dismissed", *dimensions, settled=True)
        return {"profile": name, "viewport_dp": dimensions, "input": route,
                "metal_adapter": test_adapter, "open_panel_dp": panel, "held_panel_visible_dp": held_width, "scrim_alpha_open_held": [full_alpha, held_alpha],
                "cancel_ignored_stale_release": True, "slow_subthreshold_restored_open": True,
                "slow_over_half_dismissed": True, "closing_scope_sampled_live": stable_id(settling, MODAL),
                "raster": pixels, "independent_scroll": scroll, "appkit_open": ax_open, "appkit_held": ax_held,
                "frames": {"closed": closed, "open": opened, "held": held,
                           "cancelled": cancelled, "short_returned": short_returned, "dismissed": finished}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gallery", type=Path, required=True)
    parser.add_argument("--cli", type=Path, required=True)
    parser.add_argument("--ax-reader", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile", action="append", choices=PROFILES)
    plan = parser.parse_args()
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    plan.reduced_motion = False
    os.environ["SURFACE_RAIL_QA"] = "1"
    reports = []
    for name in plan.profile or PROFILES:
        reports.append(prove(plan, name, *PROFILES[name]))
        (plan.artifacts / "report.json").write_text(json.dumps(reports, ensure_ascii=False, indent=2) + "\n")
        print(f"Verified {name}.", flush=True)


if __name__ == "__main__":
    main()
