#!/bin/sh
set -eu
if [ "$#" -ne 2 ]; then
    echo "Usage: build-and-run.sh VERIFIED_SURFACE_CHECKOUT NEW_OUTPUT_DIRECTORY" >&2
    exit 2
fi
bundle=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
source=$(CDPATH='' cd -- "$1" && pwd)
output=$2
scratch=$(mktemp -d /tmp/surface-md3-rail-landing-native.XXXXXXXX)
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_TARGET_DIR="/tmp/cargo-target/surface-$(basename "$scratch")"
export COPYFILE_DISABLE=1
(
    cd "$source"
    shasum -a 256 -c "$bundle/landing-production.sha256"
    shasum -a 256 -c "$bundle/controller-product.sha256"
    git ls-files --cached --others --exclude-standard -z | tar -cf "$scratch/source.tar" --null -T -
)
mkdir "$scratch/repo"
tar -xf "$scratch/source.tar" -C "$scratch/repo"
python3 -B "$bundle/apply-landing-qa.py" "$scratch/repo"
(
    cd "$scratch/repo"
    shasum -a 256 -c "$bundle/overlay.sha256"
    cap cargo build --locked -p surface-material-gallery -p surface-devtools \
        --features surface-material-gallery/devtools --example public_screenshot_gallery --bin surface-devtools
)
xcrun swiftc -O -module-cache-path "$scratch/swift-cache" \
    "$bundle/read-modal-gallery-ax.swift" -o "$scratch/read-modal-gallery-ax"
gallery="$CARGO_TARGET_DIR/debug/examples/public_screenshot_gallery"
cli="$CARGO_TARGET_DIR/debug/surface-devtools"
mkdir "$output"
python3 -B "$bundle/verify-swipe-native.py" --gallery "$gallery" --cli "$cli" \
    --ax-reader "$scratch/read-modal-gallery-ax" --artifacts "$output/modal"
python3 -B "$bundle/verify-inline-landing.py" --gallery "$gallery" --cli "$cli" \
    --artifacts "$output/inline"
