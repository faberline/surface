#!/usr/bin/env python3
"""Validate the PNGs and bounded receipts produced by the Navigation Rail landing fixture."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy

PNG = runpy.run_path(str(Path(__file__).with_name("verify-public-screenshot.py")))["read_png"]


def frame(directory, item):
    name = item["png"]
    if Path(name).name != name:
        raise ValueError(f"Invalid PNG filename: {name}")
    value = (directory / name).read_bytes()
    if hashlib.sha256(value).hexdigest() != item["sha256"]:
        raise ValueError(f"PNG checksum mismatch: {name}")
    width, height, _ = PNG(value)
    if [width, height] != item["pixels"]:
        raise ValueError(f"PNG dimensions mismatch: {name}")
    return name


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("modal", type=Path)
    parser.add_argument("inline", type=Path)
    args = parser.parse_args()

    modal = json.loads((args.modal / "report.json").read_text())
    inline = json.loads((args.inline / "report.json").read_text())
    if len(modal) != 3 or len(inline) != 3:
        raise RuntimeError("Expected three modal and three classic/adaptive profiles")
    seen = set()
    for case in modal:
        if not all(case[tag] for tag in (
            "cancel_ignored_stale_release", "slow_subthreshold_restored_open", "slow_over_half_dismissed"
        )):
            raise ValueError("Missing modal cancellation, short return or dismissal")
        if not all(case[key].get("trusted") for key in ("appkit_open", "appkit_held")):
            raise ValueError("AppKit tree was not read during an open or held modal")
        if not case["metal_adapter"].endswith("(Metal)"):
            raise ValueError("Modal profile did not use Metal")
        seen.update(frame(args.modal, item) for item in case["frames"].values() if "png" in item)
    for case in inline:
        if not case["metal_adapter"].endswith("(Metal)"):
            raise ValueError("Classic/adaptive profile did not use Metal")
        seen.add(frame(args.inline, case["frame"]))
    if len(seen) != 21:
        raise ValueError(f"Expected 21 individual PNGs, observed {len(seen)}")
    print(json.dumps({
        "native_profiles": len(modal) + len(inline),
        "pngs_with_matching_hash_and_size": len(seen),
        "modal_profiles_with_trusted_appkit": len(modal),
        "modal_profiles_sampled_during_closing": sum(case["closing_scope_sampled_live"] for case in modal),
        "uses_synthetic_winit_input": True,
        "uses_scratch_only_page_screenshot": True,
    }, indent=2))


if __name__ == "__main__":
    main()
