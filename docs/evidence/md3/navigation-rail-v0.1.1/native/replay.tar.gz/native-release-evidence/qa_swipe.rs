//! Isolated test input through the Gallery host's Winit window-event route.

use super::Host;
use serde_json::Value;
use surface_app::Application;
use winit::{
    application::ApplicationHandler,
    dpi::PhysicalPosition,
    event::{DeviceId, ElementState, MouseButton, MouseScrollDelta, Touch, TouchPhase, WindowEvent},
    event_loop::ActiveEventLoop,
};

pub(super) fn dispatch<A: Application>(
    host: &mut Host<A>,
    event_loop: &ActiveEventLoop,
    params: &Value,
) -> Result<(), &'static str> {
    let coordinate = |key: &str| {
        params[key]
            .as_f64()
            .filter(|v| v.is_finite() && v.abs() <= 100_000.)
            .ok_or("expected finite position")
    };
    let kind = params["kind"].as_str();
    if kind == Some("capture-cancel") {
        host.dispatch_input(event_loop, |runtime| runtime.cancel_pointer());
        return Ok(());
    }
    let window = host.window.as_ref().ok_or("Gallery window not ready")?;
    let id = window.id();
    let scale = window.scale_factor();
    let x = coordinate("x")?;
    let y = coordinate("y")?;
    let location = PhysicalPosition::new(x * scale, y * scale);
    let device_id = DeviceId::dummy();
    let event = match kind {
        Some("move") => WindowEvent::CursorMoved {
            device_id,
            position: location,
        },
        Some("down" | "up") => WindowEvent::MouseInput {
            device_id,
            button: MouseButton::Left,
            state: if kind == Some("down") {
                ElementState::Pressed
            } else {
                ElementState::Released
            },
        },
        Some("scroll") => WindowEvent::MouseWheel {
            device_id,
            delta: MouseScrollDelta::PixelDelta(PhysicalPosition::new(
                0.,
                -coordinate("dy")? * scale,
            )),
            phase: TouchPhase::Moved,
        },
        Some("touch-down" | "touch-move" | "touch-up" | "touch-cancel") => WindowEvent::Touch(Touch {
            device_id,
            phase: match kind {
                Some("touch-down") => TouchPhase::Started,
                Some("touch-move") => TouchPhase::Moved,
                Some("touch-up") => TouchPhase::Ended,
                _ => TouchPhase::Cancelled,
            },
            location,
            force: None,
            id: params["contact"].as_u64().ok_or("expected contact id")?,
        }),
        _ => return Err("unknown Gallery test event"),
    };
    host.pointer = (x as f32, y as f32);
    host.window_event(event_loop, id, event);
    Ok(())
}
