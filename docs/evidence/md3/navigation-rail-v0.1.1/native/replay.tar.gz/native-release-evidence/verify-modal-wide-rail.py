#!/usr/bin/env python3
"""Verify a modal wide rail through public native Surface DevTools."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import runpy


HERE = Path(__file__).resolve().parent
LIB = runpy.run_path(str(HERE / "verify-public-screenshot.py"))
require, node, bounds, contains, read_png, metadata, png_payload = (
    LIB[key] for key in ("require", "node", "bounds", "contains", "read_png", "metadata", "png_payload")
)
MODAL = "modal-wide-rail"
OPEN = MODAL + "-open"
CLOSE = MODAL + "-close"
RETAIN = MODAL + "-retain"
INLINE = MODAL + "-inline"
NAV = MODAL + "-navigation"
LAYER = MODAL + "-layer"
HEADER = MODAL + "-header"
HOME = MODAL + "-home"
INBOX = MODAL + "-inbox"
ARCHIVE = MODAL + "-archive"
CONTENT = MODAL + "-content"
PAGE = MODAL + "-page"
TITLE = "模態導覽列"
OPEN_NAME = "開啟導覽列"
CLOSE_NAME = "關閉導覽列"
INBOX_NAME = "跨部門協作與專案通知收件匣"
PROFILES = {
    "wide-light-ltr": (960, 800, False),
    "narrow-dark-rtl-200": (320, 240, True),
}


def present(snapshot, stable_id):
    return any(item.get("stable_id") == stable_id for item in snapshot["dom"]["nodes"])


def focus(snapshot):
    return snapshot["interaction"]["focused"]


def full_frame(snapshot, dimensions):
    view = snapshot["layout"]["viewport"]
    require([view["width"], view["height"]] == list(dimensions), f"Viewport mismatch: {view}")
    return view


def activate_failure(app, stable_id, code):
    return app.wire("Action.activate", {"id": stable_id}, code)


def assert_closed(snapshot, retained, current, restored=False):
    require(not present(snapshot, MODAL), "Dialog remains mounted")
    require(not node(snapshot, OPEN)[0]["expanded"], "Opener kept its expanded state")
    require(present(snapshot, INLINE) == retained, "Unexpected collapsed rail mode")
    if retained:
        require(math.isclose(bounds(snapshot, INLINE)["width"], 96.), "Inline rail width changed")
        require(node(snapshot, INLINE + "-" + current)[0]["current_page"], "Inline current page differs")
    if restored:
        require(focus(snapshot) == OPEN, "Collapsed layout did not restore the opener's focus")


def assert_open(snapshot, dimensions, rtl, current):
    view = full_frame(snapshot, dimensions)
    dialog, layout = node(snapshot, MODAL)
    area = layout["bounds"]
    require(dialog["role"] == "Dialog" and dialog["name"] == TITLE, "Dialog name or role differs")
    require(contains(view, area) and area["height"] == view["height"], f"Panel bounds differ: {area}")
    require(220 <= area["width"] <= min(360, dimensions[0]), f"Panel width differs: {area}")
    require(abs(area["x"] + area["width"] - view["width"] if rtl else area["x"]) <= 0.5,
            f"Dialog is on the wrong logical edge: {area}")
    close = bounds(snapshot, CLOSE)
    title = bounds(snapshot, MODAL + "-title")
    require((close["x"] > title["x"]) == rtl and contains(area, close) and contains(area, title),
            "Dialog header does not fit the requested layout direction")
    require(node(snapshot, NAV)[0]["role"] == "Navigation"
            and node(snapshot, NAV)[0]["name"] == "工作區目的地", "Navigation landmark name differs")
    require(node(snapshot, MODAL + "-" + current)[0]["current_page"], "Wrong current modal page")
    require(node(snapshot, ARCHIVE)[0]["disabled"], "Disabled Archive unexpectedly enabled")
    require(bounds(snapshot, LAYER) == view and node(snapshot, LAYER)[0]["style"]["background"][3] > 0,
            "Scrim does not cover the viewport")
    return area


def snapshot_pixels(app, plan, frame, dimensions, check_mcp=False):
    path = plan.artifacts / (frame + ".png")
    expected = {"format": "png", "width": dimensions[0], "height": dimensions[1], "scale": 1}
    cli = app.cli(["page", "screenshot", "--scale", "1", "--out", str(path)])
    raw = path.read_bytes()
    width, height, rows = read_png(raw)
    require((width, height) == dimensions and metadata(cli) == expected, "CLI capture dimensions differ")
    data = {"png": path.name, "sha256": hashlib.sha256(raw).hexdigest(), "pixels": [width, height]}
    if check_mcp:
        wire = app.wire("Page.screenshot", {"scale": 1})
        picture, description, _ = app.mcp({"scale": 1})
        require(png_payload(wire) == raw == picture and metadata(description) == metadata(wire) == expected,
                "Wire, CLI and MCP captures differ")
        data["wire_cli_mcp_png_equal"] = True
    return data, rows


def verify_scrim(before, overlay, width, panel):
    x = round((panel["x"] + panel["width"] + width) * 0.5)
    darker = 0
    for y in range(20, len(before) - 20, 11):
        open_pixel = overlay[y][x * 4:x * 4 + 3]
        prior_pixel = before[y][x * 4:x * 4 + 3]
        if all(10 <= b - a <= 170 for a, b in zip(open_pixel, prior_pixel)):
            darker += 1
    require(darker >= 12, f"Scrim did not darken the backdrop: {darker} pixels")
    return darker


def assert_raster_label(snapshot, pixels, text, button, viewport):
    descriptions = snapshot["dom"]["nodes"]
    layouts = snapshot["layout"]["nodes"]
    button_id = node(snapshot, button)[1]["id"]
    for entry, layout in zip(descriptions, layouts):
        if entry.get("text") != text:
            continue
        parent = entry["parent"]
        while parent is not None and parent != button_id:
            parent = descriptions[parent]["parent"]
        if parent == button_id:
            break
    else:
        raise RuntimeError("Missing the focused Inbox label in the public DOM")
    label = layout["bounds"]
    require(contains(viewport, label) and contains(layout["clip"], label),
            f"Inbox label is clipped: label={label}, clip={layout['clip']}")
    foreground = entry["style"]["foreground"]
    left = math.ceil(label["x"]) + 1
    right = math.floor(label["x"] + label["width"]) - 1
    top = math.ceil(label["y"])
    middle = math.floor(label["y"] + label["height"] * 0.5)
    bottom = math.floor(label["y"] + label["height"])
    rendered_lines = []
    for first_row, last_row in ((top, middle), (middle, bottom)):
        ink_rows = 0
        ink_count = 0
        for y in range(first_row, last_row):
            count = 0
            for x in range(left, right):
                sample = pixels[y][x * 4:x * 4 + 4]
                if all(abs(a - b) <= 5 for a, b in zip(sample, foreground)):
                    count += 1
            if count >= 5:
                ink_rows += 1
                ink_count += count
        require(ink_rows >= 14 and ink_count >= 70,
                f"PNG missed Inbox label ink in y{first_row}–{last_row}: {ink_rows} rows, {ink_count} pixels")
        rendered_lines.append({"ink_rows": ink_rows, "ink_pixels": ink_count})
    return {"label_bounds_dp": label, "ink_by_text_line": rendered_lines}


def ax_dialog(plan, pid, width, height, focused_title, current_title):
    receipt = LIB["appkit"](plan, pid)
    if not receipt.get("trusted"):
        return receipt
    require(receipt["windows"] == 1 and receipt["navigation_landmarks"] == 1,
            f"AppKit modal landmark/window is missing: {receipt}")
    require(receipt["dialogs"] == [{"name": TITLE, "modal": True}], "AppKit dialog is not named/modal")
    require(any(s["width"] == width and s["height"] >= height for s in receipt["window_sizes_pt"]),
            "AppKit window size differs from the case")
    buttons = receipt["buttons"]
    require(all(b["title"] != OPEN_NAME for b in buttons), "AppKit exported the background opener")
    require(any(b["title"] == current_title and b.get("current") == "page" for b in buttons),
            f"AppKit current destination differs: {buttons}")
    require(any(b["title"] == focused_title and b.get("focused") for b in buttons),
            f"AppKit focus differs: {buttons}")
    return receipt


def prove_profile(plan, name, width, height, rtl):
    dimensions = (width, height)
    with LIB["start_gallery"](plan, name, width, height) as app:
        ready = app.dom()
        full_frame(ready, dimensions)
        caps = app.cli(["capabilities"])
        require("Page.screenshot" in caps["methods"], "Host does not advertise Page.screenshot")
        if bool(node(ready, "theme")[0].get("checked")) != rtl:
            app.activate("theme")
        app.activate("section-1")
        if rtl:
            app.activate(MODAL + "-direction")
            app.activate(MODAL + "-scale")
        # Give the plain trigger focus while it is still in the page.
        # This scrolls the existing Gallery area into view via its public key route.
        app.activate(RETAIN)
        app.activate(RETAIN)
        app.key("tab")
        state = app.dom()
        assert_closed(state, retained=False, current="home")
        require(focus(state) == OPEN and contains(full_frame(state, dimensions), bounds(state, OPEN)),
                "The closed plain opener is not visible")
        closed_png, closed_rows = snapshot_pixels(app, plan, name + "-closed-trigger", dimensions)
        app.activate(OPEN)
        opened = app.dom()
        dialog = assert_open(opened, dimensions, rtl, "home")
        require(focus(opened) == CLOSE, "Close does not have initial focus")
        rejection = activate_failure(app, RETAIN, "outside_modal")
        activate_failure(app, "theme", "outside_modal")
        activate_failure(app, ARCHIVE, "disabled")
        require(focus(app.dom()) == CLOSE, "Rejected input changed focus")
        frames = {"closed_trigger": closed_png}
        frames["opened"], open_rows = snapshot_pixels(app, plan, name + "-opened", dimensions)
        require(LIB["image_color_match"](open_rows, dialog, node(opened, MODAL)[0]["style"]["background"]) >= 10,
                "PNG does not show the modal surface token")
        scrim_samples = 0 if rtl else verify_scrim(closed_rows, open_rows, width, dialog)
        modal_ax = ax_dialog(plan, app.proc.pid, width, height, CLOSE_NAME, "首頁")

        for extend in (True, False):
            args = ["action", "key", "tab"] + (["--extend"] if extend else [])
            app.cli(args)
            require(focus(app.dom()) in (CLOSE, HOME, INBOX), "Tab escaped the modal")
        if focus(app.dom()) != HOME:
            app.cli(["action", "key", "tab"])
        require(focus(app.dom()) == HOME, "Tab does not enter the destinations")
        before = app.dom()
        app.key("down")
        after = app.dom()
        require(focus(after) == INBOX, "Arrow did not skip the disabled destination")
        require(node(after, HOME)[0]["current_page"], "Arrow selected a page")
        require(bounds(before, HEADER) == bounds(after, HEADER), "Modal header scrolled")
        require(bounds(before, NAV) == bounds(after, NAV), "Scroll viewport moved")
        require(bounds(before, CONTENT) == bounds(after, CONTENT), "Background scrolled with the rail")
        scroll_dp = bounds(before, INBOX)["y"] - bounds(after, INBOX)["y"]
        if rtl:
            require(scroll_dp > 0, f"Compact navigation did not scroll: {scroll_dp}")
            require(bounds(after, INBOX)["height"] >= 110, "RTL 200% Inbox label did not wrap")
            nav_bounds = bounds(after, NAV)
            inbox_bounds = bounds(after, INBOX)
            require(contains(nav_bounds, inbox_bounds),
                    f"Focused Inbox is clipped: viewport={nav_bounds}, target={inbox_bounds}")
        frames["focused"], focused_pixels = snapshot_pixels(
            app, plan, name + "-focused-inbox", dimensions, check_mcp=rtl
        )
        if rtl:
            frames["focused"].update(assert_raster_label(after, focused_pixels, INBOX_NAME, INBOX, nav_bounds))
        focused_ax = ax_dialog(plan, app.proc.pid, width, height, INBOX_NAME, "首頁")

        app.key("escape")
        assert_closed(app.dom(), retained=False, current="home", restored=True)
        app.activate(OPEN)
        app.key("tab")
        app.key("down")
        app.key("enter")
        selected = app.dom()
        assert_closed(selected, retained=False, current="inbox", restored=True)
        require(node(selected, PAGE)[0]["text"] == "目前頁面：收件匣", "Enter did not select Inbox")
        app.activate(RETAIN)
        app.key("tab")
        app.key("tab")
        inline = app.dom()
        assert_closed(inline, retained=True, current="inbox")
        cached_underlay = {item: bounds(inline, item) for item in (INLINE, CONTENT)}
        frames["inline_closed"], _ = snapshot_pixels(app, plan, name + "-closed-inline", dimensions)
        app.activate(OPEN)
        retained = app.dom()
        assert_open(retained, dimensions, rtl, "inbox")
        require(focus(retained) == CLOSE, "Retained layout did not focus Close")
        require(all(abs(bounds(retained, item)["width"] - box["width"]) <= 0.5
                    for item, box in cached_underlay.items()), "Opening moved the inline page layout")
        activate_failure(app, INLINE + "-inbox", "outside_modal")
        frames["inline_with_modal"], _ = snapshot_pixels(app, plan, name + "-retained-modal", dimensions)
        retained_ax = ax_dialog(plan, app.proc.pid, width, height, CLOSE_NAME, INBOX_NAME)
        app.key("enter")
        assert_closed(app.dom(), retained=True, current="inbox", restored=True)
        return {
            "profile": name, "viewport_dp": list(dimensions), "dialog_dp": dialog,
            "backdrop_rejects_background": rejection, "scrim_samples_darkened": scrim_samples,
            "destination_scroll_dp": scroll_dp, "appkit_at_open": modal_ax,
            "appkit_at_focus": focused_ax, "appkit_retained_open": retained_ax,
            "escape_restored": True, "enter_selected_and_restored": True,
            "close_restored": True, "frames": frames,
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gallery", type=Path, required=True)
    parser.add_argument("--cli", type=Path, required=True)
    parser.add_argument("--ax-reader", type=Path)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--profile", action="append", choices=PROFILES)
    plan = parser.parse_args()
    plan.artifacts = plan.artifacts.resolve()
    plan.artifacts.mkdir(mode=0o700)
    reports = []
    for name, dimensions in PROFILES.items():
        if not plan.profile or name in plan.profile:
            reports.append(prove_profile(plan, name, *dimensions))
            (plan.artifacts / "report.json").write_text(json.dumps(reports, ensure_ascii=False, indent=2) + "\n")
            print(f"Verified {name} through the production screenshot transport.", flush=True)


if __name__ == "__main__":
    main()
