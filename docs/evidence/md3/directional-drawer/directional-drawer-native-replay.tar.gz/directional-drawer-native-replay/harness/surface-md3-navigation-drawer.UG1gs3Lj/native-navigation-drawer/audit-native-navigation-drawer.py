#!/usr/bin/env python3
"""Recheck the saved native Drawer PNGs and actual AX receipts."""

import argparse
from collections import Counter
import json
from pathlib import Path
import runpy


HERE = Path(__file__).resolve().parent
RUN = runpy.run_path(str(HERE / "verify-native-navigation-drawer.py"))
require = RUN["require"]
OPEN_STAGES = RUN["OPEN_STAGES"]
BASE_STAGES = (OPEN_STAGES - {"wheel-bottom", "reopen-scrim"}) | {
    "closed", "selected", "escaped", "button-closed",
}


def check_frame(folder, frame, profile):
    (width, height), dark, rtl, scale = profile
    require((frame["width"], frame["height"]) == (width, height)
            and (frame["dark"], frame["rtl"], frame["text_scale"]) == (dark, rtl, scale),
            "Viewport, theme, direction or scale changed")
    RUN["read_png"](folder, frame)
    stage = frame["stage"]
    counts = Counter(cli_pngs=1)
    require(frame["opened"] is (stage in OPEN_STAGES), "Drawer visibility differs")
    expected_page = RUN["HOME"] if stage in {"closed", "opened", "skip-disabled", "long-label",
                                            "wheel-bottom", "last-focus"} else RUN["SETTINGS"]
    require(frame["page"] == expected_page, "Drawer did not keep its controlled page")
    actions = [] if expected_page == RUN["HOME"] else [RUN["SETTINGS"]]
    if stage in {"button-closed", "reopen-scrim", "scrim-closed"}:
        actions.append(RUN["CLOSE"])
    require(frame["trace"] == actions, "A press was duplicated or reached the background")
    if not frame["opened"]:
        require(frame["focus"] == RUN["OPEN"], "Drawer did not restore focus to its opener")
    else:
        require(frame["scrim"][3] == 82 and frame["panel"]["width"] == min(360., width)
                and frame["panel"]["height"] == height
                and frame["dialog"]["modal"] and frame["navigation"]["role"] == "Navigation",
                "Drawer bounds, scrim or semantic scope differs")
        rows = list(frame["rows"].values())
        require(all(row["target"]["height"] >= 56. and row["target"]["width"] >= 48.
                    and row["icon"]["width"] == row["icon"]["height"] == 24. for row in rows),
                "A destination is smaller than its minimum")
        counts.update(open_drawers=1, row_geometry=len(rows))
        if stage == "long-label":
            paint = frame["report_paint"]
            points = RUN["sample_points"](paint["rect"])
            pixels = RUN["pixels_for"](folder / frame["file"], frame, points)
            found = sum(RUN["color_matches"](pixels[point], paint["color"], 24) for point in points)
            require(found == frame["report_glyph_pixels"] > 25 and paint["style"]["font_size"] == 14. * scale,
                    "The saved long CJK raster lost text")
            if scale == 2.:
                require(paint["rect"]["height"] == 80., "The compact CJK label did not fit on two lines")
            counts.update(long_cjk_images=1)
        if stage == "wheel-bottom":
            require(frame["scroll"]["at_bottom"] and frame["scroll"]["offset"][1] > 0.
                    and frame["rows"][RUN["SETTINGS"]]["fully_visible"], "Inner scroll did not reveal the end")
            counts.update(wheel_bottom=1)
    if "macos" in frame:
        items = frame["macos"]["controls"]
        dialogs = [c for c in items if c["subrole"] == "AXDialog" and c["modal"] is True]
        navigations = [c for c in items if c["subrole"] == "AXLandmarkNavigation"]
        require(len(dialogs) == len(navigations) == int(frame["opened"]), "The AppKit modal scope differs")
        name = RUN["NAMES"][frame["focus"]]
        focused = [c for c in items if c["name"] == name and c["role"] == "AXButton"]
        require(len(focused) == 1 and (focused[0]["focus_attr"] or focused[0]["focused"])
                and focused[0]["actions"].count("AXPress") == 1, "Public button, focus or press differs")
        counts.update(os_ax_checks=1, os_ax_modal=len(dialogs), os_ax_focused_element=int(focused[0]["focused"]))
    return counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    report = json.loads((args.folder / "report.json").read_text())
    require(not report["errors"] and set(report["runs"]) == set(RUN["PROFILES"]), "Incomplete Drawer matrix")
    total = Counter()
    for name, profile in RUN["PROFILES"].items():
        wide = profile[0][0] == 960
        stages = BASE_STAGES | ({"reopen-scrim", "scrim-closed"} if wide else {"wheel-bottom"})
        frames = [frame for frame in report["frames"] if frame["file"].startswith(name + "-")]
        require(len(frames) == len(stages) and {frame["stage"] for frame in frames} == stages,
                f"A Drawer checklist step is missing in {name}")
        headers = [frame["header"] for frame in frames if frame["opened"]]
        require(all(header == headers[0] for header in headers), "The header changed as the list scrolled")
        for frame in frames:
            total.update(check_frame(args.folder, frame, profile))
        if wide:
            base, panel = frames[0:2]
            probes = [tuple(sample["point"]) for sample in panel["scrim_samples"]]
            before = RUN["pixels_for"](args.folder / base["file"], base, probes)
            after = RUN["pixels_for"](args.folder / panel["file"], panel, probes)
            require(all(before[point] != after[point] for point in probes), "The scrim did not darken the page")
            total.update(scrim_pixels=len(probes))
    mirror = report["runs"]["compact-dark-rtl-2x"]["mcp"]
    require((args.folder / mirror["cli"]).read_bytes() == RUN["read_png"](args.folder, mirror), "CLI/MCP differs")
    require(total["cli_pngs"] == 46 and total["os_ax_checks"] == 34, "A PNG or AX query is missing")
    print(json.dumps({"renderer": "Apple M1 Max Metal", **total, "matching_mcp": mirror}, indent=2))


if __name__ == "__main__":
    main()
