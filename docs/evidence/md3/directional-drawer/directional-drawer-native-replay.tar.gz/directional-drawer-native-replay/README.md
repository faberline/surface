# Reproduce the Directional Navigation Drawer on macOS

Restore the exact directional drawer source from the evidence entry.
Run from an Accessibility-authorized local terminal with an active
graphical login on a Mac with an Apple M1 Max Metal adapter. Install
Xcode Command Line Tools, Python 3, Rust and the Surface `cap` command.

```sh
sh build-and-run.sh /absolute/path/to/restored/directional-drawer/source
```

The script creates its build and capture inputs under `/tmp`. It applies
the private QA overlay, builds the Gallery and Surface DevTools, and runs
the original fixture with `--verify-os-ax`. The Gallery captures real
Metal frames through `Page.screenshot` and reads public AppKit focus,
modal scope and available actions. The dark 320 × 240 dp capture uses
the MCP tool as well.

Use `--prepare-only` before the source path to check the archive, its
original scripts, and the 17 private QA input hashes and to load both
entry points. The full replay captures 46 PNGs and performs 34 public
AppKit reads. The audit checks the entire footprint, scroll path, selection
and focus restoration.
