#!/bin/sh
set -eu

prepare_only=false
if [ "${1:-}" = --prepare-only ]; then
    prepare_only=true
    shift
fi
if [ "$#" -ne 1 ]; then
    printf '%s\n' 'Usage: sh build-and-run.sh [--prepare-only] /path/to/verified/source' >&2
    exit 2
fi

bundle=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
source_path=$(CDPATH='' cd -- "$1" && pwd)
output=$(mktemp -d /tmp/surface-md3-directional-drawer-replay.XXXXXXXX)
runner="$output/harness/surface-md3-navigation-drawer.UG1gs3Lj/native-navigation-drawer"
workspace="$runner/qa-verified-tokens"
printf 'Native replay output %s\n' "$output"
export PYTHONDONTWRITEBYTECODE=1
(cd "$bundle" && shasum -a 256 -c harness.sha256 && shasum -a 256 -c original-runner.sha256)
(cd "$source_path" && shasum -a 256 -c "$bundle/product.sha256")
python3 "$bundle/check-qa-inputs.py" "$source_path" "$bundle/native-qa-inputs.json" production
cp -R "$bundle/harness" "$output/harness"
mkdir -p "$workspace"
rsync -a --exclude='/.git' --exclude='/target' --exclude='/artifacts' "$source_path/" "$workspace/"
gzip -dc "$bundle/native-qa.patch.gz" > "$output/private-qa.patch"
(
    cd "$workspace"
    git apply --check "$output/private-qa.patch"
    git apply "$output/private-qa.patch"
)
python3 "$bundle/check-qa-inputs.py" "$workspace" "$bundle/native-qa-inputs.json" qa
python3 "$runner/verify-native-navigation-drawer.py" --help > "$output/runner-help.txt"
python3 "$runner/audit-native-navigation-drawer.py" --help > "$output/audit-help.txt"
if [ "$prepare_only" = true ]; then
    printf '%s\n' 'Verified source inputs, private QA overlay, and both original entry points.'
    exit 0
fi

export CARGO_BUILD_JOBS=2 CARGO_PROFILE_DEV_DEBUG=0 CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/tmp/cargo-target/surface-${output##*/}}"
(
    cd "$workspace"
    cap cargo build --locked -p surface-material-gallery \
        --features surface-material-gallery/devtools,surface-platform/macos-accessibility \
        --example fab_menu_native -p surface-devtools --bin surface-devtools
) > "$output/native-build.log" 2>&1
mkdir -p "$runner/binaries/examples"
cp "$CARGO_TARGET_DIR/debug/surface-devtools" "$runner/binaries/surface-devtools"
cp "$CARGO_TARGET_DIR/debug/examples/fab_menu_native" "$runner/binaries/examples/fab_menu_native"
"$runner/binaries/examples/fab_menu_native" --palette > "$output/palette.json"
python3 "$runner/verify-native-navigation-drawer.py" \
    --artifacts "$output/captures" --verify-os-ax > "$output/native-run.log" 2>&1
python3 "$runner/audit-native-navigation-drawer.py" "$output/captures" > "$output/native-audit.json"
tail -4 "$output/native-run.log"
